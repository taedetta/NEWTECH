// Fix the broken double-onclick line 8889
// Current state: two onclick attributes concatenated, both broken
// Fix: replace the broken section with a correct onclick

const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

console.log('Line 8889 length:', targetLine.length);

// The correct onclick value for the HTML file.
// Strategy: use single-quoted HTML attribute so JS double-quotes are safe,
// and for the replace() function, use &apos; for the replacement
// (since the replacement only needs to produce valid JS string, not actual quote chars).

// BUT WAIT: we need the replace to actually produce a valid quote in JS.
// If we use &apos; in the replacement, JS sees the 5 characters &, a, p, o, s, ;
// and uses those as the replacement string. That's not what we want!

// We need the replacement string to be a double-quote character.
// In JS string literal: '"'  (one double-quote char)
// In HTML double-quoted attr: we write: "  (one double-quote char)
// BUT: in the onclick attribute, we need to open with " and close with "
// So the replacement string must contain a double-quote character somehow.

// Option 1: Use a variable or function to return the quote character
// Option 2: Build the string differently to avoid inline replacement
// Option 3: Use template literals with careful escaping

// Let me look at what the ORIGINAL correct code was supposed to be.
// The editRoleBtn creates a button with onclick that calls openRoleChangeModal.
// openRoleChangeModal(name) needs a string for the name parameter.
// The replace(/'/g, something) should replace ' with the string value of a quote.

// If we use replace(/'/g, '"') - JS sees replacement as a literal " character
// In HTML double-quoted attr: onclick="...replace(/'/g,'"')"
// The '"' in the HTML attr: first " opens, then ' is literal, then " closes
// So JS sees: replace(/'/g, '"') which means: replace ' with " (the quote char)
// CORRECT!

// But the attr is: onclick="...'"...'"
// After replace(/'/g, '"') the string becomes: onclick="...'"."..."
// The " after replacement is a literal " in the string being built
// Then we have: + '"') - this adds a " to the string
// So the onclick value will have literal " characters in it
// That's fine - the JS being built is: onclick="...replace(/'/g,'&#34;')..."
// Wait no - the JS code is built by template, not executed
// The template produces JS source code as a string

// Let me re-trace carefully what happens when the browser parses:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'"') + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// Browser parses the HTML attribute value:
// - onclick="..." starts the attr
// - Inside the attr: openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'"') + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// - JS parsing: openRoleChangeModal is a function call with args:
//   - ' + u.id + ' → JS expression concatenating string literal ' with u.id
//   - ',' → string
//   - escHtml(u.name).replace(/'/g,'"') → escHtml returns string, .replace replaces ' with '
//   - etc.
// The replace(/'/g,'"') → JS sees regex /'/g and replacement is a string with one char: "
// So escHtml("O'Brien") → "O'Brien" → .replace → "O" + " + "ren" → "O" + " + "ren" → "O" + "ren" = "Obrian"
// WRONG! We replace ' with " → O'Brien becomes Obrian

// OK so replace(/'/g,'"') replaces ' with " which corrupts the name.
// We need to replace ' with the literal string '\"
// i.e., backslash followed by quote, in the JS string that gets passed to openRoleChangeModal.
// So openRoleChangeModal gets "O\\'Brien" as a string argument (with backslash in it).

// In the HTML onclick attr, we need: .replace(/'/g, '\\\\'')
// That is: replace /'/g with the JS string that is: backslash + quote
// In HTML double-quoted attr: we need: \\'  (backslash backslash quote?)
// Let me think about what the HTML attr should contain...

// The HTML attr value (parsed by browser as JS source):
// .replace(/'/g, '\\\\'')
// When JS parses this: .replace is called with regex /'/g and replacement string \\'
// The replacement string is two chars: \backslash and 'quote
// So "O'Brien".replace(/'/g, '\\') → "O\\'Brien"  ← CORRECT!

// So in the HTML attribute, we need the JS source code: .replace(/'/g, '\\')
// That is: . r e p l a c e ( / ' / g , space ' \backslash ' )
// As HTML attribute value: onclick="...replace(/'/g,'\\')..."
// In HTML double-quoted attr: ' is literal, \\ is backslash-backslash
// So the HTML attr contains: replace(/'/g,'\\')
// Browser parses: JS sees ' (open string), \\ (escaped backslash = \backslash), ' (close string)
// JS gets the replacement string: \backslash
// CORRECT!

// But wait, we want the replacement to be a backslash followed by a QUOTE character.
// \\' in JS means: \\ (one backslash) + ' (quote) = backslash + quote = 2 chars
// Yes! That's what we want.

// In the HTML attr: replace(/'/g,'\\') where ' is literal, \\ is backslash-backslash
// Browser parses JS: replacement string = '\\' = one backslash + one quote = 2 chars
// "O'Brien".replace(/'/g, '\\') → "O\\'Brien"  ← CORRECT!

// So the correct onclick should use: .replace(/'/g, '\\')
// That's: .replace(/'/g, '\\') in the HTML attr
// Which is: . r e p l a c e ( / ' / g , space ' \backslash \backslash ' )
// Wait, in HTML double-quoted attr: '\\' = backslash-backslash? Let me be careful.

// In HTML double-quoted attribute value:
// - " opens the attr
// - Inside, we have JS code to be executed
// - \\ in the HTML attr = one backslash in the JS source
// - ' in the HTML attr = literal apostrophe in JS source (since attr uses ")
// - So in HTML attr we write: '\\'  (single-quote, backslash, backslash, single-quote)
// When JS parses: ' opens string, \\ = one backslash, ' closes string → replacement = one backslash
// WRONG! We want TWO chars: backslash + quote.

// Let me write it more clearly:
// We want JS replacement string = backslash + quote = "\" (2 chars)
// In JS string literal: '"\\"'  (open quote, backslash, quote, close quote)
// When JS evaluates this string literal: it gets the 2-char string "\"
// So in the HTML attr, we need the JS code: '"\\"' which means:
// open quote, escaped quote, escaped backslash, close quote

// In HTML double-quoted attr: we write: '"\\"'
// That's: double-quote, single-quote, backslash, backslash, double-quote, single-quote
// Wait: '"\\"' in HTML attr → browser parses as: " opens, ' is literal, \\ is backslash, " closes attr?
// NO! The attr uses " as delimiter, so the attr value is: '"\\"'
// The HTML parsing: the attr is enclosed in " ... "
// Inside the "": ' = apostrophe (literal char), \\ = backslash (escaped in HTML = \backslash)
// So the attr value is: 7 chars: " ' \backslash \backslash " ' "
// When JS parses the attribute value: it sees the JS code '"\\"' which is:
// " = open string literal, ' = literal apostrophe, \\ = escaped backslash = one backslash, " = close string
// So JS string = one quote char = '

// That's only ONE character! We need TWO (backslash + quote).
// So in the HTML attr: we need a replacement string that JS parses as 2 chars: \b a c k s l a s h, q u o t e

// In JS string literal: "\\\""
// \\ = one backslash, \" = one quote → 2 chars total
// So JS code: .replace(/'/g, "\\\"") means: replace ' with the 2-char string \"
// In HTML attr, we need: "\\\""
// In HTML double-quoted attr: we write: "\\\""
// That's: backslash, backslash, quote (wait, no...)

// In HTML attr with " delimiter:
// " opens attr
// \backslash \backslash = \\ in the attr → JS sees one backslash
// \" in the attr → JS sees one quote
// " closes attr
// So the JS code in the attr is: "\\\""
// JS parses: " (open), \\ (escaped backslash = one backslash), \" (escaped quote = one quote), " (close)
// JS replacement string = "\" (backslash + quote, 2 chars) ← CORRECT!

// So the HTML attr onclick value should contain:
// replace(/'/g, "\\\"")
// That is: replace ( / ' / g , space " \backslash \backslash \" " )
// In HTML double-quoted attr: we write it as-is (since the attr uses " as delimiter):
// onclick="...replace(/'/g,\"\\\\\\\"\")..."

// In our JS script that writes to the file, we need to escape for the JS string:
// We want the HTML file to contain: ...replace(/'/g,"\\\")...
// In our JS string literal, we write: "...replace(/'/g,\\\"\\\\\\\")..."
// Let me count the escapes carefully...

// HTML file should have: replace(/'/g,"\\\")
// Breaking it down:
// - r e p l a c e ( / ' / g , " ) = 16 chars + 1 = 17 (backslash in replace)
// - \backslash \backslash = two backslashes = 2 chars
// - " = one quote = 1 char
// Total: 17 + 2 + 1 = 20 chars in the HTML file

// In our JS string that WRITES this to file:
// Every " needs to be escaped as \"
// Every \backslash needs to be escaped as \\
// So:
// replace(/'/g, → stays as-is (no special chars)
// " → \" in JS string
// \\ → \\\\ in JS string
// \") → \\\" in JS string

// So in our JS string: "replace(/'/g,\\\"\\\\\\\")"
// That's: r e p l a c e ( / ' / g , \backslash \backslash \backslash dquote \backslash \backslash \backslash \backslash \backslash \backslash dquote

// Let me just construct it piece by piece:
const part1 = 'replace(/' + "'" + '/g,' + '"' + '\\\\' + '"' + ')';
console.log('Replacement part:', part1);
console.log('JSON:', JSON.stringify(part1));

// That gives us: replace(/'/g,"\\")  - but we want replace(/'/g,"\\\")
// I need THREE backslashes in the replacement, not two!

// Now build the full onclick:
const dq = String.fromCharCode(34);  // "
const sq = String.fromCharCode(39);  // '

// The replacement string in the HTML file should be: \"\\\"
const replReplacement = String.fromCharCode(92, 92, 92, 34); // \\\" in the file (backslash, backslash, backslash, quote)
console.log('Replacement string:', JSON.stringify(replReplacement));

// Build the replace() part: replace(/'/g, "\\\")
const part2 = "replace(/'/g,'" + replReplacement + "')";
console.log('part2:', JSON.stringify(part2));

// Now build the onclick using template literal to avoid quote issues
// The JS code we want in the HTML file:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"

const onclickAttr = `onclick="${sq} + u.id + ${sq},${sq} + escHtml(u.name).${part2} + ${sq},${sq} + u.role + ${sq},${sq} + (!!u.is_instructor ? ${sq}true${sq} : ${sq}false${sq})${sq})"`;
console.log('onclickAttr:', JSON.stringify(onclickAttr));

console.log('---');
console.log('Full onclick:', onclickAttr);
console.log('JSON:', JSON.stringify(onclickAttr));

// Verify the replacement part
const repStart = onclickAttr.indexOf('replace');
console.log('Replacement section:', onclickAttr.substring(repStart, repStart + 40));
console.log('Replacement JSON:', JSON.stringify(onclickAttr.substring(repStart, repStart + 40)));

// Now find and replace in the target line
const firstOnclick = targetLine.indexOf('onclick="');
const btnIdx = targetLine.indexOf('&#9998;');
const onclickEndTag = targetLine.lastIndexOf('">', btnIdx);

console.log('---');
console.log('First onclick at:', firstOnclick);
console.log('onclick end tag at:', onclickEndTag);
console.log('Target end substring:', JSON.stringify(targetLine.substring(onclickEndTag - 20, onclickEndTag + 5)));

const before = targetLine.substring(0, firstOnclick);
const after = targetLine.substring(onclickEndTag + 2);

const newLine = before + onclickAttr + after;

console.log('---');
console.log('New line preview (onclick area):');
const newOnclickStart = newLine.indexOf('onclick');
console.log(JSON.stringify(newLine.substring(newOnclickStart, newOnclickStart + 250)));

lines[8888] = newLine;
fs.writeFileSync('./public/app.html', lines.join('\n'));
console.log('File written!');