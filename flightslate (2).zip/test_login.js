const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=f1554f1b-a321-4352-80e1-2e48e4f4d7bd');
  const page = await browser.newPage();

  // Navigate to app
  await page.goto('https://www.newtechaviation.com/app');
  await page.waitForTimeout(2000);

  const url = page.url();
  console.log('Current URL:', url);

  const loginForm = await page.$('#login-form');
  console.log('Login form found:', !!loginForm);

  // Try to login with test account
  await page.fill('#login-email', 'polsia-test-1779153834994@test.com');
  await page.fill('#login-password', 'testpassword123');
  await page.click('#login-form button[type="submit"]');

  await page.waitForTimeout(3000);

  const afterUrl = page.url();
  console.log('URL after login attempt:', afterUrl);

  const errorEl = await page.$('#login-error');
  const errorText = errorEl ? await errorEl.textContent() : 'no error visible';
  console.log('Login error:', errorText.trim() || 'none');

  const appScreen = await page.$('#app-screen:not(.hidden)');
  console.log('App screen visible (login success):', !!appScreen);

  await browser.close();
  process.exit(0);
})();