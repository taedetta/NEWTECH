const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// The current line has:
// onclick='openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,"&apos;") + ',' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')'">...
// The issue: + ' + '  creates a string literal '  which puts ) outside quotes

// Correct fix: use double-quoted HTML attribute so JS single quotes work
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,&quot;&apos;&quot;) + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// But &quot; in the file -> &quot; in template -> " in HTML attr -> \" in JS -> "

// The replacement needs &quot; for the JS double quotes in the replace pattern
// In the file: replace(/'/g,"&quot;&apos;&quot;)  -> in template: replace(/'/g,"&quot;&apos;&quot;)  -> in HTML: replace(/'/g,"&quot;&apos;&quot;)  -> in JS: replace(/'/g,"&apos;")

// Actually simpler: use a helper in the onclick
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'&apos;') + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"

console.log('Current onclick section:', targetLine.substring(targetLine.indexOf('onclick'), targetLine.indexOf('onclick') + 200));

// The fix: change onclick=' to onclick=" and remove the extra ' + ' before ()
// Also change the replace pattern to use single quotes around &apos;

const brokenOnclick = "onclick='openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\"&apos;\") + ',' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')'";
const correctOnclick = 'onclick="openRoleChangeModal(\u0027 + u.id + \u0027,\u0027 + escHtml(u.name).replace(/\u0027/g,\u0027&amp;apos;\u0027) + \u0027,\u0027 + u.role + \u0027,(\u0027 + (!!u.is_instructor ? \u0027true\u0027 : \u0027false\u0027) + \u0027))"';

if (targetLine.includes(brokenOnclick)) {
  console.log('Found exact broken pattern!');
  const newLine = targetLine.replace(brokenOnclick, correctOnclick);
  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('Updated!');
} else {
  console.log('Exact pattern not found, trying substring search...');
  // Just replace the specific problematic part
  const onclickStart = targetLine.indexOf("onclick='");
  const quoteEnd = targetLine.indexOf('">', onclickStart);
  if (onclickStart >= 0 && quoteEnd >= 0) {
    console.log('Found onclick at', onclickStart, 'ends at', quoteEnd);
    const before = targetLine.substring(0, onclickStart);
    const after = targetLine.substring(quoteEnd + 2);
    // Build correct onclick
    const correct = 'onclick="openRoleChangeModal(\u0027 + u.id + \u0027,\u0027 + escHtml(u.name).replace(/\u0027/g,\u0027&amp;apos;\u0027) + \u0027,\u0027 + u.role + \u0027,(\u0027 + (!!u.is_instructor ? \u0027true\u0027 : \u0027false\u0027) + \u0027))"';
    const newLine = before + correct + after;
    lines[8888] = newLine;
    fs.writeFileSync('./public/app.html', lines.join('\n'));
    console.log('Updated via substring replacement!');
  }
}