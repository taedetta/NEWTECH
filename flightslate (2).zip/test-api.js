'use strict';
// Test hours-audit endpoint
const https = require('https');

const APP_HOST = 'new-tech-aviation.polsia.app';

function makeRequest(path) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, `https://${APP_HOST}`);
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'User-Agent': 'Node.js verification script',
        'Accept': 'application/json',
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        console.log(`[${res.statusCode}] ${path}`);
        console.log('Headers:', JSON.stringify(res.headers, null, 2));
        if (body.length > 0) {
          try {
            const json = JSON.parse(body);
            console.log('Body:', JSON.stringify(json, null, 2));
          } catch {
            console.log('Body (raw):', body.substring(0, 500));
          }
        }
        resolve(res.statusCode);
      });
    });
    req.on('error', e => { console.error('Request error:', e.message); reject(e); });
    req.setTimeout(10000, () => { req.destroy(); console.log('Request timed out'); reject(new Error('timeout')); });
    req.end();
  });
}

async function main() {
  console.log('=== Testing hours-audit API ===\n');
  try {
    await makeRequest('/health');
  } catch(e) {}
  console.log('\n---\n');
  try {
    await makeRequest('/api/hours-audit');
  } catch(e) {}
  console.log('\n---\n');
  try {
    await makeRequest('/api/auth/me');
  } catch(e) {}
}

main().catch(e => console.error(e.message));