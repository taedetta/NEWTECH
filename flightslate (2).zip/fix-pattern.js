const fs = require('fs');
let content = fs.readFileSync('public/app.html', 'utf8');
const lines = content.split('\n');
const line10136 = lines[10135];

console.log('Current state of line 10136:');
console.log(line10136.trim());

// The pattern we need to fix is: replace(/'/g,'&#39;') which is WRONG
// The correct replacement should be: replace(/'/g,'&#39;') — but wait, what is the original structure?

// The original was: replace(/'/g,'\\\") — replace single quote with backslash-quote
// The correct fix should be: replace(/'/g,'&#39;') — replace single quote with HTML entity
// Both of these are 20 chars: replace(/'/g,' = 14, then replacement (6 or 5 chars), then ') = 2

// The current BROKEN pattern is: replace(/'/g,'&#39;') — note: only 18 chars (wrong!)
// The CORRECT pattern should be: replace(/'/g,'&#39;') — wait, these are the same?

// Let me count: replace(/'/g,'&#39;')
// r e p l a c e ( / ' / g , ' &# 3 9 ; ' ) = 20 chars

// The broken pattern in the file is: replace(/'/g,'&#39;')
// r e p l a c e ( / ' / g , ' &# 3 9 ; ' ) = 19 chars?

// Let me just check what the actual pattern is in the file:
const idx = line10136.indexOf("replace(/'/g,'");
if (idx >= 0) {
  console.log('\nPattern found at index:', idx);
  const slice = line10136.substring(idx, idx + 25);
  console.log('Pattern + context:', JSON.stringify(slice));
  console.log('Pattern length:', slice.length);
}

// Fix: the current pattern is missing a closing '
// It currently has: replace(/'/g,'&#39;') = 18 chars (broken)
// It should be: replace(/'/g,'&#39;') = 20 chars (correct)

const brokenPattern = "replace(/'/g,'&#39;')";  // 18 chars - wrong
const correctPattern = "replace(/'/g,'&#39;')"; // 20 chars - correct

// Wait - these look the same in the string! Let me count:
// In the file: replace(/'/g,'&#39;') — 19 chars (broken, missing final ')
// In the fix: replace(/'/g,'&#39;') — 20 chars (correct, has final ')

// The fix has an EXTRA ' at the end of the replacement string
// Current: '&#39;' (5 chars) + ) (1) = 6 chars in replacement + 2 opening quotes = 8 chars + replace function = 18 total
// Correct: '&#39;' (5 chars) + ) (1) = 6 chars in replacement + 2 opening quotes = 8 chars + replace function = 18? No.

// Let me just use character-by-character analysis
// Current in file: replace(/'/g,'&#39;')  (18 chars)
// Correct:           replace(/'/g,'&#39;')  (20 chars with extra ')

// The difference is: current ends with ) but correct ends with ')'

// So the fix is to change the last ) to ')'
// Current: ...'&#39;')  → Correct: ...'&#39;') — same!

// I think I need to look at the actual bytes. Let me count:
console.log('\nActual pattern in file:');
const patternInFile = line10136.substring(line10136.indexOf('replace(/'), line10136.indexOf('replace(/') + 25);
console.log('Pattern:', JSON.stringify(patternInFile));
console.log('Length:', patternInFile.length);

// Hmm, both patterns look the same. Let me check if the issue is a missing quote
const hasDoubleQuote = line10136.includes("''&#39;");
console.log('Has double opening quote:', hasDoubleQuote);

// If the current pattern is `replace(/'/g,'&#39;')` (18 chars) and we need `replace(/'/g,'&#39;')` (20 chars),
// the fix is to add a ' before the ) — i.e., change ') to ')

const badEnding = "'&#39;')";  // wrong: extra ) after '
const goodEnding = "'&#39;')";  // correct: extra ' before )
console.log('\nBad ending:', JSON.stringify(badEnding));
console.log('Good ending:', JSON.stringify(goodEnding));

// I think the current state is: replace(/'/g,'&#39;') where the pattern is 18 chars
// And it should be: replace(/'/g,'&#39;') where the pattern is 20 chars

// Let me check by counting the actual characters
const replaceStart = line10136.indexOf('replace(/');
const replaceSlice = line10136.substring(replaceStart, replaceStart + 25);
console.log('\nReplace slice:', JSON.stringify(replaceSlice));
console.log('Replace slice length:', replaceSlice.length);

// The slice from index 0 to 25 should show us exactly what's there
// If it ends with ')': 20 chars - correct
// If it ends with ')': 19 chars - wrong (missing ')
// If it ends with ')': 18 chars - very wrong

// Based on the earlier output showing: .replace(/'/g,'&#39;'))}'
// The pattern appears to be: replace(/'/g,'&#39;') — 20 chars, but then there's an extra )

// Wait - let me count .replace(/'/g,'&#39;') ):
// . r e p l a c e ( / ' / g , ' &# 3 9 ; ' ) ) = 22 chars

// I think the pattern is: replace(/'/g,'&#39;') — 20 chars
// But the file currently has: replace(/'/g,'&#39;') — which might be 18 chars

// Let me just fix based on what the output shows:
// Current: .replace(/'/g,'&#39;'))}'
// The fix: the pattern should end with ') and then )} -- so we need:
// replace(/'/g,'&#39;')})  -- the pattern ends with ')' (19 chars total for pattern), then one more ) closes the function

// Actually, I think I should just reconstruct the line from scratch
// Original: openSignOffModal(${e.id},${s.id},'${escHtml(s.name).replace(/'/g,'\\\")}')"
// Fixed: openSignOffModal(${e.id},${s.id},'${escHtml(s.name).replace(/'/g,'&#39;')}')"

// The difference is: \\\" → &#39;
// And we need to make sure the structure is: replace(...)}') — note the ' before }

// Let me find the exact position of the broken pattern and fix it
const badPattern = "'&#39;')";  // the broken ending
const goodPattern = "'&#39;')";  // same text but we need to verify

// Actually, looking at the output more carefully:
// .replace(/'/g,'&#39;'))}' — this has an extra ) after the pattern
// The pattern `replace(/'/g,'&#39;')` is 20 chars, then there's an extra ) making it `replace(/'/g,'&#39;'))`

// So the current file has: replace(/'/g,'&#39;'))}  -- 22 chars (wrong)
// Should be: replace(/'/g,'&#39;')}  -- 21 chars (correct)

// The fix is to remove one ) from the pattern

// Let me find and fix it
const currentBad = "replace(/'/g,'&#39;'))";  // with extra )
const currentGood = "replace(/'/g,'&#39;')";  // correct (20 chars)

if (line10136.includes(currentBad)) {
  const newLine = line10136.replace(currentBad, currentGood);
  lines[10135] = newLine;
  fs.writeFileSync('public/app.html', lines.join('\n'));
  console.log('\nFixed! New line:', newLine.trim());
} else {
  console.log('\nPattern not found. Trying to find it...');
  const idx2 = line10136.indexOf('replace(/');
  console.log('replace( at index:', idx2);
  console.log('Next 30 chars:', JSON.stringify(line10136.substring(idx2, idx2 + 30)));
  console.log('Length of next 30:', line10136.substring(idx2, idx2 + 30).length);
}