// Push ALL code from workspace to taedetta/NEWTECH using curl (avoids Node.js DNS issue)
const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PAT = 'REDACTED';
const OWNER = 'taedetta';
const REPO = 'NEWTECH';
const BRANCH = 'main';

function curl(method, apiPath, data) {
  const url = `https://api.github.com${apiPath}`;
  let cmd = `curl -s -X ${method} -H "Authorization: Bearer ${PAT}" -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28"`;

  if (data) {
    const json = JSON.stringify(data);
    cmd += ` -H "Content-Type: application/json" -d '${json.replace(/'/g, "'\\''")}'`;
  }

  cmd += ` -L "${url}"`;
  const out = execSync(cmd, { timeout: 30000, encoding: 'utf8' });
  try { return JSON.parse(out); }
  catch { return out; }
}

async function getRef() {
  const r = curl('GET', `/repos/${OWNER}/${REPO}/git/ref/heads/${BRANCH}`);
  return r.object?.sha;
}

function getAllFiles(dir, baseDir) {
  const files = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const skipDirs = ['.git', 'node_modules', '.claude', '.tmp', 'todos', 'shell-snapshots', 'session-env'];
      if (entry.isDirectory()) {
        if (!skipDirs.includes(entry.name)) {
          files.push(...getAllFiles(fullPath, baseDir));
        }
      } else {
        const relativePath = path.relative(baseDir, fullPath).replace(/\\/g, '/');
        files.push({ path: relativePath, fullPath });
      }
    }
  } catch (e) { /* skip */ }
  return files;
}

async function uploadFile(filePath, contentBase64) {
  // Check if file exists
  let existingSha = null;
  const existing = curl('GET', `/repos/${OWNER}/${REPO}/contents/${encodeURIComponent(filePath)}?ref=${BRANCH}`);
  if (existing && existing.sha) existingSha = existing.sha;

  const body = {
    message: `Add ${filePath}`,
    content: contentBase64,
  };
  if (existingSha) body.sha = existingSha;

  const r = curl('PUT', `/repos/${OWNER}/${REPO}/contents/${encodeURIComponent(filePath)}`, body);
  return r;
}

async function main() {
  console.log('=== FlightSlate Full Migration to taedetta/NEWTECH ===\n');

  // Get base SHA
  console.log('Getting current main branch SHA...');
  const baseCommitSha = await getRef();
  if (!baseCommitSha) { console.error('Failed to get ref'); return; }
  console.log('Base commit SHA:', baseCommitSha);

  // Get all files
  const files = getAllFiles('.', '.');
  console.log(`Found ${files.length} files to upload\n`);

  // Filter out binary files
  const textExts = ['.js', '.json', '.html', '.css', '.md', '.sql', '.yml', '.yaml', '.toml', '.txt', '.sh', '.mjs'];
  const skipExts = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico', '.pdf', '.zip', '.lock'];

  const toUpload = files.filter(f => {
    const ext = path.extname(f.path);
    if (skipExts.includes(ext)) return false;
    // Upload all text files
    return true;
  });

  console.log(`Uploading ${toUpload.length} text files (skipping binary)...\n`);

  let uploaded = 0, errors = 0;
  for (const file of toUpload) {
    try {
      const content = fs.readFileSync(file.fullPath);
      const base64 = content.toString('base64');
      const r = await uploadFile(file.path, base64);
      if (r && (r.content || r.sha)) {
        uploaded++;
        if (uploaded % 10 === 0) process.stdout.write(`Uploaded ${uploaded}/${toUpload.length}\n`);
      } else {
        console.log(`  ERR ${file.path}:`, JSON.stringify(r).substring(0, 100));
        errors++;
      }
    } catch (err) {
      console.log(`  ERR ${file.path}: ${err.message}`);
      errors++;
    }
  }

  console.log(`\n=== Done ===`);
  console.log(`Uploaded: ${uploaded}`);
  console.log(`Errors: ${errors}`);
}

main().catch(err => { console.error('Fatal:', err.message); process.exit(1); });