const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const lines = content.split('\n');

console.log('=== CHECKING FOR BROKEN PATTERNS ===');

// Find all lines with replace(/'/g, ...) patterns
const replacePatterns = [];
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.includes('replace(/')) {
    const idx = line.indexOf('replace(/');
    const slice = line.substring(idx, idx + 30);
    replacePatterns.push({ line: i + 1, text: slice });
  }
}

let hasBroken = false;
for (const p of replacePatterns) {
  const text = p.text;
  // Check if it has &#39; (correct) or \\' (broken) or &apos; (broken)
  if (text.includes('&#39;')) {
    console.log('Line ' + p.line + ' CORRECT: ' + p.text);
  } else if (text.includes("\\'") || text.includes("'\\'")) {
    console.log('Line ' + p.line + ' BROKEN: ' + p.text);
    hasBroken = true;
  } else if (text.includes('&apos;')) {
    console.log('Line ' + p.line + ' BROKEN (&apos;): ' + p.text);
    hasBroken = true;
  } else {
    console.log('Line ' + p.line + ' UNKNOWN: ' + p.text);
  }
}

console.log('');
if (hasBroken) {
  console.log('FAIL: Some patterns still broken');
} else {
  console.log('PASS: All patterns are fixed!');
}