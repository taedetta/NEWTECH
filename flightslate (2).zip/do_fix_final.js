// Fix the broken \\' and \\"  escapes in HTML attribute values
// In HTML double-quoted attributes, \\' and \\" are NOT valid escapes
// Fix: change \" to &quot; and \\'  to ' in the template literal output
// The simplest fix: just change the file to not use escaped quotes in HTML attrs
// Since HTML double-quoted attrs allow ' (single quote) as literal characters,
// and JS single-quoted strings use ' as delimiter, the only broken part is
// the \" in the replace() function which produces \" in the output

const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');

const targetLine = lines[8888];

// The broken line has: .replace(/'/g,"\\'")
// This produces: replace(/'/g,"'") in the template output
// In an HTML double-quoted attr onclick="...", the " in this output ends the attr early
// Fix: change to use &quot; in the replacement so HTML doesn't break
// replace(/'/g,"&quot;")  → in HTML attr becomes &quot; (stays as literal chars)
// When JS parses onclick, it sees the &quot; as 5 chars: &, q, u, o, t, ;
// The JS code replace(/'/g,"&quot;") then does .replace(/'/g, "&quot;") which works

// But even simpler: change the HTML attr to use ' instead of "
// Then the JS " in replace doesn't break HTML
// Let's fix by changing onclick=" to onclick='

let fixedLine = targetLine;

// Change onclick HTML attr from double-quoted to single-quoted
fixedLine = fixedLine.replace('onclick="openRoleChangeModal', "onclick='openRoleChangeModal");

// Fix the closing of the onclick value (was '"' at end, now just end quote)
// The original ends with: ...+ ')'">&#9998;
// The onclick attr needs to end with: ')>...' (single quote for HTML attr)
fixedLine = fixedLine.replace(")'\">", ")'>");

// Now fix the inner escaped quotes in the JS code
// Since HTML attr uses ', the JS " quotes are fine
// But the \\'  patterns (backslash-quote) in the file need to become just '
// because they're inside a single-quoted HTML attr where ' is literal

// In the current broken file, we have \\' (backslash-quote) in places like: '\\''
// These are inside the onclick='...' HTML attr
// In a single-quoted HTML attr, ' is literal, so we don't need to escape it
// But the \\'  appears as literal characters in the file, which breaks when JS parses

// The pattern: '\\'' (backslash, quote, quote) in the file
// This represents: \\' + ' which when JS evaluates the template becomes: '
// But in HTML single-quoted attr: the ' is literal, the \\\\ is literal backslash
// So: onclick='openRoleChangeModal(' + u.id + ',\\'\\'' becomes:
// onclick='openRoleChangeModal(' + u.id + ',\\'\\''
// The \\'  is still broken in JS parsing

// The real fix: in a single-quoted HTML attr, use just ' (no backslash needed)
// So change '\\'' to "'" (just quote)
// Change '\\',' to "','" (just quote-comma-quote)
// Change '\\'' + to "',' + (quote-comma-quote-space-plus)

// Let me be more surgical - the broken parts are specifically:
const brokenParts = [
  ",\\'\\'' + escHtml(u.name)",  // first arg with escaped quotes
  "replace(/'/g,\"\\\\'\")",       // the replace function
  "'\\',' + u.role",              // second arg
];

console.log('Target line:', targetLine.substring(0, 300));

// Direct approach: just replace the specific broken sequences
// The file has: ',\\'\\''  which should be: ','
// The file has: replace(/'/g,"\\\\'")  which should be: replace(/'/g,"'")
// The file has: '\\'\\','  which should be: ','
// The file has: '\\''  which should be: '

// Let me just try a clean replacement for the whole editRoleBtn line
// The correct version:
const correctEditRoleBtn = `var editRoleBtn = isOwner && !isSelf ? ' <button style="background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s" title="Edit user" onmouseover="this.style.color='var(--sky)'" onmouseout="this.style.color='var(--gray-400)'" onclick='openRoleChangeModal(${u.id},"${escHtml(u.name).replace(/'/g,"&apos;")}",${u.role},${!!u.is_instructor})'>&#9998;</button>' : '';`;

console.log('Correct version:', correctEditRoleBtn);

// Check if targetLine contains the broken pattern
if (targetLine.includes("\\'\\''") || targetLine.includes('"\\\\\")')) {
  console.log('Pattern confirmed as broken');
  // Replace the entire line
  lines[8888] = correctEditRoleBtn;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated with correct version');
} else {
  console.log('Pattern not found, checking actual content...');
  console.log('Has backslash-quote:', targetLine.includes("\\'"));
}