// Fix line 8889 - replace the broken double-onclick section
const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const target = lines[8888];

console.log('Line length:', target.length);
console.log('First 150:', JSON.stringify(target.substring(0, 150)));

// The correct onclick (what the HTML file should contain):
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// In JS string: '\\\\\\"' = 3 backslashes + quote

const correctOnclick = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\\\\"') + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log('Correct onclick:', correctOnclick);

// Verify replacement part
const repStart = correctOnclick.indexOf('.replace');
console.log('Replacement:', JSON.stringify(correctOnclick.substring(repStart, repStart + 45)));

// Strategy: find &#9998; then find the SECOND-TO-LAST "> (the one from the first onclick)
// The button's "> is the LAST "> before &#9998;
// The first onclick's "> is the SECOND-TO-LAST

const btnIdx = target.indexOf('&#9998;');
console.log('Button at:', btnIdx);

// Search for "> from btnIdx-2 backwards, find the SECOND occurrence
let searchPos = btnIdx - 1;
let lastFound = -1;
let secondLastFound = -1;
while (searchPos > 0) {
  const found = target.lastIndexOf('">', searchPos);
  if (found < 0) break;
  secondLastFound = lastFound;
  lastFound = found;
  searchPos = found - 1;
}
console.log('Second-last "> at:', secondLastFound, 'last "> at:', lastFound);

if (secondLastFound < 0) {
  console.log('ERROR: not enough "> found');
  process.exit(1);
}

// The second-last "> is the end of the first onclick
const firstOnclickEnd = secondLastFound + 2; // include ">"

console.log('First onclick ends at:', firstOnclickEnd);

// Now find the first onclick=" before this
const firstOnclickStart = target.indexOf('onclick="', 0);
console.log('First onclick starts at:', firstOnclickStart);

if (firstOnclickStart < 0) {
  console.log('ERROR: onclick=" not found');
  process.exit(1);
}

// Construct new line
const before = target.substring(0, firstOnclickStart);
const after = target.substring(firstOnclickEnd);

console.log('Before:', JSON.stringify(before));
console.log('After:', JSON.stringify(after.substring(0, 50)));

const newLine = before + correctOnclick + after;
console.log('---');
const newOnIdx = newLine.indexOf('onclick');
console.log('New onclick area:', JSON.stringify(newLine.substring(newOnIdx, newOnIdx + 250)));

lines[8888] = newLine;
fs.writeFileSync('./public/app.html', lines.join('\n'));
console.log('File written!');