// Fix line 8889 definitively
const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const t = lines[8888];

console.log('Line 8889 length:', t.length);

// Find all positions of "> in the string
console.log('\nAll "> positions:');
let count = 0;
for (let i = 0; i < t.length - 1; i++) {
  if (t[i] === '>' && t[i+1] === '"') {
    console.log('  >" at', i, '-', i+1, 'prev3:', JSON.stringify(t.substring(Math.max(0,i-3),i+1)));
    count++;
    if (count >= 5) { console.log('  ...'); break; }
  }
}

// Find button position
const btnIdx = t.indexOf('&#9998;');
console.log('\nButton at:', btnIdx);

// Find all onclick= positions before button
console.log('\nAll onclick= before button:');
let searchFrom = 0;
while (true) {
  const found = t.indexOf('onclick=', searchFrom);
  if (found < 0 || found >= btnIdx) break;
  console.log('  onclick= at', found, '- prev5:', JSON.stringify(t.substring(Math.max(0,found-5),found+10)));
  searchFrom = found + 1;
}

// Find the closing of the first onclick: find "> right before the second onclick starts
// The second onclick starts at the LAST onclick= before button
let lastOnclickIdx = -1;
searchFrom = 0;
while (true) {
  const found = t.indexOf('onclick=', searchFrom);
  if (found < 0 || found >= btnIdx) break;
  lastOnclickIdx = found;
  searchFrom = found + 1;
}
console.log('\nLast onclick= before button at:', lastOnclickIdx);

// The first onclick ends at the "> that's just BEFORE lastOnclickIdx
// Find the last "> before lastOnclickIdx
let firstOnclickEnd = -1;
for (let i = lastOnclickIdx - 1; i >= 0; i--) {
  if (t[i] === '>' && t[i+1] === '"') {
    firstOnclickEnd = i + 2; // include the "> in what we replace
    break;
  }
}
console.log('First onclick end (with ">) at:', firstOnclickEnd);
if (firstOnclickEnd > 0) {
  console.log('  chars at', firstOnclickEnd-4, '-', firstOnclickEnd+2, ':', JSON.stringify(t.substring(firstOnclickEnd-4, firstOnclickEnd+2)));
}

// Find where the first onclick starts (first onclick= in the line)
const firstOnclickStart = t.indexOf('onclick=');
console.log('First onclick= at:', firstOnclickStart);

// Build the correct replacement onclick
// We want: onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// In the file, the replacement string should be: \\\"  (3 backslashes + quote) = 4 chars
// In JS string: use template literal to avoid quote issues
const sq = String.fromCharCode(39);  // single quote
const correctOnclick = `onclick="openRoleChangeModal(${sq} + u.id + ${sq},${sq} + escHtml(u.name).replace(/${sq}/g,${sq}\\\\\\\"${sq}) + ${sq},${sq} + u.role + ${sq},${sq} + (!!u.is_instructor ? ${sq}true${sq} : ${sq}false${sq})${sq})"`;

console.log('\nCorrect onclick:', correctOnclick);
console.log('Correct onclick length:', correctOnclick.length);

// Verify replacement part
const repIdx = correctOnclick.indexOf('.replace');
console.log('Replacement:', JSON.stringify(correctOnclick.substring(repIdx, repIdx + 50)));

// Do the replacement
if (firstOnclickStart >= 0 && firstOnclickEnd > 0) {
  const before = t.substring(0, firstOnclickStart);
  const after = t.substring(firstOnclickEnd);
  const newLine = before + correctOnclick + after;
  console.log('\nNew line length:', newLine.length);
  console.log('New line onclick area:', JSON.stringify(newLine.substring(newLine.indexOf('onclick'), newLine.indexOf('onclick') + 300)));
  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File written!');
} else {
  console.log('ERROR: could not determine onclick boundaries');
  console.log('firstOnclickStart:', firstOnclickStart, 'firstOnclickEnd:', firstOnclickEnd);
}