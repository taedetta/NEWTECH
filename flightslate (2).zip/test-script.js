// ─── GLOBAL ERROR HANDLER ───
window.__appVersion = '2026-05-05-v4';
window.onerror = function(msg, url, line, col, err) {
  console.error('[APP ERROR]', msg, 'at line', line, ':', col);
  // Error logged to console only — no debug UI
};
// ─── STATE ───
let currentUser = null;
let token = localStorage.getItem('fs_token');
let currentPage = 'dashboard';
let visitedPages = new Set(); // tracks which pages have been visited for skeleton loading
let calendarDate = new Date();
let selectedBookingDate = null; // tracks the last calendar-clicked date for the booking modal
let allBookings = [];
let allAircraft = [];
let allUsers = [];
let editingAircraftId = null;
let hasOwnerAccount = false;
let currentPeopleFilter = 'all';
let availabilityInstructorId = null;
let availabilityBlocks = {}; // { dow: [{start, end}, ...] }
let currentBookingAvailSlots = null; // null = no restriction, Set = restricted to these slots
let pendingPermChanges = {}; // { [userId]: { can_manage_aircraft: bool, ... } }
let completableBookings = []; // bookings awaiting hour entry
let selectedHoursLogAircraftId = null;

// ─── API HELPER ───
async function api(path, opts = {}) {
  const separator = path.includes('?') ? '&' : '?';
  const url = path + separator + '_=' + Date.now();
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(url, { ...opts, headers });
  const data = await res.json();
  if (!res.ok) throw { status: res.status, ...data };
  return data;
}

// ─── MOBILE SIDEBAR ───
function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  const isOpen = sidebar.classList.toggle('open');
  overlay.classList.toggle('active', isOpen);
}
function closeSidebar() {
  document.querySelector('.sidebar').classList.remove('open');
  document.getElementById('sidebar-overlay').classList.remove('active');
}

// ─── SCREENS ───
function showScreen(name) {
  document.getElementById('login-screen').classList.toggle('hidden', name !== 'login');
  document.getElementById('register-screen').classList.toggle('hidden', name !== 'register');
  document.getElementById('app-screen').classList.toggle('hidden', name !== 'app');
  document.getElementById('forgot-screen').classList.toggle('hidden', name !== 'forgot');
  document.getElementById('reset-screen').classList.toggle('hidden', name !== 'reset');
  document.getElementById('pending-screen').classList.toggle('hidden', name !== 'pending');
}

// ─── FORGOT PASSWORD ───
document.getElementById('forgot-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('forgot-error');
  const successEl = document.getElementById('forgot-success');
  const btn = document.getElementById('forgot-btn');
  errEl.classList.add('hidden');
  successEl.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = 'Sending…';
  try {
    const resp = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: document.getElementById('forgot-email').value }),
    });
    const data = await resp.json();
    if (resp.status === 429) {
      errEl.textContent = data.error || 'Too many attempts. Please wait a few minutes.';
      errEl.classList.remove('hidden');
      return;
    }
    // Always show success — don't reveal whether email exists (security)
    successEl.textContent = "If an account with that email exists, we've sent a password reset link. Check your inbox.";
    successEl.classList.remove('hidden');
    document.getElementById('forgot-form').reset();
  } catch (err) {
    errEl.textContent = 'Something went wrong. Please try again.';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send Reset Link';
  }
});

// ─── RESET PASSWORD ───
let resetToken = null;

document.getElementById('reset-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('reset-error');
  const successEl = document.getElementById('reset-success');
  const btn = document.getElementById('reset-btn');
  errEl.classList.add('hidden');
  successEl.classList.add('hidden');
  const password = document.getElementById('reset-password').value;
  const confirm = document.getElementById('reset-confirm').value;
  if (password !== confirm) {
    errEl.textContent = 'Passwords do not match.';
    errEl.classList.remove('hidden');
    return;
  }
  btn.disabled = true;
  btn.textContent = 'Saving…';
  try {
    const resp = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: resetToken, password }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      errEl.textContent = data.error || 'Reset failed.';
      errEl.classList.remove('hidden');
      return;
    }
    successEl.textContent = 'Password updated! Redirecting to sign in…';
    successEl.classList.remove('hidden');
    document.getElementById('reset-form').reset();
    // Clear the token from URL and go to login
    window.history.replaceState({}, '', '/app');
    setTimeout(() => showScreen('login'), 2000);
  } catch (err) {
    errEl.textContent = 'Something went wrong. Please try again.';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Set New Password';
  }
});

// Check on load if we have a reset token in the URL
(function checkResetToken() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get('reset');
  if (token) {
    resetToken = token;
    showScreen('reset');
  }
})();

// ─── AUTH ───
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('login-error');
  errEl.classList.add('hidden');
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: document.getElementById('login-email').value,
        password: document.getElementById('login-password').value,
      })
    });
    token = data.token;
    localStorage.setItem('fs_token', token);
    // Fetch full user including permissions from DB
    const meData = await api('/api/auth/me');
    currentUser = meData.user;
    enterApp();
  } catch (err) {
    if (err.error === 'pending_approval') {
      showScreen('pending');
      return;
    }
    errEl.textContent = err.error || 'Login failed';
    errEl.classList.remove('hidden');
  }
});

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('register-error');
  const phoneErrEl = document.getElementById('register-phone-error');
  errEl.classList.add('hidden');
  phoneErrEl.classList.add('hidden');

  // Client-side phone validation
  const phoneRaw = document.getElementById('register-phone').value.trim();
  const phoneDigits = phoneRaw.replace(/\D/g, '');
  if (!phoneRaw) {
    phoneErrEl.textContent = 'Phone number is required';
    phoneErrEl.classList.remove('hidden');
    document.getElementById('register-phone').focus();
    return;
  }
  if (phoneDigits.length !== 10) {
    phoneErrEl.textContent = 'Please enter a valid 10-digit US phone number';
    phoneErrEl.classList.remove('hidden');
    document.getElementById('register-phone').focus();
    return;
  }

  try {
    const data = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        name: document.getElementById('register-name').value,
        email: document.getElementById('register-email').value,
        password: document.getElementById('register-password').value,
        phone: phoneRaw,
        role: document.getElementById('register-role').value,
      })
    });
    // All new signups require approval — show pending screen instead of entering app
    if (data.pending) {
      showScreen('pending');
      return;
    }
    token = data.token;
    localStorage.setItem('fs_token', token);
    // Fetch full user including permissions from DB
    const meData = await api('/api/auth/me');
    currentUser = meData.user;
    enterApp();
  } catch (err) {
    errEl.textContent = err.error || 'Registration failed';
    errEl.classList.remove('hidden');
  }
});

function clearAppState() {
  // Clear all data arrays on logout to prevent stale data flash on re-login
  allUsers = [];
  allAircraft = [];
  allBookings = [];
  allSquawks = [];
  allADs = {};
  allPrograms = [];
  allProgressStudents = [];
  completableBookings = [];
  billingStudentSummaries = [];
  currentBillingStudentId = null;
  currentBillingFlights = [];
  currentBillingGroundSessions = [];
  atRiskData = [];
  atRiskSelectedStudentId = null;
  availabilityData = null;
  availabilityBlocks = {};
  pendingPermChanges = {};
  currentPeopleFilter = 'all';
  endorsementTemplates = [];
  editorContent = {};
  editorSavedContent = {};
  editorDirty = false;
  previewReady = false;
  canvasModeActive = false;
  elementPositions = {};
  hiddenElements = [];
  // Reset page tracking so skeletons show on re-login
  currentPage = 'dashboard';
}

function logout() {
  token = null;
  currentUser = null;
  clearAppState();
  localStorage.removeItem('fs_token');
  showScreen('login');
}

// ─── APP INIT ───
async function enterApp() {
  showScreen('app');

  // Refresh user data from server (gets fresh role + permissions)
  let meData;
  try {
    meData = await api('/api/auth/me');
    currentUser = meData.user;
    hasOwnerAccount = meData.hasOwner;
    if (meData.token) {
      token = meData.token;
      localStorage.setItem('fs_token', token);
    }
  } catch (meErr) {
    token = null;
    localStorage.removeItem('fs_token');
    showScreen('login');
    const errEl = document.getElementById('login-error');
    if (errEl) {
      errEl.textContent = 'Session verification failed. Please try logging in again.';
      errEl.classList.remove('hidden');
    }
    return;
  }

  try {
  document.getElementById('sidebar-name').textContent = currentUser.name;

  // Display role label with color

  // Display role label with color
  const roleLabels = { owner: 'Owner', instructor: 'Instructor', student: 'Student', admin: 'Admin', maintenance: 'Maintenance', renter: 'Renter' };
  const roleEl = document.getElementById('sidebar-role');
  if (roleEl) {
    roleEl.textContent = roleLabels[currentUser.role] || currentUser.role;
    if (currentUser.role === 'owner') roleEl.style.color = '#FBBF24';
  }

  const perms = currentUser.permissions || {};

  // ── Maintenance role: show ONLY 5 tabs, hide everything else ──
  if (currentUser.role === 'maintenance') {
    const allowed = new Set(['fleet', 'maintenance', 'flight-log', 'tracking']);
    document.querySelectorAll('.sidebar-nav a[data-page], .sidebar-nav a[id^="nav-"]').forEach(el => {
      const page = el.dataset.page || el.id.replace('nav-', '');
      el.classList.toggle('hidden', !allowed.has(page));
      if (!allowed.has(page)) el.style.display = 'none';
      else { el.classList.remove('hidden'); el.style.display = ''; }
    });
    // Hide section labels that become orphaned
    document.querySelectorAll('.nav-section-label').forEach(el => el.style.display = 'none');
    // Hide nav-divider too
    document.querySelectorAll('.nav-divider').forEach(el => el.style.display = 'none');
    // Load user + aircraft data in parallel with fresh auth check (faster startup)
  const [freshData] = await Promise.all([
    api('/api/auth/me'),
    loadUsers(),
    loadAircraft(),
  ]);
  // Use fresh user data (role may have changed since login)
    currentUser = freshData.user;
    hasOwnerAccount = freshData.hasOwner;
    navigate('tracking');
    return;
  }
  // ── End maintenance role ──

  // ── Renter role: limited nav (Dashboard, Schedule, Fleet, My Portal, Flight Log) ──
  if (currentUser.role === 'renter') {
    const allowed = new Set(['dashboard', 'schedule', 'fleet', 'portal', 'flight-log']);
    document.querySelectorAll('.sidebar-nav a[data-page], .sidebar-nav a[id^="nav-"]').forEach(el => {
      const page = el.dataset.page || el.id.replace('nav-', '');
      el.classList.toggle('hidden', !allowed.has(page));
      if (!allowed.has(page)) el.style.display = 'none';
      else { el.classList.remove('hidden'); el.style.display = ''; }
    });
    // My Portal nav: show for renter
    const navPortalR = document.getElementById('nav-portal');
    if (navPortalR) { navPortalR.style.display = ''; navPortalR.classList.remove('hidden'); }
    // Load user + aircraft data in parallel with fresh auth check (faster startup)
  const [freshData] = await Promise.all([
    api('/api/auth/me'),
    loadUsers(),
    loadAircraft(),
  ]);
  // Use fresh user data (role may have changed since login)
    currentUser = freshData.user;
    hasOwnerAccount = freshData.hasOwner;
    navigate('portal');
    return;
  }
  // ── End renter role ──

  // Show approvals nav for owner/admin/instructor
  const navApprovals = document.getElementById('nav-approvals');
  if (navApprovals) {
    navApprovals.classList.toggle('hidden', !['owner', 'admin', 'instructor'].includes(currentUser.role));
    if (['owner', 'admin', 'instructor'].includes(currentUser.role)) {
      loadApprovalsBadge();
    }
  }

  // Discrepancies: owner/admin only
  const navDisc = document.getElementById('nav-discrepancies');
  if (navDisc) {
    const canSeeDisc = ['owner', 'admin'].includes(currentUser.role);
    navDisc.classList.toggle('hidden', !canSeeDisc);
    if (canSeeDisc) loadDiscrepanciesBadge();
  }

  // Students can't see People page
  const navPeople = document.getElementById('nav-people');
  if (navPeople) {
    navPeople.classList.toggle('hidden', currentUser.role === 'student');
  }

  // At-Risk: visible to owner, admin, instructor — not students
  const navAtRisk = document.getElementById('nav-at-risk');
  if (navAtRisk) navAtRisk.classList.toggle('hidden', currentUser.role === 'student');

  // Leads: owner/admin only
  const navLeads = document.getElementById('nav-leads');
  if (navLeads) navLeads.classList.toggle('hidden', !['owner', 'admin'].includes(currentUser.role));

  // My Portal: visible to students only
  const navPortal = document.getElementById('nav-portal');
  if (navPortal) navPortal.classList.toggle('hidden', currentUser.role !== 'student');

  // Website Editor: visible to owner or anyone with can_edit_website permission
  const navWebsiteEditor = document.getElementById('nav-website-editor');
  if (navWebsiteEditor) {
    const canEditWebsite = currentUser.role === 'owner' || !!(perms.can_edit_website);
    navWebsiteEditor.classList.toggle('hidden', !canEditWebsite);
  }

  // Hours Audit: owner/admin only
  const navAudit = document.getElementById('nav-hours-audit');
  if (navAudit) {
    navAudit.style.display = ['owner', 'admin'].includes(currentUser.role) ? '' : 'none';
  }

  // Programs: visible to owner, admin, and instructor
  const navPrograms = document.getElementById('nav-programs');
  if (navPrograms) {
    navPrograms.classList.toggle('hidden', !['owner', 'admin', 'instructor'].includes(currentUser.role));
  }

  // Instructor Hours: visible to instructors, admins, owners — NOT students
  const navIH = document.getElementById('nav-instructor-hours');
  if (navIH) {
    navIH.classList.toggle('hidden', currentUser.role === 'student');
  }

  // Booking History: visible to instructor, admin, owner — NOT students
  const navBH = document.getElementById('nav-history');
  if (navBH) navBH.classList.toggle('hidden', currentUser.role === 'student');

  // Endorsements: visible to all roles
  const navEndorse = document.getElementById('nav-endorsements');
  if (navEndorse) navEndorse.classList.remove('hidden');

  // Availability: visible to instructors, admins, owners — NOT students
  const navAvail = document.getElementById('nav-availability');
  if (navAvail) navAvail.classList.toggle('hidden', currentUser.role === 'student');

  // Admin Settings: owner and admin only
  try {
    const navAdminSettings = document.getElementById('nav-admin-settings');
    console.log('[ENTER-APP] nav-admin-settings element:', navAdminSettings);
    console.log('[ENTER-APP] currentUser.role:', currentUser.role);
    if (navAdminSettings) {
      const isAdminOrOwner = ['owner', 'admin'].includes(currentUser.role);
      console.log('[ENTER-APP] isAdminOrOwner:', isAdminOrOwner);
      if (isAdminOrOwner) {
        navAdminSettings.classList.remove('hidden');
        navAdminSettings.style.display = '';
        console.log('[ENTER-APP] Admin settings nav shown for role:', currentUser.role);
      } else {
        navAdminSettings.classList.add('hidden');
      }
    } else {
      console.error('[ENTER-APP] nav-admin-settings element NOT FOUND in DOM');
    }
    // Also verify the page div exists
    const pageDiv = document.getElementById('page-admin-settings');
    console.log('[ENTER-APP] page-admin-settings exists:', !!pageDiv, 'innerHTML length:', pageDiv ? pageDiv.innerHTML.length : 'N/A');
  } catch(e) {
    console.error('[ENTER-APP] Error showing admin nav:', e);
  }

  // Source download section: owner only
  const sourceDownloadSection = document.getElementById('source-download-section');
  if (sourceDownloadSection) {
    sourceDownloadSection.classList.toggle('hidden', currentUser.role !== 'owner');
  }

  // Add Aircraft button: visible to owner or instructor with can_manage_aircraft
  const addAircraftBtn = document.getElementById('add-aircraft-btn');
  const canManageAircraft = currentUser.role === 'owner' || perms.can_manage_aircraft;
  if (addAircraftBtn) addAircraftBtn.classList.toggle('hidden', !canManageAircraft);

  // Load user + aircraft data in parallel with fresh auth check (faster startup)
  const [freshData] = await Promise.all([
    api('/api/auth/me'),
    loadUsers(),
    loadAircraft(),
  ]);
  // Use fresh user data (role may have changed since login)
  currentUser = freshData.user;
  hasOwnerAccount = freshData.hasOwner;
  } catch (enterErr) {
    console.error('[enterApp] error during setup:', enterErr);
    // Error logged to console only — no debug UI
  }
  // Students land on their portal; everyone else lands on dashboard
  navigate(currentUser.role === 'student' ? 'portal' : 'dashboard');
}

// ─── NAVIGATION ───
// ─── TOAST NOTIFICATIONS ────────────────────────────────
let _toastTimeout;
function showToast(msg, type) {
  let toast = document.getElementById('app-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'app-toast';
    toast.style.cssText = 'position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;padding:0.6rem 1.1rem;border-radius:8px;font-size:0.85rem;font-weight:600;font-family:inherit;transition:opacity 0.3s;max-width:320px;pointer-events:none;';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.background = type === 'error' ? 'rgba(239,68,68,0.9)' : 'rgba(34,197,94,0.9)';
  toast.style.color = '#fff';
  toast.style.opacity = '1';
  clearTimeout(_toastTimeout);
  _toastTimeout = setTimeout(() => { toast.style.opacity = '0'; }, 2500);
}

// ─── TRAINING PROGRAMS ADMIN ─────────────────────────────

async function loadProgramsAdmin() {
  const listEl = document.getElementById('programs-list');
  if (!listEl) return;
  const isAdmin = ['owner', 'admin'].includes(currentUser.role);
  const isInstructor = currentUser.role === 'instructor';

  // Show/hide student progress selector for instructors
  const studentSelector = document.getElementById('programs-student-selector');
  if (studentSelector) {
    studentSelector.classList.toggle('hidden', !isInstructor);
    studentSelector.style.display = isInstructor ? 'flex' : 'none';
  }

  // Set description and "New Program" button visibility
  const descEl = document.getElementById('programs-page-desc');
  const btnNew = document.getElementById('btn-new-program');
  if (descEl) descEl.textContent = isAdmin
    ? 'Manage the FAA training syllabus for each certificate. Add or remove stages and maneuvers. Changes apply to newly enrolled students; existing students keep their progress and receive new items added.'
    : 'View the FAA training syllabus for each certificate. Instructors use this to track student progress against program stages and maneuvers.';
  if (btnNew) btnNew.style.display = isAdmin ? '' : 'none';

  listEl.innerHTML = '<div style="color:var(--gray-400);padding:2rem">Loading...</div>';
  try {
    allPrograms = await api('/api/training/programs');
    console.log('[programs] Loaded', allPrograms.length, 'programs');

    // For instructors, also fetch student enrollment data for each program
    let programEnrollments = [];
    let allStudents = [];
    if (isInstructor) {
      try {
        [programEnrollments, allStudents] = await Promise.all([
          api('/api/training/program-enrollments'),
          api('/api/training/students')
        ]);
        console.log('[programs] Loaded', programEnrollments.length, 'program enrollments,', allStudents.length, 'students');
      } catch (e) {
        console.warn('[programs] Could not load enrollments/students:', e);
      }
      // Populate student selector
      populateProgramsStudentSelector(allStudents);
    }

    if (isAdmin) {
      renderProgramsAdmin(allPrograms);
    } else {
      renderProgramsReadOnly(allPrograms, isInstructor ? programEnrollments : null);
    }
  } catch (err) {
    listEl.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load programs. ' + escHtml(err.message || 'Unknown error') + '</div>';
    console.error('[programs] Load error:', err);
  }
}

function populateProgramsStudentSelector(students) {
  const select = document.getElementById('programs-student-select');
  if (!select) return;
  const current = select.value;
  select.innerHTML = '<option value="">— Select a student —</option>';
  (students || []).forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.textContent = s.name + (s.enrollments && s.enrollments.length ? ' (' + s.enrollments.length + ' program' + (s.enrollments.length !== 1 ? 's' : '') + ')' : '');
    select.appendChild(opt);
  });
  if (current) select.value = current;
}

async function onProgramStudentChange() {
  const studentId = document.getElementById('programs-student-select')?.value;
  const listEl = document.getElementById('programs-list');
  if (!listEl) return;

  if (!studentId) {
    // Re-render normal view
    if (allPrograms && allPrograms.length > 0) {
      renderProgramsReadOnly(allPrograms, null);
    }
    return;
  }

  listEl.innerHTML = '<div style="color:var(--gray-400);padding:2rem">Loading student progress...</div>';
  try {
    const data = await api('/api/training/students/' + studentId);
    console.log('[programs] Student progress loaded for student', studentId);
    renderStudentProgressForPrograms(data);
  } catch (err) {
    listEl.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load student progress. ' + escHtml(err.message || '') + '</div>';
    console.error('[programs] Student progress error:', err);
  }
}

function renderStudentProgressForPrograms(data) {
  const listEl = document.getElementById('programs-list');
  if (!listEl) return;
  if (!data || !data.student) {
    listEl.innerHTML = '<div style="color:var(--gray-400);padding:2rem">Student not found.</div>';
    return;
  }

  const { student, enrollments } = data;
  const statusColors = { not_started: 'var(--gray-500)', in_progress: 'var(--sky)', needs_review: 'var(--amber)', proficient: 'var(--green)', completed: 'var(--green)' };
  const statusLabels = { not_started: 'Not Started', in_progress: 'In Progress', needs_review: 'Needs Review', proficient: 'Proficient', completed: 'Completed' };

  let html = '<div style="margin-bottom:1.5rem;padding:1rem;background:rgba(255,255,255,0.05);border-radius:0.6rem;border:1px solid rgba(255,255,255,0.1)">';
  html += '<div style="display:flex;align-items:center;gap:1rem;margin-bottom:0.5rem">';
  html += '<span style="font-size:1.2rem">👤</span>';
  html += '<div><div style="font-weight:700;color:var(--white);font-size:1rem">' + escHtml(student.name) + '</div>';
  html += '<div style="font-size:0.78rem;color:var(--gray-400)">' + escHtml(student.email || '') + '</div></div>';
  html += '<div style="margin-left:auto;text-align:right"><div style="font-size:0.78rem;color:var(--gray-400)">Total Hours</div>';
  html += '<div style="font-weight:700;color:var(--white)">' + (student.total_hobbs_hours || 0).toFixed(1) + ' Hobbs</div></div>';
  html += '</div></div>';

  if (!enrollments || enrollments.length === 0) {
    html += '<div style="color:var(--gray-400);padding:2rem;text-align:center">This student is not enrolled in any training program.</div>';
  } else {
    enrollments.forEach(enroll => {
      const prog = allPrograms?.find(p => p.id === enroll.program_id);
      if (!prog) return;
      const tagClass = prog.code === 'PPL' ? 'tag-sky' : prog.code === 'IFR' ? 'tag-purple' : 'tag-amber';
      html += '<div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.6rem;padding:1.25rem;margin-bottom:1rem">';
      html += '<div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.75rem">';
      html += '<span class="tag ' + tagClass + '">' + escHtml(prog.code) + '</span>';
      html += '<span style="font-weight:700;color:var(--white)">' + escHtml(prog.name) + '</span>';
      html += '<span style="color:var(--gray-400);font-size:0.78rem;margin-left:auto">' + enroll.stages_completed + '/' + enroll.stages_total + ' stages</span>';
      html += '</div>';

      (enroll.stages || []).forEach(stage => {
        html += '<div style="margin-bottom:1rem">';
        html += '<div style="font-weight:600;color:var(--white);font-size:0.85rem;margin-bottom:0.4rem;padding:0.3rem 0.5rem;background:rgba(255,255,255,0.06);border-radius:0.3rem;display:flex;justify-content:space-between">';
        html += '<span>' + escHtml(stage.name) + '</span>';
        const stageDone = stage.maneuvers?.every(m => ['proficient', 'completed'].includes(m.status));
        html += '<span style="color:' + (stageDone ? 'var(--green)' : 'var(--amber)') + ';font-size:0.75rem">' + (stageDone ? '✓ Done' : 'In Progress') + '</span>';
        html += '</div>';
        html += '<div style="padding-left:0.5rem">';
        (stage.maneuvers || []).forEach(m => {
          const color = statusColors[m.status] || 'var(--gray-500)';
          const label = statusLabels[m.status] || m.status || 'Unknown';
          const checkIcon = ['proficient', 'completed'].includes(m.status) ? '✓' : '○';
          html += '<div style="display:flex;align-items:center;gap:0.5rem;padding:0.25rem 0;font-size:0.8rem;border-bottom:1px solid rgba(255,255,255,0.04)">';
          html += '<span style="color:' + color + ';font-size:0.75rem">' + checkIcon + '</span>';
          html += '<span style="color:var(--gray-200)">' + escHtml(m.name) + '</span>';
          html += '<span style="margin-left:auto;font-size:0.72rem;color:' + color + '">' + label + '</span>';
          if (m.proficient_date) {
            html += '<span style="font-size:0.68rem;color:var(--gray-500);margin-left:0.5rem">' + m.proficient_date.slice(0, 10) + '</span>';
          }
          html += '</div>';
        });
        html += '</div></div>';
      });
      html += '</div>';
    });
  }

  listEl.innerHTML = html;
}

function renderProgramsAdmin(programs) {
  const listEl = document.getElementById('programs-list');
  if (!listEl) return;
  if (!programs || programs.length === 0) {
    listEl.innerHTML = '<div style="color:var(--gray-500)">No programs yet. Create one above.</div>';
    return;
  }
  listEl.innerHTML = programs.map(p => renderProgramAdminCard(p)).join('');
}

function renderProgramAdminCard(p) {
  const tagClass = p.code === 'PPL' ? 'tag-sky' : p.code === 'IFR' ? 'tag-purple' : 'tag-amber';
  const stagesHtml = (p.stages || []).map(s => {
    const maneuversHtml = (s.maneuvers || []).map(m => `
      <div class="maneuver-admin-item" id="man-${m.id}">
        <span class="maneuver-admin-name">${escHtml(m.name)}</span>
        <button class="btn-icon" onclick="deleteManeuver(${m.id})" title="Delete maneuver">&#128465;</button>
      </div>
    `).join('');

    const manCount = (s.maneuvers || []).length;
    return `<div class="program-admin-stage" id="stage-${s.id}">
      <div class="program-stage-header">
        <span class="program-stage-name">${escHtml(s.name)}</span>
        <span style="font-size:0.72rem;color:var(--gray-500)">${manCount} maneuver${manCount !== 1 ? 's' : ''}</span>
        <div class="program-stage-actions">
          <button class="btn btn-secondary btn-xs" onclick="toggleAdminManeuvers('admin-ml-${s.id}',this)" style="font-size:0.7rem">Expand &#9654;</button>
          <button class="btn-icon" onclick="deleteStage(${s.id},${p.id})" title="Delete stage">&#128465;</button>
        </div>
      </div>
      <div id="admin-ml-${s.id}" style="display:none;margin-top:0.4rem">
        <div class="maneuver-admin-list">
          ${maneuversHtml}
          <div id="add-man-area-${s.id}">
            <button class="btn btn-secondary btn-xs" onclick="showAddManeuverForm(${s.id})" style="margin-top:0.3rem;font-size:0.7rem">+ Add Maneuver</button>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');

  return `<div class="program-admin-card">
    <div class="program-admin-header" style="display:flex;align-items:center;gap:0.6rem;flex-wrap:wrap">
      <span class="tag ${tagClass}">${escHtml(p.code)}</span>
      <span style="font-size:1.05rem;font-weight:700;color:var(--white)">${escHtml(p.name)}</span>
      <span style="font-size:0.8rem;color:var(--gray-500)">${(p.stages||[]).length} stages</span>
      <button class="btn-icon" onclick="deleteProgram(${p.id})" title="Delete program" style="margin-left:auto;background:rgba(239,68,68,0.1);border:none;cursor:pointer;color:var(--red);font-size:0.85rem;padding:0.15rem 0.4rem;border-radius:5px">&#128465;</button>
    </div>
    ${p.description ? `<div style="font-size:0.82rem;color:var(--gray-400);margin-bottom:1rem">${escHtml(p.description)}</div>` : ''}
    <div id="stages-${p.id}">${stagesHtml}</div>
    <!-- Add stage form -->
    <div id="add-stage-area-${p.id}" style="margin-top:0.75rem">
      <button class="btn btn-secondary btn-xs" onclick="showAddStageForm(${p.id})" style="font-size:0.75rem">+ Add Stage</button>
    </div>
  </div>`;
}

function renderProgramsReadOnly(programs, programEnrollments) {
  const listEl = document.getElementById('programs-list');
  if (!listEl) return;
  if (!programs || programs.length === 0) {
    listEl.innerHTML = '<div style="color:var(--gray-500);padding:2rem">No training programs available.</div>';
    return;
  }
  listEl.innerHTML = programs.map(p => {
    const tagClass = p.code === 'PPL' ? 'tag-sky' : p.code === 'IFR' ? 'tag-purple' : 'tag-amber';
    const stagesHtml = (p.stages || []).map(s => {
      const maneuversHtml = (s.maneuvers || []).map(m => `
        <div style="padding:0.35rem 0.5rem;border-bottom:1px solid var(--gray-700);display:flex;align-items:baseline;gap:0.5rem">
          <span style="color:var(--gray-500);font-size:0.72rem;min-width:1.2rem">${m.order_index}.</span>
          <span style="color:var(--gray-200);font-size:0.82rem">${escHtml(m.name)}</span>
          ${m.proficiency_standard ? `<span style="color:var(--gray-500);font-size:0.75rem">— ${escHtml(m.proficiency_standard)}</span>` : ''}
        </div>
      `).join('');
      return `<div style="margin-bottom:1rem">
        <div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem 0.75rem;background:rgba(255,255,255,0.06);border-radius:0.35rem;margin-bottom:0.4rem">
          <span style="font-weight:600;color:var(--white);font-size:0.88rem">${escHtml(s.name)}</span>
          <span style="color:var(--gray-500);font-size:0.75rem">${(s.maneuvers||[]).length} lesson${(s.maneuvers||[]).length !== 1 ? 's' : ''}</span>
        </div>
        ${maneuversHtml}
      </div>`;
    }).join('');
    const enrollments = programEnrollments ? (programEnrollments.find(e => e.id === p.id) || {}).students || [] : [];
    const studentsHtml = enrollments.length > 0 ? enrollments.map(s => {
      const stagesTotal = parseInt(s.stages_total) || 0;
      const stagesCompleted = parseInt(s.stages_completed) || 0;
      const pct = stagesTotal > 0 ? Math.round((stagesCompleted / stagesTotal) * 100) : 0;
      const color = pct >= 75 ? 'var(--green)' : pct >= 40 ? 'var(--sky)' : 'var(--amber)';
      return `<div style="display:flex;align-items:center;gap:0.75rem;padding:0.3rem 0;border-bottom:1px solid rgba(255,255,255,0.05)">
        <span style="color:var(--gray-200);font-size:0.82rem;flex:1">${escHtml(s.student_name)}</span>
        <div style="flex:2;background:rgba(255,255,255,0.07);border-radius:4px;height:6px;overflow:hidden"><div style="width:${pct}%;background:${color};height:100%"></div></div>
        <span style="color:var(--gray-400);font-size:0.75rem;min-width:60px;text-align:right">${stagesCompleted}/${stagesTotal} stages</span>
      </div>`;
    }).join('') : '';
    const studentsSection = enrollments.length > 0
      ? `<div style="margin-top:1rem;padding:0.75rem;background:rgba(255,255,255,0.04);border-radius:0.4rem;border:1px solid rgba(255,255,255,0.07)">
          <div style="font-size:0.72rem;font-weight:600;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.5rem">Students Enrolled (${enrollments.length})</div>
          ${studentsHtml}
        </div>`
      : '';
    return `<div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.6rem;padding:1.25rem;margin-bottom:1rem">
      <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.5rem">
        <span class="tag ${tagClass}">${escHtml(p.code)}</span>
        <span style="font-size:1.1rem;font-weight:700;color:var(--white)">${escHtml(p.name)}</span>
        <span style="color:var(--gray-500);font-size:0.8rem">${(p.stages||[]).length} stages</span>
        ${enrollments.length > 0 ? `<span style="color:var(--sky);font-size:0.78rem">• ${enrollments.length} student${enrollments.length !== 1 ? 's' : ''}</span>` : ''}
      </div>
      ${p.description ? `<div style="font-size:0.82rem;color:var(--gray-400);margin-bottom:1rem">${escHtml(p.description)}</div>` : ''}
      ${studentsSection}
      ${stagesHtml}
    </div>`;
  }).join('');
}

function toggleAdminManeuvers(listId, btn) {
  const el = document.getElementById(listId);
  if (!el) return;
  const isOpen = el.style.display !== 'none';
  el.style.display = isOpen ? 'none' : 'block';
  btn.textContent = isOpen ? 'Expand ▶' : 'Collapse ▲';
}

function showAddStageForm(programId) {
  const area = document.getElementById(`add-stage-area-${programId}`);
  if (!area) return;
  area.innerHTML = `<div class="add-stage-form">
    <input type="text" id="new-stage-name-${programId}" class="input-field" placeholder="Stage name" style="max-width:240px;padding:0.3rem 0.5rem;font-size:0.82rem">
    <button class="btn btn-primary btn-xs" onclick="addStage(${programId})">Add Stage</button>
    <button class="btn btn-secondary btn-xs" onclick="document.getElementById('add-stage-area-${programId}').innerHTML='<button class=\\'btn btn-secondary btn-xs\\' onclick=\\'showAddStageForm(${programId})\\' style=\\'font-size:0.75rem\\'>+ Add Stage</button>'">Cancel</button>
  </div>`;
}

async function addStage(programId) {
  const inp = document.getElementById(`new-stage-name-${programId}`);
  const name = inp ? inp.value.trim() : '';
  if (!name) { alert('Stage name is required'); return; }
  try {
    await api('/api/admin/training/stages', { method: 'POST', body: JSON.stringify({ program_id: programId, name }) });
    await loadProgramsAdmin();
    showToast('Stage added');
  } catch (err) {
    alert('Failed to add stage: ' + (err.error || 'Unknown error'));
  }
}

async function deleteProgram(programId) {
  if (!confirm('Delete this training program? All stages and maneuvers will be permanently removed. This cannot be undone.')) return;
  try {
    await api(`/api/admin/training/programs/${programId}`, { method: 'DELETE' });
    await loadProgramsAdmin();
    showToast('Program deleted', 'success');
  } catch (err) {
    alert(err.error || 'Failed to delete program');
  }
}

async function deleteStage(stageId, programId) {
  if (!confirm('Delete this stage? Maneuvers in it will also be removed. Students currently in this stage must be reassigned first.')) return;
  try {
    await api(`/api/admin/training/stages/${stageId}`, { method: 'DELETE' });
    await loadProgramsAdmin();
    showToast('Stage deleted');
  } catch (err) {
    alert(err.error || 'Failed to delete stage');
  }
}

function showAddManeuverForm(stageId) {
  const area = document.getElementById(`add-man-area-${stageId}`);
  if (!area) return;
  area.innerHTML = `<div style="display:flex;gap:0.4rem;margin-top:0.35rem;flex-wrap:wrap">
    <input type="text" id="new-man-name-${stageId}" class="input-field" placeholder="Maneuver name" style="max-width:260px;padding:0.25rem 0.4rem;font-size:0.78rem">
    <button class="btn btn-primary btn-xs" onclick="addManeuver(${stageId})">Add</button>
    <button class="btn btn-secondary btn-xs" onclick="showAddManeuverBtn(${stageId})">Cancel</button>
  </div>`;
  const inp = document.getElementById(`new-man-name-${stageId}`);
  if (inp) inp.focus();
}

function showAddManeuverBtn(stageId) {
  const area = document.getElementById(`add-man-area-${stageId}`);
  if (area) area.innerHTML = `<button class="btn btn-secondary btn-xs" onclick="showAddManeuverForm(${stageId})" style="margin-top:0.3rem;font-size:0.7rem">+ Add Maneuver</button>`;
}

async function addManeuver(stageId) {
  const inp = document.getElementById(`new-man-name-${stageId}`);
  const name = inp ? inp.value.trim() : '';
  if (!name) { alert('Maneuver name is required'); return; }
  try {
    await api('/api/admin/training/maneuvers', { method: 'POST', body: JSON.stringify({ stage_id: stageId, name }) });
    await loadProgramsAdmin();
    showToast('Maneuver added');
    // Re-expand the stage
    const listEl = document.getElementById(`admin-ml-${stageId}`);
    if (listEl) { listEl.style.display = 'block'; }
  } catch (err) {
    alert('Failed to add maneuver: ' + (err.error || 'Unknown error'));
  }
}

async function deleteManeuver(maneuverId) {
  if (!confirm('Delete this maneuver? Student progress records for it will also be removed.')) return;
  try {
    await api(`/api/admin/training/maneuvers/${maneuverId}`, { method: 'DELETE' });
    await loadProgramsAdmin();
    showToast('Maneuver deleted');
  } catch (err) {
    alert(err.error || 'Failed to delete maneuver');
  }
}

function showNewProgramForm() {
  document.getElementById('new-program-form').classList.remove('hidden');
}
function hideNewProgramForm() {
  document.getElementById('new-program-form').classList.add('hidden');
  document.getElementById('new-prog-name').value = '';
  document.getElementById('new-prog-code').value = '';
  document.getElementById('new-prog-desc').value = '';
}

async function createNewProgram() {
  const name = document.getElementById('new-prog-name').value.trim();
  const code = document.getElementById('new-prog-code').value.trim().toUpperCase();
  const description = document.getElementById('new-prog-desc').value.trim();
  if (!name || !code) { alert('Name and code are required'); return; }
  try {
    await api('/api/admin/training/programs', { method: 'POST', body: JSON.stringify({ name, code, description }) });
    hideNewProgramForm();
    await loadProgramsAdmin();
    showToast('Program created');
  } catch (err) {
    alert(err.error || 'Failed to create program');
  }
}

// ─── END TRAINING PROGRAMS ADMIN ─────────────────────────

function navigate(page) {
  console.log('[NAV] navigate called with:', page);
  closeSidebar(); // close mobile sidebar on navigation
  const wasVisited = visitedPages.has(page);
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  const targetPage = document.getElementById('page-' + page);
  console.log('[NAV] targetPage element:', targetPage);
  console.log('[NAV] targetPage innerHTML length:', targetPage ? targetPage.innerHTML.length : 'NULL');
  if (targetPage) {
    targetPage.classList.remove('hidden');
    targetPage.style.display = '';  // clear any inline display:none
    targetPage.style.visibility = 'visible';  // force visible
    targetPage.style.opacity = '1';  // force opaque
    console.log('[NAV] Removed hidden class. classList now:', targetPage.className);
    console.log('[NAV] computed display:', window.getComputedStyle(targetPage).display);
    console.log('[NAV] computed visibility:', window.getComputedStyle(targetPage).visibility);
    // Force-check parent visibility
    var parent = targetPage.parentElement;
    var depth = 0;
    while (parent && depth < 5) {
      var pStyle = window.getComputedStyle(parent);
      if (pStyle.display === 'none' || pStyle.visibility === 'hidden') {
        console.error('[NAV] PARENT HIDDEN! id=' + parent.id + ' class=' + parent.className + ' display=' + pStyle.display + ' visibility=' + pStyle.visibility);
      }
      parent = parent.parentElement;
      depth++;
    }
  } else {
    console.error('[NAV] page not found:', page);
  }
  document.querySelectorAll('.sidebar-nav a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === page);
  });
  document.querySelector('.sidebar').classList.remove('open');

  // Stale data flash fix: show skeleton for previously-visited pages so old content doesn't flash
  if (wasVisited) {
    if (page === 'dashboard') {
      const ss = document.getElementById('dashboard-skeleton-stats');
      const st = document.getElementById('dashboard-skeleton-table');
      if (ss) ss.classList.remove('hidden');
      if (st) st.classList.remove('hidden');
      document.getElementById('dashboard-stats').innerHTML = '';
      document.getElementById('dashboard-bookings-header').classList.add('hidden');
      document.getElementById('dashboard-table-card').classList.add('hidden');
      document.getElementById('dashboard-empty').classList.add('hidden');
    }
  }
  visitedPages.add(page);

  if (page === 'dashboard') loadDashboard();
  else if (page === 'schedule') loadCalendar();
  else if (page === 'fleet') loadFleet();
  else if (page === 'maintenance') { populateSquawkAircraftFilter(); loadMaintenance(); }
  else if (page === 'people') loadPeople('all');
  else if (page === 'progress') loadProgress();
  else if (page === 'billing') loadBilling();
  else if (page === 'instructor-hours') loadInstructorHoursPage();
  else if (page === 'flight-log') { loadFlightLog(); loadFlogAircraftHours(); }
  else if (page === 'history') loadHistoryLegacyPage();
  else if (page === 'hours-audit') loadHoursAudit();
  else if (page === 'website-editor') loadWebsiteEditor();
  else if (page === 'programs') loadProgramsAdmin();
  else if (page === 'tracking') loadTrackFlights();
  else if (page === 'approvals') loadApprovals();
  else if (page === 'discrepancies') loadDiscrepancies();
  else if (page === 'at-risk') loadAtRisk();
  else if (page === 'endorsements') loadEndorsements();
  else if (page === 'portal') loadStudentPortal();
  else if (page === 'availability') loadAvailabilityPage();
  else if (page === 'leads') loadLeads();
  // admin-settings has no async data to load — static page
}

// ─── DIGITAL ENDORSEMENTS ────────────────────────────────

// Helper: safely extract YYYY-MM-DD from any date format (ISO timestamp or plain date string)
function toDateOnly(val) {
  if (!val) return null;
  return val.toString().slice(0, 10);
}

let endorsementTemplates = [];
let currentEndorsementId = null;
let cfiSigPad = null;
let studentSigPad = null;

// ── Signature Pad Helper ──────────────────────────────
function initSigPad(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;
  const ctx = canvas.getContext('2d');

  // Scale for retina
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr || 500 * dpr;
  canvas.height = (canvasId === 'cfi-sig-canvas' ? 140 : 120) * dpr;
  ctx.scale(dpr, dpr);
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  let drawing = false;
  let lastX = 0, lastY = 0;
  let hasData = false;

  function getXY(e) {
    const r = canvas.getBoundingClientRect();
    if (e.touches) {
      return [e.touches[0].clientX - r.left, e.touches[0].clientY - r.top];
    }
    return [e.clientX - r.left, e.clientY - r.top];
  }

  function startDraw(e) {
    e.preventDefault();
    drawing = true;
    const [x, y] = getXY(e);
    lastX = x; lastY = y;
    ctx.beginPath();
    ctx.moveTo(x, y);
  }
  function draw(e) {
    if (!drawing) return;
    e.preventDefault();
    const [x, y] = getXY(e);
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
    lastX = x; lastY = y;
    hasData = true;
  }
  function endDraw(e) { e.preventDefault(); drawing = false; }

  canvas.addEventListener('mousedown', startDraw);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('mouseup', endDraw);
  canvas.addEventListener('mouseleave', endDraw);
  canvas.addEventListener('touchstart', startDraw, { passive: false });
  canvas.addEventListener('touchmove', draw, { passive: false });
  canvas.addEventListener('touchend', endDraw, { passive: false });

  return {
    clear() {
      ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
      hasData = false;
    },
    isEmpty() { return !hasData; },
    toDataURL() { return canvas.toDataURL('image/png'); },
  };
}

// ── CFI Profile Modal ─────────────────────────────────
async function openCFIProfileModal() {
  document.getElementById('cfi-profile-error').classList.add('hidden');
  try {
    const data = await api('/api/users/me/cfi-profile');
    document.getElementById('cfi-cert-number').value = data.cfi_cert_number || '';
    document.getElementById('cfi-expiry-date').value = data.cfi_expiry ? data.cfi_expiry.split('T')[0] : '';
  } catch { /* no-op */ }
  document.getElementById('cfi-profile-modal').classList.remove('hidden');
}
function closeCFIProfileModal() {
  document.getElementById('cfi-profile-modal').classList.add('hidden');
}
async function saveCFIProfile() {
  const errEl = document.getElementById('cfi-profile-error');
  errEl.classList.add('hidden');
  const num = document.getElementById('cfi-cert-number').value.trim();
  const exp = document.getElementById('cfi-expiry-date').value;
  if (!num) { errEl.textContent = 'CFI certificate number is required'; errEl.classList.remove('hidden'); return; }
  try {
    await api('/api/users/me/cfi-profile', {
      method: 'PUT',
      body: JSON.stringify({ cfi_cert_number: num, cfi_expiry: exp || null }),
    });
    closeCFIProfileModal();
    showToast('CFI profile saved');
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save';
    errEl.classList.remove('hidden');
  }
}

// ── Load Endorsements ─────────────────────────────────
async function loadEndorsements() {
  // Set up page controls based on role
  const isInstructor = ['instructor', 'owner', 'admin'].includes(currentUser.role);
  document.getElementById('new-endorsement-btn').style.display = isInstructor ? '' : 'none';
  document.getElementById('cfi-profile-btn').style.display = isInstructor ? '' : 'none';

  // Student filter: only show for owner/admin
  const studentFilter = document.getElementById('endorsement-filter-student');
  if (currentUser.role === 'student') {
    studentFilter.style.display = 'none';
    document.getElementById('endorsements-th-instructor').textContent = 'Instructor';
    document.getElementById('endorsements-th-student').style.display = 'none';
  } else if (currentUser.role === 'instructor') {
    studentFilter.style.display = 'none'; // instructors see their own
    document.getElementById('endorsements-th-student').style.display = '';
  } else {
    // owner/admin: populate student filter
    studentFilter.style.display = '';
    studentFilter.innerHTML = '<option value="">All Students</option>';
    allUsers.filter(u => u.role === 'student').forEach(u => {
      const opt = document.createElement('option');
      opt.value = u.id;
      opt.textContent = u.name;
      studentFilter.appendChild(opt);
    });
  }

  // Fetch templates if not loaded
  if (endorsementTemplates.length === 0) {
    try {
      const data = await api('/api/endorsements/templates');
      endorsementTemplates = data.templates;
    } catch { /* ignore */ }
  }

  document.getElementById('endorsements-loading').style.display = '';
  document.getElementById('endorsements-empty').classList.add('hidden');
  document.getElementById('endorsements-tbody').innerHTML = '';

  try {
    const params = new URLSearchParams();
    const sid = document.getElementById('endorsement-filter-student').value;
    const status = document.getElementById('endorsement-filter-status').value;
    if (sid) params.set('student_id', sid);
    if (status) params.set('status', status);

    const data = await api(`/api/endorsements?${params}`);
    const endorsements = data.endorsements || [];
    document.getElementById('endorsements-loading').style.display = 'none';

    // Compliance banner: count expired
    const expiredStudents = new Set(
      endorsements.filter(e => e.expiration_date && new Date(e.expiration_date) < new Date())
        .map(e => e.student_id)
    );
    const banner = document.getElementById('endorsements-compliance-banner');
    if (['owner', 'admin'].includes(currentUser.role) && expiredStudents.size > 0) {
      document.getElementById('compliance-banner-text').textContent =
        `${expiredStudents.size} student${expiredStudents.size > 1 ? 's have' : ' has'} at least one expired endorsement. Review and renew as needed.`;
      banner.classList.remove('hidden');
      banner.style.display = 'flex';
    } else {
      banner.classList.add('hidden');
      banner.style.display = 'none';
    }

    document.getElementById('endorsement-count').textContent = `${endorsements.length} endorsement${endorsements.length !== 1 ? 's' : ''}`;

    if (endorsements.length === 0) {
      document.getElementById('endorsements-empty').classList.remove('hidden');
      const emptyText = currentUser.role === 'student'
        ? 'Your endorsements will appear here once your instructor creates them.'
        : 'Create your first endorsement using the button above.';
      document.getElementById('endorsements-empty-text').textContent = emptyText;
      return;
    }

    const tbody = document.getElementById('endorsements-tbody');
    const today = new Date();

    endorsements.forEach(e => {
      const isExpired = e.expiration_date && new Date(e.expiration_date) < today;
      const expiresDate = e.expiration_date
        ? new Date(toDateOnly(e.expiration_date) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        : '—';
      const endorseDate = new Date(toDateOnly(e.endorsement_date) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

      // Days to expiry
      let expiryText = expiresDate;
      let expiryStyle = '';
      if (e.expiration_date) {
        const daysLeft = Math.ceil((new Date(toDateOnly(e.expiration_date) + 'T23:59:59') - today) / (1000 * 60 * 60 * 24));
        if (isExpired) {
          expiryStyle = 'color:var(--red);font-weight:600';
          expiryText = `${expiresDate} (expired)`;
        } else if (daysLeft <= 14) {
          expiryStyle = 'color:var(--amber);font-weight:600';
          expiryText = `${expiresDate} (${daysLeft}d)`;
        }
      }

      const statusBadge = !e.instructor_signature
        ? `<span style="font-size:0.72rem;background:rgba(245,158,11,0.1);color:var(--amber);border:1px solid rgba(245,158,11,0.2);padding:0.15rem 0.6rem;border-radius:20px">Unsigned</span>`
        : isExpired
        ? `<span style="font-size:0.72rem;background:rgba(239,68,68,0.08);color:var(--red);border:1px solid rgba(239,68,68,0.15);padding:0.15rem 0.6rem;border-radius:20px">Expired</span>`
        : `<span style="font-size:0.72rem;background:rgba(34,197,94,0.08);color:var(--green);border:1px solid rgba(34,197,94,0.15);padding:0.15rem 0.6rem;border-radius:20px">Active</span>`;

      const studentTd = currentUser.role === 'student' ? '' : `<td>${e.student_name || e.student_name_user}</td>`;
      const instrTd = `<td>${e.instructor_name || e.instructor_name_user}</td>`;

      tbody.innerHTML += `
        <tr style="cursor:pointer" onclick="openEndorsementDetail(${e.id})">
          <td style="max-width:220px">
            <div style="font-weight:600;font-size:0.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${e.endorsement_type}</div>
            ${e.aircraft_make_model ? `<div style="font-size:0.75rem;color:var(--gray-400)">${e.aircraft_make_model}</div>` : ''}
          </td>
          ${studentTd}
          ${instrTd}
          <td style="white-space:nowrap">${endorseDate}</td>
          <td style="white-space:nowrap;${expiryStyle}">${expiryText}</td>
          <td>${statusBadge}</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();downloadPDF(${e.id})">PDF</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    document.getElementById('endorsements-loading').style.display = 'none';
    console.error('Load endorsements error:', err);
  }
}

// ── New Endorsement Modal ─────────────────────────────
async function openNewEndorsementModal() {
  // Check CFI profile first
  try {
    const profile = await api('/api/users/me/cfi-profile');
    if (!profile.cfi_cert_number) {
      const go = confirm('You need to set your CFI certificate number before creating endorsements. Go to CFI Profile?');
      if (go) openCFIProfileModal();
      return;
    }
  } catch { /* no-op */ }

  document.getElementById('new-endorsement-error').classList.add('hidden');
  document.getElementById('new-endorsement-step1').classList.remove('hidden');
  document.getElementById('new-endorsement-step2').classList.add('hidden');

  // Populate students
  const studentSel = document.getElementById('endorse-student');
  studentSel.innerHTML = '<option value="">Select student...</option>';
  allUsers.filter(u => u.role === 'student').forEach(u => {
    const opt = document.createElement('option');
    opt.value = u.id; opt.textContent = u.name;
    studentSel.appendChild(opt);
  });

  // Populate templates grouped by category
  const templateSel = document.getElementById('endorse-template');
  templateSel.innerHTML = '<option value="">Select endorsement type...</option>';
  const categories = {};
  endorsementTemplates.forEach(t => {
    if (!categories[t.category]) categories[t.category] = [];
    categories[t.category].push(t);
  });
  Object.entries(categories).forEach(([cat, templates]) => {
    const grp = document.createElement('optgroup');
    grp.label = cat;
    templates.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.key; opt.textContent = t.label;
      grp.appendChild(opt);
    });
    templateSel.appendChild(grp);
  });

  // Default date = today
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('endorse-date').value = today;
  document.getElementById('endorse-aircraft-row').classList.add('hidden');
  document.getElementById('endorse-custom-text-row').classList.add('hidden');
  document.getElementById('endorse-preview-box').classList.add('hidden');

  // Populate fleet aircraft dropdown (active/available aircraft only)
  try {
    const fleetData = await api('/api/aircraft');
    const aircraftSel = document.getElementById('endorse-aircraft-select');
    // Rebuild select: placeholder + active fleet + Other
    aircraftSel.innerHTML = '<option value="">Select from fleet...</option>';
    const activeFleet = fleetData.filter(a => a.status === 'available' || a.status === 'active');
    activeFleet.forEach(a => {
      const opt = document.createElement('option');
      opt.value = a.id;
      opt.dataset.makeModel = a.make_model;
      opt.textContent = `${a.tail_number} \u2014 ${a.make_model}`;
      aircraftSel.appendChild(opt);
    });
    const otherOpt = document.createElement('option');
    otherOpt.value = '__other__';
    otherOpt.textContent = '\u270F Other \u2014 type manually';
    aircraftSel.appendChild(otherOpt);
  } catch (e) {
    // Fleet fetch failed — user can still use the "Other" option
  }

  // Reset aircraft fields
  document.getElementById('endorse-aircraft-select').value = '';
  document.getElementById('endorse-aircraft-id').value = '';
  document.getElementById('endorse-aircraft').value = '';
  document.getElementById('endorse-aircraft').style.display = 'none';

  document.getElementById('new-endorsement-modal').classList.remove('hidden');
}
function closeNewEndorsementModal() {
  document.getElementById('new-endorsement-modal').classList.add('hidden');
}

function onEndorseTemplateChange() {
  const key = document.getElementById('endorse-template').value;
  const tpl = endorsementTemplates.find(t => t.key === key);
  if (!tpl) {
    document.getElementById('endorse-aircraft-row').classList.add('hidden');
    document.getElementById('endorse-custom-text-row').classList.add('hidden');
    document.getElementById('endorse-preview-box').classList.add('hidden');
    return;
  }
  document.getElementById('endorse-aircraft-row').classList.toggle('hidden', !tpl.requiresAircraft);
  document.getElementById('endorse-custom-text-row').classList.toggle('hidden', key !== 'custom');
  updateEndorsePreview();
}

function onEndorseAircraftSelectChange() {
  const sel = document.getElementById('endorse-aircraft-select');
  const textInput = document.getElementById('endorse-aircraft');
  const idInput = document.getElementById('endorse-aircraft-id');
  const val = sel.value;

  if (val === '' || val === '__other__') {
    // Show the text input for manual entry
    textInput.style.display = 'block';
    idInput.value = '';
    if (val === '__other__') {
      textInput.value = '';
      textInput.focus();
    }
  } else {
    // A fleet aircraft was selected — auto-fill text and store aircraft_id
    const selectedOpt = sel.options[sel.selectedIndex];
    textInput.value = selectedOpt.dataset.makeModel || '';
    textInput.style.display = 'none';
    idInput.value = val;
  }
  updateEndorsePreview();
}

function updateEndorsePreview() {
  const key = document.getElementById('endorse-template').value;
  const tpl = endorsementTemplates.find(t => t.key === key);
  if (!tpl) return;

  const studentSel = document.getElementById('endorse-student');
  const studentName = studentSel.options[studentSel.selectedIndex]?.text || '';
  const aircraft = document.getElementById('endorse-aircraft').value || '[aircraft make/model]';
  const date = document.getElementById('endorse-date').value || new Date().toISOString().split('T')[0];
  const customText = document.getElementById('endorse-custom-text').value;

  const box = document.getElementById('endorse-preview-box');
  box.classList.remove('hidden');
  const textEl = document.getElementById('endorse-preview-text');

  if (key === 'custom') {
    textEl.textContent = customText || '[Enter endorsement text above]';
  } else if (!studentName || studentName === 'Select student...') {
    textEl.textContent = '[Select a student above to see the endorsement preview]';
  } else if (tpl.textPattern) {
    // Generate preview from server-provided template pattern
    textEl.textContent = tpl.textPattern
      .replace(/\{\{STUDENT\}\}/g, studentName)
      .replace(/\{\{DATE\}\}/g, date)
      .replace(/\{\{AIRCRAFT\}\}/g, aircraft);
  } else {
    textEl.textContent = '[Preview unavailable for this template]';
  }

  const expiryNotice = document.getElementById('endorse-expiry-notice');
  if (tpl.hasExpiry && tpl.expiryDays) {
    const d = new Date(date);
    d.setDate(d.getDate() + tpl.expiryDays);
    expiryNotice.textContent = `⚠ This endorsement expires ${tpl.expiryDays} days from the endorsement date (${d.toLocaleDateString()}).`;
    expiryNotice.classList.remove('hidden');
  } else {
    expiryNotice.classList.add('hidden');
  }
}

function proceedToSignature() {
  const errEl = document.getElementById('new-endorsement-error');
  errEl.classList.add('hidden');
  const studentId = document.getElementById('endorse-student').value;
  const templateKey = document.getElementById('endorse-template').value;
  const date = document.getElementById('endorse-date').value;
  const tpl = endorsementTemplates.find(t => t.key === templateKey);

  if (!studentId) { errEl.textContent = 'Please select a student'; errEl.classList.remove('hidden'); return; }
  if (!templateKey) { errEl.textContent = 'Please select an endorsement type'; errEl.classList.remove('hidden'); return; }
  if (!date) { errEl.textContent = 'Please enter a date'; errEl.classList.remove('hidden'); return; }
  if (tpl?.requiresAircraft && !document.getElementById('endorse-aircraft').value.trim()) {
    errEl.textContent = 'Please select an aircraft from the fleet or choose \u201COther\u201D to type manually'; errEl.classList.remove('hidden'); return;
  }
  if (templateKey === 'custom' && !document.getElementById('endorse-custom-text').value.trim()) {
    errEl.textContent = 'Please enter the endorsement text'; errEl.classList.remove('hidden'); return;
  }

  document.getElementById('new-endorsement-step1').classList.add('hidden');
  document.getElementById('new-endorsement-step2').classList.remove('hidden');
  document.getElementById('endorse-submit-error').classList.add('hidden');

  // Init signature pad
  setTimeout(() => {
    cfiSigPad = initSigPad('cfi-sig-canvas');
  }, 50);
}

function backToEndorseStep1() {
  document.getElementById('new-endorsement-step1').classList.remove('hidden');
  document.getElementById('new-endorsement-step2').classList.add('hidden');
}

async function submitEndorsement() {
  const errEl = document.getElementById('endorse-submit-error');
  errEl.classList.add('hidden');

  if (!cfiSigPad || cfiSigPad.isEmpty()) {
    errEl.textContent = 'Please sign before submitting';
    errEl.classList.remove('hidden');
    return;
  }

  const btn = document.getElementById('endorse-submit-btn');
  btn.disabled = true;
  btn.textContent = 'Saving...';

  try {
    const studentId = parseInt(document.getElementById('endorse-student').value);
    const templateKey = document.getElementById('endorse-template').value;
    const date = document.getElementById('endorse-date').value;
    const aircraft = document.getElementById('endorse-aircraft').value.trim();
    const aircraftId = document.getElementById('endorse-aircraft-id').value;
    const customText = document.getElementById('endorse-custom-text').value.trim();
    const sigDataUrl = cfiSigPad.toDataURL();

    const payload = {
      student_id: studentId,
      template_key: templateKey,
      endorsement_date: date,
      aircraft_make_model: aircraft || null,
      aircraft_id: aircraftId ? parseInt(aircraftId) : null,
      custom_text: customText || null,
      instructor_signature: sigDataUrl,
    };

    await api('/api/endorsements', { method: 'POST', body: JSON.stringify(payload) });

    closeNewEndorsementModal();
    showToast('Endorsement created');
    loadEndorsements();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to create endorsement';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = '✍ Sign & Create Endorsement';
  }
}

function clearCFISig() {
  if (cfiSigPad) cfiSigPad.clear();
}

// ── Endorsement Detail Modal ──────────────────────────
async function openEndorsementDetail(id) {
  currentEndorsementId = id;
  document.getElementById('endorsement-detail-modal').classList.remove('hidden');

  try {
    const data = await api(`/api/endorsements/${id}`);
    const e = data.endorsement;

    document.getElementById('detail-endorsement-type').textContent = e.endorsement_type;
    document.getElementById('detail-student').textContent = e.student_name;
    document.getElementById('detail-instructor').textContent = e.instructor_name;
    document.getElementById('detail-cfi-cert').textContent = e.instructor_cert_number;
    document.getElementById('detail-date').textContent = new Date(toDateOnly(e.endorsement_date) + 'T12:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('detail-text').textContent = e.endorsement_text;

    if (e.aircraft_make_model) {
      document.getElementById('detail-aircraft-row').classList.remove('hidden');
      document.getElementById('detail-aircraft').textContent = e.aircraft_make_model;
    } else {
      document.getElementById('detail-aircraft-row').classList.add('hidden');
    }

    // Expiry
    const isExpired = e.expiration_date && new Date(e.expiration_date) < new Date();
    if (e.expiration_date) {
      const expiryStr = new Date(toDateOnly(e.expiration_date) + 'T12:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
      document.getElementById('detail-expiry').textContent = isExpired ? `${expiryStr} (EXPIRED)` : expiryStr;
      document.getElementById('detail-expiry').style.color = isExpired ? 'var(--red)' : 'var(--white)';
    } else {
      document.getElementById('detail-expiry').textContent = 'No expiration';
      document.getElementById('detail-expiry').style.color = 'var(--gray-400)';
    }

    // Status badge
    const badge = document.getElementById('detail-status-badge');
    if (!e.instructor_signature) {
      badge.textContent = 'Unsigned'; badge.style.background = 'rgba(245,158,11,0.1)'; badge.style.color = 'var(--amber)';
    } else if (isExpired) {
      badge.textContent = 'Expired'; badge.style.background = 'rgba(239,68,68,0.08)'; badge.style.color = 'var(--red)';
    } else {
      badge.textContent = 'Active'; badge.style.background = 'rgba(34,197,94,0.08)'; badge.style.color = 'var(--green)';
    }

    // CFI Signature
    const cfiSigImg = document.getElementById('detail-cfi-sig');
    if (e.instructor_signature) {
      cfiSigImg.src = e.instructor_signature;
      cfiSigImg.style.display = '';
    } else {
      cfiSigImg.src = ''; cfiSigImg.style.display = 'none';
    }
    document.getElementById('detail-signed-at').textContent = e.signed_at ? `Signed: ${new Date(e.signed_at).toLocaleString()}` : '';

    // Student Signature
    const stuSigImg = document.getElementById('detail-student-sig');
    if (e.student_signature) {
      stuSigImg.src = e.student_signature;
      stuSigImg.style.display = '';
    } else {
      stuSigImg.src = ''; stuSigImg.style.display = 'none';
    }
    document.getElementById('detail-student-signed-at').textContent = e.student_signed_at ? `Signed: ${new Date(e.student_signed_at).toLocaleString()}` : '';

    // Student sign button
    const stuSignBtn = document.getElementById('detail-student-sign-btn');
    if (currentUser.role === 'student' && e.student_id === currentUser.id && !e.student_signature) {
      stuSignBtn.style.display = '';
    } else {
      stuSignBtn.style.display = 'none';
    }

    // Audit
    document.getElementById('detail-audit').textContent = `ID: ${e.id} · Created: ${new Date(e.created_at).toLocaleString()}${e.ip_address ? ` · IP: ${e.ip_address}` : ''}`;

    // Delete button: instructor who created it, or owner/admin
    const deleteBtn = document.getElementById('detail-delete-btn');
    const canDelete = ['owner', 'admin'].includes(currentUser.role) ||
      (currentUser.role === 'instructor' && e.instructor_id === currentUser.id);
    deleteBtn.style.display = canDelete ? '' : 'none';
  } catch (err) {
    console.error('Load endorsement detail error:', err);
  }
}

function closeEndorsementDetailModal() {
  document.getElementById('endorsement-detail-modal').classList.add('hidden');
  currentEndorsementId = null;
}

async function deleteEndorsement() {
  if (!currentEndorsementId) return;
  if (!confirm('Delete this endorsement? This cannot be undone.')) return;
  try {
    await api(`/api/endorsements/${currentEndorsementId}`, { method: 'DELETE' });
    closeEndorsementDetailModal();
    showToast('Endorsement deleted');
    loadEndorsements();
  } catch (err) {
    alert(err.error || 'Failed to delete endorsement');
  }
}

function downloadEndorsementPDF() {
  if (!currentEndorsementId) return;
  const tokenVal = token || localStorage.getItem('fs_token');
  const a = document.createElement('a');
  a.href = `/api/endorsements/${currentEndorsementId}/pdf`;
  a.click();
}

function downloadPDF(id) {
  const a = document.createElement('a');
  a.href = `/api/endorsements/${id}/pdf`;
  a.click();
}

// ── Student Sign Modal ────────────────────────────────
function openStudentSignModal() {
  document.getElementById('student-sign-error').classList.add('hidden');
  document.getElementById('student-sign-modal').classList.remove('hidden');
  setTimeout(() => {
    studentSigPad = initSigPad('student-sig-canvas');
  }, 50);
}
function closeStudentSignModal() {
  document.getElementById('student-sign-modal').classList.add('hidden');
}
function clearStudentSig() {
  if (studentSigPad) studentSigPad.clear();
}

async function submitStudentSignature() {
  const errEl = document.getElementById('student-sign-error');
  errEl.classList.add('hidden');

  if (!studentSigPad || studentSigPad.isEmpty()) {
    errEl.textContent = 'Please sign before submitting';
    errEl.classList.remove('hidden');
    return;
  }

  try {
    const sigDataUrl = studentSigPad.toDataURL();
    await api(`/api/endorsements/${currentEndorsementId}/student-sign`, {
      method: 'POST',
      body: JSON.stringify({ student_signature: sigDataUrl }),
    });
    closeStudentSignModal();
    showToast('Signature saved');
    openEndorsementDetail(currentEndorsementId);
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save signature';
    errEl.classList.remove('hidden');
  }
}

// ─── END DIGITAL ENDORSEMENTS ─────────────────────────

// ─── LIVE TRACKING ───────────────────────────────────────

let trackingMap = null;
let trackingMarkers = {}; // tailNumber → Leaflet marker
let trackingRefreshTimer = null;
let trackingCountdown = 60;
let trackingCountdownTimer = null;
let trackingSelectedTail = null;

async function loadTracking() {
  // Lazy-load Leaflet JS from CDN if not yet loaded
  if (!window.L) {
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      s.crossOrigin = '';
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  clearTrackingTimers();
  showTrackingLoading(true);

  try {
    const data = await api('/api/flights/tracking');
    showTrackingLoading(false);

    const faSection = document.getElementById('tracking-flightaware-section');
    if (!data.api_key_configured) {
      document.getElementById('tracking-no-key').classList.remove('hidden');
      if (faSection) faSection.classList.add('hidden');
      return;
    }

    document.getElementById('tracking-no-key').classList.add('hidden');
    if (faSection) faSection.classList.remove('hidden');

    renderTrackingFleet(data.aircraft);
    renderTrackingMap(data.aircraft);
    startTrackingRefresh();
  } catch (err) {
    showTrackingLoading(false);
    document.getElementById('tracking-error').classList.remove('hidden');
    document.getElementById('tracking-error-msg').textContent = 'Failed to load tracking data. Check your connection.';
  }
}

function showTrackingLoading(on) {
  document.getElementById('tracking-loading').classList.toggle('hidden', !on);
  const fg = document.getElementById('tracking-fleet-grid');
  if (fg) fg.style.visibility = on ? 'hidden' : '';
  document.getElementById('tracking-error').classList.add('hidden');
}

function startTrackingRefresh() {
  trackingCountdown = 60;
  updateTrackingLabel();

  trackingCountdownTimer = setInterval(() => {
    trackingCountdown--;
    updateTrackingLabel();
    if (trackingCountdown <= 0) {
      trackingCountdown = 60;
      refreshTracking();
    }
  }, 1000);
}

function updateTrackingLabel() {
  const el = document.getElementById('tracking-last-updated');
  if (el) el.textContent = `GPS refresh: ${trackingCountdown}s`;
}

function clearTrackingTimers() {
  clearInterval(trackingRefreshTimer);
  clearInterval(trackingCountdownTimer);
}

async function refreshTracking() {
  clearTrackingTimers();
  try {
    const data = await api('/api/flights/tracking');
    if (data.api_key_configured) {
      renderTrackingFleet(data.aircraft);
      renderTrackingMap(data.aircraft);
      if (trackingSelectedTail) {
        const entry = data.aircraft.find(a => a.aircraft.tail_number === trackingSelectedTail);
        if (entry) showTrackingDetail(entry);
      }
    }
  } catch {}
  startTrackingRefresh();
}

function renderTrackingFleet(aircraft) {
  const grid = document.getElementById('tracking-fleet-grid');
  if (!aircraft.length) {
    grid.innerHTML = '<div style="color:var(--gray-500);font-size:0.9rem;padding:0.5rem;">No aircraft in fleet.</div>';
    return;
  }

  grid.innerHTML = aircraft.map(entry => {
    const ac = entry.aircraft;
    const status = entry.flight_status;
    const isInFlight = status === 'in_flight';
    const isUnknown = status === 'unknown';
    const badgeColor = isInFlight ? 'var(--sky)' : isUnknown ? 'var(--gray-500)' : 'var(--green)';
    const badgeBg = isInFlight ? 'rgba(56,189,248,0.12)' : isUnknown ? 'rgba(100,116,139,0.15)' : 'rgba(34,197,94,0.12)';
    const badgeIcon = isInFlight ? '✈️' : isUnknown ? '❓' : '🅿️';
    const badgeLabel = isInFlight ? 'In Flight' : isUnknown ? 'Unknown' : 'On Ground';
    const isSelected = ac.tail_number === trackingSelectedTail;

    return `<div onclick="selectTrackingAircraft('${ac.tail_number}')"
      style="background:var(--dark-blue-2);border:1.5px solid ${isSelected ? 'var(--sky)' : 'var(--border)'};border-radius:10px;padding:1rem;cursor:pointer;transition:border-color 0.15s;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.5rem;">
        <div style="font-weight:700;font-size:1rem;color:var(--white);">${ac.tail_number}</div>
        <span style="background:${badgeBg};color:${badgeColor};font-size:0.72rem;font-weight:600;padding:0.2rem 0.55rem;border-radius:20px;white-space:nowrap;">${badgeIcon} ${badgeLabel}</span>
      </div>
      <div style="font-size:0.82rem;color:var(--gray-400);">${ac.make_model || '—'}</div>
      ${entry.flight && entry.flight.origin ? `<div style="font-size:0.78rem;color:var(--gray-500);margin-top:0.35rem;">
        ${entry.flight.origin.code || '?'} → ${(entry.flight.destination && entry.flight.destination.code) || '?'}
      </div>` : ''}
    </div>`;
  }).join('');
}

function selectTrackingAircraft(tailNumber) {
  trackingSelectedTail = tailNumber;
  // Re-render fleet grid to update selection highlight
  const cards = document.querySelectorAll('#tracking-fleet-grid > div');
  cards.forEach(card => {
    const isSelected = card.querySelector('div[style*="font-weight:700"]')?.textContent === tailNumber;
    card.style.borderColor = isSelected ? 'var(--sky)' : 'var(--border)';
  });

  // Find the data
  api('/api/flights/tracking').then(data => {
    const entry = data.aircraft.find(a => a.aircraft.tail_number === tailNumber);
    if (entry) showTrackingDetail(entry);
    // Pan map to this aircraft if it has a position
    if (entry && entry.flight && entry.flight.last_position && trackingMap) {
      const pos = entry.flight.last_position;
      trackingMap.setView([pos.latitude, pos.longitude], 10, { animate: true });
    }
  }).catch(() => {});
}

function showTrackingDetail(entry) {
  const ac = entry.aircraft;
  const fl = entry.flight;
  const detailEl = document.getElementById('tracking-detail-content');
  const emptyEl = document.getElementById('tracking-detail-empty');
  detailEl.classList.remove('hidden');
  emptyEl.classList.add('hidden');

  if (!fl) {
    detailEl.innerHTML = `
      <div style="text-align:center;padding:1rem 0;color:var(--gray-500);">
        <div style="font-size:2rem;margin-bottom:0.5rem;">📡</div>
        <div style="font-weight:600;color:var(--white);margin-bottom:0.3rem;">${ac.tail_number}</div>
        <div style="font-size:0.83rem;">${ac.make_model || ''}</div>
        <div style="margin-top:1rem;font-size:0.82rem;">No tracking data available from FlightAware.</div>
      </div>`;
    return;
  }

  const pos = fl.last_position;
  const statusColor = fl.flight_status === 'in_flight' ? 'var(--sky)' : 'var(--green)';
  const statusLabel = fl.flight_status === 'in_flight' ? '✈️ In Flight' : '🅿️ On Ground';

  const fmtTime = (t) => {
    if (!t) return '—';
    try { return new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return t; }
  };
  const fmtDate = (t) => {
    if (!t) return '—';
    try { return new Date(t).toLocaleDateString([], { month: 'short', day: 'numeric' }); } catch { return t; }
  };

  detailEl.innerHTML = `
    <div style="font-weight:700;font-size:1.1rem;color:var(--white);">${ac.tail_number}</div>
    <div style="font-size:0.82rem;color:var(--gray-400);margin-bottom:0.5rem;">${ac.make_model || ''}</div>
    <span style="background:${fl.flight_status === 'in_flight' ? 'rgba(56,189,248,0.12)' : 'rgba(34,197,94,0.12)'};color:${statusColor};font-size:0.78rem;font-weight:600;padding:0.25rem 0.65rem;border-radius:20px;">${statusLabel}</span>

    ${fl.origin || fl.destination ? `
    <div style="margin-top:1rem;background:var(--dark-blue-2);border-radius:8px;padding:0.85rem;">
      <div style="display:flex;align-items:center;gap:0.5rem;font-size:0.88rem;">
        <div style="text-align:center;">
          <div style="font-weight:700;color:var(--white);font-size:1.05rem;">${fl.origin?.code || '?'}</div>
          <div style="font-size:0.72rem;color:var(--gray-500);">${fl.origin?.city || fl.origin?.name || ''}</div>
        </div>
        <div style="flex:1;text-align:center;color:var(--sky);font-size:1.1rem;">→</div>
        <div style="text-align:center;">
          <div style="font-weight:700;color:var(--white);font-size:1.05rem;">${fl.destination?.code || '?'}</div>
          <div style="font-size:0.72rem;color:var(--gray-500);">${fl.destination?.city || fl.destination?.name || ''}</div>
        </div>
      </div>
      ${fl.progress_percent != null ? `
      <div style="margin-top:0.6rem;">
        <div style="height:4px;background:var(--border);border-radius:2px;overflow:hidden;">
          <div style="height:100%;width:${Math.min(100, fl.progress_percent)}%;background:var(--sky);transition:width 0.5s;"></div>
        </div>
        <div style="text-align:center;font-size:0.72rem;color:var(--gray-500);margin-top:0.25rem;">${fl.progress_percent}% complete</div>
      </div>` : ''}
    </div>` : ''}

    <div style="margin-top:0.75rem;display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
      ${pos ? `
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;text-align:center;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.2rem;">ALTITUDE</div>
        <div style="font-weight:600;color:var(--white);font-size:0.92rem;">${pos.altitude ? pos.altitude.toLocaleString() + ' ft' : '—'}</div>
      </div>
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;text-align:center;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.2rem;">GROUNDSPEED</div>
        <div style="font-weight:600;color:var(--white);font-size:0.92rem;">${pos.groundspeed ? pos.groundspeed + ' kts' : '—'}</div>
      </div>
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;text-align:center;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.2rem;">HEADING</div>
        <div style="font-weight:600;color:var(--white);font-size:0.92rem;">${pos.heading != null ? pos.heading + '°' : '—'}</div>
      </div>
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;text-align:center;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.2rem;">POSITION</div>
        <div style="font-weight:600;color:var(--white);font-size:0.78rem;">${pos.latitude?.toFixed(3)}°, ${pos.longitude?.toFixed(3)}°</div>
      </div>` : '<div style="grid-column:1/-1;text-align:center;color:var(--gray-500);font-size:0.82rem;padding:0.5rem;">No position data</div>'}
    </div>

    <div style="margin-top:0.75rem;display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.1rem;">DEPARTED</div>
        <div style="font-size:0.82rem;color:var(--white);">${fmtDate(fl.departure_time)}</div>
        <div style="font-size:0.78rem;color:var(--gray-400);">${fmtTime(fl.departure_time)}</div>
      </div>
      <div style="background:var(--dark-blue-2);border-radius:7px;padding:0.65rem;">
        <div style="font-size:0.7rem;color:var(--gray-500);margin-bottom:0.1rem;">${fl.flight_status === 'in_flight' ? 'ETA' : 'ARRIVED'}</div>
        <div style="font-size:0.82rem;color:var(--white);">${fmtDate(fl.arrival_time)}</div>
        <div style="font-size:0.78rem;color:var(--gray-400);">${fmtTime(fl.arrival_time)}</div>
      </div>
    </div>`;
}

function renderTrackingMap(aircraft) {
  if (!window.L) return;

  const mapEl = document.getElementById('tracking-map');
  if (!mapEl) return;

  // Initialize map once
  if (!trackingMap) {
    trackingMap = L.map('tracking-map', {
      center: [32.7767, -96.7970], // Default: Dallas area (NTA is in TX)
      zoom: 6,
      zoomControl: true
    });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a>'
    }).addTo(trackingMap);
  }

  // Clear existing markers
  Object.values(trackingMarkers).forEach(m => trackingMap.removeLayer(m));
  trackingMarkers = {};

  const positions = [];

  aircraft.forEach(entry => {
    const ac = entry.aircraft;
    const fl = entry.flight;
    if (!fl || !fl.last_position) return;

    const pos = fl.last_position;
    const heading = pos.heading || 0;
    const isInFlight = fl.flight_status === 'in_flight';

    // SVG airplane icon rotated to heading
    const svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32" style="transform:rotate(${heading}deg);filter:drop-shadow(0 1px 3px rgba(0,0,0,0.7))">
      <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" fill="${isInFlight ? '#38BDF8' : '#22C55E'}"/>
    </svg>`;

    const icon = L.divIcon({
      html: `<div style="position:relative;text-align:center;">
        ${svgIcon}
        <div style="position:absolute;top:100%;left:50%;transform:translateX(-50%);white-space:nowrap;background:rgba(13,21,37,0.85);color:#F1F5F9;font-size:10px;font-weight:700;padding:1px 5px;border-radius:3px;margin-top:2px;">${ac.tail_number}</div>
      </div>`,
      iconSize: [40, 48],
      iconAnchor: [20, 16],
      className: ''
    });

    const marker = L.marker([pos.latitude, pos.longitude], { icon }).addTo(trackingMap);
    marker.bindPopup(`<strong>${ac.tail_number}</strong><br>${ac.make_model || ''}<br>Alt: ${pos.altitude ? pos.altitude.toLocaleString() + ' ft' : '—'}<br>Speed: ${pos.groundspeed ? pos.groundspeed + ' kts' : '—'}`);
    marker.on('click', () => selectTrackingAircraft(ac.tail_number));
    trackingMarkers[ac.tail_number] = marker;
    positions.push([pos.latitude, pos.longitude]);
  });

  // Show overlay if no positions
  const overlay = document.getElementById('tracking-map-overlay');
  if (positions.length === 0) {
    overlay.classList.remove('hidden');
    overlay.style.display = 'flex';
  } else {
    overlay.classList.add('hidden');
    overlay.style.display = 'none';
    // Fit map to show all aircraft
    if (positions.length === 1) {
      trackingMap.setView(positions[0], 9);
    } else {
      trackingMap.fitBounds(positions, { padding: [40, 40] });
    }
  }

  // Force map to recalculate size (needed when shown after hidden)
  setTimeout(() => trackingMap && trackingMap.invalidateSize(), 150);
}

// ─── TRACK FLIGHTS (internal flight board + maintenance schedule) ─────────────

let trackFlightsTimer = null;

async function loadTrackFlights() {
  clearInterval(trackFlightsTimer);

  // Load all three sections in parallel
  await Promise.all([loadLiveFlights(), loadMaintenanceSchedule()]);

  // Also attempt FlightAware GPS if configured
  loadTracking().catch(() => {});

  // Auto-refresh every 60s
  trackFlightsTimer = setInterval(loadTrackFlights, 60 * 1000);
  const lu = document.getElementById('tracking-last-updated');
  if (lu) lu.textContent = `Updated ${new Date().toLocaleTimeString()}`;
}

async function loadLiveFlights() {
  const loadingEl = document.getElementById('live-flights-loading');
  const emptyEl = document.getElementById('live-flights-empty');
  const gridEl = document.getElementById('live-flights-grid');

  try {
    const data = await api('/api/track-flights/live');
    if (loadingEl) loadingEl.style.display = 'none';

    if (!data.flights || data.flights.length === 0) {
      if (emptyEl) emptyEl.classList.remove('hidden');
      if (gridEl) gridEl.classList.add('hidden');
      // Also load recent completed flights
      loadRecentFlights();
      return;
    }

    if (emptyEl) emptyEl.classList.add('hidden');
    if (gridEl) {
      gridEl.classList.remove('hidden');
      gridEl.innerHTML = data.flights.map(f => {
        const elapsed = f.start_time ? Math.round((Date.now() - new Date(f.start_time)) / 60000) : 0;
        return `
          <div style="background:var(--dark-blue);border:1px solid rgba(56,189,248,0.2);border-radius:12px;padding:1.25rem;position:relative;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
              <div style="font-family:'Space Grotesk';font-size:1.1rem;font-weight:700;color:var(--white);">${f.tail_number}</div>
              <span style="background:rgba(34,197,94,0.12);color:var(--green);font-size:0.65rem;font-weight:700;padding:0.2rem 0.6rem;border-radius:5px;text-transform:uppercase;letter-spacing:0.4px;">&#x25CF; In Flight</span>
            </div>
            <div style="font-size:0.82rem;color:var(--gray-300);margin-bottom:0.15rem;">${f.make_model || ''}</div>
            <div style="height:1px;background:var(--border);margin:0.75rem 0;"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;font-size:0.82rem;">
              <div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Student</div><div style="color:var(--gray-200);">${f.student_name}</div></div>
              <div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Instructor</div><div style="color:var(--gray-200);">${f.instructor_name}</div></div>
              <div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Departed</div><div style="color:var(--sky);">${new Date(f.start_time).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div></div>
              <div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Elapsed</div><div style="color:var(--gray-200);">${elapsed}m</div></div>
              ${f.hobbs_start ? `<div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Hobbs Start</div><div style="color:var(--gray-200);">${f.hobbs_start}</div></div>` : ''}
              ${f.lesson_type ? `<div><div style="font-size:0.62rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:0.1rem;">Type</div><div style="color:var(--gray-200);">${f.lesson_type}</div></div>` : ''}
            </div>
          </div>`;
      }).join('');
    }
    loadRecentFlights();
  } catch (err) {
    if (loadingEl) loadingEl.style.display = 'none';
    if (emptyEl) emptyEl.classList.remove('hidden');
  }
}

async function loadRecentFlights() {
  const loadingEl = document.getElementById('recent-flights-loading');
  const emptyEl = document.getElementById('recent-flights-empty');
  const tableEl = document.getElementById('recent-flights-table');
  const tbody = document.getElementById('recent-flights-tbody');
  try {
    const data = await api('/api/track-flights/recent');
    if (!data.flights || data.flights.length === 0) {
      if (emptyEl) emptyEl.classList.remove('hidden');
      if (tableEl) tableEl.classList.add('hidden');
      return;
    }
    if (emptyEl) emptyEl.classList.add('hidden');
    if (tableEl) tableEl.classList.remove('hidden');
    if (tbody) tbody.innerHTML = data.flights.map(f => `
      <tr>
        <td><strong>${f.tail_number}</strong><br><small style="color:var(--gray-500)">${f.make_model||''}</small></td>
        <td>${f.student_name}</td>
        <td>${f.instructor_name}</td>
        <td>${new Date(f.start_time).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</td>
        <td>${new Date(f.end_time).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</td>
        <td>${f.hobbs_start && f.hobbs_end ? (f.hobbs_end - f.hobbs_start).toFixed(1) + ' hrs' : '—'}</td>
      </tr>`).join('');
  } catch { /* suppress */ }
}

async function loadMaintenanceSchedule() {
  const loadingEl = document.getElementById('maint-schedule-loading');
  const gridEl = document.getElementById('maint-schedule-grid');
  try {
    const data = await api('/api/track-flights/maintenance-schedule');
    if (loadingEl) loadingEl.style.display = 'none';
    if (!data.schedule || data.schedule.length === 0) {
      if (gridEl) { gridEl.classList.remove('hidden'); gridEl.innerHTML = '<div style="color:var(--gray-500);font-size:0.9rem;padding:0.5rem;">No aircraft found.</div>'; }
      return;
    }
    if (gridEl) {
      gridEl.classList.remove('hidden');
      gridEl.innerHTML = data.schedule.map(ac => {
        const statusColor = ac.schedule_status === 'critical' ? 'var(--red)' : ac.schedule_status === 'warning' ? 'var(--amber)' : 'var(--green)';
        const statusBg = ac.schedule_status === 'critical' ? 'rgba(239,68,68,0.08)' : ac.schedule_status === 'warning' ? 'rgba(245,158,11,0.08)' : 'rgba(34,197,94,0.08)';
        const statusBorder = ac.schedule_status === 'critical' ? 'rgba(239,68,68,0.25)' : ac.schedule_status === 'warning' ? 'rgba(245,158,11,0.25)' : 'rgba(34,197,94,0.2)';
        const statusIcon = ac.schedule_status === 'critical' ? '🔴' : ac.schedule_status === 'warning' ? '🟡' : '🟢';

        const squawkHtml = ac.open_squawks.length ? ac.open_squawks.map(sq => `
          <div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);border-radius:7px;padding:0.6rem 0.75rem;margin-bottom:0.4rem;">
            <div style="display:flex;align-items:center;gap:0.4rem;margin-bottom:0.2rem;">
              <span style="font-size:0.6rem;font-weight:700;padding:0.1rem 0.45rem;border-radius:4px;text-transform:uppercase;background:${sq.severity==='grounding'?'rgba(239,68,68,0.15)':sq.severity==='major'?'rgba(245,158,11,0.15)':'rgba(100,116,139,0.15)'};color:${sq.severity==='grounding'?'var(--red)':sq.severity==='major'?'var(--amber)':'var(--gray-400)'};">${sq.severity}</span>
              <span style="font-size:0.6rem;color:var(--gray-500);">${sq.status}</span>
            </div>
            <div style="font-size:0.82rem;color:var(--gray-200);">${sq.description}</div>
            ${sq.expected_downtime ? `<div style="font-size:0.75rem;color:var(--amber);margin-top:0.2rem;">Est. downtime: ${sq.expected_downtime}</div>` : ''}
          </div>`).join('') : '<div style="font-size:0.82rem;color:var(--gray-500);">No open squawks</div>';

        const annual = ac.next_annual_due ? new Date(ac.next_annual_due).toLocaleDateString() : '—';
        const hobbs100 = ac.next_100hr_due ? `${ac.next_100hr_due} hrs (${ac.hours_until_100hr !== null ? ac.hours_until_100hr.toFixed(1) + ' remaining' : '—'})` : '—';
        const lastMaint = ac.last_maintenance ? `${ac.last_maintenance.description || 'Maintenance performed'} on ${new Date(ac.last_maintenance.performed_at).toLocaleDateString()}` : '—';

        return `
          <div style="background:${statusBg};border:1px solid ${statusBorder};border-radius:12px;padding:1.25rem;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
              <div style="font-family:'Space Grotesk';font-size:1.05rem;font-weight:700;color:var(--white);">${statusIcon} ${ac.tail_number}</div>
              <div style="font-size:0.72rem;color:${statusColor};font-weight:600;text-transform:uppercase;">${ac.schedule_status}</div>
            </div>
            <div style="font-size:0.8rem;color:var(--gray-400);margin-bottom:1rem;">${ac.make_model}</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;margin-bottom:1rem;font-size:0.78rem;">
              <div><div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.1rem;">Hobbs</div><div style="color:var(--gray-200);">${ac.hobbs.toFixed(1)} hrs</div></div>
              <div><div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.1rem;">Status</div><div style="color:var(--gray-200);text-transform:capitalize;">${ac.status}</div></div>
              <div><div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.1rem;">Next 100-hr</div><div style="color:${ac.hours_until_100hr !== null && ac.hours_until_100hr <= 10 ? 'var(--amber)' : 'var(--gray-200)'};">${hobbs100}</div></div>
              <div><div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.1rem;">Annual Due</div><div style="color:${ac.next_annual_due && new Date(ac.next_annual_due) <= new Date(Date.now()+30*24*60*60*1000) ? 'var(--amber)' : 'var(--gray-200)'};">${annual}</div></div>
            </div>
            <div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.4rem;">Last Maintenance</div>
            <div style="font-size:0.78rem;color:var(--gray-300);margin-bottom:1rem;">${lastMaint}</div>
            <div style="font-size:0.6rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.5rem;">Open Squawks (${ac.open_squawks.length})</div>
            ${squawkHtml}
          </div>`;
      }).join('');
    }
  } catch (err) {
    if (loadingEl) loadingEl.style.display = 'none';
    if (gridEl) { gridEl.classList.remove('hidden'); gridEl.innerHTML = '<div style="color:var(--red);font-size:0.9rem;padding:0.5rem;">Failed to load maintenance data.</div>'; }
  }
}

// ─── APPROVALS ───────────────────────────────────────────

async function loadApprovals() {
  const loadingEl = document.getElementById('approvals-loading');
  const emptyEl = document.getElementById('approvals-empty');
  const listEl = document.getElementById('approvals-list');
  const tbody = document.getElementById('approvals-tbody');
  if (!loadingEl) return;
  loadingEl.style.display = 'block';
  if (emptyEl) emptyEl.classList.add('hidden');
  if (listEl) listEl.classList.add('hidden');

  try {
    const data = await api('/api/approvals/pending');
    if (loadingEl) loadingEl.style.display = 'none';
    if (!data.users || data.users.length === 0) {
      if (emptyEl) emptyEl.classList.remove('hidden');
      return;
    }
    if (listEl) listEl.classList.remove('hidden');
    if (tbody) tbody.innerHTML = data.users.map(u => `
      <tr>
        <td><strong>${u.name}</strong></td>
        <td style="color:var(--gray-400)">${u.email}</td>
        <td><span class="tag ${u.role === 'maintenance' ? 'tag-amber' : u.role === 'instructor' ? 'tag-sky' : 'tag-green'}">${u.role}</span></td>
        <td style="color:var(--gray-500);font-size:0.82rem">${new Date(u.created_at).toLocaleDateString()}</td>
        <td>
          <div style="display:flex;gap:0.5rem;">
            <button class="btn btn-sm" style="background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2);" onclick="approveUser(${u.id})">&#10003; Approve</button>
            <button class="btn btn-sm btn-danger" onclick="rejectUser(${u.id})">&#10005; Reject</button>
          </div>
        </td>
      </tr>`).join('');
  } catch (err) {
    if (loadingEl) loadingEl.style.display = 'none';
    if (emptyEl) emptyEl.classList.remove('hidden');
  }
}

async function approveUser(id) {
  try {
    await api(`/api/approvals/${id}/approve`, { method: 'POST' });
    showToast('User approved', 'success');
    loadApprovals();
    loadApprovalsBadge();
  } catch (err) {
    showToast(err.error || 'Failed to approve user', 'error');
  }
}

async function rejectUser(id) {
  if (!confirm('Reject this user? Their account will be deleted.')) return;
  try {
    await api(`/api/approvals/${id}/reject`, { method: 'POST' });
    showToast('User rejected', 'success');
    loadApprovals();
    loadApprovalsBadge();
  } catch (err) {
    showToast(err.error || 'Failed to reject user', 'error');
  }
}

async function loadApprovalsBadge() {
  const badge = document.getElementById('approvals-badge');
  if (!badge) return;
  // Only load if user can approve (admin/owner/instructor)
  if (!currentUser || !['owner', 'admin', 'instructor'].includes(currentUser.role)) return;
  try {
    const data = await api('/api/approvals/count');
    if (data.count > 0) {
      badge.textContent = data.count;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  } catch { /* suppress */ }
}

// ─── DISCREPANCIES ───────────────────────────────────────────

let currentDiscFilter = 'all';

function setDiscrepancyFilter(filter) {
  currentDiscFilter = filter;
  ['all', 'pending', 'resolved'].forEach(f => {
    const btn = document.getElementById('disc-filter-' + f);
    if (btn) btn.classList.toggle('active', f === filter);
  });
  loadDiscrepancies();
}

async function loadDiscrepancies() {
  const loadingEl = document.getElementById('disc-loading');
  const emptyEl = document.getElementById('disc-empty');
  const listEl = document.getElementById('disc-list');
  const tbody = document.getElementById('disc-tbody');
  if (!loadingEl) return;
  loadingEl.style.display = 'block';
  if (emptyEl) emptyEl.classList.add('hidden');
  if (listEl) listEl.classList.add('hidden');
  try {
    const rows = await api('/api/discrepancies' + (currentDiscFilter !== 'all' ? '?status=' + currentDiscFilter : ''));
    loadingEl.style.display = 'none';
    if (!rows || rows.length === 0) { if (emptyEl) emptyEl.classList.remove('hidden'); return; }
    if (listEl) listEl.classList.remove('hidden');
    if (tbody) tbody.innerHTML = rows.map(d => {
      const isPending = d.status === 'pending';
      const flightDate = d.flight_date ? new Date(d.flight_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
      const flagged = d.flagged_at ? new Date(d.flagged_at).toLocaleDateString() : '—';
      const statusBadge = isPending
        ? `<span style="background:rgba(245,158,11,0.12);color:#F59E0B;border:1px solid rgba(245,158,11,0.2);padding:0.2rem 0.6rem;border-radius:999px;font-size:0.75rem;font-weight:600;">⚠️ Pending</span>`
        : `<span style="background:rgba(34,197,94,0.1);color:#22C55E;border:1px solid rgba(34,197,94,0.2);padding:0.2rem 0.6rem;border-radius:999px;font-size:0.75rem;font-weight:600;">✅ Resolved</span>`;
      const deltaColor = parseFloat(d.delta_hours) > 0.5 ? 'color:#EF4444;font-weight:700' : 'color:#F59E0B;font-weight:600';
      return `<tr style="${isPending ? '' : 'opacity:0.7'}">
        <td style="white-space:nowrap">${flightDate}</td>
        <td>${d.student_name || '—'}</td>
        <td>${d.instructor_name || '—'}</td>
        <td><span style="font-family:monospace">${d.tail_number || '—'}</span></td>
        <td style="white-space:nowrap">${d.student_hobbs_delta != null ? parseFloat(d.student_hobbs_delta).toFixed(1) + ' hrs' : '—'}<br><span style="font-size:0.75rem;color:var(--gray-500)">${d.student_hobbs_start}→${d.student_hobbs_end}</span></td>
        <td style="white-space:nowrap">${d.instructor_hobbs_delta != null ? parseFloat(d.instructor_hobbs_delta).toFixed(1) + ' hrs' : '—'}<br><span style="font-size:0.75rem;color:var(--gray-500)">${d.instructor_hobbs_start}→${d.instructor_hobbs_end}</span></td>
        <td style="${deltaColor}">${parseFloat(d.delta_hours).toFixed(2)} hrs</td>
        <td>${statusBadge}${!isPending && d.resolution_reading ? `<br><span style="font-size:0.75rem;color:var(--gray-500)">Used: ${d.resolution_reading}</span>` : ''}</td>
        <td style="color:var(--gray-500);font-size:0.82rem;white-space:nowrap">${flagged}</td>
        <td style="white-space:nowrap">${isPending
          ? `<button class="btn btn-sm" style="background:rgba(34,197,94,0.1);color:var(--green);border:1px solid rgba(34,197,94,0.2);" onclick="openDiscrepancyResolve(${d.id}, ${JSON.stringify(d).replace(/"/g,'&quot;')})">Resolve</button>`
          : (() => {
              var canDeleteDisc = currentUser && ['owner','admin'].includes(currentUser.role);
              var resolvedInfo = '<span style="color:var(--gray-500);font-size:0.8rem">' + (d.resolved_by_name || '—') + '</span>';
              var deleteBtn = canDeleteDisc
                ? '<button class="btn btn-sm" style="margin-left:0.25rem;padding:2px 7px;font-size:0.72rem;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2);" onclick="deleteDiscrepancyEntry(' + d.id + ')">&#128465;</button>'
                : '';
              return resolvedInfo + deleteBtn;
            })()
        }</td>
      </tr>`;
    }).join('');
  } catch (err) {
    loadingEl.style.display = 'none';
    if (emptyEl) emptyEl.classList.remove('hidden');
  }
}

async function loadDiscrepanciesBadge() {
  const badge = document.getElementById('discrepancies-badge');
  if (!badge) return;
  if (!currentUser || !['owner', 'admin'].includes(currentUser.role)) return;
  try {
    const data = await api('/api/discrepancies/count');
    if (data.count > 0) { badge.textContent = data.count; badge.classList.remove('hidden'); }
    else { badge.classList.add('hidden'); }
  } catch { /* suppress */ }
}

function openDiscrepancyResolve(id, d) {
  document.getElementById('disc-resolve-id').value = id;
  const errEl = document.getElementById('disc-resolve-error');
  if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
  const noteEl = document.getElementById('disc-resolve-note');
  if (noteEl) noteEl.value = '';
  const flightDate = d.flight_date ? new Date(d.flight_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
  const details = document.getElementById('disc-resolve-details');
  if (details) details.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem 1.5rem;">
      <div><div style="font-size:0.7rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.25rem">Flight Date</div><div style="font-weight:600">${flightDate}</div></div>
      <div><div style="font-size:0.7rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.25rem">Aircraft</div><div style="font-weight:600;font-family:monospace">${d.tail_number || '—'}</div></div>
      <div><div style="font-size:0.7rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.25rem">Student</div><div>${d.student_name || '—'}</div></div>
      <div><div style="font-size:0.7rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.25rem">Instructor</div><div>${d.instructor_name || '—'}</div></div>
    </div>
    <div style="margin-top:0.75rem;display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
      <div style="background:rgba(56,189,248,0.06);border:1px solid rgba(56,189,248,0.12);border-radius:8px;padding:0.65rem 0.85rem;">
        <div style="font-size:0.7rem;color:var(--sky);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.35rem">Student Reading</div>
        <div style="font-size:1.1rem;font-weight:700">${parseFloat(d.student_hobbs_delta).toFixed(1)} hrs</div>
        <div style="font-size:0.75rem;color:var(--gray-400)">${d.student_hobbs_start} → ${d.student_hobbs_end}</div>
      </div>
      <div style="background:rgba(56,189,248,0.06);border:1px solid rgba(56,189,248,0.12);border-radius:8px;padding:0.65rem 0.85rem;">
        <div style="font-size:0.7rem;color:var(--sky);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:0.35rem">Instructor Reading</div>
        <div style="font-size:1.1rem;font-weight:700">${parseFloat(d.instructor_hobbs_delta).toFixed(1)} hrs</div>
        <div style="font-size:0.75rem;color:var(--gray-400)">${d.instructor_hobbs_start} → ${d.instructor_hobbs_end}</div>
      </div>
    </div>
    <div style="margin-top:0.6rem;padding:0.5rem 0.75rem;background:rgba(239,68,68,0.07);border-radius:6px;font-size:0.85rem;color:#EF4444;font-weight:600;">
      Δ ${parseFloat(d.delta_hours).toFixed(2)} hrs discrepancy
    </div>
  `;
  document.getElementById('disc-resolve-modal').classList.remove('hidden');
}

function closeDiscrepancyModal() {
  document.getElementById('disc-resolve-modal').classList.add('hidden');
}

async function saveDiscrepancyResolve() {
  const id = document.getElementById('disc-resolve-id').value;
  const reading = document.getElementById('disc-resolve-reading').value;
  const note = document.getElementById('disc-resolve-note').value;
  const errEl = document.getElementById('disc-resolve-error');
  try {
    await api(`/api/discrepancies/${id}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolution_reading: reading, resolution_note: note }),
    });
    closeDiscrepancyModal();
    showToast('Discrepancy resolved', 'success');
    loadDiscrepancies();
    loadDiscrepanciesBadge();
  } catch (err) {
    if (errEl) { errEl.textContent = err.error || 'Failed to resolve'; errEl.classList.remove('hidden'); }
  }
}

async function deleteDiscrepancyEntry(id) {
  if (!confirm('Delete this discrepancy record? This cannot be undone.')) return;
  try {
    await api(`/api/discrepancies/${id}`, { method: 'DELETE' });
    showToast('Discrepancy deleted', 'success');
    loadDiscrepancies();
    loadDiscrepanciesBadge();
  } catch (err) {
    showToast(err.error || 'Failed to delete discrepancy', 'error');
  }
}

// ─── DATA LOADING ───
async function loadUsers() {
  try { allUsers = await api('/api/users'); } catch { allUsers = []; }
}

async function loadAircraft() {
  try { allAircraft = await api('/api/aircraft'); } catch { allAircraft = []; }
}

async function loadBookings(start, end) {
  try {
    const params = new URLSearchParams();
    if (start) params.set('start', start);
    if (end) params.set('end', end);
    return await api(`/api/bookings?${params}`);
  } catch { return []; }
}

// ─── WEATHER HELPERS ───
function wxCatClass(cat) {
  if (!cat) return 'wx-unknown';
  return { VFR: 'wx-vfr', MVFR: 'wx-mvfr', IFR: 'wx-ifr', LIFR: 'wx-lifr' }[cat] || 'wx-unknown';
}

function wxBuildChip(cat, detailId, isStale) {
  const dot = { VFR: '🟢', MVFR: '🟡', IFR: '🔴', LIFR: '⛔' }[cat] || '⚪';
  const cls = wxCatClass(cat);
  if (!cat) return `<span class="wx-chip wx-unknown">⚪ —</span>`;
  const staleTag = isStale ? '<span style="font-size:0.55rem;color:var(--gray-500);margin-left:3px" title="Stale data — weather API temporarily unavailable">⏳</span>' : '';
  return `<span class="wx-chip ${cls}" onclick="document.getElementById('${detailId}').classList.toggle('open')">${dot} ${cat}${staleTag}</span>`;
}

function wxBuildDetail(wxData, flightStart, flightEnd, detailId) {
  if (!wxData || wxData.unavailable || !wxData.metar) {
    return `<div id="${detailId}" class="wx-detail-panel"><p style="color:var(--gray-500);font-size:0.82rem;padding:0.4rem 0">Weather data temporarily unavailable. Check back shortly.</p></div>`;
  }
  const m = wxData.metar;
  const cat = m.flightCategory || '—';
  const catCls = wxCatClass(m.flightCategory);

  // Stale data indicator
  let staleNote = '';
  if (wxData.stale && wxData.fetchedAt) {
    const ago = Math.round((Date.now() - new Date(wxData.fetchedAt).getTime()) / 60000);
    const agoText = ago < 60 ? `${ago}m ago` : `${Math.round(ago / 60)}h ago`;
    staleNote = `<div style="font-size:0.68rem;color:var(--amber);margin-bottom:0.5rem">⏳ Last updated ${agoText} — live data temporarily unavailable</div>`;
  }

  // Wind
  const wdir = m.wdir === 'VRB' ? 'VRB' : (m.wdir != null ? String(m.wdir).padStart(3,'0') + '°' : '—');
  const wspd = m.wspd != null ? `${m.wspd}kt` : '—';
  const wgst = m.wgst ? ` G${m.wgst}kt` : '';
  const wind = `${wdir} ${wspd}${wgst}`;

  // Visibility
  const vis = m.visib != null ? `${m.visib} SM` : '—';

  // Ceiling — lowest BKN or OVC layer
  const ceilLayer = (m.clouds || []).find(c => c.cover === 'BKN' || c.cover === 'OVC');
  const ceiling = ceilLayer ? `${ceilLayer.cover} ${ceilLayer.base}ft` : 'CLR';

  // Temp / dewpoint
  const temp = m.temp != null ? `${m.temp}°C` : '—';
  const dewp = m.dewp != null ? `${m.dewp}°C` : '—';

  // Altimeter
  const altim = m.altim != null ? `${parseFloat(m.altim).toFixed(2)}"` : '—';

  // TAF for flight window
  let tafHtml = '';
  if (wxData.taf) {
    const startTs = new Date(flightStart).getTime() / 1000;
    const endTs   = new Date(flightEnd).getTime()   / 1000;
    const periods = (wxData.taf.fcsts || []).filter(f => {
      const from = f.timeFrom || f.fcstTimeFrom || 0;
      const to   = f.timeTo   || f.fcstTimeTo   || 0;
      return to > startTs && from < endTs;
    });
    if (periods.length > 0) {
      const summary = periods.map(f => {
        const pw = f.wdir === 'VRB' ? 'VRB' : (f.wdir != null ? String(f.wdir).padStart(3,'0') + '°' : '—');
        const ps = f.wspd != null ? `${f.wspd}kt` : '—';
        const pg = f.wgst ? ` G${f.wgst}kt` : '';
        const pv = f.visib != null ? `${f.visib}SM` : '—';
        const sky = (f.clouds || []).map(c => `${c.cover}${c.base}`).join(' ') || 'CLR';
        return `${pw} ${ps}${pg}  Vis:${pv}  ${sky}`;
      }).join('\n');
      tafHtml = `<div class="wx-taf-box"><div class="wx-taf-label">TAF — Flight Window Forecast</div><div class="wx-taf-raw">${escHtml(summary)}</div></div>`;
    } else if (wxData.taf.rawTAF) {
      const raw = wxData.taf.rawTAF.substring(0, 200);
      tafHtml = `<div class="wx-taf-box"><div class="wx-taf-label">TAF (full raw — no exact period match)</div><div class="wx-taf-raw">${escHtml(raw)}</div></div>`;
    }
  }

  return `<div id="${detailId}" class="wx-detail-panel">
    ${staleNote}
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.8rem;">
      <span class="wx-cat-badge ${catCls}">● ${cat} — KPSK Current</span>
      <button class="wx-close-btn" onclick="document.getElementById('${detailId}').classList.remove('open')">✕</button>
    </div>
    <div class="wx-detail-grid">
      <div><div class="wx-dl">Wind</div><div class="wx-dv">${wind}</div></div>
      <div><div class="wx-dl">Visibility</div><div class="wx-dv">${vis}</div></div>
      <div><div class="wx-dl">Ceiling</div><div class="wx-dv">${ceiling}</div></div>
      <div><div class="wx-dl">Temp / Dew</div><div class="wx-dv">${temp} / ${dewp}</div></div>
      <div><div class="wx-dl">Altimeter</div><div class="wx-dv">${altim}</div></div>
    </div>
    ${tafHtml}
  </div>`;
}

// ─── DASHBOARD ───
async function loadDashboard() {
  // Hide skeleton, show actual content shell (or wait for data)
  const skeletonStats = document.getElementById('dashboard-skeleton-stats');
  const skeletonTable = document.getElementById('dashboard-skeleton-table');
  const actualStats = document.getElementById('dashboard-stats');
  const actualHeader = document.getElementById('dashboard-bookings-header');
  const actualTableCard = document.getElementById('dashboard-table-card');
  const emptyEl = document.getElementById('dashboard-empty');

  if (skeletonStats) skeletonStats.classList.add('hidden');
  if (skeletonTable) skeletonTable.classList.add('hidden');
  if (actualStats) actualStats.innerHTML = '';
  if (actualHeader) actualHeader.classList.add('hidden');
  if (actualTableCard) actualTableCard.classList.add('hidden');
  if (emptyEl) emptyEl.classList.add('hidden');

  const now = new Date();
  const weekEnd = new Date(now);
  weekEnd.setDate(weekEnd.getDate() + 7);

  const bookings = await loadBookings(now.toISOString(), weekEnd.toISOString());
  const upcoming = bookings.filter(b => new Date(b.start_time) >= now).slice(0, 10);

  const todayBookings = bookings.filter(b => {
    const d = new Date(b.start_time);
    return d.toDateString() === now.toDateString();
  });

  const instructorCount = allUsers.filter(u => ['instructor','admin','owner'].includes(u.role)).length;
  const studentCount = allUsers.filter(u => u.role === 'student').length;
  const availableAircraft = allAircraft.filter(a => a.status === 'available').length;

  // Refresh user to get latest hours
  try {
    const meData = await api('/api/auth/me');
    currentUser = meData.user;
  } catch {}

  const hobbsHrs = parseFloat(currentUser.total_hobbs_hours || 0).toFixed(1);
  const tachHrs = parseFloat(currentUser.total_tach_hours || 0).toFixed(1);
  const showHours = currentUser.role === 'student' || currentUser.role === 'instructor';

  const statsEl = document.getElementById('dashboard-stats');
  if (actualStats) actualStats.classList.remove('hidden');
  statsEl.innerHTML = `
    <div class="stat-card">
      <div class="stat-label">Today's Flights</div>
      <div class="stat-value">${todayBookings.length}</div>
      <div class="stat-sub">${upcoming.length} this week</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Active Aircraft</div>
      <div class="stat-value">${availableAircraft}</div>
      <div class="stat-sub">${allAircraft.length} total in fleet</div>
    </div>
    ${showHours ? `
    <div class="stat-card">
      <div class="stat-label">My Hobbs Hours</div>
      <div class="stat-value" style="color:var(--sky)">${hobbsHrs}</div>
      <div class="stat-sub">Logged flight time</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">My Tach Hours</div>
      <div class="stat-value" style="color:var(--sky)">${tachHrs}</div>
      <div class="stat-sub">Engine time</div>
    </div>` : `
    <div class="stat-card">
      <div class="stat-label">Instructors</div>
      <div class="stat-value">${instructorCount}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Students</div>
      <div class="stat-value">${studentCount}</div>
    </div>
    <div class="stat-card" id="at-risk-dash-card" style="cursor:pointer;border-color:rgba(239,68,68,0.15)" onclick="navigate('at-risk')">
      <div class="stat-label" style="color:var(--red)">At-Risk Students</div>
      <div class="stat-value" id="at-risk-dash-count" style="color:var(--red)">—</div>
      <div class="stat-sub">Click to review</div>
    </div>`}
  `;

  // Async: fetch at-risk count for owner/admin dashboard card
  if (!['student','instructor'].includes(currentUser.role)) {
    api('/api/at-risk').then(data => {
      const countEl = document.getElementById('at-risk-dash-count');
      if (countEl) countEl.textContent = (data.students || []).length;
    }).catch(() => {});
  }

  const tbody = document.getElementById('upcoming-bookings-list');
  if (!tbody) return;

  if (upcoming.length === 0) {
    tbody.innerHTML = '';
    if (emptyEl) emptyEl.classList.remove('hidden');
    return;
  }

  if (emptyEl) emptyEl.classList.add('hidden');
  if (actualHeader) actualHeader.classList.remove('hidden');
  if (actualTableCard) actualTableCard.classList.remove('hidden');

  // Fetch KPSK weather — non-blocking, fails gracefully
  let wxData = null;
  try { wxData = await api('/api/weather'); } catch {}

  tbody.innerHTML = upcoming.map((b, i) => {
    const start = new Date(b.start_time);
    const end = new Date(b.end_time);
    const timeStr = `${formatTime(start)} - ${formatTime(end)}`;
    const dateStr = start.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const typeClass = getTypeClass(b.lesson_type);
    const soloLabel = b.booking_type === 'student_solo' ? '<span style="font-size:0.7rem;color:var(--amber)"> ✈solo</span>' :
                      b.booking_type === 'instructor_solo' ? '<span style="font-size:0.7rem;color:var(--amber)"> ✈solo</span>' : '';
    const detailId = `wx-detail-${i}`;
    const chip   = wxBuildChip(wxData?.metar?.flightCategory, detailId, wxData?.stale);
    const detail = wxBuildDetail(wxData, b.start_time, b.end_time, detailId);
    return `<tr>
      <td><div style="font-size:0.8rem;color:var(--gray-500)">${dateStr}</div><div style="font-family:'Space Grotesk';color:var(--sky);font-weight:600">${timeStr}</div></td>
      <td><span class="tag ${typeClass}">${b.lesson_type || 'Flight'}</span></td>
      <td>${escHtml(b.student_name)}</td>
      <td>${escHtml(b.instructor_name)}</td>
      <td style="font-family:'Space Grotesk';font-weight:500">${escHtml(b.tail_number)}</td>
      <td><span class="tag tag-green">${b.status}</span></td>
      <td>${chip}</td>
    </tr>
    <tr class="wx-detail-row"><td colspan="7">${detail}</td></tr>`;
  }).join('');

  // Show pending hours banner for instructors/owners
  if (currentUser.role !== 'student') {
    try {
      const pending = await api('/api/bookings/completable');
      completableBookings = pending;
      if (pending.length > 0) {
        const existing = document.getElementById('dashboard-pending-banner');
        if (existing) existing.remove();
        const banner = document.createElement('div');
        banner.id = 'dashboard-pending-banner';
        banner.style.cssText = 'background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:12px;padding:1rem 1.5rem;margin-top:1.5rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;';
        banner.innerHTML = `
          <div>
            <div style="font-weight:600;color:var(--amber)">&#9888; ${pending.length} flight${pending.length !== 1 ? 's' : ''} need hours logged</div>
            <div style="font-size:0.82rem;color:var(--gray-300);margin-top:0.2rem">Log Hobbs &amp; Tach hours to keep the aircraft record current</div>
          </div>
          <button class="btn btn-sm btn-primary" onclick="navigate('flight-log')">Go to Flight Log</button>
        `;
        document.getElementById('page-dashboard').appendChild(banner);
      }
    } catch {}
  }
}

// ─── BOOKING HISTORY ───
async function loadBookingHistory() {
  const tbody = document.getElementById('history-table-body');
  const emptyEl = document.getElementById('history-empty');
  const loadingEl = document.getElementById('history-loading');
  if (!tbody) return;

  tbody.innerHTML = '';
  emptyEl.classList.add('hidden');
  if (loadingEl) loadingEl.classList.remove('hidden');

  try {
    // Populate aircraft filter on first load
    const aircraftSel = document.getElementById('history-aircraft-filter');
    if (aircraftSel && aircraftSel.options.length <= 1) {
      (allAircraft || []).forEach(a => {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = a.tail_number;
        aircraftSel.appendChild(opt);
      });
    }

    // Populate instructor filter on first load (admins/owners/instructors)
    const instrSel = document.getElementById('history-instructor-filter');
    if (instrSel && instrSel.options.length <= 1 && currentUser && currentUser.role !== 'student') {
      instrSel.style.display = '';
      const instructors = (allUsers || []).filter(u => u.role === 'instructor' || u.role === 'admin' || u.role === 'owner');
      instructors.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = u.name;
        instrSel.appendChild(opt);
      });
    }

    const statusFilter = document.getElementById('history-status-filter')?.value || 'all';

    const params = new URLSearchParams();
    if (statusFilter !== 'all') {
      params.set('status', statusFilter);
    }
    const aircraftVal = document.getElementById('history-aircraft-filter')?.value;
    if (aircraftVal) params.set('aircraft_id', aircraftVal);
    const instrVal = document.getElementById('history-instructor-filter')?.value;
    if (instrVal) params.set('instructor_id', instrVal);
    const studentVal = document.getElementById('history-student-filter')?.value;
    if (studentVal) params.set('student_id', studentVal);

    // Apply period filter
    const period = _historyPeriod || 'month';
    const now = new Date();
    if (period === 'day') {
      const dayPicker = document.getElementById('history-date-picker');
      if (dayPicker && dayPicker.value) {
        const d = new Date(dayPicker.value + 'T00:00:00Z');
        params.set('start', d.toISOString());
        params.set('end', new Date(d.getTime() + 86400000).toISOString());
      }
    } else if (period === 'week') {
      const day = now.getUTCDay();
      const startOfWeek = new Date(now);
      startOfWeek.setUTCDate(now.getUTCDate() - day);
      startOfWeek.setUTCHours(0, 0, 0, 0);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setUTCDate(startOfWeek.getUTCDate() + 7);
      params.set('start', startOfWeek.toISOString());
      params.set('end', endOfWeek.toISOString());
    } else if (period === 'month') {
      const startOfMonth = new Date(now.getUTCFullYear(), now.getUTCMonth(), 1);
      const endOfMonth = new Date(now.getUTCFullYear(), now.getUTCMonth() + 1, 1);
      params.set('start', startOfMonth.toISOString());
      params.set('end', endOfMonth.toISOString());
    } else if (period === 'year') {
      const startOfYear = new Date(now.getUTCFullYear(), 0, 1);
      const endOfYear = new Date(now.getUTCFullYear() + 1, 0, 1);
      params.set('start', startOfYear.toISOString());
      params.set('end', endOfYear.toISOString());
    }

    // Fetch bookings based on status filter
    let completedBookings = [];
    let cancelledBookings = [];

    if (statusFilter === 'all') {
      [completedBookings, cancelledBookings] = await Promise.all([
        api(`/api/bookings/history?status=completed&${params.toString()}`),
        api(`/api/bookings/history?status=cancelled&${params.toString()}`)
      ]);
    } else if (statusFilter === 'completed') {
      completedBookings = await api(`/api/bookings/history?${params}`);
    } else {
      cancelledBookings = await api(`/api/bookings/history?${params}`);
    }

    if (loadingEl) loadingEl.classList.add('hidden');

    const allBookings = [...completedBookings, ...cancelledBookings].sort((a, b) =>
      new Date(b.start_time) - new Date(a.start_time)
    );

    if (allBookings.length === 0) {
      emptyEl.classList.remove('hidden');
      return;
    }

    tbody.innerHTML = allBookings.map(b => {
      const start = new Date(b.start_time);
      const end = new Date(b.end_time);
      const dateStr = start.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const timeStr = formatTime(start) + ' – ' + formatTime(end);
      const type = b.lesson_type || (b.booking_type === 'student_solo' ? 'Student Solo' : b.booking_type === 'instructor_solo' ? 'Instructor Solo' : 'Dual');
      const isCancelled = b.status === 'cancelled';

      // Calculate hours and revenue
      let HobbsHrs, TachHrs, InstrHrs, aircraftCharge, instrCharge, totalCharge;
      let hobbsHrsStr, tachHrsStr, instrHrsStr, aircraftChargeStr, instrChargeStr, totalChargeStr;
      let cancelledNote = '';

      if (isCancelled) {
        // Cancelled booking — no actual flight logs, show projected
        const scheduledHobbs = b.hobbs_end && b.hobbs_start
          ? (parseFloat(b.hobbs_end) - parseFloat(b.hobbs_start))
          : (end - start) / (1000 * 60 * 60);
        const scheduledTach = b.tach_end && b.tach_start
          ? (parseFloat(b.tach_end) - parseFloat(b.tach_start))
          : null;
        const airRate = parseFloat(b.aircraft_hourly_rate) || 0;
        const instrRate = parseFloat(b.instructor_hourly_rate) || 0;
        const projAircraftCharge = scheduledHobbs * airRate;
        const projInstrCharge = (b.booking_type === 'dual' || b.instructor_id) ? scheduledHobbs * instrRate : 0;

        hobbsHrsStr = `<span style="color:var(--amber)">${scheduledHobbs.toFixed(1)}h</span>`;
        tachHrsStr = scheduledTach !== null
          ? `<span style="color:var(--amber)">${scheduledTach.toFixed(1)}h</span>`
          : `<span style="color:var(--gray-600)">—</span>`;
        instrHrsStr = `<span style="color:var(--amber)">${scheduledHobbs.toFixed(1)}h</span>`;
        aircraftChargeStr = `<span style="color:var(--amber)" title="Projected — flight was cancelled">PROJ. $${projAircraftCharge.toFixed(0)}</span>`;
        instrChargeStr = projInstrCharge > 0
          ? `<span style="color:var(--amber)" title="Projected — flight was cancelled">PROJ. $${projInstrCharge.toFixed(0)}</span>`
          : `<span style="color:var(--gray-600)">—</span>`;
        const projTotal = projAircraftCharge + projInstrCharge;
        totalChargeStr = projTotal > 0
          ? `<span style="color:var(--amber);font-weight:600" title="Projected — flight was cancelled">PROJ. $${projTotal.toFixed(0)}</span>`
          : `<span style="color:var(--gray-600)">—</span>`;
        cancelledNote = b.cancellation_reason
          ? `<div style="font-size:0.75rem;color:#F87171;margin-top:0.2rem">${escHtml(b.cancellation_reason)}</div>`
          : '';
      } else {
        // Completed booking — show actual values
        const actualHobbs = parseFloat(b.actual_hobbs_hours);
        const hobbs = b.hobbs_end && b.hobbs_start ? (parseFloat(b.hobbs_end) - parseFloat(b.hobbs_start)) : null;
        const duration = actualHobbs > 0 ? actualHobbs : (hobbs ? parseFloat(hobbs) : null);
        const actualTach = b.tach_delta || (b.tach_end && b.tach_start ? parseFloat(b.tach_end) - parseFloat(b.tach_start) : null);
        const dualHrs = parseFloat(b.dual_instruction_hours) || 0;
        const airCharge = parseFloat(b.aircraft_charge_amount);
        const instrCharge = parseFloat(b.instruction_charge_amount);

        hobbsHrsStr = duration ? `${duration.toFixed(1)}h` : '—';
        tachHrsStr = actualTach != null ? `${actualTach.toFixed(1)}h` : '—';
        instrHrsStr = dualHrs > 0 ? `${dualHrs.toFixed(1)}h` : '—';
        aircraftChargeStr = airCharge > 0 ? `$${airCharge.toFixed(0)}` : '—';
        instrChargeStr = instrCharge > 0 ? `$${instrCharge.toFixed(0)}` : '—';
        const total = (airCharge > 0 ? airCharge : 0) + (instrCharge > 0 ? instrCharge : 0);
        totalChargeStr = total > 0 ? `$${total.toFixed(0)}` : '—';
      }

      let statusBadge;
      if (isCancelled) {
        statusBadge = `<span class="tag" style="background:rgba(239,68,68,0.15);color:#F87171">CANCELLED</span>${cancelledNote}`;
      } else if (b.ended_early) {
        statusBadge = `<span class="tag" style="background:rgba(245,158,11,0.15);color:var(--amber)">Ended Early</span>`;
      } else {
        statusBadge = `<span class="tag tag-completed">Completed</span>`;
      }

      const rowStyle = isCancelled ? 'opacity:0.75;background:rgba(239,68,68,0.04)' : '';

      const deleteBtn = currentUser && ['owner', 'admin'].includes(currentUser.role)
        ? `<button class="btn-sm btn-danger" onclick="deleteHistoryFlight(${b.id})" title="Delete booking record">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>
           </button>`
        : '';
      return `<tr style="${rowStyle}">
        <td>${escHtml(dateStr)}</td>
        <td>${escHtml(b.student_name || '—')}</td>
        <td>${escHtml(b.instructor_name || '—')}</td>
        <td>${escHtml(b.tail_number)}</td>
        <td style="font-size:0.82rem">${statusBadge}</td>
        <td style="text-align:right;font-size:0.85rem">${b.ended_early && !isCancelled ? hobbsHrsStr + ' <span class="tag" style="background:rgba(245,158,11,0.15);color:var(--amber);font-size:0.65rem">Early</span>' : hobbsHrsStr}</td>
        <td style="text-align:right;font-size:0.85rem">${tachHrsStr}</td>
        <td style="text-align:right;font-size:0.85rem">${instrHrsStr}</td>
        <td style="text-align:right;font-size:0.85rem">${aircraftChargeStr}</td>
        <td style="text-align:right;font-size:0.85rem">${instrChargeStr}</td>
        <td style="text-align:right;font-size:0.85rem;font-weight:600;color:var(--sky)">${totalChargeStr}</td>
        <td style="text-align:center">${deleteBtn}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    if (loadingEl) loadingEl.classList.add('hidden');
    tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;color:var(--red);padding:1.5rem;">Failed to load history</td></tr>`;
  }
}

// ─── BOOKING HISTORY MANAGEMENT ACTIONS (admin/owner only) ─────────
async function deleteHistoryFlight(id) {
  if (!confirm('Delete this booking record? This cannot be undone.')) return;
  try {
    await api(`/api/booking-history/flights/${id}`, { method: 'DELETE' });
    showToast('Booking record deleted', 'success');
    await loadHistoryLegacyPage();
  } catch (err) {
    showToast(err.error || 'Failed to delete booking record', 'error');
  }
}

async function deleteBookingFromSchedule(id) {
  if (!confirm('Delete this booking record? This cannot be undone.')) return;
  try {
    await api(`/api/booking-history/flights/${id}`, { method: 'DELETE' });
    showToast('Booking record deleted', 'success');
    await loadCalendar();
  } catch (err) {
    showToast(err.error || 'Failed to delete booking record', 'error');
  }
}

async function deleteHistoryGS(id) {
  if (!confirm('Delete this ground session record? This cannot be undone.')) return;
  try {
    await api(`/api/booking-history/ground-sessions/${id}`, { method: 'DELETE' });
    showToast('Ground session deleted', 'success');
    await loadHistoryLegacyPage();
  } catch (err) {
    showToast(err.error || 'Failed to delete ground session', 'error');
  }
}

function openManualEntryModal() {
  const modal = document.getElementById('manual-entry-modal');
  if (!modal) return;

  // Reset form
  document.getElementById('me-error').classList.add('hidden');
  const today = new Date().toISOString().slice(0, 10);
  document.getElementById('me-date').value = today;
  document.getElementById('me-session-type').value = 'flight';
  document.getElementById('me-notes').value = '';

  // Populate dropdowns
  const stuSel = document.getElementById('me-student');
  stuSel.innerHTML = '<option value="">Select student…</option>';
  (allUsers || []).filter(u => u.role === 'student' && !u.deleted_at).forEach(u => {
    const opt = document.createElement('option');
    opt.value = u.id; opt.textContent = u.name;
    stuSel.appendChild(opt);
  });

  const instrSel = document.getElementById('me-instructor');
  instrSel.innerHTML = '<option value="">None</option>';
  (allUsers || []).filter(u => ['instructor','admin','owner'].includes(u.role) && !u.deleted_at).forEach(u => {
    const opt = document.createElement('option');
    opt.value = u.id; opt.textContent = u.name;
    instrSel.appendChild(opt);
  });

  const acSel = document.getElementById('me-aircraft');
  acSel.innerHTML = '<option value="">None (ground only)</option>';
  (allAircraft || []).forEach(a => {
    const opt = document.createElement('option');
    opt.value = a.id; opt.textContent = a.tail_number + ' (' + (a.make_model || '') + ')';
    acSel.appendChild(opt);
  });

  // Pre-fill Hobbs/Tach start from aircraft
  ['me-hobbs-start', 'me-hobbs-end', 'me-tach-start', 'me-tach-end', 'me-instruction-hours', 'me-ground-hours'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });

  onManualSessionTypeChange();
  modal.classList.remove('hidden');
}

function closeManualEntryModal() {
  document.getElementById('manual-entry-modal').classList.add('hidden');
}

function onManualSessionTypeChange() {
  const type = document.getElementById('me-session-type').value;
  const flightFields = document.getElementById('me-flight-fields');
  const groundFields = document.getElementById('me-ground-fields');
  const acRow        = document.getElementById('me-aircraft-row');
  if (flightFields) flightFields.style.display = type === 'flight' ? '' : 'none';
  if (groundFields) groundFields.style.display = type === 'ground' ? '' : 'none';
  if (acRow)        acRow.style.display         = type === 'flight' ? '' : 'none';
}

async function submitManualEntry() {
  const errEl = document.getElementById('me-error');
  errEl.classList.add('hidden');

  const sessionType = document.getElementById('me-session-type').value;
  const flightDate  = document.getElementById('me-date').value;
  const studentId   = document.getElementById('me-student').value;
  const instructorId= document.getElementById('me-instructor').value;
  const aircraftId  = document.getElementById('me-aircraft').value;
  const notes       = document.getElementById('me-notes').value.trim();

  const body = { session_type: sessionType, flight_date: flightDate, notes: notes || null };
  if (studentId)    body.student_id    = studentId;
  if (instructorId) body.instructor_id = instructorId;

  if (sessionType === 'flight') {
    if (!aircraftId) { errEl.textContent = 'Aircraft is required for flights.'; errEl.classList.remove('hidden'); return; }
    body.aircraft_id = aircraftId;
    const hobbsStart = document.getElementById('me-hobbs-start').value;
    const hobbsEnd   = document.getElementById('me-hobbs-end').value;
    const tachStart  = document.getElementById('me-tach-start').value;
    const tachEnd    = document.getElementById('me-tach-end').value;
    const instrHours = document.getElementById('me-instruction-hours').value;
    if (hobbsStart) body.hobbs_start = parseFloat(hobbsStart);
    if (hobbsEnd)   body.hobbs_end   = parseFloat(hobbsEnd);
    if (tachStart)  body.tach_start  = parseFloat(tachStart);
    if (tachEnd)    body.tach_end    = parseFloat(tachEnd);
    if (instrHours) body.instruction_hours = parseFloat(instrHours);
    if (hobbsStart && hobbsEnd && parseFloat(hobbsEnd) < parseFloat(hobbsStart)) {
      errEl.textContent = 'Hobbs End must be greater than Hobbs Start.'; errEl.classList.remove('hidden'); return;
    }
  } else {
    const groundHours = document.getElementById('me-ground-hours').value;
    if (!groundHours || parseFloat(groundHours) <= 0) {
      errEl.textContent = 'Ground hours must be greater than 0.'; errEl.classList.remove('hidden'); return;
    }
    body.ground_hours = parseFloat(groundHours);
    if (!studentId) { errEl.textContent = 'Student is required for ground sessions.'; errEl.classList.remove('hidden'); return; }
  }

  const btn = document.getElementById('me-submit-btn');
  btn.disabled = true;
  btn.textContent = 'Saving…';

  try {
    await api('/api/booking-history/manual', { method: 'POST', body: JSON.stringify(body) });
    showToast('Manual entry added', 'success');
    closeManualEntryModal();
    await loadHistoryLegacyPage();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save entry.';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save Entry';
  }
}

// ─── CALENDAR ───
function loadCalendar() {
  const year = calendarDate.getFullYear();
  const month = calendarDate.getMonth();
  const title = calendarDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  document.getElementById('calendar-title').textContent = title;

  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const fetchStart = new Date(year, month, 1 - startOffset);
  const fetchEnd = new Date(year, month + 1, 7);

  loadBookings(fetchStart.toISOString(), fetchEnd.toISOString()).then(bookings => {
    // Schedule only shows live/upcoming flights — completed bookings belong in Booking History
    const liveBookings = bookings.filter(b => b.status !== 'completed');
    allBookings = liveBookings;
    renderCalendar(year, month, startOffset, new Date(year, month + 1, 0).getDate(), liveBookings);
  });
}

function renderCalendar(year, month, startOffset, daysInMonth, bookings) {
  const grid = document.getElementById('calendar-grid');
  const today = new Date();
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  let html = days.map(d => `<div class="calendar-day-header">${d}</div>`).join('');

  const prevMonth = new Date(year, month, 0);
  for (let i = startOffset - 1; i >= 0; i--) {
    html += `<div class="calendar-day other-month"><div class="day-number">${prevMonth.getDate() - i}</div></div>`;
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    const isToday = date.toDateString() === today.toDateString();
    const dayBookings = bookings.filter(b => {
      const bd = new Date(b.start_time);
      return bd.getFullYear() === year && bd.getMonth() === month && bd.getDate() === day;
    });

    const eventsHtml = dayBookings.slice(0, 3).map(b => {
      const cls = b.status === 'completed' ? 'default' : getEventClass(b.lesson_type);
      const time = formatTime(new Date(b.start_time));
      const prefix = b.status === 'completed' ? '✓ ' : (b.booking_type === 'student_solo' || b.booking_type === 'instructor_solo' ? '✈ ' : '');
      const style = b.status === 'completed' ? 'background:rgba(34,197,94,0.15);color:var(--green);' :
                    (b.booking_type === 'student_solo' || b.booking_type === 'instructor_solo') ? 'background:rgba(245,158,11,0.15);color:var(--amber);' : '';
      // Build tooltip: show who is booked and aircraft
      const who = b.student_name && b.instructor_name ? `${b.student_name} with ${b.instructor_name}` :
                  b.student_name ? `${b.student_name} (solo)` :
                  b.instructor_name ? `${b.instructor_name} (solo)` : 'Unknown';
      const tooltipLabel = `${who} — ${b.tail_number} (${b.status})`;
      return `<div class="calendar-event ${cls}" style="${style}" title="${tooltipLabel}">${prefix}${time} ${b.lesson_type || b.tail_number || ''}</div>`;
    }).join('');

    const moreHtml = dayBookings.length > 3 ? `<div style="font-size:0.6rem;color:var(--gray-500)">+${dayBookings.length - 3} more</div>` : '';

    const hasEvts = dayBookings.length > 0 ? ' has-events' : '';
    html += `<div class="calendar-day${isToday ? ' today' : ''}${hasEvts}" onclick="openDayDetail(${year},${month},${day})">
      <div class="day-number">${day}</div>${eventsHtml}${moreHtml}
    </div>`;
  }

  const totalCells = startOffset + daysInMonth;
  const remaining = (7 - (totalCells % 7)) % 7;
  for (let i = 1; i <= remaining; i++) {
    html += `<div class="calendar-day other-month"><div class="day-number">${i}</div></div>`;
  }

  grid.innerHTML = html;
}

function changeMonth(delta) {
  calendarDate.setMonth(calendarDate.getMonth() + delta);
  loadCalendar();
}

function goToToday() {
  calendarDate = new Date();
  loadCalendar();
}

function openDayDetail(year, month, day) {
  console.log('[FlightSlate v2026.05.05] openDayDetail called', { year, month, day, role: currentUser?.role, allBookingsCount: allBookings?.length });
  const date = new Date(year, month, day);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (date < today) {
    alert('Cannot schedule flights in the past.');
    return;
  }

  const title = date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  document.getElementById('day-modal-title').textContent = title;

  const dayBookings = allBookings.filter(b => {
    const bd = new Date(b.start_time);
    return bd.getFullYear() === year && bd.getMonth() === month && bd.getDate() === day;
  });
  console.log('[FlightSlate v2026.05.05] dayBookings:', dayBookings.map(b => ({ id: b.id, status: b.status })));

  const list = document.getElementById('day-bookings-list');
  if (dayBookings.length === 0) {
    list.innerHTML = '<div class="empty-state" style="padding:2rem"><h3>No flights scheduled</h3><p>Click below to add one</p></div>';
  } else {
    const now = new Date();
    list.innerHTML = dayBookings.map(b => {
      const start = new Date(b.start_time);
      const end = new Date(b.end_time);
      const typeClass = getTypeClass(b.lesson_type);
      const isPast = end < now;
      // canAct: student can cancel their own bookings, anyone else can cancel any booking
      const canAct = currentUser.role !== 'student' || b.student_id === currentUser.id;
      // Complete Flight button is now shown unconditionally on confirmed bookings
      // Server-side /api/bookings/:id/complete validates permissions

      let statusBadge = '';
      if (b.status === 'completed') {
        if (b.ended_early) {
          // Prefer actual_hobbs_hours (set by server), fallback to hobbs_end - hobbs_start
          const ahh = parseFloat(b.actual_hobbs_hours);
          const hobbsCalc = b.hobbs_end && b.hobbs_start ? parseFloat(b.hobbs_end) - parseFloat(b.hobbs_start) : 0;
          const hrs = (ahh > 0 ? ahh : hobbsCalc > 0 ? hobbsCalc : 0).toFixed(1);
          statusBadge = `<span class="tag" style="background:rgba(245,158,11,0.15);color:var(--amber)">Ended Early</span>`;
          if (parseFloat(hrs) > 0) statusBadge += ` <span style="font-size:0.75rem;color:var(--amber)">${hrs}h logged</span>`;
        } else {
          const hobbs = b.hobbs_end && b.hobbs_start ? (parseFloat(b.hobbs_end) - parseFloat(b.hobbs_start)).toFixed(1) : null;
          statusBadge = `<span class="tag tag-completed">Completed</span>`;
          if (hobbs) statusBadge += ` <span style="font-size:0.75rem;color:var(--green)">${hobbs}h Hobbs</span>`;
        }
      } else if (b.status === 'cancelled') {
        statusBadge = `<span class="tag tag-cancelled">Cancelled</span>`;
      } else {
        statusBadge = `<span class="tag tag-confirmed">Confirmed</span>`;
      }

      // Booking type badge
      const bookingTypeLabel = b.booking_type === 'student_solo' ? '✈ Solo (Student)' :
                               b.booking_type === 'instructor_solo' ? '✈ Solo (Instructor)' : null;
      const bookingTypeBadge = bookingTypeLabel
        ? `<span class="tag" style="background:rgba(245,158,11,0.15);color:var(--amber);font-size:0.7rem">${bookingTypeLabel}</span>` : '';

      // canEndEarly removed — "Complete Flight" now handles both in-progress and past flights

      let actionBtns = '';
      if (b.status === 'confirmed') {
        // Always show Complete Flight button on confirmed bookings (server validates permissions)
        actionBtns += `<button class="btn btn-sm" style="margin-top:0.5rem;margin-right:0.4rem;background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;border:none;font-weight:600;" onclick="closeDayModal();openCompleteModal(${b.id})">✓ Complete Flight</button>`;
        if (canAct) {
          actionBtns += `<button class="btn btn-sm" style="margin-top:0.5rem;background:transparent;color:#f87171;border:1px solid rgba(248,113,113,0.4);" onclick="closeDayModal();openCancelModal(${b.id})">✗ Cancel Flight</button>`;
        }
      } else if (b.status === 'completed' && ['owner','admin'].includes(currentUser.role)) {
        actionBtns = `<button class="btn btn-secondary btn-sm" style="margin-top:0.5rem" onclick="closeDayModal();openEditHoursModal(${b.id})">Edit Hours</button>`;
        actionBtns += `<button class="btn btn-sm" style="margin-top:0.5rem;margin-left:0.4rem;background:transparent;color:#f87171;border:1px solid rgba(248,113,113,0.4);" onclick="closeDayModal();deleteBookingFromSchedule(${b.id})">🗑 Delete</button>`;
      } else if (b.status === 'cancelled' && ['owner','admin'].includes(currentUser.role)) {
        actionBtns = `<button class="btn btn-sm" style="margin-top:0.5rem;background:transparent;color:#f87171;border:1px solid rgba(248,113,113,0.4);" onclick="closeDayModal();deleteBookingFromSchedule(${b.id})">🗑 Delete</button>`;
      }

      // Build people line for display (handle solo flights with null participants)
      let peopleLine = '';
      if (b.student_name && b.instructor_name) {
        peopleLine = `${escHtml(b.student_name)} with ${escHtml(b.instructor_name)}`;
      } else if (b.student_name) {
        peopleLine = `${escHtml(b.student_name)} (solo student)`;
      } else if (b.instructor_name) {
        peopleLine = `${escHtml(b.instructor_name)} (instructor solo)`;
      } else {
        peopleLine = 'Unknown';
      }

      return `<div class="booking-card">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.25rem;">
          <div class="booking-time">${formatTime(start)} - ${formatTime(end)}</div>
          <div style="display:flex;gap:0.4rem;align-items:center;flex-wrap:wrap;"><span class="tag ${typeClass}">${b.lesson_type || 'Flight'}</span>${bookingTypeBadge}${statusBadge}</div>
        </div>
        <div class="booking-details">${peopleLine}</div>
        <div class="booking-aircraft">${b.tail_number} - ${b.make_model}</div>
        ${b.notes ? `<div style="font-size:0.8rem;color:var(--gray-500);margin-top:0.25rem">${escHtml(b.notes)}</div>` : ''}
        ${b.cancellation_reason ? `<div style="font-size:0.8rem;color:#F87171;margin-top:0.25rem">Reason: ${escHtml(b.cancellation_reason)}</div>` : ''}
        ${actionBtns}
      </div>`;
    }).join('');
  }

  const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  selectedBookingDate = dateStr;
  document.getElementById('booking-date').value = dateStr;
  document.getElementById('day-modal').classList.remove('hidden');
}

function closeDayModal() {
  document.getElementById('day-modal').classList.add('hidden');
}

// ─── BOOKING MODAL ───
async function openBookingModal() {
  document.getElementById('booking-modal-title').textContent = 'New Booking';
  document.getElementById('booking-error').classList.add('hidden');
  document.getElementById('booking-conflicts').classList.add('hidden');
  document.getElementById('booking-conflicts-bottom').classList.add('hidden');
  document.getElementById('booking-avail-notice').classList.add('hidden');
  // Preserve the date pre-filled by clicking a calendar day, so reset() doesn't wipe it
  const savedDate = document.getElementById('booking-date').value;
  document.getElementById('booking-form').reset();
  document.getElementById('booking-submit-btn').textContent = 'Book Flight';
  currentBookingAvailSlots = null;

  const students = allUsers.filter(u => u.role === 'student' || u.role === 'renter');
  const instructors = allUsers.filter(u => u.is_instructor === true);
  let aircraft = allAircraft.filter(a => a.status === 'available');

  // Filter out aircraft in maintenance downtime on the selected date
  if (savedDate) {
    try {
      const downtimeEntries = await api(`/api/downtime/by-date?date=${savedDate}`);
      const downAircraftIds = new Set((downtimeEntries || []).map(d => d.aircraft_id));
      if (downAircraftIds.size > 0) {
        aircraft = aircraft.filter(a => !downAircraftIds.has(a.id));
      }
    } catch {
      // Downtime check failed — fall back to status-only filtering
    }
  }

  // Student field: role-aware — students and renters locked to self, others see full dropdown
  if (currentUser.role === 'student' || currentUser.role === 'renter') {
    // Students and renters: hide the dropdown, show a locked read-only display
    document.getElementById('booking-student-group').classList.add('hidden');
    document.getElementById('booking-student-locked-group').classList.remove('hidden');
    const roleLabel = currentUser.role === 'renter' ? 'Renter' : 'Student';
    document.getElementById('booking-student-locked-label').textContent = roleLabel;
    document.getElementById('booking-student-locked-name').value = `${roleLabel}: ${currentUser.name}`;
    document.getElementById('booking-student-locked-id').value = currentUser.id;
  } else {
    // Instructors / admins / owners: show full student selector (including renters)
    document.getElementById('booking-student-group').classList.remove('hidden');
    document.getElementById('booking-student-locked-group').classList.add('hidden');
    document.getElementById('booking-student').innerHTML =
      '<option value="">— No Student (solo instructor) —</option>' +
      (students.length ?
        students.map(u => `<option value="${u.id}">${u.name}${u.role === 'renter' ? ' (Renter)' : ''}</option>`).join('') :
        '');
  }

  // Instructor field: "None" for student solo, then all instructors
  document.getElementById('booking-instructor').innerHTML =
    '<option value="">— No Instructor (solo student) —</option>' +
    (instructors.length ?
      instructors.map(u => `<option value="${u.id}">${u.name}</option>`).join('') :
      '');

  document.getElementById('booking-aircraft').innerHTML = aircraft.length ?
    aircraft.map(a => `<option value="${a.id}">${a.tail_number} - ${a.make_model}</option>`).join('') :
    '<option value="">No aircraft available</option>';

  // Instructors default to themselves in the instructor slot
  if (currentUser.role === 'instructor') {
    document.getElementById('booking-instructor').value = currentUser.id;
  }

  // Block past dates: set min to today so the calendar greys them out
  const todayISO = new Date().toLocaleDateString('en-CA'); // "YYYY-MM-DD" in local TZ
  const dateInput = document.getElementById('booking-date');
  dateInput.min = todayISO;

  // Restore the calendar-clicked date (saved before reset). Fall back to today if missing or past.
  const finalDate = (savedDate && savedDate >= todayISO) ? savedDate : todayISO;
  dateInput.value = finalDate;
  selectedBookingDate = finalDate;

  const startSel = document.getElementById('booking-start');
  const endSel = document.getElementById('booking-end');

  // Rebuild time dropdowns respecting today's past-time filter
  rebuildBookingTimePickers();

  document.getElementById('booking-modal').classList.remove('hidden');

  // Async: apply availability filtering if instructor + date are already set
  refreshBookingAvailability();
}

// Build time <option> HTML for start or end pickers.
// minTime: earliest selectable time as "HH:MM" (exclusive — slot must be > minTime)
//          pass null to include all slots
// forDate: "YYYY-MM-DD" — if it equals today's local date, also filters out past slots
function buildTimeOptions(minTime, forDate) {
  const todayStr = new Date().toLocaleDateString('en-CA'); // "YYYY-MM-DD" in local TZ
  const isToday = forDate === todayStr;

  let nowH = 0, nowM = 0;
  if (isToday) {
    const now = new Date();
    nowH = now.getHours();
    nowM = now.getMinutes();
  }

  let minH = 0, minM = 0;
  if (minTime) {
    [minH, minM] = minTime.split(':').map(Number);
  }

  let opts = '';
  for (let h = 6; h <= 23; h++) {
    for (let m = 0; m < 60; m += 30) {
      // Skip past times when booking today
      if (isToday && (h < nowH || (h === nowH && m <= nowM))) continue;
      // Skip slots at or before minTime (for end-time picker)
      if (minTime && (h < minH || (h === minH && m <= minM))) continue;
      const time = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      opts += `<option value="${time}">${formatTimeStr(h, m)}</option>`;
    }
  }
  // Add midnight (24:00) as last end-time option only for the end-time picker (minTime is set).
  // Start-time picker (minTime=null) should NOT include midnight as a start option.
  if (minTime && minH < 24) {
    opts += `<option value="24:00">12:00 AM</option>`;
  }
  // Cross-midnight: when start time is >= 21:00 (9pm), generate end times past midnight (00:00-05:59)
  // These flights span into the next calendar day (e.g., 11:30pm start → 3:00am end next day)
  if (minTime && minH >= 21) {
    for (let h = 0; h <= 5; h++) {
      for (let m = 0; m < 60; m += 30) {
        const time = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        opts += `<option value="${time}">${formatTimeStr(h, m)} (+1 day)</option>`;
      }
    }
  }
  return opts;
}

// Rebuild start + end time dropdowns based on current selected date.
// Preserves selections when possible; auto-selects next available slot for today.
function rebuildBookingTimePickers() {
  const startSel = document.getElementById('booking-start');
  const endSel = document.getElementById('booking-end');
  const dateVal = document.getElementById('booking-date').value;
  const todayStr = new Date().toLocaleDateString('en-CA');
  const isToday = dateVal === todayStr;

  const prevStart = startSel.value;

  // Rebuild start time options
  startSel.innerHTML = buildTimeOptions(null, dateVal);

  if (isToday) {
    // Auto-select first available slot (next 30-min increment from now)
    if (startSel.options.length > 0) {
      startSel.value = startSel.options[0].value;
    }
  } else {
    // Preserve previous selection or default to 09:00
    startSel.value = prevStart && startSel.querySelector(`option[value="${prevStart}"]`) ? prevStart : '09:00';
  }

  // Rebuild end time options (must be after start)
  const chosenStart = startSel.value;
  const endOpts = buildTimeOptions(chosenStart, dateVal);
  if (endOpts === '') {
    endSel.innerHTML = '<option value="">— no valid end time —</option>';
    endSel.disabled = true;
  } else {
    endSel.innerHTML = endOpts;
    endSel.disabled = false;
  }

  // Apply availability dimming if instructor availability is active
  if (currentBookingAvailSlots) {
    for (const opt of endSel.options) {
      opt.style.color = currentBookingAvailSlots.has(opt.value) ? '' : 'var(--gray-600)';
    }
    const availableCount = Array.from(endSel.options).filter(opt => opt.style.color !== 'var(--gray-600)').length;
    if (availableCount === 0 && endSel.options.length > 0) {
      const sortedSlots = Array.from(currentBookingAvailSlots).sort();
      let lastSlot = null;
      for (const slot of sortedSlots) {
        const [sh, sm] = slot.split(':').map(Number);
        const [ph, pm] = chosenStart.split(':').map(Number);
        if (sh > ph || (sh === ph && sm > pm)) {
          lastSlot = slot;
        }
      }
      const [lh, lm] = (lastSlot || chosenStart).split(':').map(Number);
      const lastFormatted = formatTimeStr(lh, lm);
      const [ch, cm] = chosenStart.split(':').map(Number);
      const startFormatted = formatTimeStr(ch, cm);
      endSel.innerHTML = `<option value="">— No slot available —</option>
<option value="" disabled>${startFormatted} – ${lastFormatted} (instructor unavailable after ${lastFormatted})</option>`;
      endSel.disabled = true;
      return;
    }
  }

  if (isToday) {
    // Auto-select first available end slot (one slot after start, if available)
    if (endSel.options.length > 0 && endSel.options[0].value !== '') {
      endSel.value = endSel.options[Math.min(2, endSel.options.length - 1)].value; // ~1.5h default
    }
  } else {
    // Try to keep a 1.5h default gap
    const [sh, sm] = chosenStart.split(':').map(Number);
    const defaultEnd = `${String(sh + 1).padStart(2,'0')}:${String(sm === 0 ? 30 : 0).padStart(2,'0')}`.replace(/^(\d{1}):/, '0$1:');
    const endH = sm === 0 ? sh + 1 : sh + 2;
    const endM = sm === 0 ? 30 : 0;
    const defaultEndStr = `${String(endH).padStart(2,'0')}:${String(endM).padStart(2,'0')}`;
    endSel.value = endSel.querySelector(`option[value="${defaultEndStr}"]`) ? defaultEndStr :
      (endSel.options.length > 0 ? endSel.options[Math.min(2, endSel.options.length - 1)].value : '');
  }
}

// Called when start time changes — rebuilds end-time options to ensure end > start
function updateBookingEndTimes() {
  const startSel = document.getElementById('booking-start');
  const endSel = document.getElementById('booking-end');
  const dateVal = document.getElementById('booking-date').value;
  const chosenStart = startSel.value;
  const prevEnd = endSel.value;

  const opts = buildTimeOptions(chosenStart, dateVal);

  if (opts === '') {
    endSel.innerHTML = '<option value="">— no valid end time —</option>';
    endSel.disabled = true;
  } else {
    endSel.innerHTML = opts;
    endSel.disabled = false;
  }

  // Re-apply availability dimming if active
  if (currentBookingAvailSlots) {
    // Warn if start time itself is outside instructor availability
    const startInAvail = currentBookingAvailSlots.has(chosenStart);
    if (!startInAvail && !document.getElementById('booking-avail-notice').innerHTML.includes('start-conflict')) {
      const notice = document.getElementById('booking-avail-notice');
      notice.className = 'avail-notice warn';
      notice.innerHTML = `<strong>⚠ Start time outside availability</strong><br><span style="font-size:0.82rem;">The selected start time (${chosenStart}) is outside the instructor's schedule. Dimmed times are outside their availability window.</span><input type="hidden" value="1" class="start-conflict">`;
      notice.classList.remove('hidden');
    }

    for (const opt of endSel.options) {
      opt.style.color = currentBookingAvailSlots.has(opt.value) ? '' : 'var(--gray-600)';
    }
    // Check if ALL end time options are dimmed (outside availability)
    const availableCount = Array.from(endSel.options).filter(opt => opt.style.color !== 'var(--gray-600)').length;
    if (availableCount === 0 && endSel.options.length > 0) {
      // Find the last available slot before the dimmed range to show a clear message
      const sortedSlots = Array.from(currentBookingAvailSlots).sort();
      let lastSlot = null;
      for (const slot of sortedSlots) {
        const [sh, sm] = slot.split(':').map(Number);
        const [ph, pm] = chosenStart.split(':').map(Number);
        if (sh > ph || (sh === ph && sm > pm)) {
          lastSlot = slot;
        }
      }
      const [lh, lm] = (lastSlot || chosenStart).split(':').map(Number);
      const lastFormatted = formatTimeStr(lh, lm);
      const [ch, cm] = chosenStart.split(':').map(Number);
      const startFormatted = formatTimeStr(ch, cm);

      // Replace dropdown with clear message instead of showing all-dimmed options
      endSel.innerHTML = `<option value="">— No slot available —</option>
<option value="" disabled>${startFormatted} – ${lastFormatted} (instructor unavailable after ${lastFormatted})</option>`;
      endSel.disabled = true;

      const notice = document.getElementById('booking-avail-notice');
      if (!notice.innerHTML.includes('avail-conflict')) {
        notice.className = 'avail-notice warn';
        notice.innerHTML = `<strong>⚠ End time unavailable</strong><br><span style="font-size:0.82rem;">Instructor is not available after ${lastFormatted}. No valid end time for a booking starting at ${startFormatted}.</span><input type="hidden" value="1" class="avail-conflict">`;
        notice.classList.remove('hidden');
      }
      return; // Dropdown replaced — no further selection logic needed
    }
  }

  // Try to preserve previous selection; otherwise pick first available (non-dimmed) option
  if (prevEnd && endSel.querySelector(`option[value="${prevEnd}"]`)) {
    endSel.value = prevEnd;
  } else if (endSel.options.length > 0) {
    // Default: first available (non-dimmed) option; fallback to last option if none available
    const availableOptions = Array.from(endSel.options).filter(opt => opt.style.color !== 'var(--gray-600)');
    if (availableOptions.length > 0) {
      endSel.value = availableOptions[0].value;
    } else {
      // All times dimmed — select the LAST option so something is selected (not "empty")
      endSel.value = endSel.options[endSel.options.length - 1].value;
    }
  }
}

function closeBookingModal() {
  document.getElementById('booking-modal').classList.add('hidden');
  currentBookingAvailSlots = null;
}

async function refreshBookingAvailability() {
  const notice = document.getElementById('booking-avail-notice');
  const instructorId = document.getElementById('booking-instructor').value;
  const date = document.getElementById('booking-date').value;

  // Reset
  notice.classList.add('hidden');
  notice.className = 'avail-notice hidden';
  notice.innerHTML = '';
  currentBookingAvailSlots = null;

  if (!instructorId || !date) return;

  try {
    const data = await api(`/api/bookings/check-availability?instructor_id=${instructorId}&date=${date}`);

    if (data.no_config) {
      // Instructor has no availability configured — fail-open, no notice needed
      return;
    }

    if (!data.available) {
      notice.innerHTML = `<strong>🚫 Instructor unavailable</strong><br><span style="font-size:0.82rem;">${data.reason || 'Not available on this date'}</span>`;
      notice.className = 'avail-notice warn';
      notice.classList.remove('hidden');
      return;
    }

    if (data.windows && data.windows.length > 0) {
      const windowLabels = data.windows.map(w => {
        const [sh, sm] = w.start.split(':').map(Number);
        const [eh, em] = w.end.split(':').map(Number);
        return `${formatTimeStr(sh, sm)} – ${formatTimeStr(eh, em)}`;
      }).join(', ');
      notice.innerHTML = `<strong>✅ Available ${data.day || ''}</strong> &nbsp;${windowLabels}`;
      notice.className = 'avail-notice';
      notice.classList.remove('hidden');

      // Build set of valid time slots from availability windows
      const validSlots = new Set();
      for (const w of data.windows) {
        const [sh, sm] = w.start.split(':').map(Number);
        const [eh, em] = w.end.split(':').map(Number);
        let h = sh, m = sm;
        while (h < eh || (h === eh && m <= em)) {
          validSlots.add(`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`);
          m += 30;
          if (m >= 60) { m = 0; h++; }
        }
      }
      currentBookingAvailSlots = validSlots;

      // Highlight time options that are outside availability
      const startSel = document.getElementById('booking-start');
      const endSel = document.getElementById('booking-end');
      for (const sel of [startSel, endSel]) {
        for (const opt of sel.options) {
          if (!validSlots.has(opt.value)) {
            opt.style.color = 'var(--gray-600)';
          } else {
            opt.style.color = '';
          }
        }
      }

      // Show blocked ranges if any
      if (data.blocked && data.blocked.length > 0) {
        const blockedLabels = data.blocked.map(b => {
          const [sh, sm] = b.start.split(':').map(Number);
          const [eh, em] = b.end.split(':').map(Number);
          return `${formatTimeStr(sh, sm)} – ${formatTimeStr(eh, em)}${b.reason ? ' (' + b.reason + ')' : ''}`;
        }).join(', ');
        notice.innerHTML += `<br><span style="font-size:0.78rem;color:var(--amber);">⚠ Blocked: ${blockedLabels}</span>`;
      }
    }
  } catch (e) {
    // Fail silently — availability preview is non-blocking
  }
}

// Re-filter aircraft dropdown when date changes — maintains downtime window filtering
async function refreshBookingAircraft() {
  const aircraftSel = document.getElementById('booking-aircraft');
  const date = document.getElementById('booking-date').value;
  const modal = document.getElementById('booking-modal');
  const errEl = document.getElementById('booking-error');

  // Only apply if modal is open
  if (!modal || modal.classList.contains('hidden')) return;
  if (!date) return;

  // Start with all available aircraft (matching openBookingModal logic)
  let availableAircraft = allAircraft.filter(a => a.status === 'available');

  // Filter out aircraft in maintenance downtime for the new date
  try {
    const downtimeEntries = await api(`/api/downtime/by-date?date=${date}`);
    const downAircraftIds = new Set((downtimeEntries || []).map(d => d.aircraft_id));
    if (downAircraftIds.size > 0) {
      availableAircraft = availableAircraft.filter(a => !downAircraftIds.has(a.id));
    }
  } catch (err) {
    // Downtime check failed — warn user and fall back to status-only filtering
    console.error('[refreshBookingAircraft] downtime API failed:', err);
    errEl.textContent = 'Warning: Could not verify maintenance schedule. Aircraft may be unavailable.';
    errEl.classList.remove('hidden');
    setTimeout(() => { errEl.classList.add('hidden'); }, 4000);
  }

  // Save current selection so we can try to restore it
  const prevSelected = aircraftSel.value;

  // Re-populate aircraft dropdown
  aircraftSel.innerHTML = availableAircraft.length ?
    availableAircraft.map(a => `<option value="${a.id}">${a.tail_number} - ${a.make_model}</option>`).join('') :
    '<option value="">No aircraft available</option>';

  // If previously selected aircraft is now in downtime, clear it and warn
  if (prevSelected && !availableAircraft.some(a => a.id == prevSelected)) {
    aircraftSel.value = '';
    errEl.textContent = 'Previously selected aircraft is in maintenance for this date. Please choose another.';
    errEl.classList.remove('hidden');
  }
}

document.getElementById('booking-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('booking-error');
  const conflictEl = document.getElementById('booking-conflicts');
  const bottomConflictEl = document.getElementById('booking-conflicts-bottom');
  errEl.classList.add('hidden');
  conflictEl.classList.add('hidden');
  bottomConflictEl.classList.add('hidden');

  const date = document.getElementById('booking-date').value;
  const startTime = document.getElementById('booking-start').value;
  const endTime = document.getElementById('booking-end').value;

  if (!date || !startTime || !endTime) {
    errEl.textContent = 'Please fill in all time fields';
    errEl.classList.remove('hidden');
    return;
  }

  // Block past dates — use current date at submission time (handles midnight edge case)
  const todayAtSubmit = new Date().toLocaleDateString('en-CA');
  if (date < todayAtSubmit) {
    errEl.textContent = 'Cannot book a flight for a past date. Please select today or a future date.';
    errEl.classList.remove('hidden');
    // Also refresh the min attribute in case the modal was open past midnight
    document.getElementById('booking-date').min = todayAtSubmit;
    return;
  }

  // Students and renters are locked to their own ID; others read from the dropdown
  const studentVal = (currentUser.role === 'student' || currentUser.role === 'renter')
    ? document.getElementById('booking-student-locked-id').value
    : document.getElementById('booking-student').value;
  const instructorVal = document.getElementById('booking-instructor').value;
  const student_id = studentVal ? parseInt(studentVal) : null;
  const instructor_id = instructorVal ? parseInt(instructorVal) : null;

  if (!student_id && !instructor_id) {
    errEl.textContent = 'At least one person (student or instructor) must be on the booking';
    errEl.classList.remove('hidden');
    return;
  }

  const start_time = new Date(`${date}T${startTime}:00`).toISOString();
  // Handle cross-midnight end times — flights that end the next day (e.g., 23:30 → 01:00)
  // "24:00" means exactly midnight next day; times less than start time also cross midnight
  let end_time;
  const endIsBeforeStart = endTime !== '24:00' && endTime < startTime;
  if (endTime === '24:00' || endIsBeforeStart) {
    const nextDay = new Date(`${date}T00:00:00`);
    nextDay.setDate(nextDay.getDate() + 1);
    end_time = nextDay.toISOString().slice(0, 10) + `T${endTime}:00`;
    end_time = new Date(end_time).toISOString();
  } else {
    end_time = new Date(`${date}T${endTime}:00`).toISOString();
  }

  try {
    await api('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({
        student_id,
        instructor_id,
        aircraft_id: parseInt(document.getElementById('booking-aircraft').value),
        start_time, end_time,
        // Send raw wall-clock values so server can compare against availability
        // windows without timezone conversion artifacts (POL-booking-tz-bug)
        local_date: date,
        local_start: startTime,
        local_end: endTime,
        lesson_type: document.getElementById('booking-lesson-type').value || null,
        notes: document.getElementById('booking-notes').value || null,
      })
    });
    closeBookingModal();
    if (currentPage === 'schedule') loadCalendar();
    else if (currentPage === 'dashboard') loadDashboard();
  } catch (err) {
    const bottomConflictEl = document.getElementById('booking-conflicts-bottom');
    bottomConflictEl.classList.add('hidden');
    if (err.conflicts) {
      const html = formatConflictMessages(err.conflicts);
      // Show conflicts ONLY near submit button (always visible)
      bottomConflictEl.innerHTML = html;
      bottomConflictEl.classList.remove('hidden');
      // Auto-scroll modal so the conflict is visible
      bottomConflictEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else if (err.availability_conflict) {
      let html = `<strong>🚫 ${escHtml(err.instructor_name)} is not available</strong><br><span style="font-size:0.85rem;">${escHtml(err.reason)}</span>`;
      if (err.next_slots && err.next_slots.length > 0) {
        html += `<div style="margin-top:0.5rem;font-size:0.82rem;color:var(--gray-300);">Next available slots:</div>`;
        html += err.next_slots.map(s => {
          const sd = new Date(s.start_time);
          const ed = new Date(s.end_time);
          const dl = sd.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',timeZone:'UTC'});
          const tl = `${formatTimeStr(sd.getUTCHours(),sd.getUTCMinutes())}–${formatTimeStr(ed.getUTCHours(),ed.getUTCMinutes())}`;
          return `<span style="display:inline-block;margin:0.2rem 0.3rem 0 0;font-size:0.75rem;padding:0.15rem 0.5rem;border-radius:5px;background:rgba(56,189,248,0.1);color:var(--sky);cursor:pointer;border:1px solid rgba(56,189,248,0.15);" onclick="applyBookingSlot('${s.start_time}','${s.end_time}')">${dl} ${tl}</span>`;
        }).join('');
      }
      if (err.alternative_instructors && err.alternative_instructors.length > 0) {
        html += `<div style="margin-top:0.4rem;font-size:0.82rem;">Available instructors: `;
        html += err.alternative_instructors.map(i =>
          `<span style="color:var(--green);cursor:pointer;text-decoration:underline;" onclick="document.getElementById('booking-instructor').value=${i.id};refreshBookingAvailability()">${escHtml(i.name)}</span>`
        ).join(', ');
        html += '</div>';
      }
      if (err.can_force) {
        html += `<div style="margin-top:0.5rem;"><button class="btn btn-sm btn-secondary" onclick="forceBookingSubmit()" style="width:auto;font-size:0.78rem;">Override — Book Anyway</button></div>`;
      }
      // Show availability conflicts near submit button too
      bottomConflictEl.innerHTML = html;
      bottomConflictEl.classList.remove('hidden');
      bottomConflictEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else if (err.error && (err.error.includes('maintenance') || err.error.includes('Maintenance'))) {
      // Specific handling for aircraft maintenance errors — include reason
      const reasonText = err.reason ? ` Reason: ${escHtml(err.reason)}` : '';
      errEl.innerHTML = `<span style="color:#f87171;">Aircraft is in maintenance for this date.</span>${reasonText}<br><span style="font-size:0.85rem;color:var(--gray-300);">Please select a different aircraft or date.</span>`;
      errEl.classList.remove('hidden');
      // Auto-scroll modal so the error is visible
      errEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      errEl.textContent = err.error || 'Failed to create booking';
      errEl.classList.remove('hidden');
    }
  }
});

// Apply a suggested available slot to the booking modal
function applyBookingSlot(startIso, endIso) {
  const start = new Date(startIso);
  const end = new Date(endIso);
  const dateStr = start.toISOString().slice(0, 10);
  const startHM = `${String(start.getUTCHours()).padStart(2,'0')}:${String(start.getUTCMinutes()).padStart(2,'0')}`;
  const endHM = `${String(end.getUTCHours()).padStart(2,'0')}:${String(end.getUTCMinutes()).padStart(2,'0')}`;

  const dateEl = document.getElementById('booking-date');
  if (dateEl) dateEl.value = dateStr;
  // Rebuild time pickers for new date, then set values
  rebuildBookingTimePickers();
  const startSel = document.getElementById('booking-start');
  const endSel = document.getElementById('booking-end');
  if (startSel) startSel.value = startHM;
  if (endSel) endSel.value = endHM;
  // Refresh availability display
  refreshBookingAvailability();
  // Clear conflict message
  document.getElementById('booking-conflicts').classList.add('hidden');
}

// Force-book: admin/owner bypasses availability check
let _pendingForceBooking = null;
async function forceBookingSubmit() {
  const date = document.getElementById('booking-date').value;
  const startTime = document.getElementById('booking-start').value;
  const endTime = document.getElementById('booking-end').value;
  const studentVal = (currentUser.role === 'student' || currentUser.role === 'renter')
    ? document.getElementById('booking-student-locked-id').value
    : document.getElementById('booking-student').value;
  const instructorVal = document.getElementById('booking-instructor').value;
  const start_time = new Date(`${date}T${startTime}:00`).toISOString();
  // Handle cross-midnight end times — flights that end the next day (e.g., 23:30 → 01:00)
  // "24:00" means exactly midnight next day; times less than start time also cross midnight
  let end_time;
  const endIsBeforeStart = endTime !== '24:00' && endTime < startTime;
  if (endTime === '24:00' || endIsBeforeStart) {
    const nextDay = new Date(`${date}T00:00:00`);
    nextDay.setDate(nextDay.getDate() + 1);
    end_time = nextDay.toISOString().slice(0, 10) + `T${endTime}:00`;
    end_time = new Date(end_time).toISOString();
  } else {
    end_time = new Date(`${date}T${endTime}:00`).toISOString();
  }

  const errEl = document.getElementById('booking-error');
  const conflictEl = document.getElementById('booking-conflicts');
  const bottomConflictEl = document.getElementById('booking-conflicts-bottom');
  errEl.classList.add('hidden');
  conflictEl.classList.add('hidden');
  bottomConflictEl.classList.add('hidden');

  try {
    await api('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({
        student_id: studentVal ? parseInt(studentVal) : null,
        instructor_id: instructorVal ? parseInt(instructorVal) : null,
        aircraft_id: parseInt(document.getElementById('booking-aircraft').value),
        start_time, end_time,
        local_date: date,
        local_start: startTime,
        local_end: endTime,
        lesson_type: document.getElementById('booking-lesson-type').value || null,
        notes: document.getElementById('booking-notes').value || null,
        force_booking: true
      })
    });
    closeBookingModal();
    if (currentPage === 'schedule') loadCalendar();
    else if (currentPage === 'dashboard') loadDashboard();
  } catch (e2) {
    if (e2.conflicts) {
      const html = formatConflictMessages(e2.conflicts);
      bottomConflictEl.innerHTML = html;
      bottomConflictEl.classList.remove('hidden');
      bottomConflictEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      errEl.textContent = e2.error || 'Failed to create booking';
      errEl.classList.remove('hidden');
    }
  }
}

async function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  try {
    await api(`/api/bookings/${id}`, { method: 'DELETE' });
    closeDayModal();
    if (currentPage === 'schedule') loadCalendar();
    else if (currentPage === 'dashboard') loadDashboard();
  } catch (err) {
    alert(err.error || 'Failed to cancel booking');
  }
}

// ─── POST-FLIGHT WIZARD ───
let pfwAircraftId = null;
let pfwSquawkCount = 0;
let pfwIsDualFlight = false;
let pfwStudentId = null;
let pfwFlightDate = null;

function openPostFlightWizard(bookingId, bookingDataOverride) {
  const b = bookingDataOverride || allBookings.find(bk => bk.id === bookingId);
  pfwAircraftId = b ? b.aircraft_id : null;

  document.getElementById('pfw-booking-id').value = bookingId;
  document.getElementById('pfw-error').classList.add('hidden');

  // Reset step 1
  document.getElementById('pfw-no-change').checked = false;
  document.getElementById('pfw-hours-fields').style.display = '';
  document.getElementById('pfw-hobbs-start').value = '';
  document.getElementById('pfw-hobbs-end').value = '';
  document.getElementById('pfw-tach-start').value = '';
  document.getElementById('pfw-tach-end').value = '';
  document.getElementById('pfw-hobbs-delta-row').classList.add('hidden');
  document.getElementById('pfw-tach-delta-row').classList.add('hidden');
  document.getElementById('pfw-val-error').classList.add('hidden');
  document.getElementById('pfw-is-night').checked = false;
  document.getElementById('pfw-is-xc').checked = false;
  document.getElementById('pfw-is-instrument').checked = false;
  document.getElementById('pfw-is-solo').checked = false;
  document.getElementById('pfw-dual-hours').value = '';
  document.getElementById('pfw-dual-hours-section').classList.add('hidden');

  // Reset step 2
  document.getElementById('pfw-no-squawks').checked = false;
  document.getElementById('pfw-squawk-fields').style.display = '';
  document.getElementById('pfw-squawk-list').innerHTML = '';
  pfwSquawkCount = 0;
  pfwAddSquawk(); // prime first squawk slot

  // Detect dual flight for debrief step
  pfwIsDualFlight = false;
  pfwStudentId = null;
  pfwFlightDate = null;
  if (b) {
    const isDual = b.booking_type === 'dual' || (b.student_id && b.instructor_id);
    const isInstructorUser = ['instructor', 'owner', 'admin'].includes(currentUser.role);
    pfwIsDualFlight = isDual && isInstructorUser;
    pfwStudentId = b.student_id;
    pfwFlightDate = b.start_time ? new Date(b.start_time).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
  }

  // Show/hide step 3 pill based on dual flight
  const step3Pill = document.getElementById('pfw-step3-pill');
  const step3Divider = document.getElementById('pfw-step3-divider');
  if (pfwIsDualFlight) {
    step3Pill.classList.remove('hidden');
    step3Divider.classList.remove('hidden');
  } else {
    step3Pill.classList.add('hidden');
    step3Divider.classList.add('hidden');
  }

  // Show/hide dual instruction hours input based on dual flight
  document.getElementById('pfw-dual-hours-section').classList.toggle('hidden', !pfwIsDualFlight);

  if (b) {
    const start = new Date(b.start_time);
    const end   = new Date(b.actual_end_time || b.end_time);
    let whoLine = '';
    if (b.student_name && b.instructor_name) whoLine = `${b.student_name} with ${b.instructor_name}`;
    else if (b.student_name) whoLine = `${b.student_name} (solo)`;
    else if (b.instructor_name) whoLine = `${b.instructor_name} (solo)`;
    document.getElementById('pfw-booking-info').innerHTML =
      `<strong>${b.tail_number}</strong> — ${formatTime(start)}–${formatTime(end)}<br>${whoLine}`;

    // Auto-fill Hobbs/Tach start from aircraft's last known reading
    const aircraft = allAircraft.find(a => a.id === b.aircraft_id);
    if (aircraft) {
      const curHobbs = parseFloat(aircraft.current_hobbs || aircraft.total_hobbs_hours || 0);
      const curTach  = parseFloat(aircraft.current_tach  || aircraft.total_tach_hours  || 0);
      if (curHobbs > 0) document.getElementById('pfw-hobbs-start').value = curHobbs.toFixed(1);
      if (curTach  > 0) document.getElementById('pfw-tach-start').value  = curTach.toFixed(1);
    }
    // Auto-check solo for student_solo bookings
    document.getElementById('pfw-is-solo').checked = (b.booking_type === 'student_solo');
  }

  // Set step 2 button text based on whether debrief follows
  const step2Btn = document.getElementById('pfw-step2-btn');
  if (pfwIsDualFlight) {
    step2Btn.textContent = 'Next — Debrief →';
    step2Btn.style.cssText = '';
  } else {
    step2Btn.textContent = 'Done ✓';
    step2Btn.style.cssText = 'background:linear-gradient(135deg,#10b981,#059669);';
  }

  pfwShowStep(1);
  document.getElementById('post-flight-wizard').classList.remove('hidden');
}

// Backward-compat alias (existing onclicks call openCompleteModal)
function openCompleteModal(bookingId) {
  const b = allBookings.find(bk => bk.id === bookingId);
  if (b) {
    const end = new Date(b.end_time);
    const now = new Date();
    if (end > now) {
      // Flight still in progress — need to confirm actual end time first
      openEndEarlyModal(bookingId);
      return;
    }
  }
  // Past flight — go straight to post-flight wizard
  openPostFlightWizard(bookingId);
}

function closePostFlightWizard() {
  document.getElementById('post-flight-wizard').classList.add('hidden');
}
function closeCompleteModal() { closePostFlightWizard(); }

function pfwShowStep(n) {
  document.getElementById('pfw-step1').classList.toggle('hidden', n !== 1);
  document.getElementById('pfw-step2').classList.toggle('hidden', n !== 2);
  document.getElementById('pfw-step3').classList.toggle('hidden', n !== 3);
  const pill1 = document.getElementById('pfw-step1-pill');
  const pill2 = document.getElementById('pfw-step2-pill');
  const pill3 = document.getElementById('pfw-step3-pill');
  const activeCss = 'display:flex;align-items:center;gap:0.4rem;padding:0.3rem 0.8rem;border-radius:20px;font-size:0.8rem;font-weight:700;background:var(--sky);color:var(--navy);white-space:nowrap;';
  const doneCss = 'display:flex;align-items:center;gap:0.4rem;padding:0.3rem 0.8rem;border-radius:20px;font-size:0.8rem;font-weight:700;background:rgba(56,189,248,0.15);color:var(--sky);white-space:nowrap;';
  const pendingCss = 'display:flex;align-items:center;gap:0.4rem;padding:0.3rem 0.8rem;border-radius:20px;font-size:0.8rem;font-weight:700;background:var(--slate);color:var(--gray-500);white-space:nowrap;';
  if (n === 1) {
    pill1.style.cssText = activeCss;
    pill2.style.cssText = pendingCss;
    if (pfwIsDualFlight) pill3.style.cssText = pendingCss;
  } else if (n === 2) {
    pill1.style.cssText = doneCss;
    pill2.style.cssText = activeCss;
    if (pfwIsDualFlight) pill3.style.cssText = pendingCss;
  } else if (n === 3) {
    pill1.style.cssText = doneCss;
    pill2.style.cssText = doneCss;
    pill3.style.cssText = activeCss;
  }
  document.getElementById('pfw-error').classList.add('hidden');
}

function pfwToggleNoChange() {
  const nc = document.getElementById('pfw-no-change').checked;
  document.getElementById('pfw-hours-fields').style.display = nc ? 'none' : '';
  document.getElementById('pfw-val-error').classList.add('hidden');
}

function pfwToggleNoSquawks() {
  const ns = document.getElementById('pfw-no-squawks').checked;
  document.getElementById('pfw-squawk-fields').style.display = ns ? 'none' : '';
}

function pfwUpdateDelta() {
  const hs = parseFloat(document.getElementById('pfw-hobbs-start').value);
  const he = parseFloat(document.getElementById('pfw-hobbs-end').value);
  const ts = parseFloat(document.getElementById('pfw-tach-start').value);
  const te = parseFloat(document.getElementById('pfw-tach-end').value);
  const valErr = document.getElementById('pfw-val-error');
  valErr.classList.add('hidden');

  const hobbsRow = document.getElementById('pfw-hobbs-delta-row');
  if (!isNaN(hs) && !isNaN(he)) {
    const hd = he - hs;
    hobbsRow.classList.remove('hidden'); hobbsRow.style.display = 'flex';
    const hdEl = document.getElementById('pfw-hobbs-delta-value');
    if (hd < 0) { hdEl.textContent = 'Invalid (end < start)'; hdEl.style.color = 'var(--red)'; }
    else { hdEl.textContent = hd.toFixed(1) + ' hrs'; hdEl.style.color = 'var(--sky)'; }
  } else { hobbsRow.classList.add('hidden'); hobbsRow.style.display = 'none'; }

  const tachRow = document.getElementById('pfw-tach-delta-row');
  if (!isNaN(ts) && !isNaN(te)) {
    const td = te - ts;
    tachRow.classList.remove('hidden'); tachRow.style.display = 'flex';
    const tdEl = document.getElementById('pfw-tach-delta-value');
    if (td < 0) { tdEl.textContent = 'Invalid (end < start)'; tdEl.style.color = 'var(--red)'; }
    else { tdEl.textContent = td.toFixed(1) + ' hrs'; tdEl.style.color = 'var(--sky)'; }
  } else { tachRow.classList.add('hidden'); tachRow.style.display = 'none'; }

  const errors = [];
  if (!isNaN(hs) && !isNaN(he) && he < hs) errors.push('Hobbs End must be ≥ Hobbs Start');
  if (!isNaN(ts) && !isNaN(te) && te < ts) errors.push('Tach End must be ≥ Tach Start');
  if (errors.length) { valErr.textContent = errors.join('. '); valErr.classList.remove('hidden'); }
}

async function pfwSubmitStep1() {
  const bookingId  = document.getElementById('pfw-booking-id').value;
  const noChange   = document.getElementById('pfw-no-change').checked;
  const errEl      = document.getElementById('pfw-error');
  errEl.classList.add('hidden');

  if (!noChange) {
    const hs = document.getElementById('pfw-hobbs-start').value;
    const he = document.getElementById('pfw-hobbs-end').value;
    const ts = document.getElementById('pfw-tach-start').value;
    const te = document.getElementById('pfw-tach-end').value;
    const valErr = document.getElementById('pfw-val-error');
    valErr.classList.add('hidden');
    const errs = [];
    if (hs !== '' && he !== '' && parseFloat(he) < parseFloat(hs)) errs.push('Hobbs End must be ≥ Hobbs Start');
    if (ts !== '' && te !== '' && parseFloat(te) < parseFloat(ts)) errs.push('Tach End must be ≥ Tach Start');
    if (errs.length) { valErr.textContent = errs.join('. '); valErr.classList.remove('hidden'); return; }
  }

  const btn = document.getElementById('pfw-step1-btn');
  btn.disabled = true; btn.textContent = 'Saving…';

  // Capture booking info BEFORE data refresh (allBookings gets updated after)
  const bForDebrief = allBookings ? allBookings.find(bk => bk.id === parseInt(bookingId)) : null;

  try {
    const hs = document.getElementById('pfw-hobbs-start').value;
    const he = document.getElementById('pfw-hobbs-end').value;
    const ts = document.getElementById('pfw-tach-start').value;
    const te = document.getElementById('pfw-tach-end').value;

    const dualHrsVal = document.getElementById('pfw-dual-hours').value;
    await api(`/api/bookings/${bookingId}/complete`, {
      method: 'PATCH',
      body: JSON.stringify({
        no_change: noChange,
        hobbs_start: !noChange && hs !== '' ? parseFloat(hs) : null,
        hobbs_end:   !noChange && he !== '' ? parseFloat(he) : null,
        tach_start:  !noChange && ts !== '' ? parseFloat(ts) : null,
        tach_end:    !noChange && te !== '' ? parseFloat(te) : null,
        is_night:       document.getElementById('pfw-is-night').checked,
        is_xc:          document.getElementById('pfw-is-xc').checked,
        is_instrument:  document.getElementById('pfw-is-instrument').checked,
        is_solo:        document.getElementById('pfw-is-solo').checked,
        dual_instruction_hours: pfwIsDualFlight && dualHrsVal !== '' ? parseFloat(dualHrsVal) : null,
      })
    });

    await loadAircraft(); // refresh so next completion gets updated current_hobbs/current_tach
    pfwShowStep(2);
  } catch (err) {
    errEl.textContent = err.error || 'Failed to record hours';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = 'Next — Squawks →';
  }
}

function pfwGoToStep1() { pfwShowStep(1); }

function pfwAddSquawk() {
  pfwSquawkCount++;
  const n = pfwSquawkCount;
  const container = document.getElementById('pfw-squawk-list');
  const div = document.createElement('div');
  div.id = `pfw-squawk-entry-${n}`;
  div.style.cssText = 'background:var(--slate);border-radius:8px;padding:0.75rem;margin-bottom:0.75rem;';
  div.innerHTML = `
    <div class="form-group" style="margin-bottom:0.5rem;">
      <label style="font-size:0.82rem;color:var(--gray-400);">Description</label>
      <textarea id="pfw-squawk-desc-${n}" rows="2" placeholder="e.g. Left main gear shimmy on rollout, avionics master switch stiff…" style="resize:vertical;min-height:58px;font-size:0.88rem;"></textarea>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;gap:0.5rem;">
      <select id="pfw-squawk-sev-${n}" style="flex:1;font-size:0.85rem;">
        <option value="minor">Minor</option>
        <option value="major">Major</option>
        <option value="grounding">Grounding — aircraft AOG</option>
      </select>
      ${n > 1 ? `<button type="button" onclick="pfwRemoveSquawk(${n})" style="color:var(--gray-500);background:none;border:none;cursor:pointer;font-size:1rem;padding:0.2rem 0.4rem;line-height:1;" title="Remove">✕</button>` : ''}
    </div>`;
  container.appendChild(div);
}

function pfwRemoveSquawk(n) {
  const el = document.getElementById(`pfw-squawk-entry-${n}`);
  if (el) el.remove();
}

async function pfwSubmitStep2() {
  const bookingId  = parseInt(document.getElementById('pfw-booking-id').value);
  const noSquawks  = document.getElementById('pfw-no-squawks').checked;
  const errEl      = document.getElementById('pfw-error');
  errEl.classList.add('hidden');

  const btn = document.getElementById('pfw-step2-btn');
  btn.disabled = true; btn.textContent = 'Saving…';

  try {
    if (!noSquawks) {
      const entries = document.getElementById('pfw-squawk-list').querySelectorAll('[id^="pfw-squawk-entry-"]');
      for (const entry of entries) {
        const n    = entry.id.replace('pfw-squawk-entry-', '');
        const desc = document.getElementById(`pfw-squawk-desc-${n}`)?.value?.trim();
        const sev  = document.getElementById(`pfw-squawk-sev-${n}`)?.value || 'minor';
        if (desc) {
          await api('/api/squawks', {
            method: 'POST',
            body: JSON.stringify({ aircraft_id: pfwAircraftId, description: desc, severity: sev })
          });
        }
      }
    }

    // If dual flight and user is instructor, show debrief step
    if (pfwIsDualFlight) {
      document.getElementById('pfw-debrief-student-id').value = pfwStudentId || '';
      document.getElementById('pfw-debrief-booking-id').value = bookingId;
      document.getElementById('pfw-debrief-flight-date').value = pfwFlightDate || new Date().toISOString().split('T')[0];
      document.getElementById('pfw3-notes').value = '';
      document.getElementById('pfw3-recommendations').value = '';
      document.getElementById('pfw3-error').classList.add('hidden');
      const pfw3Ov = document.getElementById('pfw3-overall-val');
      if (pfw3Ov) pfw3Ov.value = '';
      initDebriefTopics('pfw3');
      const overallCont = document.getElementById('pfw3-overall-stars');
      if (overallCont) {
        overallCont.querySelectorAll('span').forEach(s => { s.textContent = '☆'; s.style.color = 'var(--gray-500)'; });
        initStarContainer('pfw3-overall-stars', 'pfw3-overall-val');
      }
      pfwShowStep(3);
    } else {
      closePostFlightWizard();
      if (currentPage === 'schedule') loadCalendar();
      else if (currentPage === 'flight-log') loadFlightLog();
      else if (currentPage === 'history') loadHistoryLegacyPage();
      else loadDashboard();
      showToast(noSquawks ? 'Flight complete. No squawks.' : 'Flight complete. Squawk(s) reported.');
    }
  } catch (err) {
    errEl.textContent = err.error || 'Failed to submit squawk';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = pfwIsDualFlight ? 'Next — Debrief →' : 'Done ✓';
  }
}

async function pfwSubmitStep3() {
  const errEl = document.getElementById('pfw3-error');
  errEl.classList.add('hidden');
  const studentId = parseInt(document.getElementById('pfw-debrief-student-id').value);
  const bookingId = parseInt(document.getElementById('pfw-debrief-booking-id').value);
  const flightDate = document.getElementById('pfw-debrief-flight-date').value;
  const notes = (document.getElementById('pfw3-notes').value || '').trim() || null;
  const recommendations = (document.getElementById('pfw3-recommendations').value || '').trim() || null;
  const overall = parseInt(document.getElementById('pfw3-overall-val').value) || null;
  const grades = collectDebriefGrades('pfw3');

  const btn = document.getElementById('pfw-step3-btn');
  btn.disabled = true; btn.textContent = 'Saving…';

  try {
    await api('/api/training/debriefs', {
      method: 'POST',
      body: JSON.stringify({ student_id: studentId, booking_id: bookingId, flight_date: flightDate, notes, recommendations, overall_performance: overall, grades })
    });
    closePostFlightWizard();
    if (currentPage === 'schedule') loadCalendar();
    else if (currentPage === 'flight-log') loadFlightLog();
    else if (currentPage === 'history') loadHistoryLegacyPage();
    else loadDashboard();
    showToast('Flight complete. Debrief saved.');
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save debrief';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = 'Save Debrief ✓';
  }
}

function pfwSkipStep3() {
  closePostFlightWizard();
  if (currentPage === 'schedule') loadCalendar();
  else if (currentPage === 'flight-log') loadFlightLog();
  else if (currentPage === 'history') loadHistoryLegacyPage();
  else loadDashboard();
  showToast('Flight complete. Debrief skipped.');
}

// ─── CANCEL MODAL ───
function openCancelModal(bookingId) {
  const b = allBookings.find(bk => bk.id === bookingId);
  document.getElementById('cancel-booking-id').value = bookingId;
  document.getElementById('cancel-reason').value = '';

  if (b) {
    const start = new Date(b.start_time);
    const end = new Date(b.end_time);
    let whoLine = '';
    if (b.student_name && b.instructor_name) whoLine = `${b.student_name} with ${b.instructor_name}`;
    else if (b.student_name) whoLine = `${b.student_name} (solo)`;
    else if (b.instructor_name) whoLine = `${b.instructor_name} (solo)`;
    document.getElementById('cancel-booking-info').innerHTML =
      `<strong>${b.tail_number}</strong> — ${formatTime(start)}–${formatTime(end)}<br>${whoLine}`;
  }

  document.getElementById('cancel-modal').classList.remove('hidden');
}

function closeCancelModal() {
  document.getElementById('cancel-modal').classList.add('hidden');
}

document.getElementById('cancel-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const bookingId = document.getElementById('cancel-booking-id').value;
  const reason = document.getElementById('cancel-reason').value || null;

  try {
    await api(`/api/bookings/${bookingId}`, {
      method: 'DELETE',
      body: JSON.stringify({ reason })
    });
    closeCancelModal();
    if (currentPage === 'schedule') loadCalendar();
    else loadDashboard();
  } catch (err) {
    alert(err.error || 'Failed to cancel booking');
  }
});

// ─── END FLIGHT EARLY MODAL ───
function openEndEarlyModal(bookingId) {
  const b = allBookings.find(bk => bk.id === bookingId);
  document.getElementById('end-early-booking-id').value = bookingId;
  document.getElementById('end-early-error').classList.add('hidden');

  if (b) {
    const start = new Date(b.start_time);
    const end = new Date(b.end_time);
    const now = new Date();
    const actualEnd = now < start ? start : now;
    const hoursFlown = Math.max(0, (actualEnd - start) / (1000 * 60 * 60));
    const freedMins = Math.round((end - actualEnd) / (1000 * 60));

    let whoLine = '';
    if (b.student_name && b.instructor_name) whoLine = `${b.student_name} with ${b.instructor_name}`;
    else if (b.student_name) whoLine = `${b.student_name} (solo)`;
    else if (b.instructor_name) whoLine = `${b.instructor_name} (solo)`;

    document.getElementById('end-early-booking-info').innerHTML =
      `<strong>${b.tail_number}</strong> — ${formatTime(start)}–${formatTime(end)}<br>${whoLine}`;

    if (freedMins > 0) {
      document.getElementById('end-early-hours').textContent = hoursFlown.toFixed(1) + 'h';
      const freedStr = freedMins >= 60
        ? `${Math.floor(freedMins / 60)}h ${freedMins % 60}m`
        : `${freedMins}m`;
      document.getElementById('end-early-freed').textContent = freedStr + ' freed';
      document.getElementById('end-early-summary').style.display = 'block';
    } else {
      document.getElementById('end-early-summary').style.display = 'none';
    }
  }

  const btn = document.getElementById('end-early-confirm-btn');
  btn.disabled = false;
  btn.textContent = 'Complete Flight';
  document.getElementById('end-early-modal').classList.remove('hidden');
}

function closeEndEarlyModal() {
  document.getElementById('end-early-modal').classList.add('hidden');
}

async function submitEndEarly() {
  const bookingId = document.getElementById('end-early-booking-id').value;
  const errEl = document.getElementById('end-early-error');
  errEl.classList.add('hidden');

  const btn = document.getElementById('end-early-confirm-btn');
  btn.disabled = true;
  btn.textContent = 'Completing flight…';

  try {
    const result = await api(`/api/bookings/${bookingId}/end-early`, {
      method: 'PATCH',
      body: JSON.stringify({ actual_end_time: new Date().toISOString() })
    });

    closeEndEarlyModal();
    // Reload schedule/dashboard so allBookings is refreshed before wizard opens
    if (currentPage === 'schedule') await loadCalendar();
    else await loadDashboard();

    // Open post-flight wizard to capture Hobbs/Tach + squawks
    // Pass booking data directly from API response since allBookings may not include completed bookings
    openPostFlightWizard(parseInt(bookingId), result.booking);
  } catch (err) {
    errEl.textContent = err.error || 'Failed to complete flight';
    errEl.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = 'Complete Flight';
  }
}

// ─── EDIT HOURS MODAL ───
function openEditHoursModal(bookingId) {
  const b = allBookings.find(bk => bk.id === bookingId);
  document.getElementById('edit-hours-booking-id').value = bookingId;
  document.getElementById('edit-hours-error').classList.add('hidden');

  if (b) {
    const start = new Date(b.start_time);
    const end = new Date(b.end_time);
    let whoLine = '';
    if (b.student_name && b.instructor_name) whoLine = `${b.student_name} with ${b.instructor_name}`;
    else if (b.student_name) whoLine = `${b.student_name} (solo)`;
    else if (b.instructor_name) whoLine = `${b.instructor_name} (solo)`;
    document.getElementById('edit-hours-booking-info').innerHTML =
      `<strong>${b.tail_number}</strong> — ${formatTime(start)}–${formatTime(end)}<br>${whoLine}`;

    document.getElementById('edit-hobbs-start').value = b.hobbs_start ?? '';
    document.getElementById('edit-hobbs-end').value = b.hobbs_end ?? '';
    document.getElementById('edit-tach-start').value = b.tach_start ?? '';
    document.getElementById('edit-tach-end').value = b.tach_end ?? '';
  }

  document.getElementById('edit-hours-modal').classList.remove('hidden');
}

function closeEditHoursModal() {
  document.getElementById('edit-hours-modal').classList.add('hidden');
}

document.getElementById('edit-hours-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('edit-hours-error');
  errEl.classList.add('hidden');

  const bookingId = document.getElementById('edit-hours-booking-id').value;
  const hobbsStart = document.getElementById('edit-hobbs-start').value;
  const hobbsEnd = document.getElementById('edit-hobbs-end').value;
  const tachStart = document.getElementById('edit-tach-start').value;
  const tachEnd = document.getElementById('edit-tach-end').value;

  try {
    await api(`/api/bookings/${bookingId}/hours`, {
      method: 'PATCH',
      body: JSON.stringify({
        hobbs_start: hobbsStart !== '' ? parseFloat(hobbsStart) : null,
        hobbs_end: hobbsEnd !== '' ? parseFloat(hobbsEnd) : null,
        tach_start: tachStart !== '' ? parseFloat(tachStart) : null,
        tach_end: tachEnd !== '' ? parseFloat(tachEnd) : null,
      })
    });
    closeEditHoursModal();
    if (currentPage === 'schedule') loadCalendar();
    else loadDashboard();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to update hours';
    errEl.classList.remove('hidden');
  }
});

// ─── FLEET ───
async function loadFleet() {
  await loadAircraft();
  const tbody = document.getElementById('fleet-table');
  const emptyEl = document.getElementById('fleet-empty');

  if (allAircraft.length === 0) {
    tbody.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }

  emptyEl.classList.add('hidden');
  const perms = currentUser.permissions || {};
  const canEdit = currentUser.role === 'owner' || perms.can_manage_aircraft;
  // All instructors, admins, and owners can edit hours
  const canEditHours = ['owner', 'instructor', 'admin'].includes(currentUser.role);
  // Only owner and admin can delete aircraft
  const canDelete = currentUser.role === 'owner' || currentUser.role === 'admin';

  // Show/hide Schedule Downtime button based on permission
  document.getElementById('schedule-downtime-btn').classList.toggle('hidden', !canEdit);

  tbody.innerHTML = allAircraft.map(a => {
    const statusClass = a.status === 'available' ? 'tag-green' : a.status === 'maintenance' ? 'tag-amber' : 'tag-red';
    return `<tr>
      <td style="font-family:'Space Grotesk';font-weight:600">${a.tail_number}</td>
      <td>${a.make_model}</td>
      <td>${a.type.replace('_', ' ')}</td>
      <td>${a.year || '-'}</td>
      <td>${a.hourly_rate ? '$' + parseFloat(a.hourly_rate).toFixed(0) : '-'}</td>
      <td style="font-family:'Space Grotesk';font-weight:500;color:var(--sky)">
        ${a.total_hobbs_hours != null ? parseFloat(a.total_hobbs_hours).toFixed(1) : '0.0'}
        ${canEditHours ? `<button class="btn btn-secondary btn-sm" style="margin-left:0.4rem;padding:2px 7px;font-size:0.7rem" onclick="openInspectionModalHoursOnly(${a.id}, '${escHtml(a.tail_number)}')">Edit</button>` : ''}
      </td>
      <td style="font-family:'Space Grotesk';font-weight:500;color:var(--sky)">${a.total_tach_hours != null ? parseFloat(a.total_tach_hours).toFixed(1) : '0.0'}</td>
      <td><span class="tag ${statusClass}">${a.status}</span></td>
      <td style="white-space:nowrap">
        ${canEdit ? `<button class="btn btn-secondary btn-sm" onclick="editAircraft(${a.id})">Edit</button>` : ''}
        <button class="btn btn-secondary btn-sm" onclick="openHoursHistory(${a.id}, '${escHtml(a.tail_number)}')" title="Hours history" style="margin-left:0.25rem">History</button>
        ${canDelete ? `<button class="btn btn-danger btn-sm" onclick="openDeleteAircraftModal(${a.id}, '${escHtml(a.tail_number)}')" style="margin-left:0.25rem" title="Delete aircraft">Delete</button>` : ''}
      </td>
      <td>
        ${canEdit ? `<button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="openDowntimeModal(${a.id})">Downtime</button>` : ''}
      </td>
    </tr>`;
  }).join('');
}

function openAircraftModal(aircraft) {
  const isEdit = !!aircraft;
  document.getElementById('aircraft-modal-title').textContent = isEdit ? 'Edit Aircraft' : 'Add Aircraft';
  document.getElementById('aircraft-error').classList.add('hidden');
  editingAircraftId = isEdit ? aircraft.id : null;

  if (isEdit) {
    document.getElementById('aircraft-tail').value = aircraft.tail_number;
    document.getElementById('aircraft-make').value = aircraft.make_model;
    document.getElementById('aircraft-type').value = aircraft.type;
    document.getElementById('aircraft-year').value = aircraft.year || '';
    document.getElementById('aircraft-rate').value = aircraft.hourly_rate || '';
    document.getElementById('aircraft-notes').value = aircraft.notes || '';
  } else {
    document.getElementById('aircraft-form').reset();
  }
  document.getElementById('aircraft-modal').classList.remove('hidden');
}

function closeAircraftModal() {
  document.getElementById('aircraft-modal').classList.add('hidden');
  editingAircraftId = null;
}

// ─── DELETE AIRCRAFT ────────────────────────────────────────────────────────
let deletingAircraftId = null;

function openDeleteAircraftModal(aircraftId, tailNumber) {
  deletingAircraftId = aircraftId;
  document.getElementById('delete-aircraft-tail').textContent = tailNumber;
  document.getElementById('delete-aircraft-counts').textContent = '';
  document.getElementById('delete-aircraft-error').classList.add('hidden');
  document.getElementById('delete-aircraft-modal').classList.remove('hidden');
}

function closeDeleteAircraftModal() {
  document.getElementById('delete-aircraft-modal').classList.add('hidden');
  deletingAircraftId = null;
}

async function confirmDeleteAircraft() {
  if (!deletingAircraftId) return;
  const btn = document.getElementById('confirm-delete-aircraft-btn');
  btn.disabled = true;
  btn.textContent = 'Deleting...';
  try {
    const res = await api(`/api/aircraft/${deletingAircraftId}`, { method: 'DELETE' });
    closeDeleteAircraftModal();
    // Remove from local fleet
    allAircraft = allAircraft.filter(a => a.id !== deletingAircraftId);
    loadFleet();
    // Refresh the booking modal aircraft list if open
    if (document.getElementById('booking-modal') && !document.getElementById('booking-modal').classList.contains('hidden')) {
      await populateFleetAircraft();
    }
  } catch (err) {
    const errEl = document.getElementById('delete-aircraft-error');
    errEl.textContent = err.message || 'Failed to delete aircraft';
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Delete Aircraft';
  }
}

// ─── AIRCRAFT DOWNTIME ──────────────────────────────────────────────────────
async function openDowntimeModal(aircraftId) {
  const errEl = document.getElementById('downtime-error');
  errEl.classList.add('hidden');

  // Pre-select aircraft if passed
  const sel = document.getElementById('downtime-aircraft');
  sel.innerHTML = allAircraft.map(a =>
    `<option value="${a.id}">${escHtml(a.tail_number)} - ${escHtml(a.make_model)}</option>`
  ).join('');
  if (aircraftId) sel.value = aircraftId;

  document.getElementById('downtime-form').reset();
  await loadDowntimeEntries();
  document.getElementById('downtime-modal').classList.remove('hidden');
}

function closeDowntimeModal() {
  document.getElementById('downtime-modal').classList.add('hidden');
}

async function loadDowntimeEntries() {
  const aircraftId = document.getElementById('downtime-aircraft').value;
  const el = document.getElementById('downtime-entries');
  try {
    const data = await api(`/api/downtime?aircraft_id=${aircraftId}`);
    if (!data || data.length === 0) {
      el.innerHTML = '<div style="color:var(--gray-500);font-size:0.82rem;text-align:center;padding:0.75rem">No scheduled downtime</div>';
      return;
    }
    const today = new Date().toISOString().slice(0, 10);
    const canManageDowntime = currentUser && ['owner','admin'].includes(currentUser.role);
    el.innerHTML = data.map(d => {
      const isPast = d.end_date < today;
      const removeBtn = canManageDowntime
        ? `<button class="btn btn-sm" style="padding:2px 8px;font-size:0.7rem;background:rgba(239,68,68,0.15);color:#f87171;border:none" onclick="deleteDowntimeEntry(${d.id})">Remove</button>`
        : '';
      return `<div style="display:flex;align-items:center;justify-content:space-between;padding:0.4rem 0.5rem;border-bottom:1px solid rgba(255,255,255,0.05);font-size:0.82rem;${isPast ? 'opacity:0.5' : ''}">
        <div>
          <span style="color:var(--sky)">${d.start_date}</span>
          <span style="color:var(--gray-500)"> → </span>
          <span style="color:var(--sky)">${d.end_date}</span>
          ${d.reason ? `<span style="color:var(--gray-400);margin-left:0.4rem">${escHtml(d.reason)}</span>` : ''}
        </div>
        ${removeBtn}
      </div>`;
    }).join('');
  } catch {
    el.innerHTML = '<div style="color:var(--gray-500);font-size:0.82rem;text-align:center;padding:0.75rem">Failed to load entries</div>';
  }
}

async function deleteDowntimeEntry(id) {
  if (!confirm('Remove this downtime window?')) return;
  try {
    await api(`/api/downtime/${id}`, { method: 'DELETE' });
    await loadDowntimeEntries();
  } catch (err) {
    const errEl = document.getElementById('downtime-error');
    errEl.textContent = err.error || 'Failed to remove downtime';
    errEl.classList.remove('hidden');
  }
}

document.getElementById('downtime-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('downtime-error');
  errEl.classList.add('hidden');
  const aircraft_id = document.getElementById('downtime-aircraft').value;
  const start_date = document.getElementById('downtime-start').value;
  const end_date = document.getElementById('downtime-end').value;
  const reason = document.getElementById('downtime-reason').value;
  const create_squawk = document.getElementById('downtime-create-squawk').checked;
  if (end_date < start_date) {
    errEl.textContent = 'End date must be on or after start date';
    errEl.classList.remove('hidden');
    return;
  }
  try {
    await api('/api/downtime', {
      method: 'POST',
      body: JSON.stringify({ aircraft_id: parseInt(aircraft_id), start_date, end_date, reason, create_squawk })
    });
    document.getElementById('downtime-form').reset();
    await loadDowntimeEntries();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to schedule downtime';
    errEl.classList.remove('hidden');
  }
});

function editAircraft(id) {
  const aircraft = allAircraft.find(a => a.id === id);
  if (aircraft) openAircraftModal(aircraft);
}

document.getElementById('aircraft-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('aircraft-error');
  errEl.classList.add('hidden');

  const data = {
    tail_number: document.getElementById('aircraft-tail').value,
    make_model: document.getElementById('aircraft-make').value,
    type: document.getElementById('aircraft-type').value,
    year: document.getElementById('aircraft-year').value ? parseInt(document.getElementById('aircraft-year').value) : null,
    hourly_rate: document.getElementById('aircraft-rate').value ? parseFloat(document.getElementById('aircraft-rate').value) : null,
    notes: document.getElementById('aircraft-notes').value || null,
  };

  try {
    if (editingAircraftId) {
      await api(`/api/aircraft/${editingAircraftId}`, { method: 'PUT', body: JSON.stringify(data) });
    } else {
      await api('/api/aircraft', { method: 'POST', body: JSON.stringify(data) });
    }
    closeAircraftModal();
    loadFleet();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save aircraft';
    errEl.classList.remove('hidden');
  }
});

// ─── PEOPLE / USER MANAGEMENT ───
async function loadPeople(filter, skipReload) {
  currentPeopleFilter = filter;
  if (!skipReload) await loadUsers();

  document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.filter === filter);
  });

  const isOwner = ['owner', 'admin'].includes(currentUser.role);
  const perms = currentUser.permissions || {};
  const canManagePerms = isOwner || perms.can_manage_permissions;
  const canManageInstructors = isOwner || perms.can_manage_instructors;
  const canManageStudents = isOwner || perms.can_manage_students;
  const canAddUsers = isOwner || canManageInstructors || canManageStudents;

  const users = filter === 'all' ? allUsers : allUsers.filter(u => u.role === filter);

  // Show/hide Add User button
  document.getElementById('add-user-btn').classList.toggle('hidden', !canAddUsers);

  // Show claim-owner banner if no owner exists
  var banner = document.getElementById('claim-owner-banner');
  if (!hasOwnerAccount && currentUser.role !== 'student') {
    banner.style.display = 'flex';
  } else {
    banner.style.display = 'none';
  }

  // Show permission banner for permission managers
  document.getElementById('perm-banner').classList.toggle('hidden', !canManagePerms);

  // Update page title
  document.getElementById('people-title').textContent = canManagePerms ? 'User Management' : 'People';

  var thead = document.getElementById('people-thead');
  var tbody = document.getElementById('people-table');

  // Update save bar
  renderSaveBar();

  if (canManagePerms) {
    // Management view with permission toggles
    thead.innerHTML = '<tr>' +
      '<th class="people-sticky">User</th><th class="people-sticky-2">Role</th>' +
      '<th>Phone</th>' +
      '<th>Rate/hr</th>' +
      '<th class="perm-col-header" style="text-align:center">Aircraft</th>' +
      '<th class="perm-col-header" style="text-align:center">Instructors</th>' +
      '<th class="perm-col-header" style="text-align:center">Students</th>' +
      '<th class="perm-col-header" style="text-align:center">Permissions</th>' +
      '<th class="perm-col-header" style="text-align:center">Website</th>' +
      '<th></th></tr>';

    tbody.innerHTML = users.map(function(u) {
      var isTargetOwner = u.role === 'owner';
      var isTargetStudent = u.role === 'student';
      var isNonMgmtRole = ['student', 'renter', 'maintenance'].includes(u.role);
      var disabled = isTargetOwner || isNonMgmtRole;
      var isSelf = u.id === currentUser.id;
      var canEditAvail = (!!u.is_instructor) && (isOwner || isSelf || canManageInstructors);
      var isDualRole = !!u.is_instructor && ['admin', 'owner'].includes(u.role) && u.role !== 'instructor';
      var roleClass = u.role === 'owner' ? 'tag-gold' : u.role === 'instructor' ? 'tag-sky' : u.role === 'admin' ? 'tag-amber' : u.role === 'renter' ? 'tag-green' : u.role === 'maintenance' ? 'tag-amber' : 'tag-purple';
      var roleLabel = u.role === 'owner' ? 'Owner' : u.role === 'instructor' ? 'Instructor' : isDualRole ? 'Admin / Instructor' : u.role === 'admin' ? 'Admin' : u.role === 'renter' ? 'Renter' : u.role === 'maintenance' ? 'Maintenance' : 'Student';
      var editRoleBtn = isOwner && !isSelf ? ' <button style="background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s" title="Edit user" onmouseover="this.style.color=\'var(--sky)\'" onmouseout="this.style.color=\'var(--gray-400)\'" onclick="openRoleChangeModal(' + u.id + ',\'' + escHtml(u.name).replace(/'/g,"\\'") + '\',\'' + u.role + '\', ' + (!!u.is_instructor ? 'true' : 'false') + ')'">&#9998;</button>' : '';

      function makeToggle(perm, value) {
        var checked = isTargetOwner ? true : !!value;
        var title = isTargetOwner ? 'Owner has all permissions' : isNonMgmtRole ? (u.role === 'student' ? 'Students' : u.role === 'renter' ? 'Renters' : 'Maintenance') + ' cannot have management permissions' : '';
        return '<label class="toggle-switch" title="' + title + '">' +
          '<input type="checkbox" ' + (checked ? 'checked ' : '') + (disabled ? 'disabled ' : '') +
          'onchange="stagePermissionChange(' + u.id + ', \'' + perm + '\', this.checked)">' +
          '<span class="toggle-slider"></span></label>';
      }

      var canEditAvail = (u.role === 'instructor' || (u.role === 'admin' && u.has_instructor_availability)) && (isOwner || isSelf || canManageInstructors);
      var canDelete = !isSelf && !isTargetOwner && (isOwner ||
        (u.role === 'instructor' && canManageInstructors) ||
        (['student', 'renter'].includes(u.role) && canManageStudents));

      var note = isTargetOwner ? '<span class="perm-note">Full access</span>' :
                 isNonMgmtRole ? '<span class="perm-note">No management access</span>' : '';

      var rateCell = '';
      var canHaveRate = ['instructor', 'admin', 'owner'].includes(u.role);
      if (canHaveRate && isOwner) {
        var rateVal = u.instructor_rate != null ? parseFloat(u.instructor_rate).toFixed(2) : '';
        rateCell = '<div class="rate-input-wrap">' +
          '<span style="color:var(--gray-300);font-size:0.85rem;">$</span>' +
          '<input type="number" id="rate-' + u.id + '" min="0" step="0.01" placeholder="0.00" value="' + escHtml(rateVal) + '" style="width:80px">' +
          '<button class="btn-save-rate" onclick="saveInstructorRate(' + u.id + ', \'rate-' + u.id + '\')">Save</button>' +
          '</div>';
      } else if (canHaveRate) {
        rateCell = u.instructor_rate != null ? '<span style="color:var(--gray-300)">$' + parseFloat(u.instructor_rate).toFixed(2) + '/hr</span>' : '<span style="color:var(--gray-500)">—</span>';
      } else {
        rateCell = '<span style="color:var(--gray-500)">—</span>';
      }

      return '<tr>' +
        '<td class="people-sticky"><div style="font-weight:600">' + escHtml(u.name) + (isSelf ? ' <span style="color:var(--gray-500);font-weight:400;font-size:0.8rem">(you)</span>' : '') + '</div><div style="font-size:0.8rem;color:var(--gray-500)">' + escHtml(u.email) + '</div></td>' +
        '<td class="people-sticky-2" style="white-space:nowrap"><span class="tag ' + roleClass + '">' + roleLabel + '</span>' + editRoleBtn + '</td>' +
        '<td style="color:var(--gray-300);font-size:0.875rem">' + (u.phone_number ? escHtml(u.phone_number) : '<span style="color:var(--gray-500)">—</span>') + '</td>' +
        '<td>' + rateCell + '</td>' +
        '<td style="text-align:center">' + (note || makeToggle('can_manage_aircraft', u.can_manage_aircraft)) + '</td>' +
        '<td style="text-align:center">' + (note ? '' : makeToggle('can_manage_instructors', u.can_manage_instructors)) + '</td>' +
        '<td style="text-align:center">' + (note ? '' : makeToggle('can_manage_students', u.can_manage_students)) + '</td>' +
        '<td style="text-align:center">' + (note ? '' : makeToggle('can_manage_permissions', u.can_manage_permissions)) + '</td>' +
        '<td style="text-align:center">' + (note ? '' : makeToggle('can_edit_website', u.can_edit_website)) + '</td>' +
        '<td style="display:flex;gap:0.4rem;flex-wrap:wrap">' +
          (canEditAvail ? '<button class="btn btn-secondary btn-sm" onclick="openAvailabilityModal(' + u.id + ', \'' + escHtml(u.name).replace(/'/g, "\\'") + '\')">Availability</button>' : '') +
          (canDelete ? '<button class="btn btn-danger btn-sm" onclick="deleteUser(' + u.id + ', \'' + escHtml(u.name) + '\')">Remove</button>' : '') +
        '</td>' +
        '</tr>';
    }).join('');
  } else {
    // Basic view
    thead.innerHTML = '<tr><th class="people-sticky">Name</th><th class="people-sticky-2">Email</th><th>Phone</th><th>Role</th><th>Joined</th><th></th></tr>';
    tbody.innerHTML = users.map(function(u) {
      var isDualRole = u.role === 'admin' && u.has_instructor_availability;
      var roleClass = u.role === 'owner' ? 'tag-gold' : u.role === 'instructor' ? 'tag-sky' : u.role === 'admin' ? 'tag-amber' : u.role === 'renter' ? 'tag-green' : u.role === 'maintenance' ? 'tag-amber' : 'tag-purple';
      var roleLabel = u.role === 'owner' ? 'Owner' : u.role === 'instructor' ? 'Instructor' : isDualRole ? 'Admin / Instructor' : u.role === 'admin' ? 'Admin' : u.role === 'renter' ? 'Renter' : u.role === 'maintenance' ? 'Maintenance' : 'Student';
      var isSelf = u.id === currentUser.id;
      var canEditAvailBasic = (u.role === 'instructor' || (u.role === 'admin' && u.has_instructor_availability)) && (isOwner || isSelf || canManageInstructors);
      return '<tr>' +
        '<td class="people-sticky" style="font-weight:600">' + escHtml(u.name) + '</td>' +
        '<td class="people-sticky-2" style="color:var(--gray-300)">' + escHtml(u.email) + '</td>' +
        '<td style="color:var(--gray-300);font-size:0.875rem">' + (u.phone_number ? escHtml(u.phone_number) : '<span style="color:var(--gray-500)">—</span>') + '</td>' +
        '<td><span class="tag ' + roleClass + '">' + roleLabel + '</span></td>' +
        '<td style="color:var(--gray-500)">' + new Date(u.created_at).toLocaleDateString() + '</td>' +
        '<td>' + (canEditAvailBasic ? '<button class="btn btn-secondary btn-sm" onclick="openAvailabilityModal(' + u.id + ', \'' + escHtml(u.name).replace(/'/g, "\\'") + '\')">Availability</button>' : '') + '</td>' +
        '</tr>';
    }).join('');
  }
}

function stagePermissionChange(userId, permission, value) {
  // Find the user's current DB value
  var user = allUsers.find(function(u) { return u.id === userId; });
  if (!user) return;

  var dbValue = !!user[permission];

  if (!pendingPermChanges[userId]) {
    pendingPermChanges[userId] = {};
  }

  // If the new value matches DB, remove the pending change for this field
  if (value === dbValue) {
    delete pendingPermChanges[userId][permission];
    // If no more pending changes for this user, remove the entry
    if (Object.keys(pendingPermChanges[userId]).length === 0) {
      delete pendingPermChanges[userId];
    }
  } else {
    pendingPermChanges[userId][permission] = value;
  }

  renderSaveBar();
  // Re-render to show changed row highlight (skip API reload)
  loadPeople(currentPeopleFilter, true);
}

function renderSaveBar() {
  var container = document.getElementById('perm-save-container');
  if (!container) return;

  var changeCount = Object.keys(pendingPermChanges).length;
  if (changeCount === 0) {
    container.innerHTML = '';
    return;
  }

  var label = changeCount === 1 ? '1 user has unsaved changes' : changeCount + ' users have unsaved changes';
  container.innerHTML = '<div class="perm-save-bar">' +
    '<div class="save-info"><span class="save-dot"></span>' + label + '</div>' +
    '<div style="display:flex;gap:0.5rem;">' +
    '<button class="btn-discard" onclick="discardPermChanges()">Discard</button>' +
    '<button class="btn-save" id="perm-save-btn" onclick="savePermissions()">Save Changes</button>' +
    '</div></div>';
}

async function savePermissions() {
  var btn = document.getElementById('perm-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving...'; }

  var userIds = Object.keys(pendingPermChanges);
  var errors = [];

  for (var i = 0; i < userIds.length; i++) {
    var userId = parseInt(userIds[i]);
    var user = allUsers.find(function(u) { return u.id === userId; });
    if (!user) continue;

    // Build full permission payload: start with DB values, overlay pending changes
    var payload = {
      can_manage_aircraft: pendingPermChanges[userId].can_manage_aircraft !== undefined ? pendingPermChanges[userId].can_manage_aircraft : !!user.can_manage_aircraft,
      can_manage_instructors: pendingPermChanges[userId].can_manage_instructors !== undefined ? pendingPermChanges[userId].can_manage_instructors : !!user.can_manage_instructors,
      can_manage_permissions: pendingPermChanges[userId].can_manage_permissions !== undefined ? pendingPermChanges[userId].can_manage_permissions : !!user.can_manage_permissions,
      can_manage_students: pendingPermChanges[userId].can_manage_students !== undefined ? pendingPermChanges[userId].can_manage_students : !!user.can_manage_students,
      can_edit_website: pendingPermChanges[userId].can_edit_website !== undefined ? pendingPermChanges[userId].can_edit_website : !!user.can_edit_website,
    };

    try {
      await api('/api/permissions/' + userId, {
        method: 'PATCH',
        body: JSON.stringify(payload)
      });
    } catch (err) {
      errors.push((user.name || 'User ' + userId) + ': ' + (err.error || 'Failed'));
    }
  }

  // Clear pending changes
  pendingPermChanges = {};

  // Reload fresh data from server
  await loadUsers();

  var container = document.getElementById('perm-save-container');
  if (errors.length > 0) {
    container.innerHTML = '<div class="perm-save-bar" style="border-color:rgba(239,68,68,0.3);background:rgba(239,68,68,0.06)">' +
      '<div class="save-info" style="color:var(--red)">Some changes failed: ' + escHtml(errors.join('; ')) + '</div></div>';
  } else {
    container.innerHTML = '<div class="perm-save-success">&#10003; Permissions saved successfully</div>';
    setTimeout(function() {
      var c = document.getElementById('perm-save-container');
      if (c && c.querySelector('.perm-save-success')) c.innerHTML = '';
    }, 3000);
  }

  loadPeople(currentPeopleFilter);
}

function discardPermChanges() {
  pendingPermChanges = {};
  renderSaveBar();
  loadPeople(currentPeopleFilter, true);
}

async function claimOwner() {
  if (!confirm('Claim owner role? This grants you full control over all permissions and user management.')) return;
  try {
    var data = await api('/api/auth/claim-owner', { method: 'POST' });
    currentUser = data.user;
    hasOwnerAccount = true;
    token = data.token;
    localStorage.setItem('fs_token', token);
    document.getElementById('sidebar-role').textContent = 'owner';
    document.getElementById('add-aircraft-btn').classList.remove('hidden');
    await loadUsers();
    loadPeople(currentPeopleFilter);
  } catch (err) {
    alert(err.error || 'Failed to claim owner role');
  }
}

async function deleteUser(userId, userName) {
  if (!confirm('Are you sure you want to delete ' + userName + '? This cannot be undone.')) return;
  try {
    await api('/api/users/' + userId, { method: 'DELETE' });
    await loadUsers();
    loadPeople(currentPeopleFilter);
  } catch (err) {
    alert(err.error || 'Failed to remove user');
  }
}

// ─── ROLE CHANGE ───
function openRoleChangeModal(userId, userName, currentRole, isInstructor) {
  const roleNames = { student: 'Student Pilot', instructor: 'Instructor (CFI)', admin: 'Admin', renter: 'Renter', owner: 'Owner', maintenance: 'Maintenance Technician' };
  document.getElementById('role-change-user-id').value = userId;
  document.getElementById('role-change-user-name').textContent = userName;
  document.getElementById('role-change-current-role').textContent = 'Current role: ' + (roleNames[currentRole] || currentRole);
  document.getElementById('role-change-select').value = currentRole;
  document.getElementById('role-change-current-instructor').value = isInstructor ? 'true' : 'false';
  document.getElementById('role-change-is-instructor').checked = !!isInstructor;
  document.getElementById('role-change-instructor-note').classList.add('hidden');
  document.getElementById('role-change-error').classList.add('hidden');
  const btn = document.getElementById('role-change-save-btn');
  btn.disabled = false;
  btn.textContent = 'Save Changes';
  document.getElementById('role-change-modal').classList.remove('hidden');
}

function closeRoleChangeModal() {
  document.getElementById('role-change-modal').classList.add('hidden');
}

async function saveRoleChange() {
  const userId = parseInt(document.getElementById('role-change-user-id').value);
  const newRole = document.getElementById('role-change-select').value;
  const isInstructor = document.getElementById('role-change-is-instructor').checked;
  const wasInstructor = document.getElementById('role-change-current-instructor').value === 'true';
  const errEl = document.getElementById('role-change-error');
  const btn = document.getElementById('role-change-save-btn');
  errEl.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = 'Saving...';
  try {
    await api('/api/users/' + userId + '/role', {
      method: 'PATCH',
      body: JSON.stringify({ role: newRole })
    });
    // Also save instructor status if it changed
    if (isInstructor !== wasInstructor) {
      await api('/api/users/' + userId + '/instructor-status', {
        method: 'PATCH',
        body: JSON.stringify({ is_instructor: isInstructor })
      });
    }
    closeRoleChangeModal();
    await loadUsers();
    loadPeople(currentPeopleFilter);
    showToast('User updated successfully', 'success');
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save changes';
    errEl.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = 'Save Changes';
  }
}

// ─── INSTRUCTOR RATE ───
async function saveInstructorRate(userId, inputId) {
  var input = document.getElementById(inputId);
  if (!input) return;
  var rate = input.value ? parseFloat(input.value) : null;
  try {
    await api('/api/users/' + userId + '/rate', {
      method: 'PATCH',
      body: JSON.stringify({ instructor_rate: rate })
    });
    await loadUsers();
    loadPeople(currentPeopleFilter, true);
  } catch (err) {
    alert(err.error || 'Failed to save rate');
  }
}

// ─── AVAILABILITY (placeholder) ───
function openAvailabilityModal(userId, userName) {
  alert('Availability management for ' + userName + ' is coming soon.');
}

// ─── INVITE USER ───
function openInviteModal() {
  document.getElementById('invite-error').classList.add('hidden');
  document.getElementById('invite-success').classList.add('hidden');
  document.getElementById('invite-form').reset();

  // Only show roles the current user can manage
  const perms = currentUser.permissions || {};
  const canManageInstructors = currentUser.role === 'owner' || perms.can_manage_instructors;
  const canManageStudents = currentUser.role === 'owner' || perms.can_manage_students;

  const roleSelect = document.getElementById('invite-role');
  roleSelect.innerHTML = '';
  if (canManageStudents) roleSelect.innerHTML += '<option value="student">Student Pilot</option>';
  if (canManageInstructors) roleSelect.innerHTML += '<option value="instructor">Instructor (CFI)</option>';

  document.getElementById('invite-modal').classList.remove('hidden');
}

function closeInviteModal() {
  document.getElementById('invite-modal').classList.add('hidden');
}

document.getElementById('invite-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('invite-error');
  const successEl = document.getElementById('invite-success');
  errEl.classList.add('hidden');
  successEl.classList.add('hidden');

  try {
    const user = await api('/api/users/invite', {
      method: 'POST',
      body: JSON.stringify({
        name: document.getElementById('invite-name').value,
        email: document.getElementById('invite-email').value,
        password: document.getElementById('invite-password').value,
        role: document.getElementById('invite-role').value,
      })
    });
    successEl.textContent = user.name + ' has been added as ' + (user.role === 'instructor' ? 'an instructor' : 'a student') + '.';
    successEl.classList.remove('hidden');
    document.getElementById('invite-form').reset();
    await loadUsers();
    loadPeople(currentPeopleFilter);
    // Auto-close after a beat
    setTimeout(() => closeInviteModal(), 1500);
  } catch (err) {
    errEl.textContent = err.error || 'Failed to add user';
    errEl.classList.remove('hidden');
  }
});

// ─── HELPERS ───
function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatTime(d) {
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

// Format structured conflict objects into labeled HTML with local-timezone times
function formatConflictMessages(conflicts) {
  if (!conflicts || conflicts.length === 0) return '';
  const items = conflicts.map(c => {
    // Handle both structured objects (new) and plain strings (legacy fallback)
    if (typeof c === 'string') return `<li>${escHtml(c)}</li>`;
    const timeRange = `${formatTime(new Date(c.start_time))}\u2013${formatTime(new Date(c.end_time))}`;
    if (c.type === 'aircraft') {
      return `<li style="margin-bottom:0.35rem;">✈️ <strong>Aircraft ${escHtml(c.entity)}</strong> is unavailable \u2014 already booked ${timeRange}${c.booked_by ? ` by ${escHtml(c.booked_by)}` : ''}</li>`;
    } else if (c.type === 'instructor') {
      return `<li style="margin-bottom:0.35rem;">👨‍✈️ <strong>Instructor ${escHtml(c.entity)}</strong> is unavailable \u2014 already booked ${timeRange}</li>`;
    } else if (c.type === 'student') {
      return `<li style="margin-bottom:0.35rem;">🎓 <strong>${escHtml(c.entity)}</strong> already has a booking ${timeRange}</li>`;
    }
    return `<li>${JSON.stringify(c)}</li>`;
  });
  return '<strong>⚠️ Scheduling Conflicts</strong><ul style="margin-top:0.5rem;padding-left:1.2rem;list-style:none;">' + items.join('') + '</ul>';
}

function formatTimeStr(h, m) {
  const period = h >= 12 ? 'PM' : 'AM';
  const hour = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${hour}:${String(m).padStart(2, '0')} ${period}`;
}

function getTypeClass(type) {
  if (!type) return 'tag-green';
  const t = type.toUpperCase();
  if (t === 'PPL' || t === 'PRIVATE') return 'tag-sky';
  if (t === 'IFR' || t === 'INSTRUMENT') return 'tag-purple';
  if (t === 'CPL' || t === 'COMMERCIAL') return 'tag-amber';
  if (t === 'CFI') return 'tag-red';
  return 'tag-green';
}

function getEventClass(type) {
  if (!type) return 'default';
  const t = type.toUpperCase();
  if (t === 'PPL' || t === 'PRIVATE') return 'ppl';
  if (t === 'IFR' || t === 'INSTRUMENT') return 'ifr';
  if (t === 'CPL' || t === 'COMMERCIAL') return 'cpl';
  return 'default';
}

// ─── MAINTENANCE ─────────────────────────────────────────
let currentMaintTab = 'fleet-status';
let allSquawks = [];
let allADs = {};
let expandedInspections = {};

async function loadMaintenance() {
  await loadAircraft();
  if (currentMaintTab === 'fleet-status') loadMaintenanceFleet();
  else if (currentMaintTab === 'squawk-log') loadSquawks();
  else if (currentMaintTab === 'inspections') loadInspections();
}

function switchMaintTab(tab, btn) {
  currentMaintTab = tab;
  document.querySelectorAll('.maint-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('maint-tab-fleet-status').classList.toggle('hidden', tab !== 'fleet-status');
  document.getElementById('maint-tab-squawk-log').classList.toggle('hidden', tab !== 'squawk-log');
  document.getElementById('maint-tab-inspections').classList.toggle('hidden', tab !== 'inspections');

  if (tab === 'fleet-status') loadMaintenanceFleet();
  else if (tab === 'squawk-log') loadSquawks();
  else if (tab === 'inspections') loadInspections();
}

function hobbsRemaining(current, due) {
  if (due == null || current == null) return null;
  return parseFloat(due) - parseFloat(current);
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);
  return Math.round((target - today) / (1000 * 60 * 60 * 24));
}

function hobbsStatusClass(remaining) {
  if (remaining == null) return 'na';
  if (remaining <= 0) return 'overdue';
  if (remaining <= 10) return 'due-soon';
  return 'ok';
}

function daysStatusClass(days) {
  if (days == null) return 'na';
  if (days <= 0) return 'overdue';
  if (days <= 30) return 'due-soon';
  return 'ok';
}

async function loadMaintenanceFleet() {
  await loadAircraft();
  const el = document.getElementById('maint-fleet-list');
  const emptyEl = document.getElementById('maint-fleet-empty');

  if (allAircraft.length === 0) {
    el.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);
  // All instructors can edit Hobbs/Tach hours
  const canEditHours = ['owner', 'instructor', 'admin'].includes(currentUser.role);

  // Also load open squawks per aircraft
  let openSquawksByAircraft = {};
  try {
    const sq = await api('/api/squawks?status=open');
    sq.forEach(s => {
      openSquawksByAircraft[s.aircraft_id] = (openSquawksByAircraft[s.aircraft_id] || 0) + 1;
    });
  } catch {}

  el.innerHTML = allAircraft.map(a => {
    const isDown = a.status === 'maintenance';
    const statusTag = isDown
      ? `<span class="tag tag-red">&#128308; Down for Maint</span>`
      : `<span class="tag tag-green">&#128994; Available</span>`;

    // Use total_hobbs_hours as single source of truth (synced with Fleet page)
    const hobbs = a.total_hobbs_hours != null ? parseFloat(a.total_hobbs_hours).toFixed(1) : null;
    const tach = a.total_tach_hours != null ? parseFloat(a.total_tach_hours).toFixed(1) : null;
    const hRem = hobbsRemaining(a.total_hobbs_hours, a.next_100hr_due);
    const dayRem = daysUntil(a.next_annual_due);
    const openSq = openSquawksByAircraft[a.id] || 0;

    const h100Class = hobbsStatusClass(hRem);
    const annualClass = daysStatusClass(dayRem);

    const h100Display = hRem == null ? 'Not set' : (hRem <= 0 ? `${Math.abs(hRem.toFixed(1))} OVERDUE` : `${hRem.toFixed(1)} hrs`);
    const annualDisplay = dayRem == null ? 'Not set' : (dayRem <= 0 ? `${Math.abs(dayRem)} days OVERDUE` : `${dayRem}d`);

    const maintBtn = canManage
      ? `<button class="btn btn-sm ${isDown ? 'btn-secondary' : 'btn-danger'}" onclick="openMaintStatusModal(${a.id}, '${escHtml(a.tail_number)}', '${a.status}')">${isDown ? 'Mark Available' : 'Mark Down'}</button>`
      : '';
    const editBtn = canEditHours
      ? `<button class="btn btn-secondary btn-sm" onclick="openInspectionModal(${a.id}, '${escHtml(a.tail_number)}')">Edit Hours</button>`
      : '';
    const historyBtn = `<button class="btn btn-secondary btn-sm" onclick="openHoursHistory(${a.id}, '${escHtml(a.tail_number)}')">History</button>`;
    const squawkBtn = `<button class="btn btn-secondary btn-sm" onclick="openSquawkModalForAircraft(${a.id})">+ Squawk</button>`;

    return `<div class="maint-aircraft-card ${isDown ? 'status-maintenance' : ''}">
      <div>
        <div class="ac-tail">${escHtml(a.tail_number)}</div>
        <div class="ac-model">${escHtml(a.make_model)}</div>
        ${isDown && a.maintenance_reason ? `<div style="font-size:0.75rem;color:var(--red);margin-top:0.2rem">${escHtml(a.maintenance_reason)}</div>` : ''}
      </div>
      ${statusTag}
      <div class="maint-stat">
        <div class="ms-label">Hobbs</div>
        <div class="ms-value">${hobbs != null ? hobbs : '—'}</div>
      </div>
      <div class="maint-stat">
        <div class="ms-label">Tach</div>
        <div class="ms-value">${tach != null ? tach : '—'}</div>
      </div>
      <div class="maint-stat">
        <div class="ms-label">100hr Due</div>
        <div class="ms-value ${h100Class}">${h100Display}</div>
      </div>
      <div class="maint-stat">
        <div class="ms-label">Annual Due</div>
        <div class="ms-value ${annualClass}">${annualDisplay}</div>
      </div>
      <div class="maint-stat">
        <div class="ms-label">Open Squawks</div>
        <div class="ms-value ${openSq > 0 ? (openSq >= 3 ? 'overdue' : 'due-soon') : 'ok'}">${openSq}</div>
      </div>
      <div class="maint-actions">
        ${squawkBtn}
        ${editBtn}
        ${historyBtn}
        ${maintBtn}
      </div>
    </div>`;
  }).join('');
}

// ─── SQUAWKS ─────────────────────────────────────────────
async function loadSquawks() {
  const aircraftFilter = document.getElementById('squawk-filter-aircraft')?.value || '';
  const severityFilter = document.getElementById('squawk-filter-severity')?.value || '';
  const statusFilter = document.getElementById('squawk-filter-status')?.value || '';

  const params = new URLSearchParams();
  if (aircraftFilter) params.set('aircraft_id', aircraftFilter);
  if (statusFilter) params.set('status', statusFilter);

  try {
    let squawks = await api(`/api/squawks?${params}`);
    if (severityFilter) squawks = squawks.filter(s => s.severity === severityFilter);
    allSquawks = squawks;

    const tbody = document.getElementById('squawk-table');
    const emptyEl = document.getElementById('squawk-empty');
    const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);

    if (squawks.length === 0) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    tbody.innerHTML = squawks.map(s => {
      const sevClass = `severity-${s.severity}`;
      const sevLabel = s.severity.charAt(0).toUpperCase() + s.severity.slice(1);
      const statusTag = s.status === 'open'
        ? `<span class="tag tag-red">Open</span>`
        : s.status === 'reviewed'
        ? `<span class="tag tag-amber">Reviewed</span>`
        : s.status === 'deferred'
        ? `<span class="tag tag-sky">Deferred</span>`
        : `<span class="tag tag-green">Resolved</span>`;
      const date = new Date(s.reported_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

      const isAdminOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
      const reviewBtn = canManage && s.status !== 'resolved'
        ? `<button class="btn btn-secondary btn-sm" onclick="openSquawkReview(${s.id})">Review</button>`
        : '';
      const editBtn = isAdminOwner
        ? `<button class="btn-icon" title="Edit" onclick="openSquawkEditModal(${s.id})" style="background:none;border:none;cursor:pointer;color:var(--gray-300);font-size:0.9rem;padding:0.15rem 0.35rem">&#9998;</button>`
        : '';
      const deleteBtn = isAdminOwner
        ? `<button class="btn-icon" title="Delete" onclick="deleteSquawk(${s.id})" style="background:none;border:none;cursor:pointer;color:var(--red-400,#f87171);font-size:0.9rem;padding:0.15rem 0.35rem">&#128465;</button>`
        : '';
      const actions = `${reviewBtn}${editBtn}${deleteBtn}`;

      const downtimeCell = s.expected_downtime
        ? `<span style="font-size:0.8rem;color:${s.severity === 'grounding' ? 'var(--red)' : 'var(--gray-300)'};font-weight:${s.severity === 'grounding' ? '600' : '400'}">${escHtml(s.expected_downtime)}</span>`
        : `<span style="font-size:0.8rem;color:var(--gray-500)">—</span>`;
      return `<tr class="squawk-row">
        <td style="font-family:'Space Grotesk';font-weight:600">${escHtml(s.tail_number)}</td>
        <td style="color:var(--gray-300);font-size:0.8rem">${date}</td>
        <td>${escHtml(s.reporter_name)}</td>
        <td><span class="${sevClass} tag ${s.severity === 'grounding' ? 'tag-red' : s.severity === 'major' ? 'tag-amber' : 'tag-sky'}">${sevLabel}</span></td>
        <td style="max-width:280px">${escHtml(s.description)}${s.resolution_notes ? `<div style="font-size:0.75rem;color:var(--green);margin-top:0.25rem">&#10003; ${escHtml(s.resolution_notes)}</div>` : ''}</td>
        <td>${downtimeCell}</td>
        <td>${statusTag}</td>
        <td style="white-space:nowrap">${actions}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    console.error('Load squawks error:', err);
  }
}

function populateSquawkAircraftFilter() {
  const sel = document.getElementById('squawk-filter-aircraft');
  if (!sel) return;
  sel.innerHTML = '<option value="">All Aircraft</option>' +
    allAircraft.map(a => `<option value="${a.id}">${escHtml(a.tail_number)} - ${escHtml(a.make_model)}</option>`).join('');
}

// ─── SQUAWK MODAL ─────────────────────────────────────────
function openSquawkModal() {
  document.getElementById('squawk-error').classList.add('hidden');
  document.getElementById('squawk-form').reset();
  document.getElementById('squawk-grounding-warning').classList.add('hidden');
  document.getElementById('squawk-downtime-group').classList.add('hidden');

  const sel = document.getElementById('squawk-aircraft');
  sel.innerHTML = allAircraft.map(a => `<option value="${a.id}">${escHtml(a.tail_number)} - ${escHtml(a.make_model)}</option>`).join('');

  document.getElementById('squawk-modal').classList.remove('hidden');
}

function openSquawkModalForAircraft(aircraftId) {
  openSquawkModal();
  document.getElementById('squawk-aircraft').value = aircraftId;
}

function closeSquawkModal() {
  document.getElementById('squawk-modal').classList.add('hidden');
}

document.getElementById('squawk-severity').addEventListener('change', function() {
  const isGrounding = this.value === 'grounding';
  document.getElementById('squawk-grounding-warning').classList.toggle('hidden', !isGrounding);
  document.getElementById('squawk-downtime-group').classList.toggle('hidden', !isGrounding);
  if (!isGrounding) document.getElementById('squawk-expected-downtime').value = '';
});

document.getElementById('squawk-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('squawk-error');
  errEl.classList.add('hidden');

  const aircraft_id = parseInt(document.getElementById('squawk-aircraft').value);
  const severity = document.getElementById('squawk-severity').value;
  const description = document.getElementById('squawk-desc').value;
  const expected_downtime = document.getElementById('squawk-expected-downtime').value || null;

  try {
    await api('/api/squawks', {
      method: 'POST',
      body: JSON.stringify({ aircraft_id, severity, description, expected_downtime })
    });
    closeSquawkModal();

    if (severity === 'grounding') {
      const ac = allAircraft.find(a => a.id === aircraft_id);
      const acName = ac ? ac.tail_number : 'this aircraft';
      if (confirm(`Grounding squawk submitted. Mark ${acName} as Down for Maintenance now?`)) {
        openMaintStatusModal(aircraft_id, acName, 'available');
        document.getElementById('maint-status-value').value = 'maintenance';
        document.getElementById('maint-reason-group').classList.remove('hidden');
        document.getElementById('maint-status-reason').value = `Grounding squawk: ${description.slice(0, 60)}`;
      }
    }

    if (currentPage === 'maintenance') {
      if (currentMaintTab === 'squawk-log') loadSquawks();
      else loadMaintenanceFleet();
    }
  } catch (err) {
    errEl.textContent = err.error || 'Failed to submit squawk';
    errEl.classList.remove('hidden');
  }
});

// ─── SQUAWK REVIEW ────────────────────────────────────────
function openSquawkReview(squawkId) {
  const sq = allSquawks.find(s => s.id === squawkId);
  if (!sq) return;

  const detail = document.getElementById('squawk-review-detail');
  const date = new Date(sq.reported_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const sevLabel = sq.severity.charAt(0).toUpperCase() + sq.severity.slice(1);
  detail.innerHTML = `
    <div style="margin-bottom:0.4rem"><strong>${escHtml(sq.tail_number)}</strong> &mdash; ${date} &mdash; <span class="tag ${sq.severity === 'grounding' ? 'tag-red' : sq.severity === 'major' ? 'tag-amber' : 'tag-sky'}">${sevLabel}</span></div>
    <div style="color:var(--gray-300)">${escHtml(sq.description)}</div>
    <div style="font-size:0.8rem;color:var(--gray-500);margin-top:0.4rem">Reported by ${escHtml(sq.reporter_name)}</div>
  `;

  document.getElementById('squawk-review-id').value = squawkId;
  document.getElementById('squawk-review-notes').value = sq.resolution_notes || '';
  document.getElementById('squawk-review-error').classList.add('hidden');
  document.getElementById('squawk-review-modal').classList.remove('hidden');
}

function closeSquawkReviewModal() {
  document.getElementById('squawk-review-modal').classList.add('hidden');
}

document.getElementById('squawk-review-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('squawk-review-error');
  errEl.classList.add('hidden');

  const id = document.getElementById('squawk-review-id').value;
  const status = document.getElementById('squawk-review-status').value;
  const resolution_notes = document.getElementById('squawk-review-notes').value || null;

  try {
    await api(`/api/squawks/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status, resolution_notes })
    });
    closeSquawkReviewModal();
    loadSquawks();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to update squawk';
    errEl.classList.remove('hidden');
  }
});

// ─── SQUAWK EDIT/DELETE (admin/owner) ─────────────────────
function openSquawkEditModal(squawkId) {
  const sq = allSquawks.find(s => s.id === squawkId);
  if (!sq) return;
  const errEl = document.getElementById('squawk-edit-error');
  errEl.classList.add('hidden');
  document.getElementById('squawk-edit-id').value = squawkId;

  // Populate aircraft dropdown
  const acSel = document.getElementById('squawk-edit-aircraft');
  acSel.innerHTML = allAircraft.map(a => `<option value="${a.id}" ${a.id === sq.aircraft_id ? 'selected' : ''}>${escHtml(a.tail_number)} - ${escHtml(a.make_model)}</option>`).join('');

  document.getElementById('squawk-edit-severity').value         = sq.severity;
  document.getElementById('squawk-edit-status').value           = sq.status;
  document.getElementById('squawk-edit-desc').value             = sq.description;
  document.getElementById('squawk-edit-expected-downtime').value = sq.expected_downtime || '';
  document.getElementById('squawk-edit-resolution').value       = sq.resolution_notes || '';
  document.getElementById('squawk-edit-modal').classList.remove('hidden');
}

function closeSquawkEditModal() {
  document.getElementById('squawk-edit-modal').classList.add('hidden');
}

document.getElementById('squawk-edit-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('squawk-edit-error');
  errEl.classList.add('hidden');
  const id             = document.getElementById('squawk-edit-id').value;
  const aircraft_id    = document.getElementById('squawk-edit-aircraft').value;
  const severity       = document.getElementById('squawk-edit-severity').value;
  const status         = document.getElementById('squawk-edit-status').value;
  const description    = document.getElementById('squawk-edit-desc').value.trim();
  const expected_downtime = document.getElementById('squawk-edit-expected-downtime').value || null;
  const resolution_notes = document.getElementById('squawk-edit-resolution').value.trim();
  if (!description) { errEl.textContent = 'Description is required'; errEl.classList.remove('hidden'); return; }
  try {
    await api(`/api/squawks/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ aircraft_id: parseInt(aircraft_id), severity, status, description, expected_downtime, resolution_notes: resolution_notes || null })
    });
    closeSquawkEditModal();
    loadSquawks();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save squawk';
    errEl.classList.remove('hidden');
  }
});

async function deleteSquawk(squawkId) {
  if (!confirm('Delete this squawk? This cannot be undone.')) return;
  try {
    await api(`/api/squawks/${squawkId}`, { method: 'DELETE' });
    loadSquawks();
  } catch (err) {
    alert(err.error || 'Failed to delete squawk');
  }
}

// ─── MAINT STATUS MODAL ───────────────────────────────────
function openMaintStatusModal(aircraftId, tailNumber, currentStatus) {
  document.getElementById('maint-status-aircraft-id').value = aircraftId;
  document.getElementById('maint-status-title').textContent = `${tailNumber} — Update Status`;
  document.getElementById('maint-status-value').value = currentStatus === 'maintenance' ? 'available' : 'maintenance';
  document.getElementById('maint-status-reason').value = '';
  document.getElementById('maint-status-error').classList.add('hidden');

  const isGoingDown = document.getElementById('maint-status-value').value === 'maintenance';
  document.getElementById('maint-reason-group').classList.toggle('hidden', !isGoingDown);

  document.getElementById('maint-status-modal').classList.remove('hidden');
}

function closeMaintStatusModal() {
  document.getElementById('maint-status-modal').classList.add('hidden');
}

document.getElementById('maint-status-value').addEventListener('change', function() {
  document.getElementById('maint-reason-group').classList.toggle('hidden', this.value !== 'maintenance');
});

document.getElementById('maint-status-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('maint-status-error');
  errEl.classList.add('hidden');

  const id = document.getElementById('maint-status-aircraft-id').value;
  const status = document.getElementById('maint-status-value').value;
  const reason = document.getElementById('maint-status-reason').value || null;

  try {
    await api(`/api/aircraft/${id}/maintenance`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason })
    });
    closeMaintStatusModal();
    await loadAircraft();
    if (currentPage === 'maintenance') loadMaintenanceFleet();
    else if (currentPage === 'fleet') loadFleet();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to update status';
    errEl.classList.remove('hidden');
  }
});

// ─── INSPECTION MODAL ─────────────────────────────────────
function openInspectionModal(aircraftId, tailNumber) {
  const ac = allAircraft.find(a => a.id === aircraftId);
  const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);

  document.getElementById('insp-aircraft-id').value = aircraftId;
  document.getElementById('inspection-modal-title').textContent = `${tailNumber} — Hours & Inspections`;
  document.getElementById('inspection-error').classList.add('hidden');

  // Use total_hobbs_hours as single source of truth
  document.getElementById('insp-hobbs').value = ac && ac.total_hobbs_hours != null ? ac.total_hobbs_hours : '';
  document.getElementById('insp-tach').value = ac && ac.total_tach_hours != null ? ac.total_tach_hours : '';
  document.getElementById('insp-note').value = '';
  document.getElementById('insp-100hr').value = ac && ac.next_100hr_due != null ? ac.next_100hr_due : '';
  document.getElementById('insp-annual').value = ac && ac.next_annual_due ? ac.next_annual_due.split('T')[0] : '';

  // Only show inspection due-date section to users who can manage aircraft
  document.getElementById('insp-inspection-section').style.display = canManage ? '' : 'none';

  document.getElementById('inspection-modal').classList.remove('hidden');
}

// Open hours-only version (for fleet table edit button, accessible to all instructors)
function openInspectionModalHoursOnly(aircraftId, tailNumber) {
  openInspectionModal(aircraftId, tailNumber);
}

function closeInspectionModal() {
  document.getElementById('inspection-modal').classList.add('hidden');
}

document.getElementById('inspection-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('inspection-error');
  errEl.classList.add('hidden');

  const id = document.getElementById('insp-aircraft-id').value;
  const hobbsVal = document.getElementById('insp-hobbs').value;
  const tachVal = document.getElementById('insp-tach').value;
  const noteVal = document.getElementById('insp-note').value;
  const next_100hr_due = document.getElementById('insp-100hr').value;
  const next_annual_due = document.getElementById('insp-annual').value;

  const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);

  try {
    // Update Hobbs and/or Tach if provided
    const hoursPayload = {};
    if (hobbsVal !== '') hoursPayload.hobbs = parseFloat(hobbsVal);
    if (tachVal !== '') hoursPayload.tach = parseFloat(tachVal);
    if (noteVal) hoursPayload.note = noteVal;

    if (Object.keys(hoursPayload).length > 1 || hoursPayload.hobbs != null || hoursPayload.tach != null) {
      await api(`/api/aircraft/${id}/hobbs`, {
        method: 'PATCH',
        body: JSON.stringify(hoursPayload)
      });
    }

    // Update inspection due dates (only for users with manage aircraft permission)
    if (canManage && (next_100hr_due !== '' || next_annual_due !== '')) {
      await api(`/api/aircraft/${id}/inspections`, {
        method: 'PUT',
        body: JSON.stringify({
          next_100hr_due: next_100hr_due ? parseFloat(next_100hr_due) : null,
          next_annual_due: next_annual_due || null
        })
      });
    }

    closeInspectionModal();
    await loadAircraft();
    if (currentPage === 'maintenance') loadMaintenanceFleet();
    else if (currentPage === 'fleet') loadFleet();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save';
    errEl.classList.remove('hidden');
  }
});

// ─── HOURS HISTORY MODAL ──────────────────────────────────
async function openHoursHistory(aircraftId, tailNumber) {
  const modal = document.getElementById('hours-history-modal');
  const title = document.getElementById('hours-history-title');
  const content = document.getElementById('hours-history-content');
  title.textContent = `Hours History — ${tailNumber}`;
  content.innerHTML = '<div style="color:var(--gray-500);font-size:0.9rem;padding:1rem">Loading…</div>';
  modal.classList.remove('hidden');

  try {
    const history = await api(`/api/aircraft/${aircraftId}/hours-history`);
    if (!history || history.length === 0) {
      content.innerHTML = '<div style="color:var(--gray-500);font-size:0.9rem;padding:1rem;text-align:center">No history recorded yet.</div>';
      return;
    }
    content.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:0.82rem;">
      <thead><tr style="border-bottom:1px solid var(--slate-light);color:var(--gray-500)">
        <th style="text-align:left;padding:0.4rem">Date</th>
        <th style="text-align:left;padding:0.4rem">Field</th>
        <th style="text-align:right;padding:0.4rem">Old</th>
        <th style="text-align:center;padding:0.4rem">→</th>
        <th style="text-align:right;padding:0.4rem">New</th>
        <th style="text-align:left;padding:0.4rem">By</th>
        <th style="text-align:left;padding:0.4rem">Source</th>
      </tr></thead>
      <tbody>${history.map(h => {
        const dt = new Date(h.created_at);
        const dateStr = dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        const timeStr = dt.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        const src = h.source === 'flight_completion' ? '<span class="tag tag-sky" style="font-size:0.7rem">Flight</span>' :
                    '<span class="tag tag-amber" style="font-size:0.7rem">Manual</span>';
        const old_v = h.old_value != null ? parseFloat(h.old_value).toFixed(1) : '—';
        const new_v = h.new_value != null ? parseFloat(h.new_value).toFixed(1) : '—';
        return `<tr style="border-bottom:1px solid var(--slate)">
          <td style="padding:0.4rem;white-space:nowrap">${dateStr}<br><span style="color:var(--gray-500);font-size:0.75rem">${timeStr}</span></td>
          <td style="padding:0.4rem;text-transform:capitalize">${escHtml(h.field)}</td>
          <td style="padding:0.4rem;text-align:right;color:var(--gray-400)">${old_v}</td>
          <td style="padding:0.4rem;text-align:center;color:var(--gray-500)">→</td>
          <td style="padding:0.4rem;text-align:right;color:var(--green);font-weight:600">${new_v}</td>
          <td style="padding:0.4rem">${escHtml(h.changed_by_name || 'System')}</td>
          <td style="padding:0.4rem">${src}${h.note ? `<div style="color:var(--gray-500);font-size:0.72rem;margin-top:2px">${escHtml(h.note)}</div>` : ''}</td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;
  } catch (err) {
    content.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load hours history.</div>';
  }
}

function closeHoursHistoryModal() {
  document.getElementById('hours-history-modal').classList.add('hidden');
}

// ─── INSPECTIONS TAB ──────────────────────────────────────
async function loadInspections() {
  await loadAircraft();
  const el = document.getElementById('inspections-list');
  const emptyEl = document.getElementById('inspections-empty');

  if (allAircraft.length === 0) {
    el.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);

  // All instructors can edit hours
  const canEditHours = ['owner', 'instructor', 'admin'].includes(currentUser.role);

  el.innerHTML = allAircraft.map(a => {
    // Use total_hobbs_hours as single source of truth
    const hobbs = a.total_hobbs_hours != null ? parseFloat(a.total_hobbs_hours).toFixed(1) : null;
    const tach = a.total_tach_hours != null ? parseFloat(a.total_tach_hours).toFixed(1) : null;
    const hRem = hobbsRemaining(a.total_hobbs_hours, a.next_100hr_due);
    const dayRem = daysUntil(a.next_annual_due);

    const h100Class = hobbsStatusClass(hRem);
    const annualClass = daysStatusClass(dayRem);

    const h100Display = hRem == null ? '—' : (hRem <= 0 ? `${Math.abs(hRem.toFixed(1))} hrs OVERDUE` : `${hRem.toFixed(1)} hrs remaining`);
    const annualDisplay = dayRem == null ? '—' : (dayRem <= 0 ? `${Math.abs(dayRem)} days OVERDUE` : `${dayRem} days remaining`);

    const editBtn = canEditHours ? `<button class="btn btn-secondary btn-sm" onclick="openInspectionModal(${a.id}, '${escHtml(a.tail_number)}')">Edit Hours</button>` : '';
    const addAdBtn = canManage ? `<button class="btn btn-secondary btn-sm" onclick="openAdModal(${a.id}, '${escHtml(a.tail_number)}')">+ Add AD</button>` : '';
    const historyBtn = `<button class="btn btn-secondary btn-sm" onclick="openHoursHistory(${a.id}, '${escHtml(a.tail_number)}')">History</button>`;

    return `<div class="aircraft-insp-card" id="insp-card-${a.id}">
      <div class="aircraft-insp-header" onclick="toggleInspCard(${a.id})">
        <span style="font-family:'Space Grotesk';font-weight:700;font-size:1.05rem">${escHtml(a.tail_number)}</span>
        <span style="color:var(--gray-300);font-size:0.85rem">${escHtml(a.make_model)}</span>
        <span class="tag ${a.status === 'maintenance' ? 'tag-red' : 'tag-green'}" style="margin-left:0.5rem">${a.status}</span>
        <span style="margin-left:auto;color:var(--gray-500);font-size:0.8rem">▼</span>
      </div>
      <div class="aircraft-insp-body ${expandedInspections[a.id] ? 'open' : ''}" id="insp-body-${a.id}">
        <div class="insp-grid">
          <div class="insp-cell">
            <div class="ic-label">Hobbs Hours</div>
            <div class="ic-value">${hobbs != null ? hobbs + ' hrs' : 'Not set'}</div>
          </div>
          <div class="insp-cell">
            <div class="ic-label">Tach Hours</div>
            <div class="ic-value">${tach != null ? tach + ' hrs' : 'Not set'}</div>
          </div>
          <div class="insp-cell">
            <div class="ic-label">100hr Inspection</div>
            <div class="ic-value ${h100Class}">${h100Display}</div>
            ${a.next_100hr_due != null ? `<div style="font-size:0.75rem;color:var(--gray-500)">Due at ${parseFloat(a.next_100hr_due).toFixed(1)} hrs</div>` : ''}
          </div>
          <div class="insp-cell">
            <div class="ic-label">Annual Inspection</div>
            <div class="ic-value ${annualClass}">${annualDisplay}</div>
            ${a.next_annual_due ? `<div style="font-size:0.75rem;color:var(--gray-500)">Due ${new Date(a.next_annual_due).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>` : ''}
          </div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
          <h4 style="font-size:0.9rem;color:var(--gray-300)">Airworthiness Directives</h4>
          <div style="display:flex;gap:0.5rem;">${editBtn}${historyBtn}${addAdBtn}</div>
        </div>
        <div id="ads-list-${a.id}">
          <div style="color:var(--gray-500);font-size:0.85rem">Loading ADs...</div>
        </div>
      </div>
    </div>`;
  }).join('');
}

async function toggleInspCard(aircraftId) {
  expandedInspections[aircraftId] = !expandedInspections[aircraftId];
  const body = document.getElementById(`insp-body-${aircraftId}`);
  body.classList.toggle('open', expandedInspections[aircraftId]);

  if (expandedInspections[aircraftId]) {
    await loadADs(aircraftId);
  }
}

async function loadADs(aircraftId) {
  const el = document.getElementById(`ads-list-${aircraftId}`);
  if (!el) return;

  const ac = allAircraft.find(a => a.id === aircraftId);
  const canManage = currentUser.role === 'owner' || (currentUser.permissions && currentUser.permissions.can_manage_aircraft);

  try {
    const ads = await api(`/api/aircraft/${aircraftId}/ads`);
    allADs[aircraftId] = ads;

    if (ads.length === 0) {
      el.innerHTML = '<div style="color:var(--gray-500);font-size:0.85rem;padding:0.5rem 0">No ADs tracked.</div>';
      return;
    }

    el.innerHTML = ads.map(ad => {
      const isComplied = ad.status === 'complied';
      let dueInfo = '';
      if (ad.due_date) {
        const d = daysUntil(ad.due_date);
        const cls = daysStatusClass(d);
        dueInfo += `<span class="ms-value ${cls}" style="font-size:0.8rem">Due ${new Date(ad.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}${d <= 0 ? ' OVERDUE' : ''}</span> `;
      }
      if (ad.due_hobbs) {
        const ac2 = allAircraft.find(a => a.id === aircraftId);
        // Use total_hobbs_hours as single source of truth
        const rem = hobbsRemaining(ac2?.total_hobbs_hours, ad.due_hobbs);
        const cls = hobbsStatusClass(rem);
        dueInfo += `<span class="ms-value ${cls}" style="font-size:0.8rem">${rem != null ? (rem <= 0 ? `${Math.abs(rem.toFixed(1))} OVERDUE` : `${rem.toFixed(1)} hrs`) : `Due at ${parseFloat(ad.due_hobbs).toFixed(1)} hrs`}</span>`;
      }

      const statusTag = isComplied ? `<span class="tag tag-green">Complied</span>` : `<span class="tag tag-red">Open</span>`;
      const toggleBtn = canManage
        ? `<button class="btn btn-sm btn-secondary" onclick="toggleAdStatus(${aircraftId}, ${ad.id}, '${isComplied ? 'open' : 'complied'}')">${isComplied ? 'Reopen' : 'Mark Complied'}</button>`
        : '';
      const deleteBtn = canManage
        ? `<button class="btn btn-sm btn-danger" onclick="deleteAd(${aircraftId}, ${ad.id})">Delete</button>`
        : '';

      return `<div class="ad-row ${!isComplied && (ad.due_date && daysUntil(ad.due_date) <= 0 || ad.due_hobbs && hobbsRemaining(ac?.total_hobbs_hours, ad.due_hobbs) <= 0) ? 'ad-overdue' : ''}">
        <div class="ad-number">${ad.ad_number ? escHtml(ad.ad_number) : 'AD'}</div>
        <div class="ad-desc">${escHtml(ad.description)}</div>
        <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
          ${dueInfo}
          ${statusTag}
          ${toggleBtn}
          ${deleteBtn}
        </div>
      </div>`;
    }).join('');
  } catch (err) {
    el.innerHTML = `<div style="color:var(--red);font-size:0.85rem">Failed to load ADs</div>`;
  }
}

async function toggleAdStatus(aircraftId, adId, newStatus) {
  try {
    await api(`/api/aircraft/${aircraftId}/ads/${adId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: newStatus })
    });
    await loadAircraft();
    await loadADs(aircraftId);
  } catch (err) {
    alert(err.error || 'Failed to update AD');
  }
}

async function deleteAd(aircraftId, adId) {
  if (!confirm('Delete this AD record?')) return;
  try {
    await api(`/api/aircraft/${aircraftId}/ads/${adId}`, { method: 'DELETE' });
    await loadADs(aircraftId);
  } catch (err) {
    alert(err.error || 'Failed to delete AD');
  }
}

// ─── AD MODAL ────────────────────────────────────────────
function openAdModal(aircraftId, tailNumber) {
  document.getElementById('ad-aircraft-id').value = aircraftId;
  document.getElementById('ad-id').value = '';
  document.getElementById('ad-modal-title').textContent = `${tailNumber} — Add AD`;
  document.getElementById('ad-error').classList.add('hidden');
  document.getElementById('ad-form').reset();
  document.getElementById('ad-status-group').style.display = 'none';
  document.getElementById('ad-modal').classList.remove('hidden');
}

function closeAdModal() {
  document.getElementById('ad-modal').classList.add('hidden');
}

document.getElementById('ad-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('ad-error');
  errEl.classList.add('hidden');

  const aircraftId = document.getElementById('ad-aircraft-id').value;
  const data = {
    ad_number: document.getElementById('ad-number').value || null,
    description: document.getElementById('ad-description').value,
    due_date: document.getElementById('ad-due-date').value || null,
    due_hobbs: document.getElementById('ad-due-hobbs').value || null,
  };

  try {
    await api(`/api/aircraft/${aircraftId}/ads`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
    closeAdModal();
    await loadADs(parseInt(aircraftId));
  } catch (err) {
    errEl.textContent = err.error || 'Failed to add AD';
    errEl.classList.remove('hidden');
  }
});

// ─── TRAINING PROGRESS ────────────────────────────────────────────────────────
let allPrograms = [];
let allProgressStudents = [];
let currentProgressStudentId = null;

async function loadProgress() {
  const role = currentUser.role;

  // Show/hide action buttons based on role
  const debriefBtn = document.getElementById('log-debrief-btn');
  const enrollBtn = document.getElementById('enroll-student-btn');
  if (debriefBtn) debriefBtn.style.display = (role !== 'student') ? '' : 'none';
  if (enrollBtn) enrollBtn.style.display = (role !== 'student') ? '' : 'none';

  // Load programs (always needed)
  try { allPrograms = await api('/api/training/programs'); } catch { allPrograms = []; }

  if (role === 'student') {
    await loadMyProgress();
  } else {
    await loadProgressStudentList();
  }
}

async function loadMyProgress() {
  const listEl = document.getElementById('progress-student-list');
  const myEl = document.getElementById('progress-my-programs');
  const emptyEl = document.getElementById('progress-empty');
  const emptySub = document.getElementById('progress-empty-sub');
  listEl.classList.add('hidden');
  myEl.classList.remove('hidden');

  try {
    const data = await api('/api/training/my-progress');
    if (!data.enrollments || data.enrollments.length === 0) {
      myEl.innerHTML = '';
      emptyEl.classList.remove('hidden');
      emptySub.textContent = "You haven't been enrolled in a training program yet. Your instructor will set this up.";
      return;
    }
    emptyEl.classList.add('hidden');

    // Load maneuver progress for student
    const maneuverProgressByEnrollment = {};
    await Promise.all(data.enrollments.map(async e => {
      try {
        const mp = await api(`/api/training/maneuver-progress/${currentUser.id}/${e.id}`);
        maneuverProgressByEnrollment[e.id] = mp;
      } catch { maneuverProgressByEnrollment[e.id] = []; }
      // Attach maneuvers from allPrograms
      const prog = (allPrograms || []).find(p => p.id === e.program_id);
      if (prog && e.stages) {
        e.stages.forEach(s => {
          const ps = (prog.stages || []).find(ps => ps.id === s.id);
          if (ps) s.maneuvers = ps.maneuvers || [];
        });
      }
    }));

    myEl.innerHTML = data.enrollments.map(e => renderEnrollmentCard(e, data.debriefs, true, maneuverProgressByEnrollment[e.id] || [])).join('');
  } catch (err) {
    myEl.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load your progress.</div>';
  }
}

async function loadProgressStudentList() {
  const listEl = document.getElementById('progress-student-list');
  const myEl = document.getElementById('progress-my-programs');
  const emptyEl = document.getElementById('progress-empty');
  listEl.classList.remove('hidden');
  myEl.classList.add('hidden');

  try {
    // Load instructor summary and students in parallel
    let instructors = [];
    try { instructors = await api('/api/training/instructors'); } catch {}
    allProgressStudents = await api('/api/training/students');

    if (allProgressStudents.length === 0 && instructors.length === 0) {
      listEl.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    // Render instructor summary cards
    let instructorHtml = '';
    if (instructors.length > 0) {
      instructorHtml = '<div class="instructor-cards">' +
        instructors.map(function(i) {
          return '<div class="instructor-summary-card">' +
            '<div class="isc-name">' + escHtml(i.name) + '</div>' +
            '<div class="isc-count">' + (parseInt(i.student_count) || 0) + '</div>' +
            '<div class="isc-label">Active Students</div>' +
          '</div>';
        }).join('') +
      '</div>';
    }

    if (allProgressStudents.length === 0) {
      listEl.innerHTML = instructorHtml +
        '<div class="empty-state"><div class="empty-icon">&#128200;</div><h3>No students yet</h3><p>Enroll students in a training program to track their progress</p></div>';
      return;
    }

    renderProgressStudentList(allProgressStudents, instructorHtml);
    // Populate enroll form dropdowns
    await populateEnrollForm();
  } catch (err) {
    listEl.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load students.</div>';
  }
}

function renderProgressStudentList(students, instructorHtml) {
  const listEl = document.getElementById('progress-student-list');
  listEl.innerHTML = (instructorHtml || '') + `<div class="progress-student-grid">${students.map(s => renderStudentCard(s)).join('')}</div>`;
}

function renderStudentCard(s) {
  const hasEnrollments = s.enrollments && s.enrollments.length > 0;
  const lastFlight = s.last_flight_date ? new Date(s.last_flight_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'No flights';

  const programs = hasEnrollments
    ? s.enrollments.map(e => {
        const pct = e.stages_total > 0 ? Math.round((e.stages_completed / e.stages_total) * 100) : 0;
        const tagClass = e.program_code === 'PPL' ? 'tag-sky' : e.program_code === 'IFR' ? 'tag-purple' : 'tag-amber';
        return `<div class="prog-row">
          <span class="tag ${tagClass}">${escHtml(e.program_code)}</span>
          <span style="font-size:0.82rem;color:var(--gray-300)">${escHtml(e.current_stage_name || 'Starting')}</span>
          <div class="mini-progress-bar"><div style="width:${pct}%"></div></div>
          <span style="font-size:0.75rem;color:var(--gray-500)">${pct}%</span>
        </div>`;
      }).join('')
    : '<div style="color:var(--gray-500);font-size:0.82rem">Not enrolled</div>';

  const instructorName = hasEnrollments && s.enrollments[0].instructor_name
    ? escHtml(s.enrollments[0].instructor_name)
    : '<span style="color:var(--gray-500)">Unassigned</span>';

  return `<div class="progress-student-card" onclick="openProgressDetail(${s.id})">
    <div class="psc-header">
      <div>
        <div class="psc-name">${escHtml(s.name)}</div>
        <div class="psc-meta">CFI: ${instructorName}</div>
        ${s.phone_number ? `<div style="font-size:0.75rem;color:var(--gray-500);margin-top:0.1rem">&#128222; ${escHtml(s.phone_number)}</div>` : ''}
      </div>
      <div class="psc-lastflight">
        <div style="font-size:0.7rem;color:var(--gray-500);text-align:right">Last flight</div>
        <div style="font-size:0.8rem;color:var(--gray-300)">${lastFlight}</div>
      </div>
    </div>
    <div class="psc-programs">${programs}</div>
  </div>`;
}

function renderEnrollmentCard(e, debriefs, isOwnView, maneuverProgress) {
  const pct = e.stages_total > 0 ? Math.round((e.stages_completed / e.stages_total) * 100) : 0;
  const tagClass = e.program_code === 'PPL' ? 'tag-sky' : e.program_code === 'IFR' ? 'tag-purple' : 'tag-amber';

  // Build stages with expandable maneuver checklists
  const stagesHtml = e.stages ? e.stages.map(s => {
    const done = s.completed;
    const isCurrent = e.current_stage_id === s.id;
    const maneuvers = (s.maneuvers || []);
    const hasManeuvers = maneuvers.length > 0;

    // Count maneuver progress for this stage
    let profCount = 0, pracCount = 0, introCount = 0;
    if (hasManeuvers && maneuverProgress) {
      maneuvers.forEach(m => {
        const p = maneuverProgress.find(mp => mp.maneuver_id === m.id);
        if (p) {
          if (p.status === 'proficient') profCount++;
          else if (p.status === 'practiced') pracCount++;
          else if (p.status === 'introduced') introCount++;
        }
      });
    }
    const doneCount = profCount;
    const progressLabel = hasManeuvers ? `${doneCount}/${maneuvers.length} proficient` : '';

    // Maneuver list HTML (hidden by default, shown on toggle)
    const maneuverListHtml = hasManeuvers ? `<div id="ml-${e.id}-${s.id}" class="maneuver-list" style="display:none">
      ${maneuvers.map(m => {
        const prog = maneuverProgress ? maneuverProgress.find(mp => mp.maneuver_id === m.id) : null;
        const st = prog ? prog.status : 'not_started';
        const gradedBy = prog && prog.instructor_name ? `by ${prog.instructor_name}` : '';
        const gradedAt = prog && prog.graded_at ? new Date(prog.graded_at).toLocaleDateString('en-US',{month:'short',day:'numeric'}) : '';

        if (isOwnView) {
          // Student view: read-only status badges
          const statusBadge = st === 'proficient'
            ? `<span style="font-size:0.68rem;font-weight:700;color:var(--green);background:rgba(34,197,94,0.12);padding:0.1rem 0.45rem;border-radius:4px">Proficient</span>`
            : st === 'practiced'
            ? `<span style="font-size:0.68rem;font-weight:700;color:var(--amber);background:rgba(245,158,11,0.12);padding:0.1rem 0.45rem;border-radius:4px">Practiced</span>`
            : st === 'introduced'
            ? `<span style="font-size:0.68rem;font-weight:700;color:var(--sky);background:rgba(56,189,248,0.12);padding:0.1rem 0.45rem;border-radius:4px">Introduced</span>`
            : `<span style="font-size:0.68rem;color:var(--gray-600)">—</span>`;
          return `<div class="maneuver-item">
            <div style="flex:1">
              <div class="maneuver-item-name">${escHtml(m.name)}</div>
              ${gradedAt ? `<div class="maneuver-graded-by">${gradedAt} ${gradedBy}</div>` : ''}
            </div>
            <div>${statusBadge}</div>
          </div>`;
        } else {
          // Instructor view: clickable 3-tier buttons
          const stuId = currentProgressStudentId;
          return `<div class="maneuver-item">
            <div style="flex:1">
              <div class="maneuver-item-name">${escHtml(m.name)}</div>
              ${gradedAt ? `<div class="maneuver-graded-by">${gradedAt} ${gradedBy}</div>` : ''}
            </div>
            <div class="maneuver-status-btns">
              <button class="msb ${st==='introduced'?'active-intro':''}" onclick="setManeuverStatus(${stuId},${e.id},${m.id},'introduced',this)" title="Introduced">I</button>
              <button class="msb ${st==='practiced'?'active-prac':''}" onclick="setManeuverStatus(${stuId},${e.id},${m.id},'practiced',this)" title="Practiced">P</button>
              <button class="msb ${st==='proficient'?'active-prof':''}" onclick="setManeuverStatus(${stuId},${e.id},${m.id},'proficient',this)" title="Proficient">✓</button>
            </div>
          </div>`;
        }
      }).join('')}
    </div>` : '';

    const toggleId = `ml-${e.id}-${s.id}`;
    return `<div class="stage-row ${done ? 'stage-done' : ''} ${isCurrent ? 'stage-current' : ''} ${hasManeuvers ? 'stage-row-clickable' : ''}"
      ${hasManeuvers ? `onclick="toggleManeuverList('${toggleId}',this)"` : ''}>
      <span class="stage-check">${done ? '&#10003;' : isCurrent ? '&#9654;' : '&#9675;'}</span>
      <span class="stage-name">${escHtml(s.name)}</span>
      ${hasManeuvers ? `<span class="maneuver-progress-count">${progressLabel}</span>` : ''}
      ${done && s.completion ? `<span class="stage-date">${new Date(s.completion.completed_at).toLocaleDateString('en-US',{month:'short',day:'numeric'})}</span>` : ''}
      ${!isOwnView && !done ? `<button class="btn btn-secondary btn-xs" onclick="event.stopPropagation();openSignOffModal(${e.id},${s.id},'${escHtml(s.name).replace(/'/g,'\\\")}')" style="font-size:0.7rem;padding:0.15rem 0.5rem">Sign Off</button>` : ''}
      ${hasManeuvers ? `<span class="stage-maneuver-toggle">&#9654;</span>` : ''}
    </div>${maneuverListHtml}`;
  }).join('') : '';

  const recentDebriefs = debriefs ? debriefs.filter(d => !d.program_code || d.program_code === e.program_code).slice(0, 3) : [];
  const _rc = (v) => v<=1?'#ef4444':v===2?'#f97316':v===3?'#eab308':v===4?'#84cc16':'#22c55e';
  const debriefsHtml = recentDebriefs.length > 0
    ? recentDebriefs.map(d => `<div style="background:var(--navy);border-radius:8px;padding:0.6rem 0.8rem;margin-bottom:0.4rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.25rem;flex-wrap:wrap;gap:0.3rem">
          <span style="font-size:0.78rem;color:var(--gray-500)">${d.flight_date ? new Date(String(d.flight_date).slice(0,10)+'T12:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : ''}</span>
          <div style="display:flex;align-items:center;gap:0.35rem">
            ${d.overall_performance ? `<span style="font-size:0.85rem;color:${_rc(d.overall_performance)}">${'★'.repeat(d.overall_performance)}${'☆'.repeat(5-d.overall_performance)}</span>` : ''}
            ${d.instructor_name ? `<span style="font-size:0.72rem;color:var(--gray-600)">${escHtml(d.instructor_name)}</span>` : ''}
          </div>
        </div>
        ${d.notes ? `<div style="font-size:0.8rem;color:var(--gray-400);line-height:1.4">${escHtml(d.notes)}</div>` : ''}
        ${d.recommendations ? `<div style="font-size:0.77rem;color:var(--sky);margin-top:0.25rem"><strong>Next:</strong> ${escHtml(d.recommendations)}</div>` : ''}
      </div>`).join('')
    : '<div style="font-size:0.82rem;color:var(--gray-500);padding:0.25rem 0">No debriefs logged yet.</div>';

  return `<div class="enrollment-card">
    <div class="enroll-header">
      <span class="tag ${tagClass}">${escHtml(e.program_code)}</span>
      <span style="font-size:1rem;font-weight:700;color:var(--white)">${escHtml(e.program_name)}</span>
      <div class="prog-progress-wrap">
        <div class="prog-progress-bar"><div style="width:${pct}%"></div></div>
        <span style="font-size:0.8rem;color:var(--gray-400)">${pct}%</span>
      </div>
    </div>
    ${e.instructor_name ? `<div style="font-size:0.82rem;color:var(--gray-400);margin-bottom:0.75rem">CFI: ${escHtml(e.instructor_name)}</div>` : ''}
    <div style="font-size:0.75rem;color:var(--gray-500);margin-bottom:0.5rem">Click a stage to expand maneuvers → I = Introduced &nbsp;·&nbsp; P = Practiced &nbsp;·&nbsp; ✓ = Proficient</div>
    <div class="stages-list">${stagesHtml}</div>
    ${!isOwnView ? '' : `<div style="margin-top:1.25rem"><h4 style="font-size:0.85rem;color:var(--gray-400);margin-bottom:0.5rem">Recent Debriefs</h4>${debriefsHtml}</div>`}
  </div>`;
}

function toggleManeuverList(listId, stageRow) {
  const list = document.getElementById(listId);
  if (!list) return;
  const isOpen = list.style.display !== 'none';
  list.style.display = isOpen ? 'none' : 'flex';
  list.style.flexDirection = 'column';
  const arrow = stageRow.querySelector('.stage-maneuver-toggle');
  if (arrow) arrow.classList.toggle('open', !isOpen);
}

async function setManeuverStatus(studentId, enrollmentId, maneuverId, status, btn) {
  // Prevent double-clicks
  if (btn.disabled) return;
  btn.disabled = true;

  try {
    await api('/api/training/maneuver-progress', {
      method: 'PUT',
      body: JSON.stringify({ student_id: studentId, enrollment_id: enrollmentId, maneuver_id: maneuverId, status })
    });

    // Update all 3 buttons in this maneuver row
    const row = btn.closest('.maneuver-item');
    if (row) {
      row.querySelectorAll('.msb').forEach(b => {
        b.classList.remove('active-intro', 'active-prac', 'active-prof');
        b.disabled = false;
      });
      if (status === 'introduced') btn.classList.add('active-intro');
      else if (status === 'practiced') btn.classList.add('active-prac');
      else if (status === 'proficient') btn.classList.add('active-prof');
      btn.disabled = false;
    }

    // Update progress count in stage row
    const list = btn.closest('.maneuver-list');
    if (list) {
      const stageId = list.id; // ml-enrollId-stageId
      const allItems = list.querySelectorAll('.maneuver-item');
      const profCount = list.querySelectorAll('.msb.active-prof').length;
      const total = allItems.length;
      const stageRow = list.previousElementSibling;
      if (stageRow) {
        const countEl = stageRow.querySelector('.maneuver-progress-count');
        if (countEl) countEl.textContent = `${profCount}/${total} proficient`;
      }
    }
  } catch (err) {
    btn.disabled = false;
    alert('Failed to save: ' + (err.error || 'Unknown error'));
  }
}

function buildInstructorDebriefHtml(debriefs, studentId) {
  if (!debriefs || debriefs.length === 0) {
    return '<div style="color:var(--gray-500);font-size:0.85rem;padding:0.5rem 0">No debriefs logged yet.</div>';
  }

  const ratingColor = (v) => v<=1?'#ef4444':v===2?'#f97316':v===3?'#eab308':v===4?'#84cc16':'#22c55e';
  const ratingBg = (v) => v<=1?'rgba(239,68,68,0.12)':v===2?'rgba(249,115,22,0.12)':v===3?'rgba(234,179,8,0.12)':v===4?'rgba(132,204,18,0.12)':'rgba(34,197,94,0.12)';
  const stars = (v) => v ? '★'.repeat(v) + '☆'.repeat(5-v) : '';
  const perfLabels = ['','Needs Work','Below Std','Meets Std','Above Std','Excellent'];

  // Topic stats — avg rating per topic across all debriefs
  const topicRatings = {};
  debriefs.forEach(d => {
    (d.grades||[]).forEach(g => {
      if (g.grade) {
        if (!topicRatings[g.maneuver_name]) topicRatings[g.maneuver_name] = [];
        topicRatings[g.maneuver_name].push(g.grade);
      }
    });
  });
  const topicKeys = Object.keys(topicRatings).sort();
  const statsHtml = topicKeys.length > 0 ? `
    <div style="background:var(--navy);border-radius:10px;padding:0.85rem 1rem;margin-bottom:1rem">
      <div style="font-size:0.75rem;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:0.6rem">Avg Performance by Topic</div>
      <div style="display:flex;flex-wrap:wrap;gap:0.35rem">
        ${topicKeys.map(t => {
          const avg = topicRatings[t].reduce((a,b)=>a+b,0)/topicRatings[t].length;
          const avgR = Math.round(avg);
          return `<span style="font-size:0.75rem;font-weight:600;padding:0.2rem 0.55rem;border-radius:4px;background:${ratingBg(avgR)};color:${ratingColor(avgR)}" title="${topicRatings[t].length} session(s)">${escHtml(t)} ${avg.toFixed(1)}★</span>`;
        }).join('')}
      </div>
    </div>` : '';

  const rows = debriefs.map(d => {
    const dateStr = d.flight_date
      ? new Date(String(d.flight_date).slice(0,10) + 'T12:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})
      : '';
    const gradeChips = (d.grades||[]).filter(g=>g.grade).map(g =>
      `<span style="font-size:0.72rem;font-weight:600;padding:0.15rem 0.45rem;border-radius:4px;background:${ratingBg(g.grade)};color:${ratingColor(g.grade)}">${escHtml(g.maneuver_name)} ${stars(g.grade)}</span>`
    ).join('');
    const noGradeTopics = (d.grades||[]).filter(g=>!g.grade).map(g =>
      `<span style="font-size:0.72rem;color:var(--gray-500);padding:0.15rem 0.45rem;border-radius:4px;background:rgba(148,163,184,0.08)">${escHtml(g.maneuver_name)}</span>`
    ).join('');
    return `<div style="background:var(--slate);border-radius:10px;padding:0.85rem 1rem;margin-bottom:0.6rem">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.45rem;flex-wrap:wrap;gap:0.35rem">
        <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap">
          <span style="font-size:0.82rem;font-weight:600;color:var(--white)">${dateStr}</span>
          ${d.stage_name ? `<span style="font-size:0.72rem;color:var(--sky);background:rgba(56,189,248,0.1);padding:0.1rem 0.4rem;border-radius:4px">${escHtml(d.stage_name)}</span>` : ''}
          ${d.instructor_name ? `<span style="font-size:0.72rem;color:var(--gray-500)">by ${escHtml(d.instructor_name)}</span>` : ''}
        </div>
        ${d.overall_performance ? `<span style="font-size:0.82rem;font-weight:600;color:${ratingColor(d.overall_performance)}" title="${perfLabels[d.overall_performance]}">${stars(d.overall_performance)} <span style="font-size:0.72rem;font-weight:400;color:var(--gray-500)">${perfLabels[d.overall_performance]}</span></span>` : ''}
      </div>
      ${(gradeChips||noGradeTopics) ? `<div style="display:flex;flex-wrap:wrap;gap:0.28rem;margin-bottom:0.45rem">${gradeChips}${noGradeTopics}</div>` : ''}
      ${d.notes ? `<div style="font-size:0.83rem;color:var(--gray-300);line-height:1.5;margin-bottom:0.35rem">${escHtml(d.notes)}</div>` : ''}
      ${d.recommendations ? `<div style="font-size:0.8rem;color:var(--sky);background:rgba(56,189,248,0.07);border-left:2px solid var(--sky);padding:0.28rem 0.6rem;border-radius:0 4px 4px 0"><strong>Next:</strong> ${escHtml(d.recommendations)}</div>` : ''}
    </div>`;
  }).join('');

  return statsHtml + `<div style="max-height:480px;overflow-y:auto;padding-right:0.25rem">${rows}</div>`;
}

async function openProgressDetail(studentId) {
  currentProgressStudentId = studentId;
  document.getElementById('progress-list-view').classList.add('hidden');
  const detailView = document.getElementById('progress-detail-view');
  const detailContent = document.getElementById('progress-detail-content');
  detailView.classList.remove('hidden');
  detailContent.innerHTML = '<div style="color:var(--gray-400);padding:2rem">Loading...</div>';

  try {
    const data = await api(`/api/training/students/${studentId}`);
    const s = data.student;
    const isInstructor = currentUser.role === 'instructor' || currentUser.role === 'owner' || currentUser.role === 'admin';

    // Load maneuver progress for all enrollments in parallel
    const maneuverProgressByEnrollment = {};
    await Promise.all(data.enrollments.map(async e => {
      try {
        const mp = await api(`/api/training/maneuver-progress/${studentId}/${e.id}`);
        maneuverProgressByEnrollment[e.id] = mp;
      } catch { maneuverProgressByEnrollment[e.id] = []; }
    }));

    // Also attach maneuvers from allPrograms to each enrollment's stages
    data.enrollments.forEach(e => {
      const prog = (allPrograms || []).find(p => p.id === e.program_id);
      if (prog && e.stages) {
        e.stages.forEach(s => {
          const ps = (prog.stages || []).find(ps => ps.id === s.id);
          if (ps) s.maneuvers = ps.maneuvers || [];
        });
      }
    });

    const enrollHtml = data.enrollments.length > 0
      ? data.enrollments.map(e => renderEnrollmentCard(e, data.debriefs, false, maneuverProgressByEnrollment[e.id] || [])).join('')
      : '<div style="color:var(--gray-500);padding:1rem">Not enrolled in any program.</div>';

    // Fetch full debrief history for instructor/admin/owner view
    let allDebriefs = data.debriefs || [];
    if (isInstructor) {
      try {
        allDebriefs = await api(`/api/training/students/${studentId}/debriefs`);
      } catch { allDebriefs = data.debriefs || []; }
    }

    const debriefsHtml = buildInstructorDebriefHtml(allDebriefs, studentId);

    const actionBtns = isInstructor
      ? `<div style="display:flex;gap:0.5rem;margin-bottom:1.5rem;flex-wrap:wrap">
          <button class="btn btn-primary btn-sm" onclick="openDebriefModal(${studentId})">+ Log Debrief</button>
          <button class="btn btn-secondary btn-sm" onclick="openAssignModal(${studentId}, '${escHtml(s.name).replace(/'/g, "\\'")}')">Reassign Instructor</button>
          <button class="btn btn-secondary btn-sm" onclick="viewStudentReadiness(${studentId}, '${escHtml(s.name).replace(/'/g, "\\'")}')">&#127775; Checkride Readiness</button>
        </div>`
      : '';

    detailContent.innerHTML = `
      <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap">
        <div>
          <h2 style="font-size:1.3rem;font-weight:700;color:var(--white);margin:0">${escHtml(s.name)}</h2>
          <div style="font-size:0.85rem;color:var(--gray-400)">${escHtml(s.email)}</div>
          ${s.phone_number ? `<div style="font-size:0.82rem;color:var(--gray-400);margin-top:0.15rem">&#128222; ${escHtml(s.phone_number)}</div>` : ''}
        </div>
        <div style="display:flex;gap:0.75rem;margin-left:auto;flex-wrap:wrap;align-items:flex-start">
          <div class="stat-card" style="min-width:80px;padding:0.5rem 0.75rem">
            <div class="stat-label" style="font-size:0.65rem">Hobbs Hrs</div>
            <div class="stat-value" style="font-size:1.1rem">${parseFloat(s.total_hobbs_hours||0).toFixed(1)}</div>
            ${['owner','admin'].includes(currentUser.role) ? `
            <div style="display:flex;gap:0.3rem;margin-top:0.35rem">
              <button class="btn btn-secondary btn-sm" style="font-size:0.65rem;padding:1px 6px" onclick="openEditStudentHoursModal(${studentId}, '${escHtml(s.name).replace(/'/g,"\\'")}', ${parseFloat(s.total_hobbs_hours||0).toFixed(1)}, ${parseFloat(s.total_tach_hours||0).toFixed(1)})">Edit</button>
              <button class="btn btn-sm" style="font-size:0.65rem;padding:1px 6px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmResetStudentHours(${studentId}, '${escHtml(s.name).replace(/'/g,"\\'")}', 'hobbs')">Reset</button>
            </div>` : ''}
          </div>
          <div class="stat-card" style="min-width:80px;padding:0.5rem 0.75rem">
            <div class="stat-label" style="font-size:0.65rem">Tach Hrs</div>
            <div class="stat-value" style="font-size:1.1rem">${parseFloat(s.total_tach_hours||0).toFixed(1)}</div>
            ${['owner','admin'].includes(currentUser.role) ? `
            <div style="display:flex;gap:0.3rem;margin-top:0.35rem">
              <button class="btn btn-secondary btn-sm" style="font-size:0.65rem;padding:1px 6px" onclick="openEditStudentHoursModal(${studentId}, '${escHtml(s.name).replace(/'/g,"\\'")}', ${parseFloat(s.total_hobbs_hours||0).toFixed(1)}, ${parseFloat(s.total_tach_hours||0).toFixed(1)})">Edit</button>
              <button class="btn btn-sm" style="font-size:0.65rem;padding:1px 6px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmResetStudentHours(${studentId}, '${escHtml(s.name).replace(/'/g,"\\'")}', 'tach')">Reset</button>
            </div>` : ''}
          </div>
        </div>
      </div>
      ${actionBtns}
      <h3 style="font-size:0.9rem;font-weight:600;color:var(--gray-400);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.75rem">Training Programs</h3>
      ${enrollHtml}
      <h3 style="font-size:0.9rem;font-weight:600;color:var(--gray-400);text-transform:uppercase;letter-spacing:0.05em;margin-top:1.5rem;margin-bottom:0.75rem">CFI Debrief History</h3>
      ${debriefsHtml}
    `;
  } catch (err) {
    detailContent.innerHTML = `<div style="color:var(--red);padding:1rem">${err.error || 'Failed to load student detail'}</div>`;
  }
}

function showProgressList() {
  currentProgressStudentId = null;
  document.getElementById('progress-list-view').classList.remove('hidden');
  document.getElementById('progress-detail-view').classList.add('hidden');
}

async function toggleEnrollForm() {
  const container = document.getElementById('enroll-form-container');
  const wasHidden = container.classList.contains('hidden');
  container.classList.toggle('hidden');

  // Re-populate dropdowns whenever opening the form (ensures data is fresh)
  if (wasHidden) {
    // Ensure programs are loaded
    if (!allPrograms || allPrograms.length === 0) {
      try { allPrograms = await api('/api/training/programs'); } catch { allPrograms = []; }
    }
    // Ensure users are loaded
    if (!allUsers || allUsers.length === 0) {
      try { allUsers = await api('/api/users'); } catch { allUsers = []; }
    }
    await populateEnrollForm();
  }
}

async function populateEnrollForm() {
  const students = allUsers.filter(u => u.role === 'student');
  const instructors = allUsers.filter(u => u.role === 'instructor' || u.role === 'admin' || u.role === 'owner');

  const studentSel = document.getElementById('enroll-student-select');
  const programSel = document.getElementById('enroll-program-select');
  const instrSel = document.getElementById('enroll-instructor-select');

  if (studentSel) {
    studentSel.innerHTML = students.map(u => `<option value="${u.id}">${escHtml(u.name)}</option>`).join('');
  }
  if (programSel) {
    programSel.innerHTML = allPrograms.map(p => `<option value="${p.id}">${escHtml(p.name)} (${escHtml(p.code)})</option>`).join('');
  }
  if (instrSel) {
    instrSel.innerHTML = '<option value="">Unassigned</option>' +
      instructors.map(u => `<option value="${u.id}">${escHtml(u.name)}</option>`).join('');
    if (currentUser.role === 'instructor') {
      instrSel.value = String(currentUser.id);
    }
  }
}

async function enrollStudent() {
  const studentId = parseInt(document.getElementById('enroll-student-select').value);
  const programId = parseInt(document.getElementById('enroll-program-select').value);
  const instructorId = document.getElementById('enroll-instructor-select').value;

  if (!studentId || !programId) { alert('Please select a student and program.'); return; }

  try {
    await api('/api/training/enroll', {
      method: 'POST',
      body: JSON.stringify({
        student_id: studentId,
        program_id: programId,
        instructor_id: instructorId ? parseInt(instructorId) : null
      })
    });
    document.getElementById('enroll-form-container').classList.add('hidden');
    await loadProgressStudentList();
  } catch (err) {
    alert(err.error || err.message || 'Failed to enroll student');
  }
}

// ─── DEBRIEF SHARED UTILITIES ───
const PFD_TOPICS = [
  'Maneuvers',
  'Takeoffs & Landings',
  'Navigation',
  'Airspace & Communications',
  'Emergency Procedures',
  'Pre/Post-Flight Procedures',
  'Ground Instruction',
  'Stage Check Prep',
  'Checkride Prep',
];

function debriefStarColor(v) {
  if (v <= 1) return '#ef4444';
  if (v === 2) return '#f97316';
  if (v === 3) return '#eab308';
  if (v === 4) return '#84cc16';
  return '#22c55e';
}

function initDebriefTopics(prefix) {
  const container = document.getElementById(prefix + '-topics');
  if (!container) return;
  container.innerHTML = PFD_TOPICS.map((t, i) => `
    <div>
      <label style="display:flex;align-items:center;gap:0.6rem;cursor:pointer;padding:0.42rem 0.75rem;background:var(--slate);border-radius:8px;border:1px solid transparent;transition:border-color 0.15s" id="${prefix}-tl-${i}">
        <input type="checkbox" id="${prefix}-tc-${i}" onchange="toggleDebriefTopic('${prefix}',${i})" style="width:15px;height:15px;cursor:pointer;flex-shrink:0;accent-color:var(--sky)">
        <span style="font-size:0.85rem;color:var(--gray-300);flex:1">${escHtml(t)}</span>
        <div id="${prefix}-ts-${i}" style="display:none;gap:0.1rem;flex-shrink:0">
          ${[1,2,3,4,5].map(v => `<span class="ds-${prefix}" data-idx="${i}" data-v="${v}" onclick="event.preventDefault();event.stopPropagation();setDebriefTopicStar('${prefix}',${i},${v})" style="font-size:1.25rem;color:var(--gray-600);cursor:pointer;user-select:none;transition:color 0.1s">★</span>`).join('')}
        </div>
      </label>
      <input type="hidden" id="${prefix}-tv-${i}" value="0">
    </div>`
  ).join('');
}

function toggleDebriefTopic(prefix, idx) {
  const cb = document.getElementById(prefix + '-tc-' + idx);
  const starsEl = document.getElementById(prefix + '-ts-' + idx);
  const labelEl = document.getElementById(prefix + '-tl-' + idx);
  if (cb.checked) {
    starsEl.style.display = 'flex';
    labelEl.style.borderColor = 'rgba(56,189,248,0.3)';
  } else {
    starsEl.style.display = 'none';
    labelEl.style.borderColor = 'transparent';
    setDebriefTopicStar(prefix, idx, 0);
  }
}

function setDebriefTopicStar(prefix, idx, val) {
  document.getElementById(prefix + '-tv-' + idx).value = val;
  document.querySelectorAll('.ds-' + prefix + '[data-idx="' + idx + '"]').forEach(s => {
    s.style.color = parseInt(s.dataset.v) <= val ? debriefStarColor(val) : 'var(--gray-600)';
  });
}

function initStarContainer(containerId, hiddenId) {
  const container = document.getElementById(containerId);
  const hiddenEl = document.getElementById(hiddenId);
  if (!container || !hiddenEl) return;
  const setStars = (val, commit) => {
    container.querySelectorAll('span').forEach(s => {
      const v = parseInt(s.dataset.v);
      s.textContent = v <= val ? '★' : '☆';
      s.style.color = v <= val ? debriefStarColor(val) : 'var(--gray-500)';
    });
    if (commit) hiddenEl.value = val;
  };
  container.querySelectorAll('span').forEach(s => {
    s.addEventListener('mouseover', () => setStars(parseInt(s.dataset.v), false));
    s.addEventListener('mouseout', () => setStars(parseInt(hiddenEl.value) || 0, false));
    s.addEventListener('click', () => setStars(parseInt(s.dataset.v), true));
  });
}

function collectDebriefGrades(prefix) {
  const grades = [];
  PFD_TOPICS.forEach((t, i) => {
    const cb = document.getElementById(prefix + '-tc-' + i);
    if (cb && cb.checked) {
      const rating = parseInt(document.getElementById(prefix + '-tv-' + i).value) || null;
      grades.push({ maneuver_name: t, grade: rating });
    }
  });
  return grades;
}

// ─── POST-FLIGHT DEBRIEF STEP (inline in complete-modal) ───
function showPostFlightDebriefStep(studentId, bookingId, flightDate) {
  document.getElementById('pfd-student-id').value = studentId;
  document.getElementById('pfd-booking-id').value = bookingId;
  document.getElementById('pfd-flight-date').value = flightDate;
  document.getElementById('pfd-notes').value = '';
  document.getElementById('pfd-recommendations').value = '';
  document.getElementById('pfd-error').classList.add('hidden');
  const pfdOv = document.getElementById('pfd-overall-val');
  if (pfdOv) pfdOv.value = '';
  initDebriefTopics('pfd');
  const overallCont = document.getElementById('pfd-overall-stars');
  if (overallCont) {
    overallCont.querySelectorAll('span').forEach(s => { s.textContent = '☆'; s.style.color = 'var(--gray-500)'; });
    initStarContainer('pfd-overall-stars', 'pfd-overall-val');
  }
  document.getElementById('complete-form').classList.add('hidden');
  const h3 = document.querySelector('#complete-modal h3');
  if (h3) h3.textContent = 'Post-Flight Debrief';
  document.getElementById('complete-debrief-step').classList.remove('hidden');
}

async function savePostFlightDebrief() {
  const errEl = document.getElementById('pfd-error');
  errEl.classList.add('hidden');
  const studentId = parseInt(document.getElementById('pfd-student-id').value);
  const bookingId = parseInt(document.getElementById('pfd-booking-id').value);
  const flightDate = document.getElementById('pfd-flight-date').value;
  const notes = (document.getElementById('pfd-notes').value || '').trim() || null;
  const recommendations = (document.getElementById('pfd-recommendations').value || '').trim() || null;
  const overall = parseInt(document.getElementById('pfd-overall-val').value) || null;
  const grades = collectDebriefGrades('pfd');
  try {
    await api('/api/training/debriefs', {
      method: 'POST',
      body: JSON.stringify({ student_id: studentId, booking_id: bookingId, flight_date: flightDate, notes, recommendations, overall_performance: overall, grades })
    });
    closeCompleteModal();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save debrief';
    errEl.classList.remove('hidden');
  }
}

function skipPostFlightDebrief() {
  closeCompleteModal();
}

// ─── DEBRIEF MODAL ───
let debriefTargetStudentId = null;

function openDebriefModal(studentId) {
  debriefTargetStudentId = studentId || currentProgressStudentId;
  document.getElementById('debrief-error').classList.add('hidden');
  document.getElementById('debrief-form').reset();
  document.getElementById('debrief-modal').classList.remove('hidden');

  // Populate student select if not targeting a specific student
  const studentGroup = document.getElementById('debrief-student-group');
  if (debriefTargetStudentId) {
    studentGroup.style.display = 'none';
  } else {
    studentGroup.style.display = '';
    const sel = document.getElementById('debrief-student-select');
    const students = allUsers.filter(u => u.role === 'student');
    sel.innerHTML = students.map(u => `<option value="${u.id}">${escHtml(u.name)}</option>`).join('');
  }

  // Populate stage select
  const stageSel = document.getElementById('debrief-stage-select');
  stageSel.innerHTML = '<option value="">No stage (general debrief)</option>' +
    allPrograms.flatMap(p =>
      p.stages.map(s => `<option value="${s.id}">[${escHtml(p.code)}] ${escHtml(s.name)}</option>`)
    ).join('');

  // Default date to today
  document.getElementById('debrief-date').value = new Date().toISOString().split('T')[0];

  // Initialize topics
  initDebriefTopics('dm');

  // Initialize overall stars
  const dmOv = document.getElementById('dm-overall-val');
  if (dmOv) dmOv.value = '';
  const dmOverallCont = document.getElementById('dm-overall-stars');
  if (dmOverallCont) {
    dmOverallCont.querySelectorAll('span').forEach(s => { s.textContent = '☆'; s.style.color = 'var(--gray-500)'; });
    initStarContainer('dm-overall-stars', 'dm-overall-val');
  }

  // Clear recommendations
  const dmRec = document.getElementById('debrief-recommendations');
  if (dmRec) dmRec.value = '';
}

function closeDebriefModal() {
  document.getElementById('debrief-modal').classList.add('hidden');
  debriefTargetStudentId = null;
}

document.addEventListener('DOMContentLoaded', () => {
  const debriefForm = document.getElementById('debrief-form');
  if (debriefForm) {
    debriefForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = document.getElementById('debrief-error');
      errEl.classList.add('hidden');

      const studentId = debriefTargetStudentId || parseInt(document.getElementById('debrief-student-select').value);
      const stageId = document.getElementById('debrief-stage-select').value || null;
      const notes = (document.getElementById('debrief-notes').value || '').trim() || null;
      const recommendations = (document.getElementById('debrief-recommendations') ? document.getElementById('debrief-recommendations').value.trim() : '') || null;
      const overall = parseInt(document.getElementById('dm-overall-val') ? document.getElementById('dm-overall-val').value : '') || null;
      const date = document.getElementById('debrief-date').value;
      const grades = collectDebriefGrades('dm');

      try {
        await api('/api/training/debriefs', {
          method: 'POST',
          body: JSON.stringify({
            student_id: studentId,
            stage_id: stageId ? parseInt(stageId) : null,
            notes,
            recommendations,
            overall_performance: overall,
            flight_date: date,
            grades,
          })
        });
        closeDebriefModal();
        if (currentProgressStudentId) {
          await openProgressDetail(currentProgressStudentId);
        } else {
          await loadProgressStudentList();
        }
      } catch (err) {
        errEl.textContent = err.error || 'Failed to log debrief';
        errEl.classList.remove('hidden');
      }
    });
  }
});

// ─── SIGN-OFF MODAL ───
let signOffData = {};

function openSignOffModal(enrollmentId, stageId, stageName) {
  signOffData = { enrollmentId, stageId };
  document.getElementById('signoff-stage-name').textContent = stageName;
  document.getElementById('signoff-notes').value = '';
  document.getElementById('signoff-error').classList.add('hidden');
  document.getElementById('signoff-modal').classList.remove('hidden');
}

function closeSignOffModal() {
  document.getElementById('signoff-modal').classList.add('hidden');
  signOffData = {};
}

document.addEventListener('DOMContentLoaded', () => {
  const signoffForm = document.getElementById('signoff-form');
  if (signoffForm) {
    signoffForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = document.getElementById('signoff-error');
      errEl.classList.add('hidden');
      const notes = document.getElementById('signoff-notes').value || null;

      try {
        await api('/api/training/milestones', {
          method: 'POST',
          body: JSON.stringify({
            student_id: currentProgressStudentId,
            stage_id: signOffData.stageId,
            enrollment_id: signOffData.enrollmentId,
            notes
          })
        });
        closeSignOffModal();
        await openProgressDetail(currentProgressStudentId);
      } catch (err) {
        errEl.textContent = err.error || 'Failed to sign off stage';
        errEl.classList.remove('hidden');
      }
    });
  }
});

// ─── CHECKRIDE READINESS MODAL (instructor/admin view from Progress tab) ───
async function viewStudentReadiness(studentId, studentName) {
  const modal = document.getElementById('readiness-modal');
  const bodyEl = document.getElementById('readiness-modal-body');
  document.getElementById('readiness-modal-student').textContent = studentName;
  bodyEl.innerHTML = '<div style="padding:2rem;text-align:center;color:var(--gray-400)">Loading readiness data…</div>';
  modal.classList.remove('hidden');
  try {
    const data = await api(`/api/training/checkride-readiness/${studentId}`);
    if (!data.programs || data.programs.length === 0) {
      bodyEl.innerHTML = '<div style="padding:1.5rem;color:var(--gray-400)">No active enrollments found for this student.</div>';
      return;
    }
    bodyEl.innerHTML = data.programs.map(prog => {
      const pct = prog.readiness_pct;
      const barColor = pct >= 80 ? 'var(--green)' : pct >= 50 ? 'var(--amber)' : 'var(--red)';
      const catsHtml = prog.categories.map(c => {
        const catColor = c.pct >= 80 ? 'var(--green)' : c.pct >= 50 ? 'var(--amber)' : 'var(--red)';
        return `<div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem 0;border-bottom:1px solid var(--border)">
          <div style="min-width:130px;font-size:0.82rem;color:var(--gray-300)">${escHtml(c.label)}</div>
          <div style="flex:1;height:6px;background:var(--slate);border-radius:3px;overflow:hidden">
            <div style="height:100%;width:${c.pct}%;background:${catColor};border-radius:3px"></div>
          </div>
          <div style="min-width:80px;text-align:right;font-size:0.82rem;color:var(--white)">${c.got}/${c.need} <span style="color:var(--gray-500)">(${c.pct}%)</span></div>
        </div>`;
      }).join('');
      const recsHtml = prog.recommendations.length > 0
        ? prog.recommendations.map(r => {
            const priorityColor = r.priority === 'high' ? 'var(--red)' : r.priority === 'medium' ? 'var(--amber)' : 'var(--green)';
            return `<div style="display:flex;align-items:flex-start;gap:0.5rem;padding:0.35rem 0;font-size:0.82rem">
              <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${priorityColor};flex-shrink:0;margin-top:4px"></span>
              <span style="color:var(--gray-300)">${escHtml(r.text)}</span>
            </div>`;
          }).join('')
        : '<div style="color:var(--green);font-size:0.85rem;padding:0.5rem 0">All requirements met — ready for checkride! ✓</div>';
      return `<div style="margin-bottom:1.5rem">
        <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.75rem">
          <h4 style="margin:0;color:var(--white);font-size:1rem">${escHtml(prog.program_name)} (${escHtml(prog.program_code)})</h4>
          <span style="font-size:0.82rem;font-weight:600;color:${barColor}">${pct}% Ready</span>
        </div>
        <div style="height:8px;background:var(--slate);border-radius:4px;overflow:hidden;margin-bottom:1rem">
          <div style="height:100%;width:${pct}%;background:${barColor};border-radius:4px;transition:width 0.4s"></div>
        </div>
        <div style="margin-bottom:1rem">${catsHtml}</div>
        <div style="margin-bottom:0.5rem;font-size:0.78rem;font-weight:600;color:var(--gray-400);text-transform:uppercase;letter-spacing:0.04em">Recommendations</div>
        ${recsHtml}
      </div>`;
    }).join('<hr style="border-color:var(--border);margin:1rem 0">');
  } catch (err) {
    bodyEl.innerHTML = `<div style="padding:1rem;color:var(--red)">${err.error || 'Failed to load readiness data'}</div>`;
  }
}
function closeReadinessModal() {
  document.getElementById('readiness-modal').classList.add('hidden');
}

// ─── ASSIGN INSTRUCTOR MODAL ───
let assignStudentId = null;

let _assignEnrollments = []; // cache enrollment data for instructor pre-selection
async function openAssignModal(studentId, studentName) {
  try {
    assignStudentId = studentId;
    _assignEnrollments = [];
    document.getElementById('assign-student-name').textContent = studentName;
    document.getElementById('assign-current-instructor').textContent = '—';
    document.getElementById('assign-error').classList.add('hidden');

    // Load instructors
    const instrSel = document.getElementById('assign-instructor-select');
    try {
      const instructors = await api('/api/training/instructors');
      instrSel.innerHTML = '<option value="">Unassigned</option>' +
        instructors.map(i => `<option value="${i.id}">${escHtml(i.name)} (${i.student_count} students)</option>`).join('');
    } catch {
      instrSel.innerHTML = '<option value="">Failed to load</option>';
    }

    // Fetch full student detail which includes instructor_id per enrollment
    const enrollSel = document.getElementById('assign-enrollment-select');
    enrollSel.innerHTML = '<option value="">Loading…</option>';
    const detailData = await api(`/api/training/students/${studentId}`).catch(() => null);
    if (detailData && detailData.enrollments && detailData.enrollments.length > 0) {
      _assignEnrollments = detailData.enrollments;
      enrollSel.innerHTML = detailData.enrollments.map(e =>
        `<option value="${e.id}" data-instructor-id="${e.instructor_id || ''}">${escHtml(e.program_code)} — ${escHtml(e.program_name)}${e.instructor_name ? ' (CFI: ' + escHtml(e.instructor_name) + ')' : ''}</option>`
      ).join('');
      // Pre-select instructor for the first enrollment
      const first = detailData.enrollments[0];
      if (first.instructor_name) {
        document.getElementById('assign-current-instructor').textContent = first.instructor_name;
      }
      if (first.instructor_id) instrSel.value = String(first.instructor_id);
    } else {
      enrollSel.innerHTML = '<option value="">No programs enrolled</option>';
    }

    // Update instructor pre-selection when enrollment changes
    enrollSel.onchange = function() {
      const selId = parseInt(enrollSel.value);
      const enroll = _assignEnrollments.find(e => e.id === selId);
      if (enroll) {
        document.getElementById('assign-current-instructor').textContent = enroll.instructor_name || '—';
        instrSel.value = enroll.instructor_id ? String(enroll.instructor_id) : '';
      }
    };

    document.getElementById('assign-modal').classList.remove('hidden');
  } catch (err) {
    console.error('openAssignModal error:', err);
    alert('Failed to open instructor assignment. Please try again.');
  }
}

function closeAssignModal() {
  document.getElementById('assign-modal').classList.add('hidden');
  assignStudentId = null;
}

document.addEventListener('DOMContentLoaded', () => {
  const assignForm = document.getElementById('assign-form');
  if (assignForm) {
    assignForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errEl = document.getElementById('assign-error');
      errEl.classList.add('hidden');

      const enrollmentId = document.getElementById('assign-enrollment-select').value;
      const instructorId = document.getElementById('assign-instructor-select').value;

      try {
        await api(`/api/training/enroll/${enrollmentId}`, {
          method: 'PATCH',
          body: JSON.stringify({ instructor_id: instructorId ? parseInt(instructorId) : null })
        });
        closeAssignModal();
        if (currentProgressStudentId) {
          await openProgressDetail(currentProgressStudentId);
        } else {
          await loadProgressStudentList();
        }
      } catch (err) {
        errEl.textContent = err.error || 'Failed to update instructor';
        errEl.classList.remove('hidden');
      }
    });
  }
});

// ─── SAVE INSTRUCTOR RATE ───
async function saveInstructorRate(userId, inputId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const rateVal = input.value ? parseFloat(input.value) : null;
  try {
    await api('/api/users/' + userId + '/rate', {
      method: 'PATCH',
      body: JSON.stringify({ instructor_rate: rateVal })
    });
    // Update local data
    var user = allUsers.find(function(u) { return u.id === userId; });
    if (user) user.instructor_rate = rateVal;
    // Brief visual feedback
    var btn = input.parentElement.querySelector('.btn-save-rate');
    if (btn) { btn.textContent = 'Saved!'; btn.style.color = 'var(--green)'; setTimeout(function() { btn.textContent = 'Save'; btn.style.color = ''; }, 1500); }
  } catch (err) {
    alert(err.error || 'Failed to save rate');
  }
}

// ─── BILLING PAGE ────────────────────────────────────────
let billingStudentSummaries = [];
let currentBillingStudentId = null;
let currentBillingFlights = [];
let currentBillingGroundSessions = [];

async function loadBilling() {
  const role = currentUser.role;
  const selectorEl = document.getElementById('billing-student-selector');
  const detailEl = document.getElementById('billing-detail');
  const emptyEl = document.getElementById('billing-empty');
  const backBtn = document.getElementById('billing-back-btn');

  if (role === 'student') {
    // Students see their own billing directly
    selectorEl.classList.add('hidden');
    backBtn.classList.add('hidden');
    emptyEl.classList.add('hidden');
    document.getElementById('billing-student-name').textContent = '';
    document.getElementById('billing-title').textContent = 'My Billing';
    await loadBillingForStudent(currentUser.id);
    return;
  }

  // Owner/instructor: show student overview
  document.getElementById('billing-title').textContent = 'Billing';
  try {
    billingStudentSummaries = await api('/api/billing/summary');
    if (billingStudentSummaries.length === 0) {
      selectorEl.classList.add('hidden');
      detailEl.classList.add('hidden');
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');
    selectorEl.classList.remove('hidden');
    detailEl.classList.add('hidden');
    backBtn.classList.add('hidden');
    renderBillingStudentList(billingStudentSummaries);
  } catch (err) {
    selectorEl.innerHTML = '<div style="color:var(--red);padding:1rem">Failed to load billing data.</div>';
    selectorEl.classList.remove('hidden');
  }
}

function renderBillingStudentList(students) {
  const listEl = document.getElementById('billing-students-list');
  listEl.innerHTML = students.map(function(s) {
    var totalCost = parseFloat(s.total_rental || 0) + parseFloat(s.total_instruction || 0);
    return '<div class="billing-student-card" onclick="selectBillingStudent(' + s.id + ', \'' + escHtml(s.name).replace(/'/g, "\\'") + '\')">' +
      '<div class="billing-student-name">' + escHtml(s.name) + '</div>' +
      '<div class="billing-student-stat"><div class="bs-label">Flights</div><div class="bs-value">' + (s.flight_count || 0) + '</div></div>' +
      '<div class="billing-student-stat"><div class="bs-label">Hours</div><div class="bs-value">' + parseFloat(s.total_hours || 0).toFixed(1) + '</div></div>' +
      '<div class="billing-student-stat"><div class="bs-label">Rental</div><div class="bs-value" style="color:var(--sky)">$' + parseFloat(s.total_rental || 0).toFixed(0) + '</div></div>' +
      '<div class="billing-student-stat"><div class="bs-label">Instruction</div><div class="bs-value" style="color:var(--amber)">$' + parseFloat(s.total_instruction || 0).toFixed(0) + '</div></div>' +
      '<div class="billing-student-stat"><div class="bs-label">Total</div><div class="bs-value" style="color:var(--green)">$' + totalCost.toFixed(0) + '</div></div>' +
      '</div>';
  }).join('');
}

async function selectBillingStudent(studentId, studentName) {
  currentBillingStudentId = studentId;
  document.getElementById('billing-student-selector').classList.add('hidden');
  document.getElementById('billing-back-btn').classList.remove('hidden');
  document.getElementById('billing-student-name').textContent = studentName;
  await loadBillingForStudent(studentId);
}

function showBillingOverview() {
  currentBillingStudentId = null;
  document.getElementById('billing-detail').classList.add('hidden');
  document.getElementById('billing-back-btn').classList.add('hidden');
  document.getElementById('billing-student-selector').classList.remove('hidden');
}

async function loadBillingForStudent(studentId) {
  const detailEl = document.getElementById('billing-detail');
  const emptyEl = document.getElementById('billing-empty');
  detailEl.classList.remove('hidden');
  emptyEl.classList.add('hidden');

  try {
    var data = await api('/api/billing/' + studentId);
    // Handle both legacy array response and new {flights, groundSessions} response
    var flights = Array.isArray(data) ? data : (data.flights || []);
    var groundSessions = Array.isArray(data) ? [] : (data.groundSessions || []);
    currentBillingFlights = flights;
    currentBillingGroundSessions = groundSessions;

    if (flights.length === 0 && groundSessions.length === 0) {
      document.getElementById('billing-stats').innerHTML = '';
      document.getElementById('billing-monthly-table').innerHTML = '';
      document.getElementById('billing-aircraft-table').innerHTML = '';
      document.getElementById('billing-flights-table').innerHTML = '';
      document.getElementById('billing-ground-table').innerHTML = '';
      document.getElementById('billing-monthly-empty').classList.remove('hidden');
      document.getElementById('billing-aircraft-empty').classList.remove('hidden');
      document.getElementById('billing-flights-empty').classList.remove('hidden');
      document.getElementById('billing-ground-empty').classList.remove('hidden');
      return;
    }

    // Show/hide section empty states based on what data exists
    if (flights.length > 0) {
      document.getElementById('billing-monthly-empty').classList.add('hidden');
      document.getElementById('billing-aircraft-empty').classList.add('hidden');
      document.getElementById('billing-flights-empty').classList.add('hidden');
    } else {
      document.getElementById('billing-monthly-empty').classList.remove('hidden');
      document.getElementById('billing-aircraft-empty').classList.remove('hidden');
      document.getElementById('billing-flights-empty').classList.remove('hidden');
    }
    document.getElementById('billing-ground-empty').classList.toggle('hidden', groundSessions.length > 0);

    // Calculate flight totals
    var totalRentalHours = 0, totalRentalCost = 0, totalDualHours = 0, totalInstructionCost = 0;
    var monthlyData = {};
    var aircraftData = {};

    flights.forEach(function(f) {
      var hobbsHrs = (f.hobbs_start != null && f.hobbs_end != null) ? parseFloat(f.hobbs_end) - parseFloat(f.hobbs_start) : 0;
      var isDual = f.booking_type === 'dual' || f.booking_type === 'ground';

      // Instruction hours: for ground sessions use scheduled duration, else use Hobbs delta
      var instrHrs = 0;
      if (isDual) {
        if (hobbsHrs > 0) {
          instrHrs = hobbsHrs;
        } else if (f.start_time && f.end_time) {
          instrHrs = Math.max(0, (new Date(f.end_time) - new Date(f.start_time)) / 3600000);
        }
      }

      var aircraftCharge = f.aircraft_charge_amount != null ? parseFloat(f.aircraft_charge_amount) : hobbsHrs * parseFloat(f.aircraft_rate || 0);
      var instrCharge = isDual ? (f.instruction_charge_amount != null ? parseFloat(f.instruction_charge_amount) : instrHrs * parseFloat(f.instructor_rate || 0)) : 0;

      totalRentalHours += hobbsHrs;
      totalRentalCost += aircraftCharge;
      if (isDual) { totalDualHours += instrHrs; totalInstructionCost += instrCharge; }

      // Monthly grouping
      var d = new Date(f.start_time);
      var monthKey = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
      var monthLabel = d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      if (!monthlyData[monthKey]) monthlyData[monthKey] = { label: monthLabel, hobbsHrs: 0, acCharge: 0, instrHrs: 0, instrCharge: 0 };
      monthlyData[monthKey].hobbsHrs += hobbsHrs;
      monthlyData[monthKey].acCharge += aircraftCharge;
      if (isDual) { monthlyData[monthKey].instrHrs += instrHrs; monthlyData[monthKey].instrCharge += instrCharge; }

      // Aircraft grouping
      var acKey = f.aircraft_id || 'ground';
      if (!aircraftData[acKey]) aircraftData[acKey] = { tail: f.tail_number || 'Ground', model: f.make_model || '', rate: parseFloat(f.aircraft_rate || 0), hobbsHrs: 0, acCharge: 0, instrHrs: 0, instrCharge: 0 };
      aircraftData[acKey].hobbsHrs += hobbsHrs;
      aircraftData[acKey].acCharge += aircraftCharge;
      if (isDual) { aircraftData[acKey].instrHrs += instrHrs; aircraftData[acKey].instrCharge += instrCharge; }
    });

    // Add ground session instruction costs to totals
    var totalGroundHours = 0, totalGroundCost = 0;
    groundSessions.forEach(function(gs) {
      totalGroundHours += parseFloat(gs.ground_hours || 0);
      totalGroundCost += parseFloat(gs.instruction_charge_amount || 0);
      totalInstructionCost += parseFloat(gs.instruction_charge_amount || 0);
    });

    if (groundSessions.length > 0) {
      document.getElementById('billing-ground-empty').classList.add('hidden');
    }

    // Stats (includes ground session instruction costs)
    document.getElementById('billing-stats').innerHTML =
      '<div class="stat-card"><div class="stat-label">Total Flights</div><div class="stat-value">' + flights.length + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">Flight Hours</div><div class="stat-value" style="color:var(--sky)">' + totalRentalHours.toFixed(1) + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">Rental Costs</div><div class="stat-value" style="color:var(--amber)">$' + totalRentalCost.toFixed(0) + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">Instruction Costs</div><div class="stat-value" style="color:var(--green)">$' + totalInstructionCost.toFixed(0) + '</div></div>' +
      (groundSessions.length > 0 ? '<div class="stat-card"><div class="stat-label">Ground Sessions</div><div class="stat-value" style="color:var(--purple, #a78bfa)">' + groundSessions.length + '</div></div>' : '');

    // Monthly breakdown
    var months = Object.keys(monthlyData).sort().reverse();
    document.getElementById('billing-monthly-table').innerHTML = months.map(function(k) {
      var m = monthlyData[k];
      var tot = m.acCharge + m.instrCharge;
      return '<tr><td style="font-weight:600">' + m.label + '</td>' +
        '<td>' + m.hobbsHrs.toFixed(1) + '</td>' +
        '<td style="color:var(--sky)">$' + m.acCharge.toFixed(0) + '</td>' +
        '<td>' + m.instrHrs.toFixed(1) + '</td>' +
        '<td style="color:var(--amber)">$' + m.instrCharge.toFixed(0) + '</td>' +
        '<td style="font-weight:600;color:var(--green)">$' + tot.toFixed(0) + '</td></tr>';
    }).join('');

    // Aircraft breakdown
    var acKeys = Object.keys(aircraftData);
    document.getElementById('billing-aircraft-table').innerHTML = acKeys.map(function(k) {
      var a = aircraftData[k];
      var tot = a.acCharge + a.instrCharge;
      return '<tr><td style="font-weight:600">' + escHtml(a.tail) + ' <span style="color:var(--gray-500);font-size:0.8rem">' + escHtml(a.model) + '</span></td>' +
        '<td>' + (a.rate > 0 ? '$' + a.rate.toFixed(0) + '/hr' : '<span style="color:var(--gray-500)">—</span>') + '</td>' +
        '<td>' + a.hobbsHrs.toFixed(1) + '</td>' +
        '<td style="color:var(--sky)">$' + a.acCharge.toFixed(0) + '</td>' +
        '<td>' + a.instrHrs.toFixed(1) + '</td>' +
        '<td style="color:var(--amber)">$' + a.instrCharge.toFixed(0) + '</td>' +
        '<td style="font-weight:600;color:var(--green)">$' + tot.toFixed(0) + '</td></tr>';
    }).join('');

    // Show/hide Actions column for admin/owner
    var canEditBilling = ['owner','admin'].includes(currentUser.role);
    var actThF = document.getElementById('billing-flights-actions-th');
    if (actThF) actThF.classList.toggle('hidden', !canEditBilling);
    if (actThF && canEditBilling) actThF.textContent = 'Actions';

    // Individual flights (now includes Instructor column)
    document.getElementById('billing-flights-table').innerHTML = flights.map(function(f) {
      var hrs = (f.hobbs_start != null && f.hobbs_end != null) ? parseFloat(f.hobbs_end) - parseFloat(f.hobbs_start) : 0;
      var rentalCost = f.aircraft_charge_amount != null ? parseFloat(f.aircraft_charge_amount) : hrs * parseFloat(f.aircraft_rate || 0);
      var instrCost = f.booking_type === 'dual' ? (f.instruction_charge_amount != null ? parseFloat(f.instruction_charge_amount) : hrs * parseFloat(f.instructor_rate || 0)) : 0;
      var total = rentalCost + instrCost;
      var d = new Date(f.start_time);
      var dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      var typeTag = f.booking_type === 'dual' ? '<span class="tag tag-sky">Dual</span>' : '<span class="tag tag-green">Solo</span>';
      var dualHrsStr = (f.booking_type === 'dual' && f.dual_instruction_hours != null) ? parseFloat(f.dual_instruction_hours).toFixed(1) + ' hrs' : (f.booking_type === 'dual' ? hrs.toFixed(1) + ' hrs' : '—');
      var actionTd = canEditBilling
        ? '<td style="white-space:nowrap"><button class="btn btn-secondary btn-sm" style="font-size:0.72rem;padding:2px 8px;margin-right:4px" onclick=\'openEditBillingFlightModal(' + JSON.stringify(f.id) + ')\'>Edit</button>' +
          '<button class="btn btn-sm" style="font-size:0.72rem;padding:2px 8px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick=\'confirmDeleteBillingFlight(' + JSON.stringify(f.id) + ', ' + JSON.stringify(dateStr) + ')\'>Delete</button></td>'
        : '';
      return '<tr><td>' + dateStr + '</td>' +
        '<td style="font-weight:600">' + escHtml(f.tail_number || '—') + '</td>' +
        '<td style="font-size:0.82rem;color:var(--gray-400)">' + escHtml(f.instructor_name || '—') + '</td>' +
        '<td>' + typeTag + '</td>' +
        '<td>' + hrs.toFixed(1) + '</td>' +
        '<td style="color:var(--gray-300);font-size:0.82rem">' + dualHrsStr + '</td>' +
        '<td style="color:var(--sky)">$' + rentalCost.toFixed(0) + '</td>' +
        '<td style="color:var(--amber)">' + (instrCost > 0 ? '$' + instrCost.toFixed(0) : '—') + '</td>' +
        '<td style="font-weight:600;color:var(--green)">$' + total.toFixed(0) + '</td>' +
        actionTd + '</tr>';
    }).join('');

    // Show/hide Actions column for ground sessions
    var actThG = document.getElementById('billing-ground-actions-th');
    if (actThG) actThG.classList.toggle('hidden', !canEditBilling);
    if (actThG && canEditBilling) actThG.textContent = 'Actions';

    // Ground sessions table
    document.getElementById('billing-ground-table').innerHTML = groundSessions.map(function(gs) {
      var dateStr = String(gs.session_date).slice(0,10);
      var d = new Date(dateStr + 'T12:00:00');
      var dateLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      var charge = parseFloat(gs.instruction_charge_amount || 0);
      var actionTd = canEditBilling
        ? '<td><button class="btn btn-sm" style="font-size:0.72rem;padding:2px 8px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick=\'confirmDeleteGroundSession(' + JSON.stringify(gs.id) + ', ' + JSON.stringify(dateLabel) + ')\'>Delete</button></td>'
        : '';
      return '<tr>' +
        '<td style="color:var(--gray-300)">' + dateLabel + '</td>' +
        '<td style="font-size:0.82rem;color:var(--gray-400)">' + escHtml(gs.instructor_name || '—') + '</td>' +
        '<td><span class="tag" style="background:rgba(167,139,250,0.15);color:#a78bfa;border:1px solid rgba(167,139,250,0.3);">Ground</span></td>' +
        '<td style="color:var(--amber)">' + parseFloat(gs.ground_hours || 0).toFixed(1) + '</td>' +
        '<td style="color:var(--gray-500)">$0</td>' +
        '<td style="color:var(--amber)">$' + charge.toFixed(0) + '</td>' +
        '<td style="font-weight:600;color:var(--green)">$' + charge.toFixed(0) + '</td>' +
        actionTd + '</tr>';
    }).join('');

  } catch (err) {
    detailEl.innerHTML = '<div style="color:var(--red);padding:2rem">Failed to load billing data: ' + escHtml(err.error || err.message || 'Unknown error') + '</div>';
  }
}

// ─── BILLING EDIT/DELETE (admin/owner) ────────────────────

function openEditBillingFlightModal(id) {
  var f = (currentBillingFlights || []).find(function(x) { return x.id === id; });
  if (!f) { showToast('Flight data not found — reload the page', 'error'); return; }
  document.getElementById('edit-billing-flight-id').value = id;
  var d = new Date(f.start_time);
  var dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  var infoEl = document.getElementById('edit-billing-flight-info');
  if (infoEl) infoEl.textContent = (f.tail_number || '') + '  ·  ' + dateStr + (f.instructor_name ? '  ·  Instr: ' + f.instructor_name : '');
  var hrs = (f.hobbs_start != null && f.hobbs_end != null) ? parseFloat(f.hobbs_end) - parseFloat(f.hobbs_start) : 0;
  var rentalCost = f.aircraft_charge_amount != null ? parseFloat(f.aircraft_charge_amount) : hrs * parseFloat(f.aircraft_rate || 0);
  var instrCost = f.instruction_charge_amount != null ? parseFloat(f.instruction_charge_amount) : (f.booking_type === 'dual' ? hrs * parseFloat(f.instructor_rate || 0) : 0);
  document.getElementById('edit-billing-flight-ac-charge').value = rentalCost.toFixed(2);
  document.getElementById('edit-billing-flight-instr-charge').value = instrCost.toFixed(2);
  document.getElementById('edit-billing-flight-dual-hrs').value = f.dual_instruction_hours != null ? parseFloat(f.dual_instruction_hours).toFixed(1) : hrs.toFixed(1);
  // Use flight_date from billing flight log or fallback to start_time date
  var flightDate = f.flight_date ? String(f.flight_date).slice(0,10) : d.toISOString().slice(0,10);
  document.getElementById('edit-billing-flight-date').value = flightDate;
  var errEl = document.getElementById('edit-billing-flight-error');
  if (errEl) errEl.classList.add('hidden');
  document.getElementById('edit-billing-flight-modal').classList.remove('hidden');
}

function closeEditBillingFlightModal() {
  document.getElementById('edit-billing-flight-modal').classList.add('hidden');
}

async function saveEditBillingFlight() {
  var errEl = document.getElementById('edit-billing-flight-error');
  if (errEl) errEl.classList.add('hidden');
  var id = document.getElementById('edit-billing-flight-id').value;
  var body = {
    aircraft_charge_amount: document.getElementById('edit-billing-flight-ac-charge').value !== '' ? parseFloat(document.getElementById('edit-billing-flight-ac-charge').value) : null,
    instruction_charge_amount: document.getElementById('edit-billing-flight-instr-charge').value !== '' ? parseFloat(document.getElementById('edit-billing-flight-instr-charge').value) : null,
    dual_instruction_hours: document.getElementById('edit-billing-flight-dual-hrs').value !== '' ? parseFloat(document.getElementById('edit-billing-flight-dual-hrs').value) : null,
    flight_date: document.getElementById('edit-billing-flight-date').value || null,
  };
  try {
    await api('/api/billing/flights/' + id, { method: 'PUT', body: JSON.stringify(body) });
    showToast('Billing entry updated', 'success');
    closeEditBillingFlightModal();
    if (currentBillingStudentId != null) await loadBillingForStudent(currentBillingStudentId);
    else await loadBilling();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to update billing entry.'; errEl.classList.remove('hidden'); }
  }
}

async function confirmDeleteBillingFlight(id, dateStr) {
  if (!confirm('Delete flight billing entry from ' + dateStr + '? This removes the charge record. Cannot be undone.')) return;
  try {
    await api('/api/booking-history/flights/' + id, { method: 'DELETE' });
    showToast('Flight billing entry deleted', 'success');
    if (currentBillingStudentId != null) await loadBillingForStudent(currentBillingStudentId);
    else await loadBilling();
  } catch(e) {
    showToast(e.error || 'Failed to delete entry', 'error');
  }
}

async function confirmDeleteGroundSession(id, dateStr) {
  if (!confirm('Delete ground session from ' + dateStr + '? This cannot be undone.')) return;
  try {
    await api('/api/booking-history/ground-sessions/' + id, { method: 'DELETE' });
    showToast('Ground session deleted', 'success');
    if (currentBillingStudentId != null) await loadBillingForStudent(currentBillingStudentId);
    else await loadBilling();
  } catch(e) {
    showToast(e.error || 'Failed to delete ground session', 'error');
  }
}

// ─── INIT ───
// (modal HTML injected below in body)
async function init() {
  // If a password-reset token is present in the URL, the checkResetToken()
  // IIFE already called showScreen('reset'). Don't override it.
  if (resetToken) return;

  if (token) {
    try {
      const data = await api('/api/auth/me');
      currentUser = data.user;
      enterApp();
    } catch {
      token = null;
      localStorage.removeItem('fs_token');
      showScreen('login');
    }
  } else {
    showScreen('login');
  }
}




// ─── FLIGHT LOG PAGE ─────────────────────────────────────
async function loadFlightLog() {
  // Populate filter dropdowns
  const aircraftSel = document.getElementById('flog-aircraft-filter');
  const personSel = document.getElementById('flog-person-filter');

  if (aircraftSel.options.length <= 1) {
    allAircraft.forEach(a => {
      aircraftSel.innerHTML += `<option value="${a.id}">${a.tail_number} - ${a.make_model}</option>`;
    });
  }
  if (personSel.options.length <= 1) {
    allUsers.forEach(u => {
      personSel.innerHTML += `<option value="${u.id}">${u.name} (${u.role})</option>`;
    });
  }

  const params = new URLSearchParams();
  const acId = aircraftSel.value;
  const perId = personSel.value;
  const startD = document.getElementById('flog-start-date').value;
  const endD = document.getElementById('flog-end-date').value;
  if (acId) params.set('aircraft_id', acId);
  if (perId) params.set('person_id', perId);
  if (startD) params.set('start_date', startD);
  if (endD) params.set('end_date', endD);

  try {
    const logs = await api(`/api/flight-logs?${params}`);
    const tbody = document.getElementById('flog-table-body');
    const emptyEl = document.getElementById('flog-empty');

    if (!logs.length) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    // Show/hide actions column for admin/owner
    const canEditFlog = currentUser && ['owner', 'admin'].includes(currentUser.role);
    const flogActTh = document.getElementById('flog-actions-th');
    if (flogActTh) { flogActTh.classList.toggle('hidden', !canEditFlog); if (canEditFlog) flogActTh.textContent = 'Actions'; }

    // Cache for modal pre-population
    window._flogCache = window._flogCache || {};
    logs.forEach(l => { window._flogCache[l.id] = l; });

    tbody.innerHTML = logs.map(l => {
      const typeLabel = l.booking_type === 'student_solo' ? '✈ Solo' :
                        l.booking_type === 'instructor_solo' ? '✈ Instructor Solo' : 'Dual';
      const typeColor = l.booking_type !== 'dual' ? 'color:var(--amber)' : '';
      const fmtVal = (v) => v != null ? parseFloat(v).toFixed(1) : '—';
      const fmtDelta = (v) => v != null ? `<strong>${parseFloat(v).toFixed(1)}</strong>` : '—';
      const dateStr = String(l.flight_date).slice(0,10);
      const actionTd = canEditFlog
        ? `<td style="white-space:nowrap"><button class="btn btn-secondary btn-sm" style="font-size:0.72rem;padding:2px 7px;margin-right:3px" onclick="openEditFlogModal(${l.id})">✏</button><button class="btn btn-sm" style="font-size:0.72rem;padding:2px 7px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmDeleteFlogEntry(${l.id}, '${dateStr}')">🗑</button></td>`
        : '';
      return `<tr>
        <td style="white-space:nowrap">${dateStr}</td>
        <td><strong>${escHtml(l.tail_number)}</strong></td>
        <td style="${typeColor};font-size:0.85rem">${typeLabel}</td>
        <td>${escHtml(l.student_name || '—')}</td>
        <td>${escHtml(l.instructor_name || '—')}</td>
        <td style="text-align:right;font-family:'Space Grotesk'">${fmtVal(l.hobbs_start)}</td>
        <td style="text-align:right;font-family:'Space Grotesk'">${fmtVal(l.hobbs_end)}</td>
        <td style="text-align:right;font-family:'Space Grotesk';color:var(--sky)">${fmtDelta(l.hobbs_delta)}</td>
        <td style="text-align:right;font-family:'Space Grotesk'">${fmtVal(l.tach_start)}</td>
        <td style="text-align:right;font-family:'Space Grotesk'">${fmtVal(l.tach_end)}</td>
        <td style="text-align:right;font-family:'Space Grotesk';color:var(--sky)">${fmtDelta(l.tach_delta)}</td>
        <td style="font-size:0.85rem;color:var(--gray-400)">${escHtml(l.submitted_by_name || '—')}</td>
        ${actionTd}
      </tr>`;
    }).join('');

    // Render mobile card view
    const cardsEl = document.getElementById('flog-cards');
    if (logs.length === 0) {
      cardsEl.innerHTML = '<div class="flog-empty-card">No flight log entries yet.</div>';
    } else {
      cardsEl.innerHTML = logs.map(l => {
        const typeLabel = l.booking_type === 'student_solo' ? 'Solo' :
                          l.booking_type === 'instructor_solo' ? 'Instr. Solo' : 'Dual';
        const typeClass = l.booking_type !== 'dual' ? 'solo' : 'dual';
        const fmtVal = (v) => v != null ? parseFloat(v).toFixed(1) : '—';
        const fmtDelta = (v) => v != null ? parseFloat(v).toFixed(1) : '—';
        const dateStr = String(l.flight_date).slice(0,10);
        const peopleParts = [];
        if (l.student_name) peopleParts.push(`<span>Stu: ${escHtml(l.student_name)}</span>`);
        if (l.instructor_name) peopleParts.push(`<span>Instr: ${escHtml(l.instructor_name)}</span>`);
        const actionsHtml = canEditFlog
          ? `<div class="flog-card-actions">
              <button class="btn btn-secondary btn-sm" style="font-size:0.72rem;padding:2px 8px" onclick="openEditFlogModal(${l.id})">✏ Edit</button>
              <button class="btn btn-sm" style="font-size:0.72rem;padding:2px 8px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmDeleteFlogEntry(${l.id}, '${dateStr}')">🗑 Delete</button>
            </div>`
          : '';
        return `<div class="flog-card" onclick="toggleFlogCard(this)">
  <div class="flog-card-hdr">
    <span class="flog-card-date">${dateStr}</span>
    <span style="display:flex;align-items:center;gap:0.5rem">
      <span class="flog-card-aircraft">${escHtml(l.tail_number)}</span>
      <span class="flog-card-type ${typeClass}">${typeLabel}</span>
    </span>
  </div>
  <div class="flog-card-metrics">
    <div class="flog-card-metric">
      <div class="flog-card-metric-lbl">Hobbs Δ</div>
      <div class="flog-card-metric-val highlight">${fmtDelta(l.hobbs_delta)}</div>
    </div>
    <div class="flog-card-metric">
      <div class="flog-card-metric-lbl">Tach Δ</div>
      <div class="flog-card-metric-val highlight">${fmtDelta(l.tach_delta)}</div>
    </div>
    <div class="flog-card-metric">
      <div class="flog-card-metric-lbl">Hobbs S</div>
      <div class="flog-card-metric-val">${fmtVal(l.hobbs_start)}</div>
    </div>
    <div class="flog-card-metric">
      <div class="flog-card-metric-lbl">Hobbs E</div>
      <div class="flog-card-metric-val">${fmtVal(l.hobbs_end)}</div>
    </div>
  </div>
  ${peopleParts.length ? `<div class="flog-card-people">${peopleParts.join('')}</div>` : ''}
  ${actionsHtml}
  <div class="flog-card-expand">
    <span class="flog-card-expand-icon">&#9660;</span>
    <span>View details</span>
  </div>
  <div class="flog-card-detail">
    <div class="flog-card-detail-row"><span>Hobbs Start</span><span>${fmtVal(l.hobbs_start)}</span></div>
    <div class="flog-card-detail-row"><span>Hobbs End</span><span>${fmtVal(l.hobbs_end)}</span></div>
    <div class="flog-card-detail-row"><span class="detail-highlight">Hobbs Δ</span><span class="detail-highlight">${fmtDelta(l.hobbs_delta)} hrs</span></div>
    <div class="flog-card-detail-row"><span>Tach Start</span><span>${fmtVal(l.tach_start)}</span></div>
    <div class="flog-card-detail-row"><span>Tach End</span><span>${fmtVal(l.tach_end)}</span></div>
    <div class="flog-card-detail-row"><span class="detail-highlight">Tach Δ</span><span class="detail-highlight">${fmtDelta(l.tach_delta)} hrs</span></div>
    <div class="flog-card-detail-row"><span>Submitted by</span><span>${escHtml(l.submitted_by_name || '—')}</span></div>
  </div>
</div>`;
      }).join('');
    }
  } catch (err) {
    console.error('Flight log load error:', err);
  }
}

function toggleFlogCard(card) {
  card.classList.toggle('expanded');
}

function clearFlightLogFilters() {
  document.getElementById('flog-aircraft-filter').value = '';
  document.getElementById('flog-person-filter').value = '';
  document.getElementById('flog-start-date').value = '';
  document.getElementById('flog-end-date').value = '';
  loadFlightLog();
}

// ─── FLIGHT LOG EDIT/DELETE (admin/owner) ─────────────────

function openEditFlogModal(id) {
  var l = (window._flogCache || {})[id];
  if (!l) { showToast('Entry data not found — reload the page', 'error'); return; }
  document.getElementById('edit-flog-id').value = id;
  document.getElementById('edit-flog-date').value = l.flight_date ? String(l.flight_date).slice(0,10) : '';
  document.getElementById('edit-flog-dual-hrs').value = l.dual_instruction_hours != null ? parseFloat(l.dual_instruction_hours).toFixed(1) : '';
  document.getElementById('edit-flog-hobbs-start').value = l.hobbs_start != null ? parseFloat(l.hobbs_start).toFixed(1) : '';
  document.getElementById('edit-flog-hobbs-end').value = l.hobbs_end != null ? parseFloat(l.hobbs_end).toFixed(1) : '';
  document.getElementById('edit-flog-tach-start').value = l.tach_start != null ? parseFloat(l.tach_start).toFixed(1) : '';
  document.getElementById('edit-flog-tach-end').value = l.tach_end != null ? parseFloat(l.tach_end).toFixed(1) : '';
  document.getElementById('edit-flog-notes').value = l.notes || '';
  var errEl = document.getElementById('edit-flog-error');
  if (errEl) errEl.classList.add('hidden');
  document.getElementById('edit-flog-modal').classList.remove('hidden');
}

function closeEditFlogModal() {
  document.getElementById('edit-flog-modal').classList.add('hidden');
}

async function saveEditFlog() {
  var errEl = document.getElementById('edit-flog-error');
  if (errEl) errEl.classList.add('hidden');
  var id = document.getElementById('edit-flog-id').value;
  var body = {
    flight_date: document.getElementById('edit-flog-date').value || null,
    dual_instruction_hours: document.getElementById('edit-flog-dual-hrs').value !== '' ? parseFloat(document.getElementById('edit-flog-dual-hrs').value) : null,
    hobbs_start: document.getElementById('edit-flog-hobbs-start').value !== '' ? parseFloat(document.getElementById('edit-flog-hobbs-start').value) : null,
    hobbs_end: document.getElementById('edit-flog-hobbs-end').value !== '' ? parseFloat(document.getElementById('edit-flog-hobbs-end').value) : null,
    tach_start: document.getElementById('edit-flog-tach-start').value !== '' ? parseFloat(document.getElementById('edit-flog-tach-start').value) : null,
    tach_end: document.getElementById('edit-flog-tach-end').value !== '' ? parseFloat(document.getElementById('edit-flog-tach-end').value) : null,
    notes: document.getElementById('edit-flog-notes').value.trim() || null,
  };
  try {
    await api('/api/flight-logs/' + id, { method: 'PUT', body: JSON.stringify(body) });
    showToast('Flight log updated', 'success');
    closeEditFlogModal();
    await loadFlightLog();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to update entry.'; errEl.classList.remove('hidden'); }
  }
}

async function confirmDeleteFlogEntry(id, dateStr) {
  if (!confirm('Delete flight log entry from ' + dateStr + '? This cannot be undone.')) return;
  try {
    await api('/api/flight-logs/' + id, { method: 'DELETE' });
    showToast('Flight log entry deleted', 'success');
    await loadFlightLog();
  } catch(e) {
    showToast(e.error || 'Failed to delete entry', 'error');
  }
}

// ─── FLIGHT LOG: Aircraft Current Hours Panel ────────────
async function loadFlogAircraftHours() {
  const wrap = document.getElementById('flog-aircraft-hours-wrap');
  const list = document.getElementById('flog-aircraft-hours-list');
  if (!wrap || !list) return;

  // Only admin/owner sees this panel
  if (!currentUser || !['owner','admin'].includes(currentUser.role)) {
    wrap.classList.add('hidden');
    return;
  }

  // Use allAircraft which is already loaded at app init
  if (!allAircraft || allAircraft.length === 0) {
    wrap.classList.add('hidden');
    return;
  }

  wrap.classList.remove('hidden');

  list.innerHTML = allAircraft.map(a => {
    const hobbs = parseFloat(a.total_hobbs_hours || 0).toFixed(1);
    const tach = parseFloat(a.total_tach_hours || 0).toFixed(1);
    return `<div style="background:var(--gray-800);border-radius:8px;padding:0.75rem 1rem;min-width:180px;flex:1;max-width:260px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem">
        <span style="font-weight:600;font-size:0.85rem;color:var(--gray-200)">${escHtml(a.tail_number)}</span>
        <button onclick="promptEditAircraftHours(${a.id},'${escHtml(a.tail_number)}',${hobbs},${tach})" style="background:none;border:none;cursor:pointer;font-size:0.85rem;color:var(--gray-400)" title="Edit hours">&#9998;</button>
      </div>
      <div style="display:flex;gap:1rem;font-size:0.8rem;color:var(--gray-400)">
        <span>Hobbs: <strong style="color:var(--gray-200)">${hobbs}</strong></span>
        <span>Tach: <strong style="color:var(--gray-200)">${tach}</strong></span>
      </div>
    </div>`;
  }).join('');
}

function promptEditAircraftHours(aircraftId, tailNumber, currentHobbs, currentTach) {
  const newHobbs = prompt('New Hobbs hours for ' + tailNumber + '\\nCurrent: ' + currentHobbs, currentHobbs);
  if (newHobbs === null) return;
  const newTach = prompt('New Tach hours for ' + tailNumber + '\\nCurrent: ' + currentTach, currentTach);
  if (newTach === null) return;

  const h = parseFloat(newHobbs);
  const t = parseFloat(newTach);
  if (isNaN(h) || isNaN(t)) { showToast('Invalid number entered', 'error'); return; }
  if (h === currentHobbs && t === currentTach) return;

  const body = {};
  if (h !== currentHobbs) body.hobbs = h;
  if (t !== currentTach) body.tach = t;
  body.note = 'Manual edit from Flight Log page';

  api('/api/aircraft/' + aircraftId + '/hobbs', { method: 'PATCH', body: JSON.stringify(body) })
    .then(function() {
      showToast('Hours updated for ' + tailNumber, 'success');
      // Refresh allAircraft cache and re-render panel
      api('/api/aircraft').then(function(data) { allAircraft = data; loadFlogAircraftHours(); });
    })
    .catch(function(e) { showToast(e.error || 'Failed to update hours', 'error'); });
}

// ─── BOOKING HISTORY PAGE ─────────────────────────────────
let _historyPeriod = 'month';
let _historySortAsc = false; // default: newest first (DESC)

function setHistoryPeriod(period) {
  _historyPeriod = period;
  document.querySelectorAll('.history-period-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.period === period);
  });
  // Show date picker for day filtering
  const dateWrap = document.getElementById('history-date-picker-wrap');
  if (dateWrap) {
    dateWrap.style.display = (period === 'day') ? '' : 'none';
    if (period === 'day') {
      const picker = document.getElementById('history-date-picker');
      if (!picker.value) picker.value = new Date().toISOString().slice(0, 10);
    }
  }
  loadHistoryLegacyPage();
}

function toggleHistoryDateSort() {
  _historySortAsc = !_historySortAsc;
  const icon = document.getElementById('history-sort-icon');
  if (icon) icon.innerHTML = _historySortAsc ? '&#9650;' : '&#9660;';
  loadHistoryLegacyPage();
}

async function loadHistoryLegacyPage() {
  // Populate filter dropdowns once
  const acSel = document.getElementById('history-aircraft-filter');
  const stuSel = document.getElementById('history-student-filter');
  const instSel = document.getElementById('history-instructor-filter');

  if (acSel.options.length <= 1 && allAircraft && allAircraft.length > 0) {
    acSel.innerHTML = '<option value="">All Aircraft</option>' +
      allAircraft.map(a => `<option value="${a.id}">${escHtml(a.tail_number)} — ${escHtml(a.make_model)}</option>`).join('');
  }
  if (stuSel.options.length <= 1 && allUsers && allUsers.length > 0) {
    const students = allUsers.filter(u => u.role === 'student');
    stuSel.innerHTML = '<option value="">All Students</option>' +
      students.map(u => `<option value="${u.id}">${escHtml(u.name)}</option>`).join('');
  }
  // Only show instructor filter to non-instructors
  const instWrap = document.getElementById('history-instructor-filter-wrap');
  const isInstructor = currentUser && currentUser.role === 'instructor';
  if (instWrap) instWrap.classList.toggle('hidden', isInstructor);
  if (!isInstructor && instSel.options.length <= 1 && allUsers && allUsers.length > 0) {
    const instructors = allUsers.filter(u => u.role === 'instructor' || u.role === 'admin' || u.role === 'owner');
    instSel.innerHTML = '<option value="">All Instructors</option>' +
      instructors.map(u => `<option value="${u.id}">${escHtml(u.name)}</option>`).join('');
  }

  // Show/hide date picker
  const dateWrap = document.getElementById('history-date-picker-wrap');
  if (dateWrap) dateWrap.style.display = (_historyPeriod === 'day') ? '' : 'none';

  // Build query
  const params = new URLSearchParams();
  params.set('period', _historyPeriod);
  if (_historyPeriod === 'day') {
    const specificDate = document.getElementById('history-date-picker').value;
    if (specificDate) params.set('specific_date', specificDate);
  }
  if (_historySortAsc) params.set('sort', 'asc');
  const acId = acSel.value;
  const stuId = stuSel.value;
  const instId = instSel.value;
  if (acId) params.set('aircraft_id', acId);
  if (stuId) params.set('student_id', stuId);
  if (instId) params.set('instructor_id', instId);
  const statusVal = document.getElementById('history-status-filter')?.value || 'all';
  if (statusVal && statusVal !== 'all') params.set('status', statusVal);
  else params.set('status', 'all');

  try {
    const data = await api(`/api/booking-history?${params}`);
    const { rows, totals } = data;

    // Render stats bar
    const statsEl = document.getElementById('history-stats');
    const fmtHrs = v => parseFloat(v || 0).toFixed(1);
    const fmtMoney = v => '$' + parseFloat(v || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    statsEl.innerHTML = [
      { label: 'Bookings', value: totals.count, color: 'var(--sky)' },
      { label: 'Hobbs Hours', value: fmtHrs(totals.hobbs_hours), color: 'var(--sky)' },
      { label: 'Tach Hours', value: fmtHrs(totals.tach_hours), color: 'var(--sky)' },
      { label: 'Instr Hours', value: fmtHrs(totals.instruction_hours), color: 'var(--amber)' },
      { label: 'Revenue', value: fmtMoney(totals.revenue), color: 'var(--green,#22c55e)' }
    ].map(s => `
      <div class="table-card" style="padding:1rem 1.25rem;text-align:center">
        <div style="font-size:1.5rem;font-weight:700;color:${s.color};font-family:'Space Grotesk',sans-serif">${s.value}</div>
        <div style="font-size:0.75rem;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.5px;margin-top:0.25rem">${s.label}</div>
      </div>`).join('');

    // Render table
    const tbody = document.getElementById('history-table-body');
    const emptyEl = document.getElementById('history-empty');

    if (!rows.length) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    const fmtVal = v => v != null ? parseFloat(v).toFixed(1) : '—';
    const fmtDollar = v => v != null ? '$' + parseFloat(v).toFixed(2) : '—';

    // Show/hide actions column for admin/owner
    const canEditHistory = currentUser && ['owner', 'admin'].includes(currentUser.role);
    const histActTh = document.getElementById('history-actions-th');
    if (histActTh) { histActTh.classList.toggle('hidden', !canEditHistory); if (canEditHistory) histActTh.textContent = 'Actions'; }

    // Cache rows for modal pre-population
    window._historyRowsCache = window._historyRowsCache || {};
    rows.forEach(r => { window._historyRowsCache[r.id] = r; });

    tbody.innerHTML = rows.map(r => {
      const dateStr = String(r.flight_date).slice(0, 10);
      const isGround = !r.aircraft_charge_amount && !r.hobbs_delta;
      const actionTd = canEditHistory
        ? `<td style="white-space:nowrap"><button class="btn btn-secondary btn-sm" style="font-size:0.72rem;padding:2px 7px;margin-right:3px" onclick="openEditHistoryModal(${r.id})">✏</button><button class="btn btn-sm" style="font-size:0.72rem;padding:2px 7px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmDeleteHistoryEntry(${r.id}, '${dateStr}')">🗑</button></td>`
        : '';
      return `<tr>
        <td style="white-space:nowrap">${dateStr}</td>
        <td>${r.student_name ? escHtml(r.student_name) : '<span style="color:var(--gray-500)">—</span>'}</td>
        <td>${r.instructor_name ? escHtml(r.instructor_name) : '<span style="color:var(--gray-500)">—</span>'}</td>
        <td><strong>${escHtml(r.tail_number || '—')}</strong> <span style="font-size:0.78rem;color:var(--gray-500)">${escHtml(r.make_model || '')}</span></td>
        <td>${r.status === 'cancelled' ? '<span class="tag" style="background:rgba(239,68,68,0.15);color:#F87171">Cancelled</span>' + (r.cancellation_reason ? `<div style="font-size:0.75rem;color:#F87171;margin-top:0.2rem">${escHtml(r.cancellation_reason)}</div>` : '<div style="font-size:0.75rem;color:#F87171;margin-top:0.2rem">—</div>') : isGround ? '<span class="tag" style="background:rgba(59,130,246,0.15);color:var(--sky)">Ground</span>' : '<span class="tag tag-completed">Completed</span>'}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif">${isGround ? '<span style="color:var(--gray-500)">—</span>' : fmtVal(r.hobbs_delta)}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif">${isGround ? '<span style="color:var(--gray-500)">—</span>' : fmtVal(r.tach_delta)}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif">${fmtVal(r.dual_instruction_hours)}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif">${fmtDollar(r.aircraft_charge_amount)}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif">${fmtDollar(r.instruction_charge_amount)}</td>
        <td style="text-align:right;font-family:'Space Grotesk',sans-serif;font-weight:700;color:var(--sky)">${fmtDollar(r.total_charge > 0 ? r.total_charge : null)}</td>
        ${actionTd}
      </tr>`;
    }).join('');
  } catch (err) {
    console.error('Booking history load error:', err);
  }
}

function clearHistoryFilters() {
  document.getElementById('history-aircraft-filter').value = '';
  document.getElementById('history-student-filter').value = '';
  document.getElementById('history-instructor-filter').value = '';
  document.getElementById('history-date-picker').value = '';
  document.getElementById('history-status-filter').value = 'all';
  _historyPeriod = 'month';
  _historySortAsc = false;
  const icon = document.getElementById('history-sort-icon');
  if (icon) icon.innerHTML = '&#9660;';
  document.querySelectorAll('.history-period-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.period === 'month');
  });
  loadHistoryLegacyPage();
}

// ─── BOOKING HISTORY EDIT/DELETE (admin/owner) ────────────

function openEditHistoryModal(id) {
  var r = (window._historyRowsCache || {})[id];
  if (!r) { showToast('Row data not found — reload the page', 'error'); return; }
  document.getElementById('edit-history-id').value = id;
  document.getElementById('edit-history-date').value = r.flight_date ? String(r.flight_date).slice(0,10) : '';
  document.getElementById('edit-history-dual-hrs').value = r.dual_instruction_hours != null ? parseFloat(r.dual_instruction_hours).toFixed(1) : '';
  document.getElementById('edit-history-hobbs-start').value = r.hobbs_start != null ? parseFloat(r.hobbs_start).toFixed(1) : '';
  document.getElementById('edit-history-hobbs-end').value = r.hobbs_end != null ? parseFloat(r.hobbs_end).toFixed(1) : '';
  document.getElementById('edit-history-tach-start').value = r.tach_start != null ? parseFloat(r.tach_start).toFixed(1) : '';
  document.getElementById('edit-history-tach-end').value = r.tach_end != null ? parseFloat(r.tach_end).toFixed(1) : '';
  document.getElementById('edit-history-ac-charge').value = r.aircraft_charge_amount != null ? parseFloat(r.aircraft_charge_amount).toFixed(2) : '';
  document.getElementById('edit-history-instr-charge').value = r.instruction_charge_amount != null ? parseFloat(r.instruction_charge_amount).toFixed(2) : '';
  var errEl = document.getElementById('edit-history-error');
  if (errEl) errEl.classList.add('hidden');
  document.getElementById('edit-history-modal').classList.remove('hidden');
}

function closeEditHistoryModal() {
  document.getElementById('edit-history-modal').classList.add('hidden');
}

async function saveEditHistory() {
  var errEl = document.getElementById('edit-history-error');
  if (errEl) errEl.classList.add('hidden');
  var id = document.getElementById('edit-history-id').value;
  var body = {
    flight_date: document.getElementById('edit-history-date').value || null,
    dual_instruction_hours: document.getElementById('edit-history-dual-hrs').value !== '' ? parseFloat(document.getElementById('edit-history-dual-hrs').value) : null,
    hobbs_start: document.getElementById('edit-history-hobbs-start').value !== '' ? parseFloat(document.getElementById('edit-history-hobbs-start').value) : null,
    hobbs_end: document.getElementById('edit-history-hobbs-end').value !== '' ? parseFloat(document.getElementById('edit-history-hobbs-end').value) : null,
    tach_start: document.getElementById('edit-history-tach-start').value !== '' ? parseFloat(document.getElementById('edit-history-tach-start').value) : null,
    tach_end: document.getElementById('edit-history-tach-end').value !== '' ? parseFloat(document.getElementById('edit-history-tach-end').value) : null,
    aircraft_charge_amount: document.getElementById('edit-history-ac-charge').value !== '' ? parseFloat(document.getElementById('edit-history-ac-charge').value) : null,
    instruction_charge_amount: document.getElementById('edit-history-instr-charge').value !== '' ? parseFloat(document.getElementById('edit-history-instr-charge').value) : null,
  };
  try {
    await api('/api/flight-logs/' + id, { method: 'PUT', body: JSON.stringify(body) });
    showToast('Booking record updated', 'success');
    closeEditHistoryModal();
    await loadHistoryLegacyPage();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to update record.'; errEl.classList.remove('hidden'); }
  }
}

async function confirmDeleteHistoryEntry(id, dateStr) {
  if (!confirm('Delete this booking record from ' + dateStr + '? This cannot be undone.')) return;
  try {
    await api('/api/booking-history/flights/' + id, { method: 'DELETE' });
    showToast('Booking record deleted', 'success');
    await loadHistoryLegacyPage();
  } catch(e) {
    showToast(e.error || 'Failed to delete record', 'error');
  }
}

// ─── HOURS AUDIT PAGE ─────────────────────────────────────
async function loadHoursAudit() {
  // Populate filter dropdowns
  const aircraftSel = document.getElementById('audit-aircraft-filter');
  const userSel = document.getElementById('audit-user-filter');

  // Only reload dropdowns if they're empty
  if (aircraftSel.options.length <= 1) {
    if (!allAircraft || allAircraft.length === 0) await loadAircraft();
    aircraftSel.innerHTML = '<option value="">All Aircraft</option>' +
      allAircraft.map(a => `<option value="${a.id}">${escHtml(a.tail_number)} — ${escHtml(a.make_model)}</option>`).join('');
  }
  if (userSel.options.length <= 1) {
    if (!allUsers || allUsers.length === 0) await loadUsers();
    const crew = allUsers.filter(u => u.role !== 'student');
    userSel.innerHTML = '<option value="">All Users</option>' +
      crew.map(u => `<option value="${u.id}">${escHtml(u.name)} (${u.role})</option>`).join('');
  }

  // Build query params from filters
  const params = new URLSearchParams();
  const acFilter = aircraftSel.value;
  const usrFilter = userSel.value;
  const startDate = document.getElementById('audit-start-date').value;
  const endDate = document.getElementById('audit-end-date').value;
  if (acFilter) params.set('aircraft_id', acFilter);
  if (usrFilter) params.set('user_id', usrFilter);
  if (startDate) params.set('start_date', startDate);
  if (endDate) params.set('end_date', endDate);

  const tbody = document.getElementById('audit-table-body');
  const emptyEl = document.getElementById('audit-empty');
  tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--gray-500);padding:2rem">Loading…</td></tr>';
  emptyEl.classList.add('hidden');

  try {
    const qs = params.toString();
    const data = await api(`/api/hours-audit${qs ? '?' + qs : ''}`);

    if (!data || data.length === 0) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }

    emptyEl.classList.add('hidden');
    tbody.innerHTML = data.map(h => {
      const dt = new Date(h.created_at);
      const dateStr = dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const timeStr = dt.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
      const oldV = h.old_value != null ? parseFloat(h.old_value).toFixed(1) : '—';
      const newV = h.new_value != null ? parseFloat(h.new_value).toFixed(1) : '—';
      const srcLabel = h.source === 'flight_completion'
        ? '<span class="tag tag-sky" style="font-size:0.7rem">Flight</span>'
        : '<span class="tag tag-amber" style="font-size:0.7rem">Manual</span>';

      return `<tr>
        <td style="white-space:nowrap">${dateStr}<br><span style="color:var(--gray-500);font-size:0.75rem">${timeStr}</span></td>
        <td><strong>${escHtml(h.tail_number)}</strong><br><span style="color:var(--gray-500);font-size:0.75rem">${escHtml(h.make_model)}</span></td>
        <td style="text-transform:capitalize">${escHtml(h.field)}</td>
        <td style="text-align:right;color:var(--gray-400)">${oldV}</td>
        <td style="text-align:center;color:var(--gray-500)">→</td>
        <td style="text-align:right;color:var(--green);font-weight:600">${newV}</td>
        <td>${escHtml(h.changed_by_name || 'System')}</td>
        <td>${srcLabel}</td>
        <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:0.82rem;color:var(--gray-400)">${h.note ? escHtml(h.note) : '—'}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    const msg = err?.detail || err?.error || (err.status === 403 ? 'Access denied — owner/admin only' : 'Failed to load audit data.');
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:var(--red);padding:2rem">${escHtml(msg)}</td></tr>`;
    console.error('[loadHoursAudit] Error:', err);
  }
}

function clearAuditFilters() {
  document.getElementById('audit-aircraft-filter').value = '';
  document.getElementById('audit-user-filter').value = '';
  document.getElementById('audit-start-date').value = '';
  document.getElementById('audit-end-date').value = '';
  loadHoursAudit();
}

// ─── SECTION MANAGER ─────────────────────────────────────

// All known sections, their metadata, and lock status
const SM_ALL_SECTIONS = [
  { id: 'hero',        name: 'Hero',         icon: '🏠', locked: true  },  // locked first
  { id: 'about',       name: 'About',        icon: '📋', locked: false },
  { id: 'programs',    name: 'Programs',     icon: '🎓', locked: false },
  { id: 'fleet',       name: 'Fleet',        icon: '✈️', locked: false },
  { id: 'instructors', name: 'Instructors',  icon: '👤', locked: false },
  { id: 'contact',     name: 'Contact',      icon: '📍', locked: true  },  // locked last
];
const SM_DEFAULT_ORDER = SM_ALL_SECTIONS.map(s => s.id);
// Track runtime state
let smSectionOrder = [...SM_DEFAULT_ORDER];    // current order
let smSectionVisibility = {};                  // id → true/false (missing = visible)
let smDragSrcIdx = null;
let smPendingDeleteId = null;

function smIsVisible(id) {
  return smSectionVisibility[id] !== false;
}

function smGetMeta(id) {
  return SM_ALL_SECTIONS.find(s => s.id === id);
}

function renderSectionManager() {
  const list = document.getElementById('sm-section-list');
  if (!list) return;

  const visibleCount = smSectionOrder.filter(id => smIsVisible(id)).length;
  const badge = document.getElementById('sm-count-badge');
  if (badge) badge.textContent = smSectionOrder.length + ' sections';

  list.innerHTML = smSectionOrder.map((id, idx) => {
    const meta = smGetMeta(id);
    if (!meta) return '';
    const visible = smIsVisible(id);
    const isFirst = idx === 0;
    const isLast = idx === smSectionOrder.length - 1;
    const locked = meta.locked;
    const eyeIcon = visible ? '👁️' : '🙈';
    const eyeTitle = visible ? 'Hide section from live site' : 'Show section on live site';

    return `<li class="sm-section-item${visible ? '' : ' sm-hidden'}"
              draggable="${locked ? 'false' : 'true'}"
              data-sm-id="${id}"
              data-sm-idx="${idx}"
              ondragstart="smDragStart(event,${idx})"
              ondragover="smDragOver(event,${idx})"
              ondragleave="smDragLeave(event)"
              ondrop="smDrop(event,${idx})"
              ondragend="smDragEnd()">
      <span class="sm-drag-handle${locked ? ' locked' : ''}" title="${locked ? 'This section is pinned' : 'Drag to reorder'}">⠿</span>
      <span class="sm-section-icon">${meta.icon}</span>
      <span class="sm-section-name">${meta.name}</span>
      ${locked ? '<span class="sm-lock-icon" title="Pinned">🔒</span>' : ''}
      <button class="sm-btn sm-btn-vis${visible ? '' : ' hidden'}" title="${eyeTitle}" onclick="smToggleVisibility('${id}')">${eyeIcon}</button>
      ${locked ? '' : `<button class="sm-btn sm-btn-del" title="Remove section" onclick="smRequestDelete('${id}')">🗑</button>`}
    </li>`;
  }).join('');
}

function smToggleVisibility(id) {
  smSectionVisibility[id] = !smIsVisible(id);
  renderSectionManager();
  markEditorDirty();
}

function smRequestDelete(id) {
  smPendingDeleteId = id;
  const meta = smGetMeta(id);
  document.getElementById('sm-confirm-title').textContent = `Remove "${meta ? meta.name : id}" section?`;
  document.getElementById('sm-confirm-msg').textContent = 'This section will be removed from your live site. Content is preserved — you can restore it anytime via "+ Add Section".';
  document.getElementById('sm-confirm-overlay').style.display = 'flex';
}

function cancelDeleteSection() {
  smPendingDeleteId = null;
  document.getElementById('sm-confirm-overlay').style.display = 'none';
}

function confirmDeleteSection() {
  if (!smPendingDeleteId) return;
  smSectionVisibility[smPendingDeleteId] = false;
  smPendingDeleteId = null;
  document.getElementById('sm-confirm-overlay').style.display = 'none';
  renderSectionManager();
  markEditorDirty();
}

function smDragStart(event, idx) {
  const item = SM_ALL_SECTIONS.find(s => s.id === smSectionOrder[idx]);
  if (item && item.locked) { event.preventDefault(); return; }
  smDragSrcIdx = idx;
  event.dataTransfer.effectAllowed = 'move';
  setTimeout(() => {
    const el = document.querySelector(`[data-sm-idx="${idx}"]`);
    if (el) el.classList.add('sm-dragging');
  }, 0);
}

function smDragOver(event, idx) {
  event.preventDefault();
  if (smDragSrcIdx === null || smDragSrcIdx === idx) return;
  // Don't allow dragging over first (hero) or last (contact) if they're locked
  const tgtMeta = smGetMeta(smSectionOrder[idx]);
  if (tgtMeta && tgtMeta.locked) return;
  event.dataTransfer.dropEffect = 'move';
  document.querySelectorAll('.sm-section-item').forEach(el => el.classList.remove('sm-drag-over-top', 'sm-drag-over-bottom'));
  const el = event.currentTarget;
  if (idx < smDragSrcIdx) el.classList.add('sm-drag-over-top');
  else el.classList.add('sm-drag-over-bottom');
}

function smDragLeave(event) {
  event.currentTarget.classList.remove('sm-drag-over-top', 'sm-drag-over-bottom');
}

function smDrop(event, toIdx) {
  event.preventDefault();
  if (smDragSrcIdx === null || smDragSrcIdx === toIdx) { smDragEnd(); return; }

  const fromIdx = smDragSrcIdx;
  const fromMeta = smGetMeta(smSectionOrder[fromIdx]);
  const toMeta = smGetMeta(smSectionOrder[toIdx]);

  // Hero always first, contact always last — prevent moving past those positions
  const heroIdx = smSectionOrder.indexOf('hero');
  const contactIdx = smSectionOrder.indexOf('contact');

  // Cannot move into position 0 (hero is always 0) if moving from non-hero
  if (toIdx === heroIdx && fromMeta && fromMeta.id !== 'hero') { smDragEnd(); return; }
  // Cannot move into last position (contact is always last)
  if (toIdx === contactIdx && fromMeta && fromMeta.id !== 'contact') { smDragEnd(); return; }

  // Do the reorder (locked items can't be source, already checked)
  const newOrder = [...smSectionOrder];
  const [moved] = newOrder.splice(fromIdx, 1);
  newOrder.splice(toIdx, 0, moved);

  // Ensure hero is first, contact is last
  const heroI = newOrder.indexOf('hero');
  if (heroI !== 0) { newOrder.splice(heroI, 1); newOrder.unshift('hero'); }
  const contactI = newOrder.indexOf('contact');
  if (contactI !== newOrder.length - 1) { newOrder.splice(contactI, 1); newOrder.push('contact'); }

  smSectionOrder = newOrder;
  smDragEnd();
  renderSectionManager();
  markEditorDirty();
}

function smDragEnd() {
  smDragSrcIdx = null;
  document.querySelectorAll('.sm-section-item').forEach(el => {
    el.classList.remove('sm-dragging', 'sm-drag-over-top', 'sm-drag-over-bottom');
  });
}

function resetSectionOrder() {
  if (!confirm('Reset section order to default?')) return;
  smSectionOrder = [...SM_DEFAULT_ORDER];
  smSectionVisibility = {};
  renderSectionManager();
  markEditorDirty();
}

function toggleSectionManager() {
  const el = document.getElementById('section-manager');
  if (el) el.classList.toggle('open');
}

function openSectionPicker() {
  const grid = document.getElementById('section-picker-grid');
  if (!grid) return;

  // Show sections that are currently hidden/removed, plus blank option
  grid.innerHTML = SM_ALL_SECTIONS.map(s => {
    const isVisible = smIsVisible(s.id);
    const isHidden = !isVisible;
    const disabled = isVisible ? ' disabled' : '';
    const status = isVisible ? 'Already on page' : 'Hidden — click to restore';
    return `<button class="section-picker-item${isVisible ? ' disabled' : ''}" onclick="smAddSection('${s.id}')" ${isVisible ? 'disabled' : ''}>
      <span class="sp-icon">${s.icon}</span>
      <span class="sp-name">${s.name}</span>
      <span class="sp-status">${status}</span>
    </button>`;
  }).join('');

  document.getElementById('section-picker-overlay').style.display = 'flex';
}

function closeSectionPicker() {
  document.getElementById('section-picker-overlay').style.display = 'none';
}

function smAddSection(id) {
  smSectionVisibility[id] = true;
  closeSectionPicker();
  renderSectionManager();
  markEditorDirty();
}

function smLoadFromContent(content) {
  // Restore section order from saved content
  if (content.section_order) {
    try {
      const saved = JSON.parse(content.section_order);
      if (Array.isArray(saved) && saved.length > 0) {
        // Merge: keep saved order, add any missing sections from defaults at end
        const merged = [...saved.filter(id => SM_DEFAULT_ORDER.includes(id))];
        SM_DEFAULT_ORDER.forEach(id => { if (!merged.includes(id)) merged.push(id); });
        smSectionOrder = merged;
      }
    } catch {}
  } else {
    smSectionOrder = [...SM_DEFAULT_ORDER];
  }

  // Restore visibility
  if (content.section_visibility) {
    try {
      const saved = JSON.parse(content.section_visibility);
      if (saved && typeof saved === 'object') {
        smSectionVisibility = saved;
      }
    } catch {}
  } else {
    smSectionVisibility = {};
  }

  renderSectionManager();
}

// ─── WEBSITE EDITOR ───────────────────────────────────────

let editorContent = {};      // current state of all fields (loaded from DB)
let editorSavedContent = {}; // last successfully saved state
let editorDirty = false;

// All the CMS field keys we manage in the editor
const EDITOR_FIELD_KEYS = [
  'school_name',
  'hero_badge','hero_h1_before','hero_h1_em','hero_subtitle','hero_cta_primary','hero_cta_secondary',
  'hero_loc_label','hero_training','hero_region','hero_bg_image',
  'about_label','about_h2','about_p1','about_p2',
  'about_stat1_value','about_stat1_label','about_stat2_value','about_stat2_label','about_stat3_value','about_stat3_label',
  'about_image',
  'programs_label','programs_h2','programs_intro',
  'program_1_title','program_1_tag','program_1_body',
  'program_2_title','program_2_tag','program_2_body',
  'program_3_title','program_3_tag','program_3_body',
  'program_4_title','program_4_tag','program_4_body',
  'program_5_title','program_5_tag','program_5_body',
  'program_6_title','program_6_tag','program_6_body',
  'program_7_title','program_7_tag','program_7_body',
  'fleet_label','fleet_h2','fleet_intro',
  'instructors_label','instructors_h2','instructors_intro',
  'cta_label','contact_h2','contact_p','contact_email','contact_phone','contact_location',
  'location_label','location_h2','location_desc',
  'location_fact1_title','location_fact1_text',
  'location_fact2_title','location_fact2_text',
  'location_fact3_title','location_fact3_text',
  'location_fact4_title','location_fact4_text',
  'footer_copy','nav_cta',
  'font_heading','font_body',
  'color_heading','color_body','color_accent','color_primary',
  'banner_headline','banner_sub','banner_cta'
  // fleet_N_* and instructor_N_* are handled dynamically by fleet/instructor functions
];

const IMAGE_KEYS = ['hero_bg_image','about_image'];
// fleet_N_image and instructor_N_image handled dynamically

// Track whether the preview iframe has finished loading
let previewReady = false;
let canvasModeActive = false;       // true when canvas/drag-drop mode is on
let elementPositions = {};          // {cmsKey: {top, left, width, height}}
let hiddenElements = [];            // array of CSS selectors for deleted non-CMS elements

// CMS key → public site DOM element ID (mirrors index.html TEXT_MAP)
// fleet_N_* and instructor_N_* entries are added dynamically by buildDynamicMaps()
const CMS_DOM_MAP = {
  school_name:'cms-school-name', hero_badge:'cms-hero-badge',
  hero_h1_before:'cms-hero-h1-before', hero_h1_em:'cms-hero-h1-em',
  hero_subtitle:'cms-hero-subtitle', hero_cta_primary:'cms-hero-cta-primary',
  hero_cta_secondary:'cms-hero-cta-secondary', hero_loc_label:'cms-hero-loc-label',
  hero_training:'cms-hero-training', hero_region:'cms-hero-region',
  about_label:'cms-about-label', about_h2:'cms-about-h2',
  about_p1:'cms-about-p1', about_p2:'cms-about-p2',
  about_stat1_value:'cms-about-stat1-value', about_stat1_label:'cms-about-stat1-label',
  about_stat2_value:'cms-about-stat2-value', about_stat2_label:'cms-about-stat2-label',
  about_stat3_value:'cms-about-stat3-value', about_stat3_label:'cms-about-stat3-label',
  programs_label:'cms-programs-label', programs_h2:'cms-programs-h2', programs_intro:'cms-programs-intro',
  program_1_title:'cms-prog-1-title', program_1_body:'cms-prog-1-body', program_1_tag:'cms-prog-1-tag',
  program_2_title:'cms-prog-2-title', program_2_body:'cms-prog-2-body', program_2_tag:'cms-prog-2-tag',
  program_3_title:'cms-prog-3-title', program_3_body:'cms-prog-3-body', program_3_tag:'cms-prog-3-tag',
  program_4_title:'cms-prog-4-title', program_4_body:'cms-prog-4-body', program_4_tag:'cms-prog-4-tag',
  program_5_title:'cms-prog-5-title', program_5_body:'cms-prog-5-body', program_5_tag:'cms-prog-5-tag',
  program_6_title:'cms-prog-6-title', program_6_body:'cms-prog-6-body', program_6_tag:'cms-prog-6-tag',
  program_7_title:'cms-prog-7-title', program_7_body:'cms-prog-7-body', program_7_tag:'cms-prog-7-tag',
  fleet_label:'cms-fleet-label', fleet_h2:'cms-fleet-h2', fleet_intro:'cms-fleet-intro',
  instructors_label:'cms-instructors-label', instructors_h2:'cms-instructors-h2', instructors_intro:'cms-instructors-intro',
  cta_label:'cms-cta-label', contact_h2:'cms-contact-h2', contact_p:'cms-contact-p',
  contact_email:'cms-contact-email', contact_phone:'cms-contact-phone', contact_location:'cms-contact-location',
  location_label:'cms-location-label', location_h2:'cms-location-h2', location_desc:'cms-location-desc',
  location_fact1_title:'cms-location-fact1-title', location_fact1_text:'cms-location-fact1-text',
  location_fact2_title:'cms-location-fact2-title', location_fact2_text:'cms-location-fact2-text',
  location_fact3_title:'cms-location-fact3-title', location_fact3_text:'cms-location-fact3-text',
  location_fact4_title:'cms-location-fact4-title', location_fact4_text:'cms-location-fact4-text',
  footer_copy:'cms-footer-copy', nav_cta:'cms-nav-cta'
};

// Reverse map: DOM ID → CMS key (for click-to-edit)
// fleet/instructor dynamic entries added by buildDynamicMaps()
const CMS_DOM_REVERSE = {};
Object.entries(CMS_DOM_MAP).forEach(function(e) { CMS_DOM_REVERSE[e[1]] = e[0]; });
CMS_DOM_REVERSE['cms-hero-bg'] = 'hero_bg_image';
CMS_DOM_REVERSE['cms-about-image'] = 'about_image';

// CMS key → editor accordion section name
// fleet_N_* and instructor_N_* entries added dynamically by buildDynamicMaps()
const CMS_SECTION_MAP = {
  school_name:'hero', hero_badge:'hero', hero_h1_before:'hero', hero_h1_em:'hero', hero_subtitle:'hero',
  hero_cta_primary:'hero', hero_cta_secondary:'hero', hero_loc_label:'hero', hero_training:'hero', hero_region:'hero', hero_bg_image:'hero',
  about_label:'about', about_h2:'about', about_p1:'about', about_p2:'about',
  about_stat1_value:'about', about_stat1_label:'about', about_stat2_value:'about', about_stat2_label:'about',
  about_stat3_value:'about', about_stat3_label:'about', about_image:'about',
  programs_label:'programs', programs_h2:'programs', programs_intro:'programs',
  program_1_title:'programs', program_1_tag:'programs', program_1_body:'programs',
  program_2_title:'programs', program_2_tag:'programs', program_2_body:'programs',
  program_3_title:'programs', program_3_tag:'programs', program_3_body:'programs',
  program_4_title:'programs', program_4_tag:'programs', program_4_body:'programs',
  program_5_title:'programs', program_5_tag:'programs', program_5_body:'programs',
  program_6_title:'programs', program_6_tag:'programs', program_6_body:'programs',
  program_7_title:'programs', program_7_tag:'programs', program_7_body:'programs',
  fleet_label:'fleet', fleet_h2:'fleet', fleet_intro:'fleet',
  instructors_label:'instructors', instructors_h2:'instructors', instructors_intro:'instructors',
  cta_label:'contact', contact_h2:'contact', contact_p:'contact', contact_email:'contact', contact_phone:'contact', contact_location:'contact',
  location_label:'contact', location_h2:'contact', location_desc:'contact',
  location_fact1_title:'contact', location_fact1_text:'contact',
  location_fact2_title:'contact', location_fact2_text:'contact',
  location_fact3_title:'contact', location_fact3_text:'contact',
  location_fact4_title:'contact', location_fact4_text:'contact',
  footer_copy:'contact', nav_cta:'contact',
  font_heading:'style', font_body:'style',
  color_heading:'style', color_body:'style', color_accent:'style', color_primary:'style'
};

async function loadWebsiteEditor() {
  setEditorStatus('');
  editorDirty = false;
  document.getElementById('editor-discard-btn').style.display = 'none';
  // Always start on the Visual tab when opening the editor
  activeEditorTab = 'visual';
  document.getElementById('tab-btn-visual').classList.add('active');
  document.getElementById('tab-btn-code').classList.remove('active');
  document.getElementById('editor-tab-visual').classList.add('active');
  document.getElementById('editor-tab-code').classList.remove('active');

  try {
    const data = await fetch('/api/site-content?full=1').then(r => r.json());
    editorContent = Object.assign({}, data);
    editorSavedContent = Object.assign({}, data);

    // Load element positions from saved data
    if (data.element_positions) {
      try { elementPositions = JSON.parse(data.element_positions); } catch(e) { elementPositions = {}; }
    }
    // Load hidden elements (deleted non-CMS elements)
    if (data.hidden_elements) {
      try { hiddenElements = JSON.parse(data.hidden_elements); if (!Array.isArray(hiddenElements)) hiddenElements = []; } catch(e) { hiddenElements = []; }
    } else {
      hiddenElements = [];
    }
    // Merge live site defaults for any missing fields
    if (previewReady) {
      mergePreviewDefaults();
    }
    populateEditorFields();
    smLoadFromContent(data);
  } catch (err) {
    setEditorStatus('error', 'Failed to load website content.');
  }
}

function populateEditorFields() {
  EDITOR_FIELD_KEYS.forEach(key => {
    const el = document.getElementById('ef-' + key);
    if (!el) return;
    const val = editorContent[key] || '';

    if (IMAGE_KEYS.includes(key)) {
      // Images handled separately via preview img
    } else if (el.tagName === 'SELECT') {
      // Find matching option
      const opt = Array.from(el.options).find(o => o.value === val);
      el.value = opt ? val : '';
    } else {
      el.value = val;
    }
  });

  // Populate image previews and scale sliders for static fields
  IMAGE_KEYS.forEach(key => {
    const preview = document.getElementById('efpreview-' + key);
    if (!preview) return;
    const val = editorContent[key] || '';
    if (val) {
      preview.src = val;
      preview.style.display = 'block';
    } else {
      preview.src = '';
      preview.style.display = 'none';
    }
    // Restore scale slider
    var scaleEl = document.getElementById('efscale-' + key);
    var scaleValEl = document.getElementById('efscaleval-' + key);
    var scaleVal = parseInt(editorContent[key + '_scale'] || '100', 10) || 100;
    if (scaleEl) scaleEl.value = scaleVal;
    if (scaleValEl) scaleValEl.textContent = scaleVal + '%';
  });

  // Banner show/hide checkbox
  var bannerShowEl = document.getElementById('ef-banner_show');
  if (bannerShowEl) {
    bannerShowEl.checked = (editorContent.banner_show !== 'false' && editorContent.banner_show !== '0');
  }

  // Render and populate dynamic fleet/instructor sections
  renderFleetEditorItems();
  populateFleetFields();
  renderInstructorEditorItems();
  populateInstructorFields();
  buildDynamicMaps();
}

function collectEditorFields() {
  const out = {};
  EDITOR_FIELD_KEYS.forEach(key => {
    if (IMAGE_KEYS.includes(key)) {
      // Images are stored in editorContent directly after upload
      out[key] = editorContent[key] || '';
      // Also collect scale for static image keys
      var scaleEl = document.getElementById('efscale-' + key);
      if (scaleEl) out[key + '_scale'] = scaleEl.value || '100';
      else out[key + '_scale'] = editorContent[key + '_scale'] || '100';
    } else {
      const el = document.getElementById('ef-' + key);
      if (el) out[key] = el.value || '';
    }
  });

  // Collect dynamic fleet items
  var fleetCount = getFleetCount();
  out.fleet_count = String(fleetCount);
  for (var fn = 1; fn <= fleetCount; fn++) {
    ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
      var el = document.getElementById('ef-fleet_'+fn+'_'+f);
      out['fleet_'+fn+'_'+f] = el ? (el.value || '') : (editorContent['fleet_'+fn+'_'+f] || '');
    });
    out['fleet_'+fn+'_image'] = editorContent['fleet_'+fn+'_image'] || '';
    out['fleet_'+fn+'_image_scale'] = editorContent['fleet_'+fn+'_image_scale'] || '100';
  }

  // Collect dynamic instructor items
  var instrCount = getInstructorCount();
  out.instructors_count = String(instrCount);
  for (var ii = 1; ii <= instrCount; ii++) {
    ['name','title','cert','bio'].forEach(function(f) {
      var el = document.getElementById('ef-instructor_'+ii+'_'+f);
      out['instructor_'+ii+'_'+f] = el ? (el.value || '') : (editorContent['instructor_'+ii+'_'+f] || '');
    });
    out['instructor_'+ii+'_image'] = editorContent['instructor_'+ii+'_image'] || '';
    out['instructor_'+ii+'_image_scale'] = editorContent['instructor_'+ii+'_image_scale'] || '100';
  }

  // Banner show/hide
  var bannerShowEl = document.getElementById('ef-banner_show');
  out.banner_show = bannerShowEl ? (bannerShowEl.checked ? 'true' : 'false') : (editorContent.banner_show || 'true');

  // Section order and visibility
  out.section_order = JSON.stringify(smSectionOrder);
  out.section_visibility = JSON.stringify(smSectionVisibility);

  // Hidden elements (deleted non-CMS elements)
  if (hiddenElements.length > 0) {
    out.hidden_elements = JSON.stringify(hiddenElements);
  } else {
    out.hidden_elements = '';
  }

  // Element positions (canvas mode)
  if (Object.keys(elementPositions).length > 0) {
    out.element_positions = JSON.stringify(elementPositions);
  }

  // Include orphan text edits (inline edits on non-CMS elements by ordinal index)
  Object.keys(editorContent).forEach(function(k) {
    if (/^orphan_text_\d+$/.test(k)) {
      out[k] = editorContent[k];
    }
  });

  return out;
}

// ──────────────────────────────────────────────
// CANVAS MODE: Drag & Drop Free-Form Positioning
// ──────────────────────────────────────────────

function toggleCanvasMode() {
  canvasModeActive = !canvasModeActive;
  var toggleBtn = document.getElementById('btn-canvas-toggle');
  var badge = document.getElementById('pt-canvas-badge');
  var resetBtn = document.getElementById('btn-reset-layout');
  var clickHint = document.getElementById('pt-click-hint');

  if (toggleBtn) toggleBtn.classList.toggle('on', canvasModeActive);
  if (badge) badge.classList.toggle('active', canvasModeActive);
  if (resetBtn) resetBtn.style.display = canvasModeActive ? '' : 'none';
  if (clickHint) clickHint.classList.toggle('hidden', canvasModeActive);

  injectClickToEdit();

  if (!canvasModeActive) {
    var iframe = document.getElementById('editor-preview-iframe');
    if (iframe) {
      try {
        var doc = iframe.contentDocument || iframe.contentWindow.document;
        ['cms-canvas-css','cms-canvas-script','cms-canvas-base'].forEach(function(id) {
          var el = doc.getElementById(id);
          if (el) el.remove();
        });
        if (doc.body) doc.body.classList.remove('cms-canvas-mode-active');
      } catch(e) {}
    }
  }

  if (canvasModeActive) markEditorDirty();
}

function resetCanvasLayout() {
  if (!confirm('Reset all element positions to their default layout? This cannot be undone.')) return;
  elementPositions = {};
  markEditorDirty();
  if (canvasModeActive) injectClickToEdit();
  setEditorStatus('unsaved', 'Layout reset. Save to publish.');
}

function injectCanvasMode(doc) {
  ['cms-canvas-css','cms-canvas-script','cms-canvas-base'].forEach(function(id) {
    var el = doc.getElementById(id);
    if (el) el.remove();
  });

  var baseStyle = doc.createElement('style');
  baseStyle.id = 'cms-canvas-base';
  baseStyle.textContent = 'body { position: relative !important; } body > * { position: absolute !important; }';
  doc.head.appendChild(baseStyle);

  var style = doc.createElement('style');
  style.id = 'cms-canvas-css';
  style.textContent = [
    '.cms-el-wrap { position: absolute !important; box-sizing: border-box; z-index: 99990; }',
    '.cms-el-wrap .cms-el-overlay { position: absolute; inset: 0; z-index: 99991; pointer-events: none; }',
    '.cms-el-wrap.cms-selected .cms-el-overlay { border: 2px solid rgba(56,189,248,0.7); background: rgba(14,165,233,0.04); border-radius: 3px; }',
    '.cms-el-wrap:hover .cms-el-overlay { border: 1px solid rgba(56,189,248,0.4); border-radius: 3px; }',
    '.cms-hd { position: absolute; width: 14px; height: 14px; background: #0ea5e9; border: 2px solid #fff; border-radius: 50%; top: -7px; left: -7px; cursor: move; z-index: 99999; display: none; align-items: center; justify-content: center; }',
    '.cms-el-wrap.cms-selected .cms-hd { display: flex; }',
    '.cms-hd-label { position: absolute; top: -18px; left: 0; background: rgba(14,165,233,0.85); color: #fff; font-size: 9px; font-family: -apple-system, sans-serif; padding: 1px 5px; border-radius: 3px; white-space: nowrap; pointer-events: none; }',
    '.cms-rz { position: absolute; width: 10px; height: 10px; background: #fff; border: 2px solid #0ea5e9; border-radius: 2px; z-index: 99999; display: none; }',
    '.cms-el-wrap.cms-selected .cms-rz { display: block; }',
    '.cms-rz.se { bottom: -5px; right: -5px; cursor: se-resize; }',
    '.cms-rz.sw { bottom: -5px; left: -5px; cursor: sw-resize; }',
    '.cms-rz.ne { top: -5px; right: -5px; cursor: ne-resize; }',
    '.cms-rz.nw { top: -5px; left: -5px; cursor: nw-resize; }'
  ].join('');
  doc.head.appendChild(style);

  // Get injected script content from the hidden textarea
  var srcEl = document.getElementById('cms-canvas-script-src');
  var src = srcEl ? srcEl.textContent : '';
  var script = doc.createElement('script');
  script.id = 'cms-canvas-script';
  script.textContent = src;
  doc.head.appendChild(script);

  if (doc.body) doc.body.classList.add('cms-canvas-mode-active');
}

function markEditorDirty() {
  if (!editorDirty) {
    editorDirty = true;
    setEditorStatus('unsaved', 'You have unsaved changes.');
    document.getElementById('editor-discard-btn').style.display = '';
  }
}

function setEditorStatus(type, msg) {
  const el = document.getElementById('editor-status');
  el.className = 'editor-status';
  if (!type || !msg) { el.style.display = 'none'; return; }
  el.className = 'editor-status ' + type;
  el.innerHTML = `<span class="es-dot"></span><span>${escHtml(msg)}</span>`;
}

function toggleEditorSection(section) {
  const btn = document.getElementById('esb-' + section);
  const fields = document.getElementById('ef-' + section);
  const isOpen = fields.classList.contains('open');
  // Close all
  document.querySelectorAll('.editor-section-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.editor-fields').forEach(f => f.classList.remove('open'));
  // Toggle clicked
  if (!isOpen) {
    btn.classList.add('active');
    fields.classList.add('open');
  }
}

async function saveWebsiteContent() {
  const btn = document.getElementById('editor-save-btn');
  const content = collectEditorFields();

  btn.disabled = true;
  btn.textContent = 'Saving…';
  setEditorStatus('unsaved', 'Saving changes…');

  try {
    await api('/api/site-content', { method: 'PUT', body: JSON.stringify(content) });
    editorSavedContent = Object.assign({}, content);
    editorContent = Object.assign({}, content);
    editorDirty = false;
    setEditorStatus('saved', 'Published! Changes are live on your website.');
    document.getElementById('editor-discard-btn').style.display = 'none';
    // Refresh preview after short delay so new content is rendered
    setTimeout(refreshEditorPreview, 800);
  } catch (err) {
    setEditorStatus('unsaved', 'Save failed: ' + (err.error || 'Unknown error'));
  } finally {
    btn.disabled = false;
    btn.textContent = '✓ Save & Publish';
  }
}

function discardEditorChanges() {
  if (!confirm('Discard all unsaved changes and reload from last saved?')) return;
  editorContent = Object.assign({}, editorSavedContent);
  editorDirty = false;
  // Restore hidden elements from saved state
  if (editorSavedContent.hidden_elements) {
    try { hiddenElements = JSON.parse(editorSavedContent.hidden_elements); if (!Array.isArray(hiddenElements)) hiddenElements = []; } catch(e) { hiddenElements = []; }
  } else {
    hiddenElements = [];
  }
  populateEditorFields();
  smLoadFromContent(editorSavedContent);
  setEditorStatus('');
  document.getElementById('editor-discard-btn').style.display = 'none';
  // Refresh preview to restore deleted elements
  refreshEditorPreview();
}

// ─── DOWNLOAD SOURCE CODE ───
function downloadSourceCode() {
  var btn = document.getElementById('download-source-btn');
  var origHTML = btn.innerHTML;
  btn.innerHTML = '&#8987; Preparing...';
  btn.disabled = true;
  btn.style.opacity = '0.7';

  // Use a hidden link to trigger the download
  var link = document.createElement('a');
  link.href = '/api/download-source';
  link.style.display = 'none';
  document.body.appendChild(link);

  // Use fetch to check for errors before triggering download
  fetch('/api/download-source', { credentials: 'same-origin' })
    .then(function(response) {
      if (!response.ok) {
        throw new Error('Download failed — ' + response.status);
      }
      return response.blob();
    })
    .then(function(blob) {
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      var dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      a.href = url;
      a.download = 'nta-source-' + dateStr + '.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      btn.innerHTML = '&#10003; Downloaded!';
      btn.style.opacity = '1';
      setTimeout(function() {
        btn.innerHTML = origHTML;
        btn.disabled = false;
      }, 2000);
    })
    .catch(function(err) {
      console.error('Download error:', err);
      btn.innerHTML = '&#10007; Failed';
      btn.style.opacity = '1';
      setTimeout(function() {
        btn.innerHTML = origHTML;
        btn.disabled = false;
      }, 2000);
      showToast('Download failed. Please try again.', 'error');
    });

  document.body.removeChild(link);
}

// ─── CODE TAB ───
var activeEditorTab = 'visual';

function switchEditorTab(tab) {
  activeEditorTab = tab;

  // Update tab buttons
  document.getElementById('tab-btn-visual').classList.toggle('active', tab === 'visual');
  document.getElementById('tab-btn-code').classList.toggle('active', tab === 'code');

  // Show/hide panels
  document.getElementById('editor-tab-visual').classList.toggle('active', tab === 'visual');
  document.getElementById('editor-tab-code').classList.toggle('active', tab === 'code');

  if (tab === 'code') {
    // Sync visual editor fields into editorContent before showing JSON
    if (editorDirty) {
      editorContent = Object.assign(editorContent, collectEditorFields());
    }
    loadCodeTab();
  } else {
    // Switching back to visual: if code tab has unparsed changes, apply them
    var ta = document.getElementById('editor-code-textarea');
    var errEl = document.getElementById('editor-code-error');
    errEl.classList.remove('show');
    try {
      var parsed = JSON.parse(ta.value);
      editorContent = Object.assign({}, parsed);
      populateEditorFields();
    } catch (e) {
      // Invalid JSON — just leave visual as-is
    }
  }
}

function loadCodeTab() {
  var content = Object.assign({}, editorContent);
  // Also collect any unsaved visual fields
  if (editorDirty) {
    content = Object.assign(content, collectEditorFields());
  }
  document.getElementById('editor-code-textarea').value = JSON.stringify(content, null, 2);
  document.getElementById('editor-code-error').classList.remove('show');
}

function formatCodeTab() {
  var ta = document.getElementById('editor-code-textarea');
  var errEl = document.getElementById('editor-code-error');
  try {
    var parsed = JSON.parse(ta.value);
    ta.value = JSON.stringify(parsed, null, 2);
    errEl.classList.remove('show');
  } catch (e) {
    errEl.textContent = '⚠ Invalid JSON: ' + e.message;
    errEl.classList.add('show');
  }
}

function validateCodeTab() {
  var ta = document.getElementById('editor-code-textarea');
  var errEl = document.getElementById('editor-code-error');
  try {
    JSON.parse(ta.value);
    errEl.classList.remove('show');
    setEditorStatus('saved', 'JSON is valid ✓');
    setTimeout(function() { setEditorStatus(''); }, 2500);
  } catch (e) {
    errEl.textContent = '⚠ Invalid JSON: ' + e.message;
    errEl.classList.add('show');
  }
}

async function saveFromCodeTab() {
  var ta = document.getElementById('editor-code-textarea');
  var errEl = document.getElementById('editor-code-error');
  var parsed;

  try {
    parsed = JSON.parse(ta.value);
  } catch (e) {
    errEl.textContent = '⚠ Invalid JSON — fix before saving: ' + e.message;
    errEl.classList.add('show');
    return;
  }

  errEl.classList.remove('show');
  var btn = document.querySelector('#editor-tab-code .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  setEditorStatus('unsaved', 'Saving changes…');

  try {
    await api('/api/site-content', { method: 'PUT', body: JSON.stringify(parsed) });
    editorSavedContent = Object.assign({}, parsed);
    editorContent = Object.assign({}, parsed);
    editorDirty = false;
    setEditorStatus('saved', 'Published! Changes are live on your website.');
    document.getElementById('editor-discard-btn').style.display = 'none';
    // Keep the textarea in sync with what was saved (pretty-printed)
    ta.value = JSON.stringify(parsed, null, 2);
    setTimeout(refreshEditorPreview, 800);
  } catch (err) {
    setEditorStatus('unsaved', 'Save failed: ' + (err.error || 'Unknown error'));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '✓ Save & Publish'; }
  }
}

async function handleEditorImageUpload(key, input) {
  const file = input.files[0];
  if (!file) return;

  const dropEl = input.closest('.ef-img-drop');
  const preview = document.getElementById('efpreview-' + key);
  const origHtml = dropEl ? dropEl.innerHTML : '';

  if (dropEl) {
    dropEl.innerHTML = '<div class="ef-img-uploading">&#8987; Uploading…</div>';
  }

  try {
    const base64 = await fileToBase64(file);
    const resp = await api('/api/site-content/upload-image', {
      method: 'POST',
      body: JSON.stringify({ filename: file.name, base64, mimeType: file.type })
    });

    editorContent[key] = resp.url;
    if (preview) {
      preview.src = resp.url;
      preview.style.display = 'block';
    }
    markEditorDirty();
  } catch (err) {
    alert('Image upload failed: ' + (err.error || 'Unknown error'));
  } finally {
    if (dropEl) dropEl.innerHTML = origHtml;
    // Re-attach file input listener (innerHTML replacement loses it)
    const newInput = dropEl ? dropEl.querySelector('input[type=file]') : null;
    if (newInput) newInput.onchange = function() { handleEditorImageUpload(key, this); };
  }
}

// ─── FILE BROWSER (Code Tab — Project Files Mode) ───
var codeMode = 'json'; // 'json' or 'files'
var currentFilePath = null;
var currentFileContent = null;
var fileTreeCache = null;

function switchCodeMode(mode) {
  codeMode = mode;
  document.getElementById('code-mode-json-btn').classList.toggle('active', mode === 'json');
  document.getElementById('code-mode-files-btn').classList.toggle('active', mode === 'files');
  document.getElementById('code-json-panel').classList.toggle('hidden', mode !== 'json');
  document.getElementById('code-files-panel').classList.toggle('active', mode === 'files');
  if (mode === 'files' && !fileTreeCache) {
    loadFileTree();
  }
}

async function loadFileTree() {
  const treeEl = document.getElementById('code-file-tree');
  const emptyEl = document.getElementById('code-file-empty');
  treeEl.innerHTML = '<div class="code-empty-state"><div class="ces-icon">&#8987;</div><p>Loading files…</p></div>';
  try {
    const data = await fetch('/api/project-files').then(r => r.ok ? r.json() : Promise.reject(r.status));
    fileTreeCache = data;
    // Show root entries as a flat list with folder expansion
    renderFileTree(data.entries || [], treeEl, '');
    emptyEl.style.display = 'none';
  } catch (err) {
    treeEl.innerHTML = '<div class="code-empty-state"><div class="ces-icon">&#9888;</div><p>Could not load files: ' + (err.message || 'Server error') + '</p></div>';
    console.error('File tree load error:', err);
  }
}

function renderFileTree(entries, container, parentPath) {
  container.innerHTML = '';
  // Sort: folders first, then files
  const sorted = [...entries].sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  for (const entry of sorted) {
    const item = document.createElement('div');
    const fullPath = parentPath ? parentPath + '/' + entry.name : entry.name;

    if (entry.type === 'dir') {
      item.className = 'file-tree-item folder';
      item.innerHTML = '<span class="ft-icon">&#128193;</span><span class="ft-name">' + escHtml(entry.name) + '/</span>';
      // Make folders expandable
      item.style.cursor = 'pointer';
      item.onclick = async function(e) {
        e.stopPropagation();
        const icon = item.querySelector('.ft-icon');
        const childContainer = item.nextElementSibling;
        if (childContainer && childContainer.classList.contains('ft-children')) {
          // Toggle collapse
          childContainer.style.display = childContainer.style.display === 'none' ? 'block' : 'none';
          icon.textContent = childContainer.style.display === 'none' ? '&#128194;' : '&#128194;';
        } else {
          // Load children
          icon.textContent = '&#8987;';
          try {
            const data = await fetch('/api/project-files?path=' + encodeURIComponent(fullPath)).then(r => r.json());
            const childDiv = document.createElement('div');
            childDiv.className = 'ft-children';
            item.parentNode.insertBefore(childDiv, item.nextSibling);
            renderFileTree(data.entries || [], childDiv, fullPath);
            icon.textContent = '&#128194;';
          } catch(e) {
            icon.textContent = '&#9888;';
          }
        }
      };
    } else {
      const ext = entry.extension || '';
      const icon = getFileIcon(ext);
      item.className = 'file-tree-item file';
      item.innerHTML = '<span class="ft-icon">' + icon + '</span><span class="ft-name">' + escHtml(entry.name) + '</span>';
      item.onclick = function() {
        openFile(fullPath);
      };
    }

    container.appendChild(item);
  }
}

function getFileIcon(ext) {
  const icons = {
    '.js': '&#129704;',
    '.html': '&#128196;',
    '.css': '&#127912;',
    '.json': '&#123;',
    '.md': '&#128221;',
    '.txt': '&#128196;',
    '.yaml': '&#128260;',
    '.yml': '&#128260;',
    '.sql': '&#128451;',
    '.gitignore': '&#128270;',
    '.env': '&#128274;',
  };
  return icons[ext] || '&#128196;';
}

async function openFile(filePath) {
  currentFilePath = filePath;
  const editor = document.getElementById('code-file-editor');
  const empty = document.getElementById('code-file-empty');
  editor.style.display = 'flex';
  empty.style.display = 'none';

  // Update header
  const filename = filePath.split('/').pop();
  const ext = '.' + filename.split('.').pop();
  document.getElementById('code-filename').textContent = filename;
  document.getElementById('code-lang').textContent = getLangLabel(ext);

  // Show loading state
  const body = document.getElementById('code-editor-body');
  body.innerHTML = '<div class="code-empty-state"><div class="ces-icon">&#8987;</div><p>Loading ' + escHtml(filename) + '…</p></div>';
  document.getElementById('code-status-msg').textContent = '';

  try {
    const data = await fetch('/api/project-files?path=' + encodeURIComponent(filePath)).then(r => r.ok ? r.json() : Promise.reject(r.status));
    if (data.type === 'file' && data.content !== undefined) {
      currentFileContent = data.content;
      const lang = getLangLabel(data.extension || '.' + filename.split('.').pop());
      document.getElementById('code-lang').textContent = lang;
      document.getElementById('code-file-size').textContent = formatBytes(data.size || data.content.length);
      renderCodeViewer(data.content, data.extension || '.' + filename.split('.').pop());
      document.getElementById('code-status-msg').textContent = 'Loaded ' + filename + ' (' + formatBytes(data.size || data.content.length) + ')';
      // Highlight active file in tree
      document.querySelectorAll('.file-tree-item.file').forEach(el => {
        el.classList.toggle('active', el.querySelector('.ft-name').textContent === filename);
      });
    }
  } catch (err) {
    body.innerHTML = '<div class="code-empty-state"><div class="ces-icon">&#9888;</div><p>Could not load file: ' + (err.message || 'Server error') + '</p></div>';
  }
}

function renderCodeViewer(code, ext) {
  const body = document.getElementById('code-editor-body');
  const lines = code.split('\n');
  let html = '';
  for (let i = 0; i < lines.length; i++) {
    const highlighted = highlightLine(lines[i], ext);
    html += '<div class="code-line"><span class="code-linenum">' + (i + 1) + '</span><span class="code-token">' + highlighted + '</span></div>';
  }
  body.innerHTML = html;
  body.scrollTop = 0;
}

function highlightLine(line, ext) {
  // Simple syntax highlighting
  const escaped = escHtml(line);
  if (ext === '.js' || ext === '.json' || ext === '.html' || ext === '.css') {
    let result = escaped
      // HTML comments
      .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="token-comment">$1</span>')
      // Single-line comments (for JS/CSS)
      .replace(/(\/\/[^\n]*)/g, '<span class="token-comment">$1</span>')
      // HTML tags
      .replace(/(&lt;\/?[\w\s="'-]+)/g, '<span class="token-tag">$1</span>')
      .replace(/(&gt;)/g, '<span class="token-tag">$1</span>')
      // Strings
      .replace(/(&quot;[^&]*?&quot;)/g, '<span class="token-string">$1</span>')
      .replace(/('[^']*?')/g, '<span class="token-string">$1</span>')
      // Numbers
      .replace(/\b([0-9]+)\b/g, '<span class="token-number">$1</span>')
      // JS/CSS keywords
      .replace(/\b(function|const|let|var|return|if|else|for|while|class|import|export|from|async|await|new|try|catch|throw|default|extends|this|true|false|null|undefined|typeof|instanceof|require|module|exports)\b/g, '<span class="token-keyword">$1</span>')
      // Functions
      .replace(/([a-zA-Z_$][a-zA-Z0-9_$]*)(?=\()/g, '<span class="token-function">$1</span>');
    return result;
  }
  // For other file types, just return escaped text
  return escaped;
}

function getLangLabel(ext) {
  const labels = {
    '.js': 'JavaScript',
    '.html': 'HTML',
    '.css': 'CSS',
    '.json': 'JSON',
    '.md': 'Markdown',
    '.txt': 'Text',
    '.yaml': 'YAML',
    '.yml': 'YAML',
    '.sql': 'SQL',
    '.gitignore': 'Git Ignore',
    '.env': 'Environment',
    '.txt': 'Plain Text',
  };
  return labels[ext] || ext.replace('.', '') || 'File';
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

async function saveProjectFile() {
  if (!currentFilePath || currentFileContent === null) {
    document.getElementById('code-status-msg').textContent = 'No file open to save';
    return;
  }
  // Get current content from the displayed code (read back from the rendered divs)
  const lines = Array.from(document.querySelectorAll('#code-editor-body .code-line')).map(l => {
    const tokens = l.querySelectorAll('.code-token');
    // Get the raw text content (de-highlighted)
    return Array.from(tokens).map(t => t.textContent).join('');
  });

  const btn = document.getElementById('code-save-btn');
  btn.disabled = true;
  btn.textContent = 'Saving…';
  document.getElementById('code-status-msg').textContent = 'Saving ' + currentFilePath + '…';

  try {
    const resp = await api('/api/project-files', {
      method: 'PUT',
      body: JSON.stringify({ path: currentFilePath, content: lines.join('\n') })
    });
    currentFileContent = lines.join('\n');
    document.getElementById('code-status-msg').textContent = '✓ Saved ' + currentFilePath;
    setTimeout(() => {
      const msg = document.getElementById('code-status-msg');
      if (msg.textContent.includes('Saved')) msg.textContent = 'Saved ' + currentFilePath;
    }, 2000);
  } catch (err) {
    document.getElementById('code-status-msg').textContent = '✗ Save failed: ' + (err.error || 'Unknown error');
  } finally {
    btn.disabled = false;
    btn.textContent = '✓ Save File';
  }
}

async function copyCodeContent() {
  if (!currentFilePath) return;
  // Copy from the displayed code
  const lines = Array.from(document.querySelectorAll('#code-editor-body .code-line')).map(l => {
    return Array.from(l.querySelectorAll('.code-token')).map(t => t.textContent).join('');
  });
  const text = lines.join('\n');
  try {
    await navigator.clipboard.writeText(text);
    document.getElementById('code-status-msg').textContent = '✓ Copied to clipboard';
    setTimeout(() => {
      const msg = document.getElementById('code-status-msg');
      if (msg.textContent.includes('Copied')) msg.textContent = currentFilePath ? 'Viewing ' + currentFilePath.split('/').pop() : '';
    }, 2000);
  } catch (err) {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    document.getElementById('code-status-msg').textContent = '✓ Copied to clipboard';
  }
}



function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Called when a scale slider changes value
function onScaleChange(key, value) {
  var v = parseInt(value, 10) || 100;
  var valEl = document.getElementById('efscaleval-' + key);
  if (valEl) valEl.textContent = v + '%';
  editorContent[key + '_scale'] = String(v);
  markEditorDirty();
}

function refreshEditorPreview() {
  const iframe = document.getElementById('editor-preview-iframe');
  const loading = document.getElementById('preview-loading');
  if (loading) loading.style.display = 'flex';
  if (iframe) {
    iframe.style.opacity = '0';
    iframe.src = '/?t=' + Date.now();
  }
}

function previewLoaded() {
  const iframe = document.getElementById('editor-preview-iframe');
  const loading = document.getElementById('preview-loading');
  if (iframe) iframe.style.opacity = '1';
  if (loading) loading.style.display = 'none';
  previewReady = true;
  injectClickToEdit();
  // If editor page is active, merge live defaults and re-populate
  if (currentPage === 'website-editor') {
    mergePreviewDefaults();
    populateEditorFields();
  }
}

// Scrape current live content from the preview iframe DOM and fill in missing editor fields
function mergePreviewDefaults() {
  var iframe = document.getElementById('editor-preview-iframe');
  if (!iframe) return;
  try {
    var doc = iframe.contentDocument || iframe.contentWindow.document;
    if (!doc || !doc.body) return;

    // Text content: fill gaps from live DOM
    // Use hasOwnProperty so empty strings (cleared fields) are preserved —
    // only fill keys that were never saved to the DB at all.
    Object.keys(CMS_DOM_MAP).forEach(function(key) {
      if (editorContent.hasOwnProperty(key)) return; // DB value (even '') takes priority
      var el = doc.getElementById(CMS_DOM_MAP[key]);
      if (el) {
        var text = el.textContent.trim();
        if (text) editorContent[key] = text;
      }
    });

    // Hero background image (CSS default or inline override)
    if (!editorContent.hero_bg_image) {
      var heroBg = doc.getElementById('cms-hero-bg');
      if (heroBg) {
        var bg = iframe.contentWindow.getComputedStyle(heroBg).backgroundImage;
        var m = bg && bg.match(/url\(["']?([^"')]+)["']?\)/);
        if (m && m[1] && m[1] !== 'none') editorContent.hero_bg_image = m[1];
      }
    }

    // About image
    if (!editorContent.about_image) {
      var aboutImg = doc.getElementById('cms-about-image');
      if (aboutImg && aboutImg.src && aboutImg.naturalWidth > 0) editorContent.about_image = aboutImg.src;
    }

    // Fleet images (dynamic count)
    var fleetMergeCount = Math.max(2, getFleetCount());
    for (var fmi = 1; fmi <= fleetMergeCount; fmi++) {
      var fmKey = 'fleet_' + fmi + '_image';
      if (!editorContent[fmKey]) {
        var fmEl = doc.getElementById('cms-fleet-' + fmi + '-image');
        if (fmEl && fmEl.src && fmEl.naturalWidth > 0) editorContent[fmKey] = fmEl.src;
      }
    }

    // Instructor images (dynamic count, inside avatar divs)
    var instrMergeCount = Math.max(3, getInstructorCount());
    for (var imi = 1; imi <= instrMergeCount; imi++) {
      var imKey = 'instructor_' + imi + '_image';
      if (!editorContent[imKey]) {
        var imAvatar = doc.getElementById('cms-instructor-' + imi + '-avatar');
        if (imAvatar) {
          var imImg = imAvatar.querySelector('img');
          if (imImg && imImg.src && imImg.naturalWidth > 0) editorContent[imKey] = imImg.src;
        }
      }
    }

    // Update saved baseline so these defaults don't trigger dirty state
    editorSavedContent = Object.assign({}, editorContent);
  } catch (e) {
    // Cross-origin or iframe access error — ignore silently
  }
}

// ─── DYNAMIC FLEET / INSTRUCTOR MANAGEMENT ───────────────────────────────────

function getFleetCount() {
  return Math.max(1, parseInt(editorContent.fleet_count || '2', 10) || 2);
}

function getInstructorCount() {
  return Math.max(1, parseInt(editorContent.instructors_count || '3', 10) || 3);
}

// Build dynamic entries in CMS_DOM_MAP, CMS_DOM_REVERSE, CMS_SECTION_MAP
function buildDynamicMaps() {
  var fc = getFleetCount();
  var ic = getInstructorCount();
  for (var n = 1; n <= fc; n++) {
    ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
      var domId = 'cms-fleet-' + n + '-' + f;
      CMS_DOM_MAP['fleet_'+n+'_'+f] = domId;
      CMS_DOM_REVERSE[domId] = 'fleet_'+n+'_'+f;
      CMS_SECTION_MAP['fleet_'+n+'_'+f] = 'fleet';
    });
    CMS_DOM_REVERSE['cms-fleet-'+n+'-image'] = 'fleet_'+n+'_image';
    CMS_SECTION_MAP['fleet_'+n+'_image'] = 'fleet';
  }
  for (var m = 1; m <= ic; m++) {
    ['name','title','cert','bio'].forEach(function(f) {
      var domId = 'cms-instructor-' + m + '-' + f;
      CMS_DOM_MAP['instructor_'+m+'_'+f] = domId;
      CMS_DOM_REVERSE[domId] = 'instructor_'+m+'_'+f;
      CMS_SECTION_MAP['instructor_'+m+'_'+f] = 'instructors';
    });
    CMS_DOM_REVERSE['cms-instructor-'+m+'-avatar'] = 'instructor_'+m+'_image';
    CMS_SECTION_MAP['instructor_'+m+'_image'] = 'instructors';
  }
}

function renderFleetEditorItems() {
  var count = getFleetCount();
  var container = document.getElementById('fleet-items-list');
  if (!container) return;
  var html = '';
  for (var n = 1; n <= count; n++) {
    var removeBtn = count > 1
      ? '<button class="btn-remove-cms-item" onclick="removeFleetItem('+n+')" title="Remove aircraft">&times;</button>'
      : '';
    var dragHandle = count > 1
      ? '<span class="cms-drag-handle" title="Drag to reorder">&#10303;</span>'
      : '';
    html += '<div class="cms-item-group" data-item-type="fleet" data-item-index="'+n+'" draggable="'+(count>1)+'">' +
      '<div class="cms-item-header">'+dragHandle+'<span class="cms-item-label">Aircraft '+n+'</span>'+removeBtn+'</div>' +
      '<div class="ef-row"><label>Title</label><input type="text" id="ef-fleet_'+n+'_title" placeholder="Cessna 172S Skyhawk" oninput="markEditorDirty()"></div>' +
      '<div class="ef-row"><label>Tail # / Subtitle</label><input type="text" id="ef-fleet_'+n+'_subtitle" placeholder="N12345 · Primary Trainer" oninput="markEditorDirty()"></div>' +
      '<div class="ef-row"><label>Description</label><textarea id="ef-fleet_'+n+'_body" rows="2" oninput="markEditorDirty()"></textarea></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.4rem">' +
        '<div class="ef-row"><label>Spec 1</label><input type="text" id="ef-fleet_'+n+'_spec1" placeholder="G1000 Glass" oninput="markEditorDirty()"></div>' +
        '<div class="ef-row"><label>Spec 2</label><input type="text" id="ef-fleet_'+n+'_spec2" placeholder="180 HP" oninput="markEditorDirty()"></div>' +
        '<div class="ef-row"><label>Spec 3</label><input type="text" id="ef-fleet_'+n+'_spec3" placeholder="Dual Controls" oninput="markEditorDirty()"></div>' +
      '</div>' +
      '<div class="ef-row"><label>Aircraft Photo</label>' +
        '<div class="ef-img-wrap">' +
          '<img class="ef-img-preview" id="efpreview-fleet_'+n+'_image" src="" alt="Fleet '+n+'">' +
          '<div class="ef-img-drop"><div>&#8679; Drag &amp; drop or click to upload</div>' +
            '<div style="font-size:0.7rem;margin-top:0.2rem;color:var(--gray-600)">JPEG/PNG/WebP · max 15MB</div>' +
            '<input type="file" accept="image/*" id="effile-fleet_'+n+'_image">' +
          '</div>' +
          '<div class="ef-scale-row">' +
            '<label>Zoom</label>' +
            '<input type="range" min="50" max="200" step="5" id="efscale-fleet_'+n+'_image" value="100" oninput="onScaleChange(\'fleet_'+n+'_image\',this.value)">' +
            '<span class="ef-scale-val" id="efscaleval-fleet_'+n+'_image">100%</span>' +
          '</div>' +
        '</div></div>' +
      '</div>';
  }
  container.innerHTML = html;
  for (var i = 1; i <= count; i++) {
    (function(nn) {
      var fi = document.getElementById('effile-fleet_'+nn+'_image');
      if (fi) fi.onchange = function() { handleEditorImageUpload('fleet_'+nn+'_image', this); };
    })(i);
  }
  initDragAndDrop(container, 'fleet');
}

function renderInstructorEditorItems() {
  var count = getInstructorCount();
  var container = document.getElementById('instructors-items-list');
  if (!container) return;
  var html = '';
  for (var n = 1; n <= count; n++) {
    var removeBtn = count > 1
      ? '<button class="btn-remove-cms-item" onclick="removeInstructorItem('+n+')" title="Remove instructor">&times;</button>'
      : '';
    var dragHandle = count > 1
      ? '<span class="cms-drag-handle" title="Drag to reorder">&#10303;</span>'
      : '';
    html += '<div class="cms-item-group" data-item-type="instructor" data-item-index="'+n+'" draggable="'+(count>1)+'">' +
      '<div class="cms-item-header">'+dragHandle+'<span class="cms-item-label">Instructor '+n+'</span>'+removeBtn+'</div>' +
      '<div class="ef-row"><label>Name</label><input type="text" id="ef-instructor_'+n+'_name" placeholder="Captain John Smith" oninput="markEditorDirty()"></div>' +
      '<div class="ef-row"><label>Title <span style="font-size:0.6rem;font-weight:400;text-transform:none;letter-spacing:0;color:var(--gray-500)">(optional — e.g. Chief Flight Instructor)</span></label>' +
        '<input type="text" id="ef-instructor_'+n+'_title" placeholder="Chief Flight Instructor" oninput="markEditorDirty()"></div>' +
      '<div class="ef-row"><label>Certifications</label><input type="text" id="ef-instructor_'+n+'_cert" placeholder="CFI, CFII, MEI" oninput="markEditorDirty()"></div>' +
      '<div class="ef-row"><label>Bio</label><textarea id="ef-instructor_'+n+'_bio" rows="2" oninput="markEditorDirty()"></textarea></div>' +
      '<div class="ef-row"><label>Photo</label>' +
        '<div class="ef-img-wrap">' +
          '<img class="ef-img-preview" id="efpreview-instructor_'+n+'_image" src="" alt="Instructor '+n+'">' +
          '<div class="ef-img-drop"><div>&#8679; Drag &amp; drop or click to upload</div>' +
            '<div style="font-size:0.7rem;margin-top:0.2rem;color:var(--gray-600)">JPEG/PNG/WebP · max 15MB</div>' +
            '<input type="file" accept="image/*" id="effile-instructor_'+n+'_image">' +
          '</div>' +
          '<div class="ef-scale-row">' +
            '<label>Zoom</label>' +
            '<input type="range" min="50" max="200" step="5" id="efscale-instructor_'+n+'_image" value="100" oninput="onScaleChange(\'instructor_'+n+'_image\',this.value)">' +
            '<span class="ef-scale-val" id="efscaleval-instructor_'+n+'_image">100%</span>' +
          '</div>' +
        '</div></div>' +
      '</div>';
  }
  container.innerHTML = html;
  for (var i = 1; i <= count; i++) {
    (function(nn) {
      var fi = document.getElementById('effile-instructor_'+nn+'_image');
      if (fi) fi.onchange = function() { handleEditorImageUpload('instructor_'+nn+'_image', this); };
    })(i);
  }
  initDragAndDrop(container, 'instructor');
}

function populateFleetFields() {
  var count = getFleetCount();
  for (var n = 1; n <= count; n++) {
    ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
      var el = document.getElementById('ef-fleet_'+n+'_'+f);
      if (el) el.value = editorContent['fleet_'+n+'_'+f] || '';
    });
    var preview = document.getElementById('efpreview-fleet_'+n+'_image');
    if (preview) {
      var val = editorContent['fleet_'+n+'_image'] || '';
      if (val) { preview.src = val; preview.style.display = 'block'; }
      else { preview.src = ''; preview.style.display = 'none'; }
    }
    var scaleKey = 'fleet_'+n+'_image_scale';
    var scaleEl = document.getElementById('efscale-fleet_'+n+'_image');
    var scaleValEl = document.getElementById('efscaleval-fleet_'+n+'_image');
    var scaleVal = parseInt(editorContent[scaleKey] || '100', 10) || 100;
    if (scaleEl) scaleEl.value = scaleVal;
    if (scaleValEl) scaleValEl.textContent = scaleVal + '%';
  }
}

function populateInstructorFields() {
  var count = getInstructorCount();
  for (var n = 1; n <= count; n++) {
    ['name','title','cert','bio'].forEach(function(f) {
      var el = document.getElementById('ef-instructor_'+n+'_'+f);
      if (el) el.value = editorContent['instructor_'+n+'_'+f] || '';
    });
    var preview = document.getElementById('efpreview-instructor_'+n+'_image');
    if (preview) {
      var val = editorContent['instructor_'+n+'_image'] || '';
      if (val) { preview.src = val; preview.style.display = 'block'; }
      else { preview.src = ''; preview.style.display = 'none'; }
    }
    var scaleKey = 'instructor_'+n+'_image_scale';
    var scaleEl = document.getElementById('efscale-instructor_'+n+'_image');
    var scaleValEl = document.getElementById('efscaleval-instructor_'+n+'_image');
    var scaleVal = parseInt(editorContent[scaleKey] || '100', 10) || 100;
    if (scaleEl) scaleEl.value = scaleVal;
    if (scaleValEl) scaleValEl.textContent = scaleVal + '%';
  }
}

function addFleetItem() {
  var count = getFleetCount();
  if (count >= 10) { alert('Maximum 10 aircraft allowed.'); return; }
  editorContent.fleet_count = String(count + 1);
  renderFleetEditorItems();
  populateFleetFields();
  buildDynamicMaps();
  markEditorDirty();
  setTimeout(function() {
    var container = document.getElementById('fleet-items-list');
    if (container) {
      var last = container.lastElementChild;
      if (last) last.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, 60);
}

function removeFleetItem(n) {
  var count = getFleetCount();
  if (count <= 1) return;
  if (!confirm('Remove Aircraft '+n+'? This cannot be undone.')) return;
  for (var i = n; i < count; i++) {
    ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
      editorContent['fleet_'+i+'_'+f] = editorContent['fleet_'+(i+1)+'_'+f] || '';
    });
    editorContent['fleet_'+i+'_image'] = editorContent['fleet_'+(i+1)+'_image'] || '';
    editorContent['fleet_'+i+'_image_scale'] = editorContent['fleet_'+(i+1)+'_image_scale'] || '100';
  }
  ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
    delete editorContent['fleet_'+count+'_'+f];
  });
  delete editorContent['fleet_'+count+'_image'];
  delete editorContent['fleet_'+count+'_image_scale'];
  editorContent.fleet_count = String(count - 1);
  renderFleetEditorItems();
  populateFleetFields();
  buildDynamicMaps();
  markEditorDirty();
}

function addInstructorItem() {
  var count = getInstructorCount();
  if (count >= 10) { alert('Maximum 10 instructors allowed.'); return; }
  editorContent.instructors_count = String(count + 1);
  renderInstructorEditorItems();
  populateInstructorFields();
  buildDynamicMaps();
  markEditorDirty();
  setTimeout(function() {
    var container = document.getElementById('instructors-items-list');
    if (container) {
      var last = container.lastElementChild;
      if (last) last.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, 60);
}

function removeInstructorItem(n) {
  var count = getInstructorCount();
  if (count <= 1) return;
  if (!confirm('Remove Instructor '+n+'? This cannot be undone.')) return;
  for (var i = n; i < count; i++) {
    ['name','title','cert','bio'].forEach(function(f) {
      editorContent['instructor_'+i+'_'+f] = editorContent['instructor_'+(i+1)+'_'+f] || '';
    });
    editorContent['instructor_'+i+'_image'] = editorContent['instructor_'+(i+1)+'_image'] || '';
    editorContent['instructor_'+i+'_image_scale'] = editorContent['instructor_'+(i+1)+'_image_scale'] || '100';
  }
  ['name','title','cert','bio'].forEach(function(f) {
    delete editorContent['instructor_'+count+'_'+f];
  });
  delete editorContent['instructor_'+count+'_image'];
  delete editorContent['instructor_'+count+'_image_scale'];
  editorContent.instructors_count = String(count - 1);
  renderInstructorEditorItems();
  populateInstructorFields();
  buildDynamicMaps();
  markEditorDirty();
}

// ─── COLOR PICKER SYNC ─────────────────────────────────────────────────────
function syncColorFromPicker(key, value) {
  var textInput = document.getElementById('ef-' + key);
  if (textInput) textInput.value = value;
  markEditorDirty();
}

function syncColorFromText(key, value) {
  var picker = document.getElementById('ef-' + key + '_picker');
  if (picker && /^#[0-9a-fA-F]{6}$/.test(value)) {
    picker.value = value;
  }
}

function resetColor(key) {
  var defaults = { color_heading: '', color_body: '', color_accent: '', color_primary: '' };
  var textInput = document.getElementById('ef-' + key);
  var picker = document.getElementById('ef-' + key + '_picker');
  var defaultColors = { color_heading: '#ffffff', color_body: '#94a3b8', color_accent: '#f59e0b', color_primary: '#0ea5e9' };
  if (textInput) textInput.value = '';
  if (picker) picker.value = defaultColors[key] || '#ffffff';
  markEditorDirty();
}

// Override populateEditorFields to also handle color pickers
var _origPopulateEditorFields = populateEditorFields;
populateEditorFields = function() {
  _origPopulateEditorFields();
  // Sync color pickers from text inputs
  ['color_heading','color_body','color_accent','color_primary'].forEach(function(key) {
    var textInput = document.getElementById('ef-' + key);
    var picker = document.getElementById('ef-' + key + '_picker');
    if (textInput && picker) {
      var val = textInput.value || '';
      if (/^#[0-9a-fA-F]{6}$/.test(val)) {
        picker.value = val;
      }
    }
  });
};

// ─── DRAG-AND-DROP REORDERING ───────────────────────────────────────────────
function initDragAndDrop(container, itemType) {
  var groups = container.querySelectorAll('.cms-item-group');
  var dragSrcIndex = null;

  groups.forEach(function(group) {
    group.addEventListener('dragstart', function(e) {
      dragSrcIndex = parseInt(this.getAttribute('data-item-index'));
      this.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', dragSrcIndex);
    });

    group.addEventListener('dragend', function() {
      this.classList.remove('dragging');
      container.querySelectorAll('.cms-item-group').forEach(function(g) {
        g.classList.remove('drag-over-top', 'drag-over-bottom');
      });
    });

    group.addEventListener('dragover', function(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      var targetIndex = parseInt(this.getAttribute('data-item-index'));
      if (targetIndex === dragSrcIndex) return;
      this.classList.remove('drag-over-top', 'drag-over-bottom');
      if (targetIndex < dragSrcIndex) {
        this.classList.add('drag-over-top');
      } else {
        this.classList.add('drag-over-bottom');
      }
    });

    group.addEventListener('dragleave', function() {
      this.classList.remove('drag-over-top', 'drag-over-bottom');
    });

    group.addEventListener('drop', function(e) {
      e.preventDefault();
      this.classList.remove('drag-over-top', 'drag-over-bottom');
      var targetIndex = parseInt(this.getAttribute('data-item-index'));
      if (targetIndex === dragSrcIndex || dragSrcIndex === null) return;
      swapCmsItems(itemType, dragSrcIndex, targetIndex);
      dragSrcIndex = null;
    });
  });
}

function swapCmsItems(itemType, fromIdx, toIdx) {
  // Collect current values from DOM first
  collectEditorFieldsToContent();

  var fields;
  if (itemType === 'fleet') {
    fields = ['title','subtitle','body','spec1','spec2','spec3','image'];
  } else {
    fields = ['name','title','cert','bio','image'];
  }

  var prefix = itemType === 'fleet' ? 'fleet_' : 'instructor_';

  // Store the "from" values
  var temp = {};
  fields.forEach(function(f) {
    temp[f] = editorContent[prefix + fromIdx + '_' + f] || '';
  });

  // Shift items between from and to
  if (fromIdx < toIdx) {
    for (var i = fromIdx; i < toIdx; i++) {
      fields.forEach(function(f) {
        editorContent[prefix + i + '_' + f] = editorContent[prefix + (i+1) + '_' + f] || '';
      });
    }
  } else {
    for (var i = fromIdx; i > toIdx; i--) {
      fields.forEach(function(f) {
        editorContent[prefix + i + '_' + f] = editorContent[prefix + (i-1) + '_' + f] || '';
      });
    }
  }

  // Place the dragged item at the target position
  fields.forEach(function(f) {
    editorContent[prefix + toIdx + '_' + f] = temp[f];
  });

  // Re-render
  if (itemType === 'fleet') {
    renderFleetEditorItems();
    populateFleetFields();
  } else {
    renderInstructorEditorItems();
    populateInstructorFields();
  }
  buildDynamicMaps();
  markEditorDirty();
}

function collectEditorFieldsToContent() {
  // Sync current input values back to editorContent before reorder
  var fc = getFleetCount();
  for (var n = 1; n <= fc; n++) {
    ['title','subtitle','body','spec1','spec2','spec3'].forEach(function(f) {
      var el = document.getElementById('ef-fleet_'+n+'_'+f);
      if (el) editorContent['fleet_'+n+'_'+f] = el.value || '';
    });
  }
  var ic = getInstructorCount();
  for (var m = 1; m <= ic; m++) {
    ['name','title','cert','bio'].forEach(function(f) {
      var el = document.getElementById('ef-instructor_'+m+'_'+f);
      if (el) editorContent['instructor_'+m+'_'+f] = el.value || '';
    });
  }
}

// Generate a stable CSS selector for a DOM element (used for non-CMS elements)
function generateSelector(el, doc) {
  var esc = typeof CSS !== 'undefined' && CSS.escape ? CSS.escape : function(s) { return s.replace(/([^\w-])/g, '\\$1'); };
  // Prefer id-based selector
  if (el.id && !el.id.startsWith('cms-')) return '#' + esc(el.id);

  // Build a path from tag + classes + nth-child
  var parts = [];
  var current = el;
  while (current && current !== doc.body && current !== doc.documentElement) {
    var tag = current.tagName.toLowerCase();
    if (current.id) {
      parts.unshift('#' + esc(current.id));
      break;
    }
    // Use tag + distinguishing classes
    var cls = Array.from(current.classList || []).filter(function(c) {
      return c && !c.startsWith('cms-') && !c.startsWith('fade-');
    }).slice(0, 2);
    var sel = tag;
    if (cls.length) sel += '.' + cls.join('.');
    // Add nth-child for disambiguation
    var parent = current.parentElement;
    if (parent) {
      var siblings = Array.from(parent.children).filter(function(s) { return s.tagName === current.tagName; });
      if (siblings.length > 1) {
        var idx = siblings.indexOf(current) + 1;
        sel += ':nth-of-type(' + idx + ')';
      }
    }
    parts.unshift(sel);
    current = current.parentElement;
  }
  return parts.join(' > ');
}

// Inject hover highlights, click handlers, and action toolbar into the preview iframe
function injectClickToEdit() {
  var iframe = document.getElementById('editor-preview-iframe');
  if (!iframe) return;
  try {
    var doc = iframe.contentDocument || iframe.contentWindow.document;
    if (!doc || !doc.body) return;

    // Remove previous injection if any (e.g. after preview refresh)
    ['cms-click-to-edit-css', 'cms-action-toolbar'].forEach(function(id) {
      var old = doc.getElementById(id);
      if (old) old.remove();
    });
    // Disconnect any previous MutationObserver
    if (window._cmsObserver) { window._cmsObserver.disconnect(); window._cmsObserver = null; }

    // Apply hidden elements CSS
    var hiddenCss = doc.getElementById('cms-hidden-elements-css');
    if (hiddenCss) hiddenCss.remove();
    if (hiddenElements.length > 0) {
      var hideStyle = doc.createElement('style');
      hideStyle.id = 'cms-hidden-elements-css';
      hideStyle.textContent = hiddenElements.map(function(sel) {
        return sel + ' { display: none !important; }';
      }).join('\n');
      doc.head.appendChild(hideStyle);
    }

    // Inject highlight + toolbar CSS
    var style = doc.createElement('style');
    style.id = 'cms-click-to-edit-css';
    style.textContent = [
      '[data-cms-edit], [data-cms-orphan] { cursor: pointer !important; transition: outline 0.15s ease, box-shadow 0.15s ease; }',
      '[data-cms-edit]:hover, [data-cms-orphan]:hover { outline: 2px solid rgba(56,189,248,0.75) !important; outline-offset: 3px; box-shadow: 0 0 0 6px rgba(56,189,248,0.12) !important; border-radius: 4px; }',
      '[data-cms-edit]:hover::after { content: attr(data-cms-label); position: absolute; top: -22px; left: 0; background: #0ea5e9; color: #fff; font-size: 10px; font-weight: 600; padding: 2px 7px; border-radius: 3px; white-space: nowrap; z-index: 99999; pointer-events: none; font-family: -apple-system, BlinkMacSystemFont, sans-serif; line-height: 1.4; }',
      '[data-cms-orphan]:hover::after { content: attr(data-cms-label); position: absolute; top: -22px; left: 0; background: #f59e0b; color: #fff; font-size: 10px; font-weight: 600; padding: 2px 7px; border-radius: 3px; white-space: nowrap; z-index: 99999; pointer-events: none; font-family: -apple-system, BlinkMacSystemFont, sans-serif; line-height: 1.4; }',
      '.cms-action-toolbar { position: fixed; z-index: 999999; display: flex; align-items: center; gap: 4px; background: #0D1525; border: 1px solid rgba(56,189,248,0.3); border-radius: 8px; padding: 4px 6px; box-shadow: 0 4px 16px rgba(0,0,0,0.4); font-family: -apple-system, BlinkMacSystemFont, sans-serif; pointer-events: all; }',
      '.cms-toolbar-btn { display: inline-flex; align-items: center; gap: 4px; padding: 5px 10px; border-radius: 5px; font-size: 11px; font-weight: 600; border: none; cursor: pointer; white-space: nowrap; transition: all 0.15s ease; font-family: inherit; line-height: 1.2; }',
      '.cms-toolbar-edit { background: rgba(56,189,248,0.15); color: #38BDF8; }',
      '.cms-toolbar-edit:hover { background: rgba(56,189,248,0.25); }',
      '.cms-toolbar-delete { background: rgba(239,68,68,0.12); color: #EF4444; }',
      '.cms-toolbar-delete:hover { background: rgba(239,68,68,0.22); }',
      '.cms-toolbar-save { background: rgba(34,197,94,0.15); color: #22C55E; }',
      '.cms-toolbar-save:hover { background: rgba(34,197,94,0.25); }',
      '.cms-toolbar-cancel { background: rgba(148,163,184,0.1); color: #94A3B8; }',
      '.cms-toolbar-cancel:hover { background: rgba(148,163,184,0.18); color: #e2e8f0; }',
      '.cms-toolbar-label { font-size: 10px; color: #94A3B8; padding: 0 4px; max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }',
      '.cms-el-active { outline: 2px solid rgba(56,189,248,0.7) !important; outline-offset: 2px; box-shadow: 0 0 0 6px rgba(56,189,248,0.1) !important; }',
      '.cms-inline-editing { outline: 2px solid #22C55E !important; outline-offset: 2px !important; box-shadow: 0 0 0 6px rgba(34,197,94,0.12) !important; cursor: text !important; min-width: 20px; min-height: 1em; white-space: pre-wrap; }',
      '.cms-inline-editing:focus { outline: 2px solid #22C55E !important; }',
      '.cms-inline-editing:hover { outline: 2px solid #22C55E !important; box-shadow: 0 0 0 6px rgba(34,197,94,0.12) !important; }',
      '.cms-inline-editing:hover::after { display: none !important; content: none !important; }',
      // Clickable overlay for elements with CSS background-image (hero-bg, sections)
      '.cms-bg-overlay { position: absolute; inset: 0; z-index: 10; cursor: pointer; }',
    ].join('\n');
    doc.head.appendChild(style);

    // Create the shared toolbar element (hidden until element is clicked)
    var toolbar = doc.createElement('div');
    toolbar.id = 'cms-action-toolbar';
    toolbar.className = 'cms-action-toolbar';
    toolbar.style.display = 'none';
    toolbar.innerHTML =
      '<span class="cms-toolbar-label" id="cms-tb-label"></span>' +
      // Normal mode buttons
      '<button class="cms-toolbar-btn cms-toolbar-edit" id="cms-tb-edit" title="Edit in sidebar">&#9998; Edit</button>' +
      '<button class="cms-toolbar-btn cms-toolbar-delete" id="cms-tb-delete" title="Delete element">&#128465; Delete</button>' +
      // Inline edit mode buttons (hidden by default)
      '<button class="cms-toolbar-btn cms-toolbar-save" id="cms-tb-save" style="display:none" title="Save changes">&#10003; Done</button>' +
      '<button class="cms-toolbar-btn cms-toolbar-cancel" id="cms-tb-cancel" style="display:none" title="Cancel editing">&#10005; Cancel</button>';
    doc.body.appendChild(toolbar);

    var activeEl = null;       // currently selected element
    var inlineEditEl = null;   // element currently being inline-edited
    var inlineOrigText = '';   // original text before inline editing began
    var inlineEditKey = null;  // cmsKey being inline-edited

    // ── Helper: detect if a CMS key refers to a text (not image) field ──
    function isTextKey(cmsKey) {
      if (!cmsKey) return false;
      if (cmsKey.endsWith('_image') || cmsKey === 'hero_bg_image' || cmsKey === 'about_image') return false;
      return true;
    }

    // ── Start inline editing on a text element ──
    function startInlineEdit(el, cmsKey) {
      // If already editing something else, finish it first
      if (inlineEditEl && inlineEditEl !== el) {
        finishInlineEdit(true);
      }

      inlineEditEl = el;
      inlineEditKey = cmsKey;
      inlineOrigText = el.textContent;

      // Disable hover tooltip and click-to-edit cursor during editing
      el.removeAttribute('data-cms-label'); // suppress hover tooltip
      el.classList.remove('cms-el-active');
      el.classList.add('cms-inline-editing');

      // Enable contenteditable
      el.contentEditable = 'true';
      el.focus();

      // Place cursor at end
      try {
        var range = doc.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = doc.defaultView.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      } catch (e) {}

      // Switch toolbar to inline mode
      var tbLabel = doc.getElementById('cms-tb-label');
      var tbEdit = doc.getElementById('cms-tb-edit');
      var tbDelete = doc.getElementById('cms-tb-delete');
      var tbSave = doc.getElementById('cms-tb-save');
      var tbCancel = doc.getElementById('cms-tb-cancel');

      tbLabel.textContent = 'Editing…';
      tbEdit.style.display = 'none';
      tbDelete.style.display = 'none';
      tbSave.style.display = '';
      tbCancel.style.display = '';

      // Position toolbar above element
      positionToolbarAbove(el);
      toolbar.style.display = 'flex';

      // Live-sync to parent as user types
      el._cmsInputHandler = function() {
        window.parent.postMessage({ type: 'cms-inline-text-live', cmsKey: inlineEditKey, value: el.textContent }, '*');
        positionToolbarAbove(el);
      };
      el.addEventListener('input', el._cmsInputHandler);

      // Enter key = save (except for multiline fields like textarea-mapped)
      el._cmsKeyHandler = function(ev) {
        if (ev.key === 'Escape') { ev.preventDefault(); finishInlineEdit(false); }
        // Ctrl+Enter or Enter to save for single-line fields
        if (ev.key === 'Enter' && !ev.shiftKey) {
          // Allow shift+enter for multiline, but single Enter saves for one-line elements
          var tag = el.tagName.toUpperCase();
          var isMultiline = (tag === 'P' || tag === 'DIV') && el.offsetHeight > 50;
          if (!isMultiline) { ev.preventDefault(); finishInlineEdit(true); }
        }
      };
      el.addEventListener('keydown', el._cmsKeyHandler);

      // Blur = save (with small delay to allow button clicks)
      el._cmsBlurHandler = function() {
        setTimeout(function() {
          // Only save if not clicking a toolbar button
          if (inlineEditEl === el && !document.activeElement.closest('#cms-action-toolbar')) {
            finishInlineEdit(true);
          }
        }, 150);
      };
      el.addEventListener('blur', el._cmsBlurHandler);

      // Wire save/cancel buttons
      tbSave.onclick = function(ev) { ev.stopPropagation(); finishInlineEdit(true); };
      tbCancel.onclick = function(ev) { ev.stopPropagation(); finishInlineEdit(false); };
    }

    // ── Finish inline editing ──
    function finishInlineEdit(save) {
      if (!inlineEditEl) return;
      var el = inlineEditEl;
      var cmsKey = inlineEditKey;
      var newText = el.textContent;

      // Clean up event listeners
      if (el._cmsInputHandler) { el.removeEventListener('input', el._cmsInputHandler); el._cmsInputHandler = null; }
      if (el._cmsKeyHandler) { el.removeEventListener('keydown', el._cmsKeyHandler); el._cmsKeyHandler = null; }
      if (el._cmsBlurHandler) { el.removeEventListener('blur', el._cmsBlurHandler); el._cmsBlurHandler = null; }

      // Disable contenteditable
      el.contentEditable = 'false';
      el.classList.remove('cms-inline-editing');

      // Restore data-cms-label
      var label = cmsKey.replace(/_/g, ' ').replace(/\b\w/g, function(c) { return c.toUpperCase(); });
      el.setAttribute('data-cms-label', 'Edit: ' + label);

      if (save) {
        // Notify parent to update editorContent and sidebar field
        window.parent.postMessage({ type: 'cms-inline-text-update', cmsKey: cmsKey, value: newText }, '*');
      } else {
        // Restore original text
        el.textContent = inlineOrigText;
        // Notify parent to restore (undo any live updates)
        window.parent.postMessage({ type: 'cms-inline-text-update', cmsKey: cmsKey, value: inlineOrigText }, '*');
      }

      inlineEditEl = null;
      inlineEditKey = null;
      inlineOrigText = '';

      // Hide toolbar
      toolbar.style.display = 'none';
      activeEl = null;
    }

    // ── Position toolbar just above an element ──
    function positionToolbarAbove(el) {
      var rect = el.getBoundingClientRect();
      var tbHeight = 36;
      var topPos = rect.top - tbHeight - 8;
      if (topPos < 4) topPos = rect.bottom + 8;
      toolbar.style.top = topPos + 'px';
      toolbar.style.left = Math.max(4, Math.min(rect.left, doc.documentElement.clientWidth - 200)) + 'px';
    }

    function showToolbar(el) {
      // If currently inline-editing a different element, save it first
      if (inlineEditEl && inlineEditEl !== el) finishInlineEdit(true);

      // Deselect previous
      if (activeEl) activeEl.classList.remove('cms-el-active');
      activeEl = el;

      var cmsKey = el.getAttribute('data-cms-edit');
      var orphanSel = el.getAttribute('data-cms-orphan');
      var label = el.getAttribute('data-cms-label') || 'Element';

      // ── TEXT ELEMENT: enter inline edit mode immediately ──
      if (cmsKey && isTextKey(cmsKey)) {
        startInlineEdit(el, cmsKey);
        return;
      }

      // ── IMAGE / ORPHAN ELEMENT: show normal Edit/Delete toolbar ──
      el.classList.add('cms-el-active');

      var tbLabel = doc.getElementById('cms-tb-label');
      var tbEdit = doc.getElementById('cms-tb-edit');
      var tbDelete = doc.getElementById('cms-tb-delete');
      var tbSave = doc.getElementById('cms-tb-save');
      var tbCancel = doc.getElementById('cms-tb-cancel');

      tbLabel.textContent = label.replace('Edit: ', '').replace('Element: ', '');
      tbEdit.style.display = cmsKey ? '' : 'none';
      tbDelete.style.display = '';
      tbSave.style.display = 'none';
      tbCancel.style.display = 'none';

      positionToolbarAbove(el);
      toolbar.style.display = 'flex';

      // Wire up edit button (sidebar navigation for images)
      tbEdit.onclick = function(ev) {
        ev.stopPropagation();
        if (cmsKey) {
          window.parent.postMessage({ type: 'cms-click-to-edit', cmsKey: cmsKey }, '*');
        }
      };

      // Wire up delete button
      tbDelete.onclick = function(ev) {
        ev.stopPropagation();
        if (cmsKey) {
          el.style.display = 'none';
          toolbar.style.display = 'none';
          activeEl = null;
          window.parent.postMessage({ type: 'cms-element-delete', cmsKey: cmsKey }, '*');
        } else if (orphanSel) {
          el.style.display = 'none';
          var parent = el.parentElement;
          if (parent && parent.children.length === 1 && parent !== doc.body) {
            parent.style.display = 'none';
            var parentSel = parent.getAttribute('data-cms-orphan');
            if (parentSel) orphanSel = parentSel;
          }
          toolbar.style.display = 'none';
          activeEl = null;
          window.parent.postMessage({ type: 'cms-element-delete', selector: orphanSel }, '*');
        }
      };
    }

    function hideToolbar() {
      // If inline editing, finish it first
      if (inlineEditEl) { finishInlineEdit(true); return; }
      toolbar.style.display = 'none';
      if (activeEl) activeEl.classList.remove('cms-el-active');
      activeEl = null;
    }

    // ── Helper: check if element has a visible CSS background image ──
    function hasBackgroundImage(el) {
      if (!el || !el.style) return false;
      // Check inline style first (faster)
      if (el.style.backgroundImage && el.style.backgroundImage !== 'none' && el.style.backgroundImage !== '') return true;
      // Check computed style
      try {
        var computed = doc.defaultView.getComputedStyle(el);
        var bg = computed.backgroundImage;
        return bg && bg !== 'none' && bg !== '';
      } catch (e) { return false; }
    }

    // ── Tag a single element (CMS or orphan) ──
    function tagElement(el) {
      if (!el || !el.tagName) return;
      var tag = el.tagName.toUpperCase();
      // Skip non-visual elements
      if (tag === 'LINK' || tag === 'SCRIPT' || tag === 'META' || tag === 'STYLE' || tag === 'HEAD' || tag === 'HTML') return;
      // Skip toolbar and lightbox internals
      if (el.closest && el.closest('#cms-action-toolbar')) return;
      if (el.closest && el.closest('#lb-overlay')) return;
      // Skip already-tagged elements
      if (el.hasAttribute('data-cms-edit') || el.hasAttribute('data-cms-orphan')) return;

      // Check if this is a CMS-mapped element
      if (el.id && el.id.startsWith('cms-')) {
        var cmsKey = CMS_DOM_REVERSE[el.id];
        if (cmsKey) {
          var label = cmsKey.replace(/_/g, ' ').replace(/\b\w/g, function(c) { return c.toUpperCase(); });
          el.setAttribute('data-cms-edit', cmsKey);
          el.setAttribute('data-cms-label', 'Edit: ' + label);
          el.style.position = el.style.position || 'relative';
          return;
        }
      }

      // Otherwise check if it's a visual element worth tagging as orphan
      var isImg = tag === 'IMG';
      var isVideo = tag === 'VIDEO';
      var isSvg = tag === 'SVG';
      var hasBg = hasBackgroundImage(el);
      var hasLogoClass = el.className && typeof el.className === 'string' && (el.className.indexOf('logo') !== -1 || el.className.indexOf('brand') !== -1);
      var isSection = tag === 'SECTION';

      if (!isImg && !isVideo && !isSvg && !hasBg && !hasLogoClass && !isSection) return;

      // Skip very small or hidden elements
      var rect = el.getBoundingClientRect();
      if (rect.width < 15 && rect.height < 15) return;

      var selector = generateSelector(el, doc);
      var classes = Array.from(el.classList || []).slice(0, 2).join(' ');
      var labelText = classes || (el.alt) || tag.toLowerCase();
      if (hasBg && !isImg) labelText = (classes || tag.toLowerCase()) + ' (bg)';
      labelText = 'Element: ' + labelText.replace(/[-_]/g, ' ').replace(/\b\w/g, function(c) { return c.toUpperCase(); });

      el.setAttribute('data-cms-orphan', selector);
      el.setAttribute('data-cms-label', labelText);
      el.style.position = el.style.position || 'relative';
    }

    // ── Tag all elements in the document ──
    function tagAllElements() {
      // 1. CMS-mapped elements (by id)
      doc.querySelectorAll('[id^="cms-"]').forEach(tagElement);

      // 2. Orphan images, videos, logos, brand elements
      var orphanSelectors = 'img, video, svg, [class*="logo"], [class*="brand"], section';
      doc.querySelectorAll(orphanSelectors).forEach(tagElement);

      // 3. Elements with CSS background-image (sections, hero-bg, fleet cards, etc.)
      doc.querySelectorAll('div, section, header, footer, aside, main, article').forEach(function(el) {
        if (el.hasAttribute('data-cms-edit') || el.hasAttribute('data-cms-orphan')) return;
        if (hasBackgroundImage(el)) {
          tagElement(el);
        }
      });

      // 4. Tag non-CMS text elements for inline editing
      // These are headings, paragraphs, labels etc. that don't have cms- IDs
      var TEXT_ORPHAN_TAGS = ['H1','H2','H3','H4','H5','H6','P','BUTTON','A'];
      var textOrphanIdx = 0;
      // Walk in DOM order for stable ordinal indices
      var walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_ELEMENT, null, false);
      var node = walker.nextNode();
      while (node) {
        var ntag = node.tagName.toUpperCase();
        if (TEXT_ORPHAN_TAGS.indexOf(ntag) !== -1) {
          // Skip already-tagged elements
          if (!node.hasAttribute('data-cms-edit') && !node.hasAttribute('data-cms-orphan')) {
            // Skip toolbar internals and script/style containers
            var skip = false;
            if (node.closest) {
              if (node.closest('#cms-action-toolbar, script, style, noscript, [data-cms-edit], [data-cms-orphan]')) skip = true;
            }
            // Skip empty or whitespace-only text
            if (!node.textContent.trim()) skip = true;
            // Skip very small hidden elements
            if (!skip) {
              var rect = node.getBoundingClientRect();
              if (rect.width < 5 && rect.height < 5) skip = true;
            }
            if (!skip) {
              var key = 'orphan_text_' + textOrphanIdx;
              var preview = node.textContent.trim().substring(0, 28);
              if (node.textContent.trim().length > 28) preview += '…';
              var labelText = 'Edit ' + ntag.charAt(0) + ntag.slice(1).toLowerCase() + ': ' + preview;
              node.setAttribute('data-cms-edit', key);
              node.setAttribute('data-cms-label', labelText);
              node.style.position = node.style.position || 'relative';
              textOrphanIdx++;
            }
          }
        }
        node = walker.nextNode();
      }
    }

    // Initial tagging
    tagAllElements();

    // ── Make hero-bg clickable by adding a transparent overlay ──
    // The hero-bg div is position:absolute behind hero-content, so clicks never reach it.
    // We add a small clickable indicator on the hero section.
    var heroBg = doc.getElementById('cms-hero-bg');
    if (heroBg && heroBg.hasAttribute('data-cms-edit')) {
      // The hero section parent needs a clickable zone for the background
      var heroSection = heroBg.closest('section') || heroBg.parentElement;
      if (heroSection) {
        var bgIndicator = doc.createElement('div');
        bgIndicator.className = 'cms-bg-overlay';
        bgIndicator.setAttribute('data-cms-edit', heroBg.getAttribute('data-cms-edit'));
        bgIndicator.setAttribute('data-cms-label', heroBg.getAttribute('data-cms-label'));
        bgIndicator.style.cssText = 'position:absolute;top:0;left:0;right:0;height:60px;z-index:10;cursor:pointer;background:transparent;';
        bgIndicator.title = 'Click to edit hero background image';
        heroSection.style.position = heroSection.style.position || 'relative';
        heroSection.insertBefore(bgIndicator, heroSection.firstChild);
      }
    }

    // ── Event delegation: handle ALL clicks via a single document listener ──
    // This catches dynamically created elements (fleet/instructor images rebuilt by JS)
    doc.addEventListener('click', function(e) {
      var target = e.target;

      // Skip toolbar clicks
      if (target.closest && target.closest('.cms-action-toolbar')) return;

      // Walk up from clicked element to find a tagged ancestor
      var el = target;
      while (el && el !== doc.body && el !== doc.documentElement) {
        if (el.hasAttribute('data-cms-edit') || el.hasAttribute('data-cms-orphan')) {
          // If this element is already being inline-edited, let the browser handle it (cursor placement)
          if (inlineEditEl === el) return;
          e.preventDefault();
          e.stopPropagation();
          showToolbar(el);
          return;
        }
        el = el.parentElement;
      }

      // If we reach an untagged img or bg element, tag it on-the-fly and show toolbar
      el = target;
      while (el && el !== doc.body && el !== doc.documentElement) {
        var shouldTag = false;
        if (el.tagName === 'IMG' || el.tagName === 'VIDEO') shouldTag = true;
        if (hasBackgroundImage(el)) shouldTag = true;
        if (el.className && typeof el.className === 'string' && (el.className.indexOf('logo') !== -1 || el.className.indexOf('brand') !== -1)) shouldTag = true;
        if (el.tagName === 'SECTION') shouldTag = true;

        if (shouldTag) {
          // Skip toolbar and lightbox
          if (el.closest && (el.closest('#cms-action-toolbar') || el.closest('#lb-overlay'))) break;
          var rect = el.getBoundingClientRect();
          if (rect.width >= 15 && rect.height >= 15) {
            tagElement(el);
            if (el.hasAttribute('data-cms-edit') || el.hasAttribute('data-cms-orphan')) {
              e.preventDefault();
              e.stopPropagation();
              showToolbar(el);
              return;
            }
          }
        }
        el = el.parentElement;
      }

      // Click on empty space — hide toolbar
      hideToolbar();
    }, true); // Use capture phase to intercept before other handlers

    // ── MutationObserver: auto-tag new elements added to the DOM ──
    // Fleet and instructor grids are rebuilt dynamically by JS after page load.
    // This observer catches those new elements and tags them immediately.
    var observer = new MutationObserver(function(mutations) {
      var needsRetagging = false;
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          mutation.addedNodes.forEach(function(node) {
            if (node.nodeType === 1) { // Element node
              tagElement(node);
              // Also tag children of the added node
              if (node.querySelectorAll) {
                node.querySelectorAll('img, video, svg, [class*="logo"], [class*="brand"], [id^="cms-"], section').forEach(tagElement);
                // Check for background images on container elements
                node.querySelectorAll('div, section, header, footer').forEach(function(child) {
                  if (hasBackgroundImage(child)) tagElement(child);
                });
              }
              needsRetagging = true;
            }
          });
        }
      });
    });
    observer.observe(doc.body, { childList: true, subtree: true });
    window._cmsObserver = observer;

    // Canvas mode: inject drag & drop when active
    if (canvasModeActive) {
      injectCanvasMode(doc);
    }
  } catch (e) {
    // iframe access error — ignore
  }
}

// Force-open a specific editor accordion section
function openEditorSection(section) {
  document.querySelectorAll('.editor-section-btn').forEach(function(b) { b.classList.remove('active'); });
  document.querySelectorAll('.editor-fields').forEach(function(f) { f.classList.remove('open'); });
  var btn = document.getElementById('esb-' + section);
  var fields = document.getElementById('ef-' + section);
  if (btn) btn.classList.add('active');
  if (fields) fields.classList.add('open');
}

// Handle click-to-edit and canvas mode messages from the preview iframe
window.addEventListener('message', function(e) {
  if (!e.data) return;

  // Canvas mode: element moved
  if (e.data.type === 'cms-canvas-move') {
    var k = e.data.cmsKey, pos = e.data.pos;
    if (k && pos) {
      elementPositions[k] = Object.assign(elementPositions[k] || {}, pos);
      markEditorDirty();
    }
    return;
  }

  // Canvas mode: element resized
  if (e.data.type === 'cms-canvas-resize') {
    var k = e.data.cmsKey, pos = e.data.pos;
    if (k && pos) {
      elementPositions[k] = Object.assign(elementPositions[k] || {}, pos);
      markEditorDirty();
    }
    return;
  }

  // Canvas mode: element selected (no action needed in parent)
  if (e.data.type === 'cms-canvas-select') return;

  // Element deletion (from toolbar Delete button)
  if (e.data.type === 'cms-element-delete') {
    if (e.data.cmsKey) {
      // CMS-mapped element: clear its content value
      var delKey = e.data.cmsKey;
      editorContent[delKey] = '';
      // Also clear image URL and scale if it's an image
      if (delKey.endsWith('_image') || IMAGE_KEYS.includes(delKey)) {
        editorContent[delKey] = '';
        editorContent[delKey + '_scale'] = '100';
        // Clear the image preview in the editor panel
        var preview = document.getElementById('efpreview-' + delKey);
        if (preview) { preview.src = ''; preview.style.display = 'none'; }
      }
      // Clear the editor field value
      var field = document.getElementById('ef-' + delKey);
      if (field) field.value = '';
      // Add to hidden list as well so it hides even if content exists in HTML template
      var domId = CMS_DOM_MAP[delKey];
      if (domId) {
        var selector = '#' + domId;
        if (!hiddenElements.includes(selector)) hiddenElements.push(selector);
      }
      markEditorDirty();
      setEditorStatus('unsaved', 'Element deleted. Save to publish.');
    } else if (e.data.selector) {
      // Non-CMS element: add its selector to hidden list
      var sel = e.data.selector;
      if (!hiddenElements.includes(sel)) {
        hiddenElements.push(sel);
      }
      markEditorDirty();
      setEditorStatus('unsaved', 'Element deleted. Save to publish.');
    }
    return;
  }

  // Inline text update (committed save or cancel restore from inline editing)
  if (e.data.type === 'cms-inline-text-update') {
    var itKey = e.data.cmsKey;
    var itVal = e.data.value || '';
    if (!itKey) return;
    // Update editorContent
    editorContent[itKey] = itVal;
    // Update sidebar field if it exists
    var itField = document.getElementById('ef-' + itKey);
    if (itField) itField.value = itVal;
    // Mark dirty and show status
    markEditorDirty();
    setEditorStatus('unsaved', 'Text updated. Save & Publish to go live.');
    return;
  }

  // Inline text live sync (fires as user types — just update sidebar field without marking dirty)
  if (e.data.type === 'cms-inline-text-live') {
    var liveKey = e.data.cmsKey;
    var liveVal = e.data.value || '';
    if (!liveKey) return;
    var liveField = document.getElementById('ef-' + liveKey);
    if (liveField) liveField.value = liveVal;
    return;
  }

  // Click-to-edit (images only now — text elements use inline editing)
  if (e.data.type !== 'cms-click-to-edit') return;
  var cmsKey = e.data.cmsKey;
  if (!cmsKey) return;

  // Navigate to editor if not there already
  if (currentPage !== 'website-editor') navigate('website-editor');

  // Open the correct section
  var section = CMS_SECTION_MAP[cmsKey];
  if (section) openEditorSection(section);

  // Focus the field
  setTimeout(function() {
    var fieldId = IMAGE_KEYS.includes(cmsKey) ? 'efimg-' + cmsKey : 'ef-' + cmsKey;
    var field = document.getElementById(fieldId) || document.getElementById('efpreview-' + cmsKey) || document.getElementById('ef-' + cmsKey);
    if (field) {
      field.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if (field.focus) field.focus();
      // Flash highlight
      field.style.transition = 'box-shadow 0.3s ease';
      field.style.boxShadow = '0 0 0 3px rgba(56,189,248,0.5)';
      setTimeout(function() { field.style.boxShadow = ''; }, 1800);
    }
  }, 100);
});

// ─── INSTRUCTOR HOURS PAGE ────────────────────────────────

var ihPeriod = 'month';
var ihSortField = 'entry_date';
var ihSortDir = 'desc';
var ihActiveTab = 'hobbs';
var ihEntries = [];
// Anchor date: the "current" date for navigation (defaults to today)
var ihAnchor = new Date();

function ihPad(n) { return String(n).padStart(2, '0'); }
function ihFmt(d) { return d.getFullYear() + '-' + ihPad(d.getMonth()+1) + '-' + ihPad(d.getDate()); }

function getIHDateRange() {
  var d = new Date(ihAnchor);
  var start = null, end = null;
  if (ihPeriod === 'day') {
    start = end = ihFmt(d);
  } else if (ihPeriod === 'week') {
    var dow = d.getDay();
    var weekStart = new Date(d); weekStart.setDate(d.getDate() - dow);
    var weekEnd = new Date(d); weekEnd.setDate(d.getDate() + (6 - dow));
    start = ihFmt(weekStart); end = ihFmt(weekEnd);
  } else if (ihPeriod === 'month') {
    start = d.getFullYear() + '-' + ihPad(d.getMonth()+1) + '-01';
    var lastDay = new Date(d.getFullYear(), d.getMonth()+1, 0);
    end = ihFmt(lastDay);
  } else if (ihPeriod === 'year') {
    start = d.getFullYear() + '-01-01';
    end = d.getFullYear() + '-12-31';
  }
  return { start: start, end: end };
}

// Navigate to previous period
function ihNavPrev() {
  var d = new Date(ihAnchor);
  if (ihPeriod === 'day') { d.setDate(d.getDate() - 1); }
  else if (ihPeriod === 'week') { d.setDate(d.getDate() - 7); }
  else if (ihPeriod === 'month') { d.setMonth(d.getMonth() - 1); }
  else if (ihPeriod === 'year') { d.setFullYear(d.getFullYear() - 1); }
  ihAnchor = d;
  ihUpdateNavUI();
  loadInstructorHours();
}

// Navigate to next period
function ihNavNext() {
  var d = new Date(ihAnchor);
  if (ihPeriod === 'day') { d.setDate(d.getDate() + 1); }
  else if (ihPeriod === 'week') { d.setDate(d.getDate() + 7); }
  else if (ihPeriod === 'month') { d.setMonth(d.getMonth() + 1); }
  else if (ihPeriod === 'year') { d.setFullYear(d.getFullYear() + 1); }
  ihAnchor = d;
  ihUpdateNavUI();
  loadInstructorHours();
}

// Jump to today / current period
function ihNavToday() {
  ihAnchor = new Date();
  ihUpdateNavUI();
  loadInstructorHours();
}

// Called when the date input changes
function ihNavFromInput(type) {
  if (type === 'day') {
    var val = document.getElementById('ih-nav-day').value;
    if (val) { ihAnchor = new Date(val + 'T12:00:00'); }
  } else if (type === 'week') {
    var val = document.getElementById('ih-nav-week-input').value; // "2025-W24"
    if (val) {
      var parts = val.split('-W');
      var year = parseInt(parts[0]), week = parseInt(parts[1]);
      // ISO week to date: Jan 4 is always in week 1
      var jan4 = new Date(year, 0, 4);
      var dayOfWeek = jan4.getDay() || 7; // make Sunday=7
      var weekStart = new Date(jan4);
      weekStart.setDate(jan4.getDate() - (dayOfWeek - 1) + (week - 1) * 7);
      ihAnchor = weekStart;
    }
  } else if (type === 'month') {
    var val = document.getElementById('ih-nav-month-input').value; // "2025-06"
    if (val) { ihAnchor = new Date(val + '-15T12:00:00'); }
  } else if (type === 'year') {
    var val = document.getElementById('ih-nav-year').value;
    if (val) { ihAnchor = new Date(parseInt(val), 5, 15); } // mid-year
  }
  ihUpdateNavUI();
  loadInstructorHours();
}

// Update nav UI controls to reflect current ihAnchor + ihPeriod
function ihUpdateNavUI() {
  var nav = document.getElementById('ih-date-nav');
  if (!nav) return;
  // Hide entire nav for "all"
  nav.style.display = ihPeriod === 'all' ? 'none' : 'flex';
  if (ihPeriod === 'all') return;

  var d = new Date(ihAnchor);
  // Hide all pickers first
  var dayEl = document.getElementById('ih-nav-day');
  if (dayEl) dayEl.style.display = 'none';
  var weekWrap = document.getElementById('ih-nav-week-wrap');
  if (weekWrap) weekWrap.style.display = 'none';
  var monthWrap = document.getElementById('ih-nav-month-wrap');
  if (monthWrap) monthWrap.style.display = 'none';
  var yearEl = document.getElementById('ih-nav-year');
  if (yearEl) yearEl.style.display = 'none';

  var MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  if (ihPeriod === 'day') {
    if (dayEl) { dayEl.style.display = 'inline-block'; dayEl.value = ihFmt(d); }
  } else if (ihPeriod === 'week') {
    if (weekWrap) weekWrap.style.display = 'inline-block';
    // Compute ISO week string for the week input
    var dow = d.getDay();
    var weekStart = new Date(d); weekStart.setDate(d.getDate() - dow);
    var weekEnd = new Date(d); weekEnd.setDate(d.getDate() + (6 - dow));
    var label = document.getElementById('ih-nav-week-label');
    if (label) label.textContent = MONTHS[weekStart.getMonth()] + ' ' + weekStart.getDate() + ' – ' + MONTHS[weekEnd.getMonth()] + ' ' + weekEnd.getDate() + ', ' + weekEnd.getFullYear();
    // Set week input value (ISO week)
    var jan1 = new Date(d.getFullYear(), 0, 1);
    var isoWeek = Math.ceil(((d - jan1) / 86400000 + jan1.getDay() + 1) / 7);
    var weekInput = document.getElementById('ih-nav-week-input');
    if (weekInput) weekInput.value = d.getFullYear() + '-W' + ihPad(isoWeek);
  } else if (ihPeriod === 'month') {
    if (monthWrap) monthWrap.style.display = 'inline-block';
    var monthLabel = document.getElementById('ih-nav-month-label');
    if (monthLabel) monthLabel.textContent = MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    var monthInput = document.getElementById('ih-nav-month-input');
    if (monthInput) monthInput.value = d.getFullYear() + '-' + ihPad(d.getMonth()+1);
  } else if (ihPeriod === 'year') {
    if (yearEl) {
      yearEl.style.display = 'inline-block';
      // Populate year options if needed
      if (yearEl.options.length === 0) {
        var curYear = new Date().getFullYear();
        for (var y = curYear - 3; y <= curYear + 2; y++) {
          yearEl.innerHTML += '<option value="' + y + '">' + y + '</option>';
        }
      }
      yearEl.value = String(d.getFullYear());
    }
  }
}

function setIHTab(tab) {
  ihActiveTab = tab;
  document.querySelectorAll('.ih-tab-btn').forEach(function(btn) {
    var isActive = btn.dataset.tab === tab;
    btn.style.color = isActive ? 'var(--sky)' : 'var(--gray-400)';
    btn.style.borderBottomColor = isActive ? 'var(--sky)' : 'transparent';
    btn.style.fontWeight = isActive ? '700' : '600';
  });
  // Set default sort based on tab
  if (tab === 'hobbs') {
    ihSortField = 'aircraft_name';
    ihSortDir = 'asc';
  } else {
    ihSortField = 'instructor_name';
    ihSortDir = 'asc';
  }
  updateIHSortIndicators();
  renderIHTable(ihEntries);
}

function setIHPeriod(p) {
  ihPeriod = p;
  document.querySelectorAll('.ih-period-btn').forEach(function(btn) {
    btn.classList.toggle('active', btn.dataset.period === p);
  });
  ihUpdateNavUI();
  loadInstructorHours();
}

function sortIH(field) {
  if (ihSortField === field) {
    ihSortDir = ihSortDir === 'asc' ? 'desc' : 'asc';
  } else {
    ihSortField = field;
    ihSortDir = (field === 'entry_date' || field === 'instructor_name' || field === 'aircraft_name') ? 'desc' : 'asc';
  }
  renderIHTable(ihEntries);
  updateIHSortIndicators();
}

function updateIHSortIndicators() {
  ['entry_date','instructor_name','aircraft_name','hobbs_hrs','hobbs_charge','instruction_hours','instr_charge','total_billed'].forEach(function(f) {
    var el = document.getElementById('ih-sort-' + f);
    if (!el) return;
    if (f === ihSortField) {
      el.textContent = ihSortDir === 'asc' ? '↑' : '↓';
    } else {
      el.textContent = f === 'entry_date' ? '⇅' : '';
    }
  });
}

async function loadInstructorHoursPage() {
  var isAdminOrOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
  var isInstructor = currentUser.role === 'instructor';
  var filterWrap = document.getElementById('ih-filter-instructor-wrap');
  var ihInstructorGroup = document.getElementById('ih-instructor-group');
  // Show instructor filter for admins/owners and instructors; hide for students
  if (filterWrap) filterWrap.style.display = (isAdminOrOwner || isInstructor) ? '' : 'none';
  if (ihInstructorGroup) ihInstructorGroup.style.display = isAdminOrOwner ? '' : 'none';

  // Show/hide ground session instructor group
  var gsInstructorGroup = document.getElementById('gs-instructor-group');
  if (gsInstructorGroup) gsInstructorGroup.style.display = isAdminOrOwner ? '' : 'none';

  // Set default date in form
  var today = new Date().toISOString().slice(0,10);
  document.getElementById('ih-date').value = today;
  document.getElementById('gs-date').value = today;

  // Load prefill first (rates + aircraft + students)
  await loadIHPrefill();

  // Populate aircraft filter dropdown from prefill data (handles CMS fallback too)
  var acSel = document.getElementById('ih-filter-aircraft');
  if (acSel.options.length <= 1 && ihPrefillData.aircraft) {
    ihPrefillData.aircraft.forEach(function(a) {
      var val = a.id || ('cms_' + a.tail_number);
      acSel.innerHTML += '<option value="' + val + '">' + escHtml(a.tail_number) + ' — ' + escHtml(a.make_model) + '</option>';
    });
  }

  // Populate instructor filter dropdown
  var instrSel = document.getElementById('ih-filter-instructor');
  if (isAdminOrOwner) {
    // Admins/owners: see all instructors with "All Instructors" default
    if (instrSel.options.length <= 1) {
      allUsers.filter(function(u) { return ['instructor','admin','owner'].includes(u.role); }).forEach(function(u) {
        instrSel.innerHTML += '<option value="' + u.id + '">' + escHtml(u.name) + '</option>';
      });
    }
  } else if (isInstructor) {
    // Instructors: see only themselves, pre-selected (no "All" option)
    instrSel.innerHTML = '<option value="' + currentUser.id + '">' + escHtml(currentUser.name) + '</option>';
    instrSel.value = String(currentUser.id);
    instrSel.disabled = true;
  }

  // Init date nav UI
  ihAnchor = new Date();
  ihUpdateNavUI();

  // Load entries
  await loadInstructorHours();
}

var ihPrefillData = {};
var ihStudentList = [];
var ihEntriesCache = {}; // id → entry data for IH (flight) entries
var gsEntriesCache = {}; // id → entry data for ground session entries

async function loadIHPrefill(instructorId) {
  try {
    var url = '/api/instructor-hours/prefill';
    if (instructorId) url += '?instructor_id=' + instructorId;
    ihPrefillData = await api(url);

    // Fill aircraft dropdown in form
    var acSel = document.getElementById('ih-aircraft-id');
    // Only rebuild if needed
    if (acSel.options.length <= 1 && ihPrefillData.aircraft) {
      ihPrefillData.aircraft.forEach(function(a) {
        var val = a.id || ('cms_' + a.tail_number);
        acSel.innerHTML += '<option value="' + val + '" data-rate="' + (a.hourly_rate || 0) + '">' + escHtml(a.tail_number) + ' — ' + escHtml(a.make_model) + '</option>';
      });
    }

    // Fill instructor dropdown in submit form
    if ((currentUser.role === 'owner' || currentUser.role === 'admin')) {
      var ihInstrSel = document.getElementById('ih-instructor-id');
      if (ihInstrSel && ihInstrSel.options.length <= 1) {
        allUsers.filter(function(u) { return ['instructor','admin','owner'].includes(u.role); }).forEach(function(u) {
          ihInstrSel.innerHTML += '<option value="' + u.id + '">' + escHtml(u.name) + '</option>';
        });
        // Select current user by default
        ihInstrSel.value = String(currentUser.id);
      }
    }

    // Set instructor rate from profile
    if (ihPrefillData.instructor_rate != null) {
      document.getElementById('ih-instructor-rate').value = parseFloat(ihPrefillData.instructor_rate).toFixed(2);
    } else {
      document.getElementById('ih-instructor-rate').value = '';
    }
    updateIHTotal();

    // Store students for the student dropdown
    ihStudentList = ihPrefillData.students || [];

    // Populate ground session student dropdown
    var gsStudentSel = document.getElementById('gs-student-id');
    if (gsStudentSel) {
      gsStudentSel.innerHTML = '<option value="">Select student...</option>';
      (ihPrefillData.students || []).forEach(function(s) {
        gsStudentSel.innerHTML += '<option value="' + s.id + '">' + escHtml(s.name) + '</option>';
      });
    }

    // Populate ground session instructor dropdown (admin/owner only)
    if (currentUser.role === 'owner' || currentUser.role === 'admin') {
      var gsInstrSel = document.getElementById('gs-instructor-id');
      if (gsInstrSel && gsInstrSel.options.length <= 1) {
        allUsers.filter(function(u) { return ['instructor','admin','owner'].includes(u.role); }).forEach(function(u) {
          gsInstrSel.innerHTML += '<option value="' + u.id + '">' + escHtml(u.name) + '</option>';
        });
        gsInstrSel.value = String(currentUser.id);
      }
    }
  } catch(e) {
    // noop
  }
}

function onIHInstructorChange() {
  var instrId = document.getElementById('ih-instructor-id').value;
  loadIHPrefill(instrId);
}

function onIHAircraftChange() {
  var acSel = document.getElementById('ih-aircraft-id');
  var selectedOpt = acSel.options[acSel.selectedIndex];
  var rate = selectedOpt ? selectedOpt.dataset.rate : null;
  if (rate) {
    document.getElementById('ih-aircraft-rate').value = parseFloat(rate).toFixed(2);
  } else {
    document.getElementById('ih-aircraft-rate').value = '';
  }
  updateIHTotal();
}

function updateIHTotal() {
  var acHrs = parseFloat(document.getElementById('ih-aircraft-hours').value) || 0;
  var acRate = parseFloat(document.getElementById('ih-aircraft-rate').value) || 0;
  var inHrs = parseFloat(document.getElementById('ih-instruction-hours').value) || 0;
  var inRate = parseFloat(document.getElementById('ih-instructor-rate').value) || 0;
  var total = (acHrs * acRate) + (inHrs * inRate);
  var preview = document.getElementById('ih-total-preview');
  var valEl = document.getElementById('ih-total-value');
  if (preview && valEl) {
    preview.style.display = total > 0 ? '' : 'none';
    valEl.textContent = '$' + total.toFixed(2);
  }
}

// Wire up live total calculation
document.addEventListener('DOMContentLoaded', function() {
  ['ih-aircraft-hours','ih-aircraft-rate','ih-instruction-hours','ih-instructor-rate'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', updateIHTotal);
  });
  // Close student dropdown when clicking outside
  document.addEventListener('click', function(e) {
    var dd = document.getElementById('ih-student-dropdown');
    var inp = document.getElementById('ih-student-name');
    if (dd && inp && !dd.contains(e.target) && e.target !== inp) {
      dd.classList.add('hidden');
    }
  });
});

// Student dropdown functions
function showStudentDropdown() {
  filterStudentDropdown();
}

function filterStudentDropdown() {
  var input = document.getElementById('ih-student-name');
  var dd = document.getElementById('ih-student-dropdown');
  if (!input || !dd) return;
  var query = input.value.toLowerCase().trim();
  var filtered = ihStudentList.filter(function(s) {
    return !query || s.name.toLowerCase().includes(query);
  });
  if (filtered.length === 0 && !query) {
    dd.classList.add('hidden');
    return;
  }
  var html = '';
  filtered.forEach(function(s) {
    html += '<div class="ih-student-option" onclick="selectStudent(\'' + escHtml(s.name).replace(/'/g, "\\'") + '\')" style="padding:0.5rem 0.75rem;cursor:pointer;font-size:0.85rem;color:var(--gray-300);border-bottom:1px solid var(--border-light);transition:background 0.15s;" onmouseenter="this.style.background=\'var(--slate)\'" onmouseleave="this.style.background=\'transparent\'">' + escHtml(s.name) + '</div>';
  });
  if (query && filtered.length === 0) {
    html = '<div style="padding:0.5rem 0.75rem;font-size:0.8rem;color:var(--gray-500);font-style:italic;">No matching students — name will be saved as typed</div>';
  }
  dd.innerHTML = html;
  dd.classList.remove('hidden');
}

function selectStudent(name) {
  var input = document.getElementById('ih-student-name');
  if (input) input.value = name;
  var dd = document.getElementById('ih-student-dropdown');
  if (dd) dd.classList.add('hidden');
}

async function loadInstructorHours() {
  var params = new URLSearchParams();
  var range = getIHDateRange();
  if (range.start) params.set('start_date', range.start);
  if (range.end) params.set('end_date', range.end);

  var acFilter = document.getElementById('ih-filter-aircraft').value;
  // Only send numeric aircraft_id filter (skip CMS-sourced entries)
  if (acFilter && !acFilter.toString().startsWith('cms_')) params.set('aircraft_id', acFilter);

  // Apply instructor filter for admins/owners (user-selected) and instructors (pre-set to self)
  var instrFilterEl = document.getElementById('ih-filter-instructor');
  var instrFilterVal = instrFilterEl ? instrFilterEl.value : '';
  if (instrFilterVal) params.set('instructor_id', instrFilterVal);

  // Show "Clear All" button only for admin/owner when a specific instructor is filtered
  var clearBtn = document.getElementById('ih-clear-all-btn');
  if (clearBtn) {
    var isAdminOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
    clearBtn.style.display = (isAdminOwner && instrFilterVal) ? '' : 'none';
  }

  try {
    ihEntries = await api('/api/instructor-hours?' + params.toString());
    // Cache by id for edit modal lookup
    ihEntriesCache = {};
    ihEntries.forEach(function(e) { ihEntriesCache[e.id] = e; });
  } catch(e) {
    ihEntries = [];
    ihEntriesCache = {};
  }

  // Also fetch ground sessions with the same date/instructor filters
  var gsParams = new URLSearchParams();
  if (range.start) gsParams.set('start_date', range.start);
  if (range.end) gsParams.set('end_date', range.end);
  if (instrFilterVal) gsParams.set('instructor_id', instrFilterVal);

  var gsEntries = [];
  var rawGSData = [];
  try {
    var rawGS = await api('/api/ground-sessions?' + gsParams.toString());
    rawGSData = rawGS;
    // Cache raw GS data by id for edit modal lookup
    gsEntriesCache = {};
    rawGS.forEach(function(gs) { gsEntriesCache[gs.id] = gs; });
    // Transform ground sessions to match ihEntries format for unified rendering
    gsEntries = rawGS.map(function(gs) {
      return {
        id: gs.id,
        entry_type: 'ground',
        entry_date: gs.session_date,
        instructor_id: gs.instructor_id,
        instructor_name: gs.instructor_name,
        student_name: gs.student_name,
        tail_number: null,
        make_model: null,
        aircraft_hours: 0,
        instruction_hours: parseFloat(gs.ground_hours || 0),
        aircraft_rate: null,
        instructor_rate: gs.instructor_rate,
        total_billed: gs.instruction_charge_amount,
        notes: gs.notes,
      };
    });
  } catch(e) {
    gsEntries = [];
    gsEntriesCache = {};
  }

  // Combine: instructor hours + ground sessions (respect Ground checkbox)
  var showGround = document.getElementById('ih-filter-ground').checked;
  var allEntries = showGround ? ihEntries.concat(gsEntries) : ihEntries;

  renderIHStats(allEntries);
  renderIHTable(allEntries);
  updateIHSortIndicators();
}

function renderIHStats(entries) {
  var totalAcHrs = 0, totalHobbsCharge = 0, totalInHrs = 0, totalInstrCharge = 0, totalBilled = 0;
  entries.forEach(function(e) {
    totalAcHrs += parseFloat(e.aircraft_hours || 0);
    totalHobbsCharge += parseFloat(e.aircraft_hours || 0) * parseFloat(e.aircraft_rate || 0);
    totalInHrs += parseFloat(e.instruction_hours || 0);
    totalInstrCharge += parseFloat(e.instruction_hours || 0) * parseFloat(e.instructor_rate || 0);
    totalBilled += parseFloat(e.total_billed || 0);
  });
  var statsEl = document.getElementById('ih-stats');
  statsEl.innerHTML =
    '<div class="stat-card"><div class="stat-label">Entries</div><div class="stat-value">' + entries.length + '</div></div>' +
    '<div class="stat-card"><div class="stat-label">Hobbs Hrs</div><div class="stat-value" style="color:var(--sky)">' + totalAcHrs.toFixed(1) + '</div></div>' +
    '<div class="stat-card"><div class="stat-label">Hobbs Charge</div><div class="stat-value" style="color:var(--sky)">$' + totalHobbsCharge.toFixed(2) + '</div></div>' +
    '<div class="stat-card"><div class="stat-label">Instr Hrs</div><div class="stat-value" style="color:var(--amber)">' + totalInHrs.toFixed(1) + '</div></div>' +
    '<div class="stat-card"><div class="stat-label">Instr Charge</div><div class="stat-value" style="color:var(--amber)">$' + totalInstrCharge.toFixed(2) + '</div></div>' +
    '<div class="stat-card"><div class="stat-label">Total Billed</div><div class="stat-value" style="color:var(--green)">$' + totalBilled.toFixed(2) + '</div></div>';
}

function renderIHTable(entries) {
  var sorted = entries.slice().sort(function(a, b) {
    var va, vb;
    if (ihSortField === 'instr_charge') {
      va = parseFloat(a.instruction_hours || 0) * parseFloat(a.instructor_rate || 0);
      vb = parseFloat(b.instruction_hours || 0) * parseFloat(b.instructor_rate || 0);
    } else if (ihSortField === 'hobbs_charge') {
      va = parseFloat(a.aircraft_hours || 0) * parseFloat(a.aircraft_rate || 0);
      vb = parseFloat(b.aircraft_hours || 0) * parseFloat(b.aircraft_rate || 0);
    } else if (ihSortField === 'hobbs_hrs') {
      va = parseFloat(a.aircraft_hours || 0);
      vb = parseFloat(b.aircraft_hours || 0);
    } else if (ihSortField === 'total_billed') {
      va = parseFloat(a.total_billed || 0);
      vb = parseFloat(b.total_billed || 0);
    } else if (ihSortField === 'aircraft_name') {
      va = (a.tail_number || '').toString().toLowerCase();
      vb = (b.tail_number || '').toString().toLowerCase();
    } else if (ihSortField === 'instructor_name') {
      va = (a.instructor_name || '').toString().toLowerCase();
      vb = (b.instructor_name || '').toString().toLowerCase();
    } else {
      va = a[ihSortField]; vb = b[ihSortField];
      va = (va || '').toString().toLowerCase(); vb = (vb || '').toString().toLowerCase();
    }
    var cmp = va < vb ? -1 : va > vb ? 1 : 0;
    return ihSortDir === 'asc' ? cmp : -cmp;
  });

  var tbody = document.getElementById('ih-tbody');
  var tfoot = document.getElementById('ih-tfoot');
  var emptyEl = document.getElementById('ih-empty');
  var isAdminOrOwner = currentUser.role === 'owner' || currentUser.role === 'admin';

  if (!sorted.length) {
    tbody.innerHTML = '';
    if (tfoot) tfoot.innerHTML = '';
    if (emptyEl) emptyEl.classList.remove('hidden');
    return;
  }
  if (emptyEl) emptyEl.classList.add('hidden');

  // Show/hide instructor column based on role
  var isAdminOrOwnerView = currentUser.role === 'owner' || currentUser.role === 'admin';
  var instrColHeader = document.getElementById('ih-col-instructor');
  if (instrColHeader) instrColHeader.style.display = isAdminOrOwnerView ? '' : 'none';

  // Running totals for footer
  var footTotalAcHrs = 0, footTotalHobbsCharge = 0, footTotalInHrs = 0, footTotalInstrCharge = 0, footTotalBilled = 0;

  tbody.innerHTML = sorted.map(function(e) {
    var dateStr = e.entry_date ? e.entry_date.slice(0,10) : '—';
    var isGround = e.entry_type === 'ground';
    var acStr = isGround
      ? '<span class="tag" style="background:rgba(167,139,250,0.15);color:#a78bfa;border:1px solid rgba(167,139,250,0.3);">Ground</span>'
      : (e.tail_number ? ('<span style="font-weight:600">' + escHtml(e.tail_number) + '</span> <span style="color:var(--gray-400);font-size:0.8rem">' + escHtml(e.make_model || '') + '</span>') : '<span style="color:var(--gray-500)">—</span>');
    var acHrs = isGround ? '—' : parseFloat(e.aircraft_hours || 0).toFixed(1);
    var hobbsCharge = parseFloat(e.aircraft_hours || 0) * parseFloat(e.aircraft_rate || 0);
    var inHrs = parseFloat(e.instruction_hours || 0).toFixed(1);
    var instrCharge = parseFloat(e.instruction_hours || 0) * parseFloat(e.instructor_rate || 0);
    var totalBilled = parseFloat(e.total_billed || 0);
    var hobbsChargeStr = !isGround && hobbsCharge > 0
      ? '<span style="color:var(--sky);font-weight:600">$' + hobbsCharge.toFixed(2) + '</span>'
      : '<span style="color:var(--gray-500)">—</span>';
    var instrChargeStr = instrCharge > 0
      ? '<span style="color:var(--amber);font-weight:600">$' + instrCharge.toFixed(2) + '</span>'
      : '<span style="color:var(--gray-500)">—</span>';
    var totalBilledStr = totalBilled > 0
      ? '<span style="color:var(--green);font-weight:600">$' + totalBilled.toFixed(2) + '</span>'
      : '<span style="color:var(--gray-500)">—</span>';
    var instrNameTd = isAdminOrOwnerView ? '<td style="font-size:0.85rem">' + escHtml(e.instructor_name || '') + '</td>' : '';
    var studentStr = e.student_name ? escHtml(e.student_name) : '<span style="color:var(--gray-500)">—</span>';
    var canDelete = currentUser.role === 'owner' || currentUser.role === 'admin' || (currentUser.role === 'instructor' && e.instructor_id === currentUser.id);
    var canEdit = currentUser.role === 'owner' || currentUser.role === 'admin';
    var editBtn = canEdit
      ? (isGround
        ? '<button class="btn btn-sm btn-secondary" onclick="openEditGSModal(' + e.id + ')" title="Edit ground session" style="padding:0.25rem 0.5rem;font-size:0.75rem;">✏</button>'
        : '<button class="btn btn-sm btn-secondary" onclick="openEditIHModal(' + e.id + ')" title="Edit entry" style="padding:0.25rem 0.5rem;font-size:0.75rem;">✏</button>')
      : '';
    var deleteBtn = canDelete
      ? (isGround
        ? '<button class="btn btn-sm btn-danger" onclick="deleteGSEntry(' + e.id + ', \'' + escHtml(e.student_name || '') + '\', \'' + escHtml(dateStr) + '\')" title="Delete ground session" style="padding:0.25rem 0.5rem;font-size:0.75rem;">✕</button>'
        : '<button class="btn btn-sm btn-danger" onclick="deleteIHEntry(' + e.id + ', \'' + escHtml(e.student_name || '') + '\', \'' + escHtml(dateStr) + '\')" title="Delete entry" style="padding:0.25rem 0.5rem;font-size:0.75rem;">✕</button>')
      : '';
    var acHrsCell = !isGround && parseFloat(e.aircraft_hours || 0) > 0
      ? '<td style="color:var(--sky);font-weight:600">' + acHrs + '</td>'
      : '<td style="color:var(--gray-500)">—</td>';
    // Accumulate footer totals
    if (!isGround) {
      footTotalAcHrs += parseFloat(e.aircraft_hours || 0);
      footTotalHobbsCharge += hobbsCharge;
    }
    footTotalInHrs += parseFloat(e.instruction_hours || 0);
    footTotalInstrCharge += instrCharge;
    footTotalBilled += totalBilled;
    return '<tr>' +
      '<td style="white-space:nowrap;color:var(--gray-300)">' + escHtml(dateStr) + '</td>' +
      instrNameTd +
      '<td style="font-size:0.85rem">' + studentStr + '</td>' +
      '<td>' + acStr + '</td>' +
      acHrsCell +
      '<td>' + hobbsChargeStr + '</td>' +
      '<td style="color:var(--amber)">' + inHrs + '</td>' +
      '<td>' + instrChargeStr + '</td>' +
      '<td>' + totalBilledStr + '</td>' +
      '<td style="white-space:nowrap;display:flex;gap:0.3rem;">' + editBtn + deleteBtn + '</td>' +
      '</tr>';
  }).join('');

  // Render footer totals row
  if (tfoot) {
    var instrNameFootTd = isAdminOrOwnerView ? '<td></td>' : '';
    tfoot.innerHTML = '<tr style="border-top:2px solid var(--border-light);font-weight:700;font-size:0.85rem;color:var(--gray-300);">' +
      '<td style="padding-top:0.6rem;">Total</td>' +
      instrNameFootTd +
      '<td></td>' +
      '<td></td>' +
      '<td style="color:var(--sky);font-weight:700;padding-top:0.6rem;">' + footTotalAcHrs.toFixed(1) + '</td>' +
      '<td style="color:var(--sky);font-weight:700;padding-top:0.6rem;">$' + footTotalHobbsCharge.toFixed(2) + '</td>' +
      '<td style="color:var(--amber);padding-top:0.6rem;">' + footTotalInHrs.toFixed(1) + '</td>' +
      '<td style="color:var(--amber);padding-top:0.6rem;">$' + footTotalInstrCharge.toFixed(2) + '</td>' +
      '<td style="color:var(--green);font-weight:700;padding-top:0.6rem;">$' + footTotalBilled.toFixed(2) + '</td>' +
      '<td></td>' +
      '</tr>';
  }
}

function toggleIHForm() {
  var panel = document.getElementById('ih-form-panel');
  var btn = document.getElementById('ih-toggle-btn');
  var hidden = panel.classList.contains('hidden');
  panel.classList.toggle('hidden', !hidden);
  // Close GS form if opening this one
  if (hidden) {
    document.getElementById('gs-form-panel').classList.add('hidden');
    var gsBtn = document.getElementById('gs-toggle-btn');
    if (gsBtn) gsBtn.textContent = '+ Ground Session';
  }
  if (btn) btn.textContent = hidden ? '✕ Close' : '+ Log Hours';
}

async function submitIHEntry() {
  var errEl = document.getElementById('ih-form-error');
  if (errEl) errEl.classList.add('hidden');

  var isAdminOrOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
  var instructorId = isAdminOrOwner ? document.getElementById('ih-instructor-id').value : null;

  var aircraftVal = document.getElementById('ih-aircraft-id').value || null;
  // If it's a CMS-sourced entry (no real DB id), send null
  if (aircraftVal && aircraftVal.toString().startsWith('cms_')) aircraftVal = null;

  var body = {
    entry_date: document.getElementById('ih-date').value,
    aircraft_id: aircraftVal,
    aircraft_hours: parseFloat(document.getElementById('ih-aircraft-hours').value) || 0,
    instruction_hours: document.getElementById('ih-instruction-hours').value,
    aircraft_rate: document.getElementById('ih-aircraft-rate').value ? parseFloat(document.getElementById('ih-aircraft-rate').value) : null,
    instructor_rate: document.getElementById('ih-instructor-rate').value ? parseFloat(document.getElementById('ih-instructor-rate').value) : null,
    notes: document.getElementById('ih-notes').value || null,
    student_name: document.getElementById('ih-student-name').value.trim() || null,
  };

  if (instructorId) body.instructor_id = instructorId;

  if (!body.instruction_hours && body.instruction_hours !== 0) {
    if (errEl) { errEl.textContent = 'Instruction hours is required.'; errEl.classList.remove('hidden'); }
    return;
  }

  try {
    await api('/api/instructor-hours', { method: 'POST', body: JSON.stringify(body) });
    showToast('Hours entry saved', 'success');
    toggleIHForm();
    // Reset form
    document.getElementById('ih-aircraft-hours').value = '0';
    document.getElementById('ih-instruction-hours').value = '';
    document.getElementById('ih-notes').value = '';
    document.getElementById('ih-student-name').value = '';
    document.getElementById('ih-total-preview').style.display = 'none';
    await loadInstructorHours();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to save entry.'; errEl.classList.remove('hidden'); }
  }
}

async function deleteIHEntry(id, studentName, dateStr) {
  var who = studentName ? 'for ' + studentName : '';
  var when = dateStr ? ' on ' + dateStr : '';
  var msg = 'Delete this hours entry' + who + when + '?';
  if (!confirm(msg)) return;
  try {
    await api('/api/instructor-hours/' + id, { method: 'DELETE' });
    showToast('Entry deleted', 'success');
    await loadInstructorHours();
  } catch(e) {
    showToast(e.error || 'Failed to delete entry', 'error');
  }
}

// ─── GROUND SESSION FORM ──────────────────────────────────

function toggleGSForm() {
  var panel = document.getElementById('gs-form-panel');
  var btn = document.getElementById('gs-toggle-btn');
  if (!panel) return;
  var hidden = panel.classList.contains('hidden');
  panel.classList.toggle('hidden', !hidden);
  // Close the IH form if opening this one
  if (hidden) {
    document.getElementById('ih-form-panel').classList.add('hidden');
    var ihBtn = document.getElementById('ih-toggle-btn');
    if (ihBtn) ihBtn.textContent = '+ Log Hours';
  }
  if (btn) btn.textContent = hidden ? '✕ Close' : '+ Ground Session';
}

function onGSInstructorChange() {
  // When admin/owner switches instructor in GS form, update the charge preview
  updateGSCharge();
}

function updateGSCharge() {
  var hrs = parseFloat(document.getElementById('gs-hours').value) || 0;
  // Get instructor rate — for the selected instructor if admin, else current user's rate
  var isAdminOrOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
  var instrRate = null;
  if (isAdminOrOwner) {
    var instrId = document.getElementById('gs-instructor-id').value;
    if (instrId && allUsers) {
      var instrUser = allUsers.find(function(u) { return String(u.id) === String(instrId); });
      instrRate = instrUser ? instrUser.instructor_rate : null;
    }
  } else {
    instrRate = ihPrefillData.instructor_rate;
  }
  var preview = document.getElementById('gs-charge-preview');
  var valEl = document.getElementById('gs-charge-value');
  var noteEl = document.getElementById('gs-rate-note');
  if (preview && valEl) {
    if (hrs > 0 && instrRate != null) {
      var charge = hrs * parseFloat(instrRate);
      preview.style.display = '';
      valEl.textContent = '$' + charge.toFixed(2);
      if (noteEl) noteEl.textContent = '(' + hrs.toFixed(1) + ' hrs × $' + parseFloat(instrRate).toFixed(0) + '/hr)';
    } else if (hrs > 0) {
      preview.style.display = '';
      valEl.textContent = '$0.00';
      if (noteEl) noteEl.textContent = '(no instructor rate set)';
    } else {
      preview.style.display = 'none';
    }
  }
}

async function submitGSEntry() {
  var errEl = document.getElementById('gs-form-error');
  if (errEl) errEl.classList.add('hidden');

  var isAdminOrOwner = currentUser.role === 'owner' || currentUser.role === 'admin';
  var instructorId = isAdminOrOwner ? document.getElementById('gs-instructor-id').value : null;

  var studentId = document.getElementById('gs-student-id').value;
  var sessionDate = document.getElementById('gs-date').value;
  var groundHours = document.getElementById('gs-hours').value;
  var notes = document.getElementById('gs-notes').value.trim() || null;

  if (!studentId) {
    if (errEl) { errEl.textContent = 'Please select a student.'; errEl.classList.remove('hidden'); }
    return;
  }
  if (!groundHours || parseFloat(groundHours) <= 0) {
    if (errEl) { errEl.textContent = 'Ground hours must be greater than 0.'; errEl.classList.remove('hidden'); }
    return;
  }

  var body = {
    student_id: parseInt(studentId),
    session_date: sessionDate || new Date().toISOString().slice(0, 10),
    ground_hours: parseFloat(groundHours),
    notes: notes,
  };
  if (instructorId) body.instructor_id = instructorId;

  try {
    var result = await api('/api/ground-sessions', { method: 'POST', body: JSON.stringify(body) });
    var charge = parseFloat(result.instruction_charge_amount || 0).toFixed(2);
    var hrs = parseFloat(result.ground_hours).toFixed(1);
    showToast('Ground session saved — ' + hrs + ' hrs, $' + charge + ' charged', 'success');
    toggleGSForm();
    // Reset form
    document.getElementById('gs-student-id').value = '';
    document.getElementById('gs-hours').value = '';
    document.getElementById('gs-notes').value = '';
    document.getElementById('gs-charge-preview').style.display = 'none';
    await loadInstructorHours();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to save ground session.'; errEl.classList.remove('hidden'); }
  }
}

async function deleteGSEntry(id, studentName, dateStr) {
  var who = studentName ? ' for ' + studentName : '';
  var when = dateStr ? ' on ' + dateStr : '';
  var msg = 'Delete ground session' + who + when + '? This will also remove the associated billing charge from the student\'s account.';
  if (!confirm(msg)) return;
  try {
    await api('/api/ground-sessions/' + id, { method: 'DELETE' });
    showToast('Ground session deleted', 'success');
    await loadInstructorHours();
  } catch(e) {
    showToast(e.error || 'Failed to delete ground session', 'error');
  }
}

// ─── EDIT INSTRUCTOR HOURS ────────────────────────────────

function openEditIHModal(id) {
  var e = ihEntriesCache[id];
  if (!e) { showToast('Entry data not found — refresh the page', 'error'); return; }
  document.getElementById('edit-ih-id').value = id;
  document.getElementById('edit-ih-date').value = e.entry_date ? e.entry_date.slice(0,10) : '';
  document.getElementById('edit-ih-student').value = e.student_name || '';
  document.getElementById('edit-ih-aircraft-hours').value = parseFloat(e.aircraft_hours || 0).toFixed(1);
  document.getElementById('edit-ih-aircraft-rate').value = e.aircraft_rate != null ? parseFloat(e.aircraft_rate).toFixed(2) : '';
  document.getElementById('edit-ih-instruction-hours').value = parseFloat(e.instruction_hours || 0).toFixed(1);
  document.getElementById('edit-ih-instructor-rate').value = e.instructor_rate != null ? parseFloat(e.instructor_rate).toFixed(2) : '';
  document.getElementById('edit-ih-notes').value = e.notes || '';
  var errEl = document.getElementById('edit-ih-error');
  if (errEl) errEl.classList.add('hidden');
  updateEditIHPreview();
  document.getElementById('edit-ih-modal').classList.remove('hidden');
}

function closeEditIHModal() {
  document.getElementById('edit-ih-modal').classList.add('hidden');
}

function updateEditIHPreview() {
  var acHrs = parseFloat(document.getElementById('edit-ih-aircraft-hours').value) || 0;
  var acRate = parseFloat(document.getElementById('edit-ih-aircraft-rate').value) || 0;
  var inHrs = parseFloat(document.getElementById('edit-ih-instruction-hours').value) || 0;
  var inRate = parseFloat(document.getElementById('edit-ih-instructor-rate').value) || 0;
  var total = (acHrs * acRate) + (inHrs * inRate);
  var preview = document.getElementById('edit-ih-preview');
  var valEl = document.getElementById('edit-ih-preview-val');
  if (preview && valEl) {
    preview.style.display = total > 0 ? '' : 'none';
    valEl.textContent = '$' + total.toFixed(2);
  }
}

async function saveEditIH() {
  var errEl = document.getElementById('edit-ih-error');
  if (errEl) errEl.classList.add('hidden');
  var id = document.getElementById('edit-ih-id').value;
  var instrHours = document.getElementById('edit-ih-instruction-hours').value;
  if (!instrHours && instrHours !== '0') {
    if (errEl) { errEl.textContent = 'Instruction hours is required.'; errEl.classList.remove('hidden'); }
    return;
  }
  var body = {
    entry_date: document.getElementById('edit-ih-date').value || null,
    aircraft_hours: parseFloat(document.getElementById('edit-ih-aircraft-hours').value) || 0,
    instruction_hours: parseFloat(instrHours) || 0,
    aircraft_rate: document.getElementById('edit-ih-aircraft-rate').value ? parseFloat(document.getElementById('edit-ih-aircraft-rate').value) : null,
    instructor_rate: document.getElementById('edit-ih-instructor-rate').value ? parseFloat(document.getElementById('edit-ih-instructor-rate').value) : null,
    notes: document.getElementById('edit-ih-notes').value.trim() || null,
    student_name: document.getElementById('edit-ih-student').value.trim() || null,
  };
  try {
    await api('/api/instructor-hours/' + id, { method: 'PUT', body: JSON.stringify(body) });
    showToast('Entry updated', 'success');
    closeEditIHModal();
    await loadInstructorHours();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to update entry.'; errEl.classList.remove('hidden'); }
  }
}

// ─── EDIT GROUND SESSION ───────────────────────────────────

function openEditGSModal(id) {
  var gs = gsEntriesCache[id];
  if (!gs) { showToast('Session data not found — refresh the page', 'error'); return; }
  document.getElementById('edit-gs-id').value = id;
  document.getElementById('edit-gs-date').value = gs.session_date ? gs.session_date.slice(0,10) : '';
  document.getElementById('edit-gs-hours').value = parseFloat(gs.ground_hours || 0).toFixed(1);
  document.getElementById('edit-gs-notes').value = gs.notes || '';
  // Show student info
  var infoEl = document.getElementById('edit-gs-info');
  if (infoEl) infoEl.textContent = 'Student: ' + (gs.student_name || '—') + '  ·  Instructor Rate: ' + (gs.instructor_rate != null ? '$' + parseFloat(gs.instructor_rate).toFixed(0) + '/hr' : 'not set');
  var errEl = document.getElementById('edit-gs-error');
  if (errEl) errEl.classList.add('hidden');
  // Store instructor_rate for preview
  document.getElementById('edit-gs-modal').dataset.instrRate = gs.instructor_rate != null ? gs.instructor_rate : '';
  updateEditGSPreview();
  document.getElementById('edit-gs-modal').classList.remove('hidden');
}

function closeEditGSModal() {
  document.getElementById('edit-gs-modal').classList.add('hidden');
}

function updateEditGSPreview() {
  var hrs = parseFloat(document.getElementById('edit-gs-hours').value) || 0;
  var modal = document.getElementById('edit-gs-modal');
  var instrRate = modal ? parseFloat(modal.dataset.instrRate) : NaN;
  var preview = document.getElementById('edit-gs-preview');
  var valEl = document.getElementById('edit-gs-preview-val');
  var noteEl = document.getElementById('edit-gs-preview-note');
  if (preview && valEl) {
    if (hrs > 0 && !isNaN(instrRate)) {
      var charge = hrs * instrRate;
      preview.style.display = '';
      valEl.textContent = '$' + charge.toFixed(2);
      if (noteEl) noteEl.textContent = '(' + hrs.toFixed(1) + ' hrs × $' + instrRate.toFixed(0) + '/hr)';
    } else if (hrs > 0) {
      preview.style.display = '';
      valEl.textContent = '$0.00';
      if (noteEl) noteEl.textContent = '(no instructor rate set)';
    } else {
      preview.style.display = 'none';
    }
  }
}

async function saveEditGS() {
  var errEl = document.getElementById('edit-gs-error');
  if (errEl) errEl.classList.add('hidden');
  var id = document.getElementById('edit-gs-id').value;
  var hrs = document.getElementById('edit-gs-hours').value;
  if (!hrs || parseFloat(hrs) <= 0) {
    if (errEl) { errEl.textContent = 'Ground hours must be greater than 0.'; errEl.classList.remove('hidden'); }
    return;
  }
  var body = {
    session_date: document.getElementById('edit-gs-date').value || null,
    ground_hours: parseFloat(hrs),
    notes: document.getElementById('edit-gs-notes').value.trim() || null,
  };
  try {
    await api('/api/ground-sessions/' + id, { method: 'PUT', body: JSON.stringify(body) });
    showToast('Ground session updated', 'success');
    closeEditGSModal();
    await loadInstructorHours();
  } catch(e) {
    if (errEl) { errEl.textContent = e.error || 'Failed to update ground session.'; errEl.classList.remove('hidden'); }
  }
}

// ─── CLEAR ALL FOR INSTRUCTOR ──────────────────────────────

async function clearAllForInstructor() {
  var instrFilterEl = document.getElementById('ih-filter-instructor');
  var instrId = instrFilterEl ? instrFilterEl.value : '';
  if (!instrId) { showToast('Select a specific instructor to clear', 'error'); return; }
  // Get instructor name
  var instrName = 'this instructor';
  if (instrFilterEl && instrFilterEl.options[instrFilterEl.selectedIndex]) {
    instrName = instrFilterEl.options[instrFilterEl.selectedIndex].text || instrName;
  }
  var msg = 'Clear all logged hours for ' + instrName + '?\n\nThis permanently removes all their session records and associated billing charges. This cannot be undone.';
  if (!confirm(msg)) return;
  try {
    var ihRes = await api('/api/instructor-hours/clear?instructor_id=' + instrId, { method: 'DELETE' });
    var gsRes = await api('/api/ground-sessions/clear?instructor_id=' + instrId, { method: 'DELETE' });
    var total = (ihRes.deleted || 0) + (gsRes.deleted || 0);
    showToast('Cleared ' + total + ' entries for ' + instrName, 'success');
    await loadInstructorHours();
  } catch(e) {
    showToast(e.error || 'Failed to clear entries', 'error');
  }
}

// ─── END INSTRUCTOR HOURS PAGE ────────────────────────────

// ─── AT-RISK STUDENTS ─────────────────────────────────────

let atRiskData = [];
let atRiskSelectedStudentId = null;
let atRiskSelectedStudentName = '';

function riskBadgeHtml(level) {
  const labels = { low: 'Low', medium: 'Medium', high: 'High', critical: 'Critical' };
  return `<span class="risk-badge risk-${level}">${labels[level] || level}</span>`;
}

function riskBarHtml(score) {
  const colors = { low: '#FBBF24', medium: '#FB923C', high: '#F87171', critical: '#FCA5A5' };
  let color = '#FBBF24';
  if (score >= 85) color = colors.critical;
  else if (score >= 68) color = colors.high;
  else if (score >= 48) color = colors.medium;
  return `<div class="risk-bar-wrap"><div class="risk-bar" style="width:${score}%;background:${color}"></div></div>`;
}

async function loadAtRisk() {
  const tbody = document.getElementById('at-risk-tbody');
  const emptyEl = document.getElementById('at-risk-empty');
  tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray-500);padding:2rem">Loading...</td></tr>';
  emptyEl.classList.add('hidden');

  // Show threshold settings for owner/admin
  const settingsWrap = document.getElementById('at-risk-settings-wrap');
  if (settingsWrap) {
    const canEdit = ['owner','admin'].includes(currentUser.role);
    settingsWrap.classList.toggle('hidden', !canEdit);
    if (canEdit) {
      try {
        const thresholds = await api('/api/at-risk/thresholds');
        document.getElementById('thresh-low').value      = thresholds.at_risk_low_days      || 14;
        document.getElementById('thresh-medium').value   = thresholds.at_risk_medium_days   || 21;
        document.getElementById('thresh-high').value     = thresholds.at_risk_high_days     || 30;
        document.getElementById('thresh-critical').value = thresholds.at_risk_critical_days || 45;
      } catch {}
    }
  }

  try {
    const data = await api('/api/at-risk');
    atRiskData = data.students || [];

    // Populate instructor filter
    const instructorSel = document.getElementById('at-risk-filter-instructor');
    const instructors = [...new Set(atRiskData.map(s => s.instructor_name).filter(Boolean))];
    instructorSel.innerHTML = '<option value="">All Instructors</option>' +
      instructors.map(n => `<option value="${escHtml(n)}">${escHtml(n)}</option>`).join('');

    renderAtRiskTable();
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--red);padding:2rem">${err.error || 'Failed to load at-risk data'}</td></tr>`;
  }
}

function renderAtRiskTable() {
  const levelFilter      = document.getElementById('at-risk-filter-level').value;
  const instructorFilter = document.getElementById('at-risk-filter-instructor').value;
  const tbody            = document.getElementById('at-risk-tbody');
  const emptyEl          = document.getElementById('at-risk-empty');
  const countLabel       = document.getElementById('at-risk-count-label');
  const canOverride      = currentUser && ['owner','admin'].includes(currentUser.role);

  let filtered = atRiskData;
  if (levelFilter)      filtered = filtered.filter(s => (s.manual_override_level || s.risk_level) === levelFilter);
  if (instructorFilter) filtered = filtered.filter(s => s.instructor_name === instructorFilter);

  countLabel.textContent = `${filtered.length} student${filtered.length !== 1 ? 's' : ''}`;

  if (filtered.length === 0) {
    tbody.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  tbody.innerHTML = filtered.map(s => {
    const effectiveLevel = s.manual_override_level || s.risk_level;
    const daysText = s.days_since_last_flight >= 900
      ? '<span style="color:var(--gray-500)">No flights</span>'
      : `<span style="font-weight:600;color:var(--red)">${s.days_since_last_flight}d</span>`;
    const lastFlightText = s.last_flight_date
      ? new Date(s.last_flight_date).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })
      : '<span style="color:var(--gray-500)">—</span>';
    const isSelected = s.student_id === atRiskSelectedStudentId;

    const overrideBadge = s.manual_override_level
      ? `<span style="font-size:0.7rem;color:var(--amber);margin-left:0.3rem" title="Manually overridden${s.manual_override_notes ? ': ' + s.manual_override_notes : ''}">✎ override</span>`
      : '';

    // Override toggle for admin/owner
    const overrideControls = canOverride ? `
      <button class="btn btn-sm" style="padding:0.2rem 0.45rem;font-size:0.72rem;background:transparent;border:1px solid var(--border-light);color:var(--gray-300);border-radius:5px;cursor:pointer;margin-left:0.25rem" title="Toggle at-risk status" onclick="openAtRiskOverrideModal(${s.student_id},'${escHtml(s.student_name).replace(/'/g,"\\'")}','${effectiveLevel}')">&#9998;</button>` : '';

    return `<tr style="${isSelected ? 'background:rgba(56,189,248,0.04);' : ''}">
      <td style="font-weight:600">${escHtml(s.student_name)}</td>
      <td>${riskBadgeHtml(effectiveLevel)}${overrideBadge}</td>
      <td>${riskBarHtml(s.risk_score)} <span style="font-size:0.75rem;color:var(--gray-400)">${s.risk_score}</span></td>
      <td>${daysText}</td>
      <td style="font-size:0.82rem">${lastFlightText}</td>
      <td style="font-size:0.82rem;color:var(--gray-400)">${escHtml(s.instructor_name || 'Unassigned')}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-secondary btn-sm" onclick="openInterventionPanel(${s.student_id},'${escHtml(s.student_name).replace(/'/g,"\\'")}')">Log</button>${overrideControls}
      </td>
    </tr>`;
  }).join('');
}

// ─── AT-RISK OVERRIDE MODAL ──────────────────────────────
function openAtRiskOverrideModal(studentId, studentName, currentLevel) {
  document.getElementById('at-risk-override-student-id').value = studentId;
  document.getElementById('at-risk-override-student-name').textContent = studentName;
  document.getElementById('at-risk-override-level').value = currentLevel || '';
  document.getElementById('at-risk-override-notes').value = '';
  document.getElementById('at-risk-override-modal').classList.remove('hidden');
}

function closeAtRiskOverrideModal() {
  document.getElementById('at-risk-override-modal').classList.add('hidden');
}

async function saveAtRiskOverride() {
  const studentId = document.getElementById('at-risk-override-student-id').value;
  const level     = document.getElementById('at-risk-override-level').value;
  const notes     = document.getElementById('at-risk-override-notes').value.trim();
  try {
    await api(`/api/at-risk/${studentId}/override`, {
      method: 'PATCH',
      body: JSON.stringify({ level: level || null, notes: notes || null })
    });
    closeAtRiskOverrideModal();
    await loadAtRisk();
  } catch (err) {
    alert(err.error || 'Failed to save override');
  }
}

async function openInterventionPanel(studentId, studentName) {
  atRiskSelectedStudentId = studentId;
  atRiskSelectedStudentName = studentName;
  renderAtRiskTable(); // re-render to highlight selected row

  const panel = document.getElementById('at-risk-intervention-panel');
  const title = document.getElementById('at-risk-panel-title');
  title.textContent = `Interventions — ${studentName}`;
  panel.classList.remove('hidden');

  // Reset form
  document.getElementById('intervention-type-sel').value    = 'Check-in call';
  document.getElementById('intervention-outcome-sel').value = '';
  document.getElementById('intervention-notes').value       = '';

  await loadInterventionHistory(studentId);
  panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeInterventionPanel() {
  atRiskSelectedStudentId = null;
  document.getElementById('at-risk-intervention-panel').classList.add('hidden');
  renderAtRiskTable();
}

// ─── DISCOVERY FLIGHT LEADS (admin/owner) ─────────────────

async function loadLeads() {
  const tbody = document.getElementById('leads-tbody');
  const emptyEl = document.getElementById('leads-empty');
  const listEl = document.getElementById('leads-list');
  const filter = document.getElementById('leads-status-filter').value;
  const canDelete = ['owner', 'admin'].includes(currentUser.role);

  tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--gray-500);padding:2rem">Loading...</td></tr>';
  emptyEl.classList.add('hidden');
  listEl.classList.remove('hidden');

  // Show/hide actions column
  const actTh = document.getElementById('leads-actions-th');
  if (actTh) { actTh.style.display = canDelete ? '' : 'none'; if (canDelete) actTh.textContent = 'Actions'; }

  try {
    const data = await api('/api/leads');
    const allLeads = data.leads || [];
    const filtered = filter === 'all' ? allLeads : allLeads.filter(l => l.status === filter);

    if (filtered.length === 0) {
      tbody.innerHTML = '';
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    tbody.innerHTML = filtered.map(l => {
      const statusBadge = leadStatusBadge(l.status);
      const dateStr = l.created_at ? new Date(l.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
      const prefDate = l.preferred_date ? String(l.preferred_date).slice(0, 10) : '—';
      const msg = l.message ? `<span title="${escHtml(l.message)}" style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;cursor:default">${escHtml(l.message).slice(0, 40)}${l.message.length > 40 ? '…' : ''}</span>` : '—';
      const actionTd = canDelete
        ? `<td style="white-space:nowrap"><button class="btn btn-sm" style="font-size:0.72rem;padding:2px 8px;background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2)" onclick="confirmDeleteLead(${l.id}, '${escHtml(l.name).replace(/'/g, "\\'")}')">Delete</button></td>`
        : '';
      return `<tr>
        <td style="font-weight:600">${escHtml(l.name)}</td>
        <td><a href="mailto:${escHtml(l.email)}" style="color:var(--sky)">${escHtml(l.email)}</a></td>
        <td><a href="tel:${escHtml(l.phone || '')}" style="color:var(--gray-300)">${escHtml(l.phone || '—')}</a></td>
        <td style="color:var(--gray-400);font-size:0.82rem">${escHtml(l.experience_level || '—')}</td>
        <td style="font-size:0.82rem;color:var(--gray-400)">${escHtml(prefDate)}</td>
        <td style="font-size:0.8rem;color:var(--gray-400)">${msg}</td>
        <td>${statusBadge}</td>
        <td style="font-size:0.82rem;color:var(--gray-500)">${dateStr}</td>
        ${actionTd}
      </tr>`;
    }).join('');
  } catch (err) {
    const msg = err?.status === 403 ? 'Access denied — admin/owner only' : (err?.error || 'Failed to load leads');
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:var(--red);padding:2rem">${escHtml(msg)}</td></tr>`;
    console.error('[loadLeads] error:', err);
  }
}

function leadStatusBadge(status) {
  const map = {
    new: ['tag-amber', 'New'],
    contacted: ['tag-sky', 'Contacted'],
    booked: ['tag-green', 'Booked'],
    no_show: ['tag-red', 'No Show'],
    converted: ['tag-purple', '&#10003; Converted'],
  };
  const [cls, label] = map[status] || ['tag-amber', status || 'New'];
  return `<span class="tag ${cls}" style="font-size:0.7rem">${label}</span>`;
}

function confirmDeleteLead(id, name) {
  if (!confirm('Delete lead "' + name + '"? This cannot be undone.')) return;
  api('/api/leads/' + id, { method: 'DELETE' })
    .then(() => { showToast('Lead deleted', 'success'); loadLeads(); })
    .catch(e => showToast(e.error || 'Failed to delete lead', 'error'));
}

async function loadInterventionHistory(studentId) {
  const listEl = document.getElementById('intervention-history-list');
  listEl.innerHTML = '<div style="color:var(--gray-500);font-size:0.82rem">Loading...</div>';
  try {
    const items = await api(`/api/at-risk/${studentId}/interventions`);
    if (items.length === 0) {
      listEl.innerHTML = '<div style="color:var(--gray-500);font-size:0.82rem">No interventions logged yet.</div>';
      return;
    }
    const outcomeLabels = {
      flight_booked: '✈ Flight booked',
      responded: 'Student responded',
      no_response: 'No response',
      on_break: 'On break',
      discontinued: 'Discontinued'
    };
    listEl.innerHTML = items.map(item => `
      <div class="intervention-item">
        <div class="intervention-type-dot"></div>
        <div style="flex:1;min-width:0">
          <div style="font-size:0.85rem;font-weight:600;color:var(--white)">${escHtml(item.intervention_type)}</div>
          ${item.notes ? `<div style="font-size:0.8rem;color:var(--gray-400);margin-top:0.15rem">${escHtml(item.notes)}</div>` : ''}
          <div style="font-size:0.72rem;color:var(--gray-500);margin-top:0.2rem">
            ${item.outcome ? `<span style="margin-right:0.75rem;color:var(--green)">${outcomeLabels[item.outcome] || item.outcome}</span>` : ''}
            by ${escHtml(item.logged_by_name)} · ${new Date(item.occurred_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
          </div>
        </div>
      </div>
    `).join('');
  } catch {
    listEl.innerHTML = '<div style="color:var(--red);font-size:0.82rem">Failed to load history.</div>';
  }
}

async function logIntervention() {
  if (!atRiskSelectedStudentId) return;
  const type    = document.getElementById('intervention-type-sel').value;
  const outcome = document.getElementById('intervention-outcome-sel').value;
  const notes   = document.getElementById('intervention-notes').value.trim();

  try {
    await api(`/api/at-risk/${atRiskSelectedStudentId}/interventions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ intervention_type: type, outcome: outcome || null, notes: notes || null })
    });
    document.getElementById('intervention-notes').value       = '';
    document.getElementById('intervention-outcome-sel').value = '';
    showToast('Intervention logged');
    await loadInterventionHistory(atRiskSelectedStudentId);
  } catch (err) {
    showToast(err.error || 'Failed to log intervention', 'error');
  }
}

async function saveAtRiskThresholds() {
  const low      = parseInt(document.getElementById('thresh-low').value);
  const medium   = parseInt(document.getElementById('thresh-medium').value);
  const high     = parseInt(document.getElementById('thresh-high').value);
  const critical = parseInt(document.getElementById('thresh-critical').value);

  if ([low, medium, high, critical].some(n => isNaN(n) || n < 1)) {
    showToast('All thresholds must be positive numbers', 'error');
    return;
  }
  if (low >= medium || medium >= high || high >= critical) {
    showToast('Thresholds must be in increasing order: Low < Medium < High < Critical', 'error');
    return;
  }
  try {
    await api('/api/at-risk/thresholds', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        at_risk_low_days: low,
        at_risk_medium_days: medium,
        at_risk_high_days: high,
        at_risk_critical_days: critical
      })
    });
    showToast('Thresholds saved');
    await loadAtRisk(); // re-run assessment with new thresholds
  } catch (err) {
    showToast(err.error || 'Failed to save thresholds', 'error');
  }
}

// ─── END AT-RISK STUDENTS ──────────────────────────────────

// ─── STUDENT PORTAL ─────────────────────────────────────

let portalData = null;
let portalProgramIdx = 0;

// ─── RENTER PORTAL ───
async function loadRenterPortal() {
  const loadingEl = document.getElementById('portal-loading');
  const contentEl = document.getElementById('portal-content');
  const emptyEl = document.getElementById('portal-empty');
  // Update page title to Renter Portal
  const titleEl = document.querySelector('#page-portal h1');
  if (titleEl) titleEl.textContent = 'My Rental Portal';
  loadingEl.innerHTML = 'Loading your rental activity...';
  loadingEl.classList.remove('hidden');
  contentEl.classList.add('hidden');
  emptyEl.classList.add('hidden');
  try {
    // Fetch renter's own flight logs
    const logs = await api('/api/flight-logs').catch(() => []);
    loadingEl.classList.add('hidden');
    contentEl.classList.remove('hidden');
    const heroEl = document.getElementById('portal-hero-area');
    const tabsEl = document.getElementById('portal-tabs');
    const hobbsHrs = parseFloat(currentUser.total_hobbs_hours || 0).toFixed(1);
    const tachHrs = parseFloat(currentUser.total_tach_hours || 0).toFixed(1);
    heroEl.innerHTML = `
      <div style="background:var(--dark-blue);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.5rem;margin-bottom:1.25rem;display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap;">
        <div style="flex:1;min-width:200px">
          <div style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-500);font-weight:600;margin-bottom:0.35rem">Welcome back</div>
          <div style="font-size:1.25rem;font-weight:700;color:var(--white);margin-bottom:0.2rem">${escHtml(currentUser.name)}</div>
          <div style="font-size:0.82rem;color:var(--gray-400)">Renter Account · <span style="color:var(--sky)">${logs.length} flight${logs.length !== 1 ? 's' : ''} logged</span></div>
        </div>
        <div style="display:flex;gap:1.5rem;flex-wrap:wrap">
          <div style="text-align:center">
            <div style="font-family:'Space Grotesk';font-size:1.6rem;font-weight:700;color:var(--sky)">${hobbsHrs}</div>
            <div style="font-size:0.68rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-500);font-weight:600">Hobbs Hrs</div>
          </div>
          <div style="text-align:center">
            <div style="font-family:'Space Grotesk';font-size:1.6rem;font-weight:700;color:var(--green)">${tachHrs}</div>
            <div style="font-size:0.68rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-500);font-weight:600">Tach Hrs</div>
          </div>
        </div>
      </div>`;
    tabsEl.innerHTML = `<button class="portal-tab active" data-tab="activity">&#9992; My Flights</button>`;
    const panelEl = document.getElementById('portal-panel-readiness');
    const recentLogs = (Array.isArray(logs) ? logs : []).slice(0, 15);
    if (recentLogs.length === 0) {
      panelEl.innerHTML = `
        <div style="text-align:center;padding:3rem 1rem;color:var(--gray-500)">
          <div style="font-size:2.5rem;margin-bottom:1rem">&#9992;</div>
          <div style="font-weight:600;color:var(--gray-300);margin-bottom:0.5rem">No flights logged yet</div>
          <div style="font-size:0.85rem">Head to Schedule to book your first rental flight.</div>
        </div>`;
    } else {
      panelEl.innerHTML = `
        <div style="margin-bottom:0.75rem;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-500);font-weight:600">Recent Rental Activity</div>
        ${recentLogs.map(l => `
          <div style="background:var(--dark-blue);border:1px solid var(--border);border-radius:var(--radius);padding:0.85rem 1rem;margin-bottom:0.5rem;display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
            <div style="flex:1;min-width:140px">
              <div style="font-weight:600;font-size:0.88rem;color:var(--white)">${escHtml(l.tail_number || '—')}</div>
              <div style="font-size:0.78rem;color:var(--gray-500);margin-top:0.1rem">${l.flight_date ? String(l.flight_date).slice(0,10) : '—'}</div>
            </div>
            <div style="text-align:right">
              <div style="font-family:'Space Grotesk';font-size:0.92rem;font-weight:600;color:var(--sky)">${l.hobbs_delta != null ? parseFloat(l.hobbs_delta).toFixed(1) + ' Hobbs' : '—'}</div>
              ${l.tach_delta != null ? `<div style="font-size:0.78rem;color:var(--gray-400)">${parseFloat(l.tach_delta).toFixed(1)} Tach</div>` : ''}
            </div>
          </div>`).join('')}`;
    }
    ['milestones','recommendations','feedback','cohort','endorsements'].forEach(id => {
      const el = document.getElementById('portal-panel-' + id);
      if (el) el.innerHTML = '';
    });
  } catch (err) {
    loadingEl.innerHTML = `<div style="color:var(--red);padding:2rem">Failed to load rental portal: ${err.error || 'Unknown error'}</div>`;
    loadingEl.classList.remove('hidden');
    contentEl.classList.add('hidden');
  }
}

async function loadStudentPortal() {
  // Renters see a simplified rental portal instead of the student training portal
  if (currentUser.role === 'renter') {
    return loadRenterPortal();
  }
  const studentId = currentUser.id;
  const loadingEl = document.getElementById('portal-loading');
  const contentEl = document.getElementById('portal-content');
  const emptyEl = document.getElementById('portal-empty');
  if (!loadingEl) return;
  loadingEl.innerHTML = 'Loading your progress...';
  loadingEl.classList.remove('hidden');
  contentEl.classList.add('hidden');
  emptyEl.classList.add('hidden');
  try {
    const data = await api(`/api/training/checkride-readiness/${studentId}`);
    if (!data.programs || data.programs.length === 0) {
      loadingEl.classList.add('hidden');
      emptyEl.classList.remove('hidden');
      return;
    }
    portalData = data;
    portalProgramIdx = 0;
    loadingEl.classList.add('hidden');
    contentEl.classList.remove('hidden');
    renderPortal(data);
    // Async: fetch cohort stats per program (non-blocking)
    for (let i = 0; i < data.programs.length; i++) {
      const prog = data.programs[i];
      try {
        const cohort = await api(`/api/training/cohort-stats/${prog.program_code}`);
        data.programs[i].cohort = cohort;
        if (portalProgramIdx === i) {
          document.getElementById('portal-panel-cohort').innerHTML = renderCohortPanel(prog.cohort);
        }
      } catch { /* cohort stats are non-critical */ }
    }
  } catch (err) {
    loadingEl.innerHTML = `<div style="color:var(--red);padding:2rem">Failed to load portal: ${err.error || 'Unknown error'}</div>`;
    loadingEl.classList.remove('hidden');
  }
}

function renderPortal(data) {
  const heroEl = document.getElementById('portal-hero-area');
  const tabsEl = document.getElementById('portal-tabs');
  const prog = data.programs[portalProgramIdx];

  // Program selector (shown when enrolled in multiple programs)
  if (data.programs.length > 1) {
    heroEl.innerHTML = `
      <div class="prog-selector">
        ${data.programs.map((p, i) => `
          <button class="prog-tab ${i === portalProgramIdx ? 'active' : ''}"
                  onclick="switchPortalProgram(${i})">${p.program_code} — ${p.program_name}</button>
        `).join('')}
      </div>
      <div id="portal-hero-card"></div>`;
  } else {
    heroEl.innerHTML = `<div id="portal-hero-card"></div>`;
  }
  document.getElementById('portal-hero-card').innerHTML = renderPortalHeroCard(prog);

  // Tab bar
  const tabs = [
    { id: 'readiness',       label: '&#128200; Readiness' },
    { id: 'milestones',      label: '&#127919; Milestones' },
    { id: 'recommendations', label: '&#128161; Next Flights' },
    { id: 'feedback',        label: '&#128172; CFI Feedback' },
    { id: 'cohort',          label: '&#128101; Cohort' },
    { id: 'endorsements',    label: '&#9997; Endorsements' },
  ];
  tabsEl.innerHTML = tabs.map(t =>
    `<button class="portal-tab${t.id === 'readiness' ? ' active' : ''}" data-tab="${t.id}"
             onclick="switchPortalTab('${t.id}')">${t.label}</button>`
  ).join('');

  // Render all panels
  document.getElementById('portal-panel-readiness').innerHTML      = renderReadinessPanel(prog);
  document.getElementById('portal-panel-milestones').innerHTML     = renderMilestonesPanel(prog);
  document.getElementById('portal-panel-recommendations').innerHTML = renderRecommendationsPanel(prog);
  document.getElementById('portal-panel-feedback').innerHTML       = renderFeedbackPanel(prog.debriefs);
  document.getElementById('portal-panel-cohort').innerHTML         = renderCohortPanel(prog.cohort);
  document.getElementById('portal-panel-endorsements').innerHTML   = renderEndorsementsPanel(prog.endorsements);

  // Show first panel
  document.getElementById('portal-panel-readiness').classList.add('active');
}

function renderPortalHeroCard(prog) {
  const pct = prog.readiness_pct;
  const r = 38, cx = 50, cy = 50;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const color = pct >= 80 ? '#22c55e' : pct >= 50 ? '#38bdf8' : pct >= 25 ? '#f59e0b' : '#ef4444';
  return `
    <div class="portal-hero">
      <div class="portal-readiness-ring">
        <svg width="100" height="100" viewBox="0 0 100 100">
          <circle class="ring-track" cx="${cx}" cy="${cy}" r="${r}"/>
          <circle class="ring-fill" cx="${cx}" cy="${cy}" r="${r}"
            style="stroke:${color};stroke-dasharray:${circ.toFixed(2)};stroke-dashoffset:${offset.toFixed(2)};transform:rotate(-90deg);transform-origin:50% 50%"/>
          <text class="ring-label" x="${cx}" y="${cy - 5}" font-size="15">${pct}%</text>
          <text class="ring-sublabel" x="${cx}" y="${cy + 13}">Ready</text>
        </svg>
      </div>
      <div class="portal-hero-info">
        <h2>${prog.program_name}</h2>
        <div class="portal-hero-meta">
          ${prog.instructor_name ? `CFI: ${prog.instructor_name}` : ''}
          ${prog.instructor_name && prog.current_stage_name ? ' &nbsp;·&nbsp; ' : ''}
          ${prog.current_stage_name ? `Stage: ${prog.current_stage_name}` : ''}
        </div>
        <div class="portal-hours-row">
          <div class="portal-hour-chip">Total <span>${prog.hours.total}h</span></div>
          <div class="portal-hour-chip">Solo <span>${prog.hours.solo}h</span></div>
          ${prog.hours.night > 0 ? `<div class="portal-hour-chip">Night <span>${prog.hours.night}h</span></div>` : ''}
          ${prog.hours.xc > 0 ? `<div class="portal-hour-chip">XC <span>${prog.hours.xc}h</span></div>` : ''}
          ${prog.hours.instrument > 0 ? `<div class="portal-hour-chip">Hood/Sim <span>${prog.hours.instrument}h</span></div>` : ''}
        </div>
      </div>
    </div>`;
}

function renderReadinessPanel(prog) {
  if (!prog.categories || prog.categories.length === 0) {
    return `<div class="empty-state"><div class="empty-icon">&#128203;</div>
      <h3>No flight data yet</h3><p>Complete your first flight to see your readiness breakdown.</p></div>`;
  }
  const cards = prog.categories.map(c => {
    const color = c.pct >= 80 ? '#22c55e' : c.pct >= 50 ? '#38bdf8' : c.pct >= 25 ? '#f59e0b' : '#ef4444';
    const isCount = c.label === 'Stage Completion' || c.label === 'Maneuver Proficiency';
    const gotLabel = isCount ? `${c.got} / ${c.need}` : `${c.got}h / ${c.need}h`;
    return `
      <div class="readiness-card">
        <div class="readiness-card-label">${c.label}</div>
        <div class="readiness-card-nums"><strong>${c.pct}%</strong> &nbsp; ${gotLabel}</div>
        <div class="readiness-bar-track">
          <div class="readiness-bar-fill" style="width:${c.pct}%;background:${color}"></div>
        </div>
      </div>`;
  }).join('');
  return `<div class="readiness-grid">${cards}</div>`;
}

function renderMilestonesPanel(prog) {
  const list = (prog.stages && prog.stages.list) || [];
  if (list.length === 0) {
    return `<div class="empty-state"><div class="empty-icon">&#127919;</div>
      <h3>No stages defined</h3><p>Ask your instructor to set up your training syllabus.</p></div>`;
  }
  const items = list.map(s => {
    const isDone = parseInt(s.total_maneuvers) > 0 && parseInt(s.proficient_count) >= parseInt(s.total_maneuvers);
    const isCurrent = prog.current_stage_name === s.name;
    const cls = isDone ? 'done' : (isCurrent ? 'current' : 'upcoming');
    const icon = isDone ? '&#10003;' : (isCurrent ? '&#9658;' : '&#8901;');
    const manLabel = parseInt(s.total_maneuvers) > 0
      ? `${s.proficient_count} / ${s.total_maneuvers} maneuvers proficient`
      : 'No maneuvers assigned';
    return `
      <div class="milestone-item">
        <div class="milestone-icon ${cls}">${icon}</div>
        <div class="milestone-info">
          <div class="milestone-name">${s.name}</div>
          <div class="milestone-meta">${manLabel}</div>
        </div>
      </div>`;
  }).join('');
  const { completed, total } = prog.stages;
  return `
    <div style="margin-bottom:1rem;font-size:0.82rem;color:var(--gray-400)">${completed} of ${total} stages complete</div>
    <div class="milestone-list">${items}</div>`;
}

function renderRecommendationsPanel(prog) {
  if (!prog.recommendations || prog.recommendations.length === 0) {
    return `
      <div class="empty-state">
        <div class="empty-icon" style="color:#22c55e">&#10003;</div>
        <h3>All FAA minimums met!</h3>
        <p>You've hit your hour requirements. Schedule your checkride prep with your CFI.</p>
      </div>`;
  }
  const items = prog.recommendations.map(r => `
    <div class="rec-item">
      <div class="rec-dot ${r.priority}"></div>
      <div class="rec-text">${r.text}</div>
    </div>`).join('');
  return `<div class="rec-list">${items}</div>`;
}

function renderFeedbackPanel(debriefs) {
  if (!debriefs || debriefs.length === 0) {
    return `<div class="empty-state"><div class="empty-icon">&#128172;</div>
      <h3>No feedback yet</h3><p>Your CFI's debrief notes will appear here after each flight.</p></div>`;
  }
  const perfLabels = ['', 'Needs Improvement', 'Below Standards', 'Meets Standards', 'Above Standards', 'Excellent'];
  const ratingStars = (v) => {
    if (!v) return '';
    const colors = ['','#ef4444','#f97316','#eab308','#84cc16','#22c55e'];
    return `<span style="color:${colors[v] || 'var(--gray-400)'};font-size:0.95rem">${'★'.repeat(v)}${'☆'.repeat(5-v)}</span>`;
  };
  const chipStyle = (g) => {
    const bg = g<=1?'rgba(239,68,68,0.15)':g===2?'rgba(249,115,22,0.15)':g===3?'rgba(234,179,8,0.15)':g===4?'rgba(132,204,18,0.15)':'rgba(34,197,94,0.15)';
    const col = g<=1?'#ef4444':g===2?'#f97316':g===3?'#eab308':g===4?'#84cc16':'#22c55e';
    return `background:${bg};color:${col};border:1px solid ${col}40`;
  };
  const items = debriefs.map(d => {
    const dateStr = d.flight_date
      ? new Date(String(d.flight_date).slice(0,10) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : '';
    const perfLabel = perfLabels[d.overall_performance] || '';
    const gradeChips = (d.grades || []).filter(g => g.grade).map(g =>
      `<span style="display:inline-flex;align-items:center;gap:0.25rem;font-size:0.75rem;font-weight:600;padding:0.18rem 0.5rem;border-radius:4px;${chipStyle(g.grade)}">${escHtml(g.maneuver_name)} <span>${'★'.repeat(g.grade)}</span></span>`
    ).join('');
    const topicsNoGrade = (d.grades || []).filter(g => !g.grade).map(g =>
      `<span style="font-size:0.75rem;color:var(--gray-500);padding:0.18rem 0.45rem;border-radius:4px;background:rgba(148,163,184,0.1)">${escHtml(g.maneuver_name)}</span>`
    ).join('');
    return `
      <div class="feedback-item" style="border-bottom:1px solid rgba(148,163,184,0.08);padding-bottom:1rem;margin-bottom:1rem">
        <div class="feedback-header" style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.5rem;margin-bottom:0.5rem;flex-wrap:wrap">
          <div>
            <span class="feedback-date" style="font-size:0.82rem;color:var(--gray-400)">${dateStr}</span>
            ${d.stage_name ? `<span style="font-size:0.78rem;color:var(--sky);margin-left:0.5rem">${escHtml(d.stage_name)}</span>` : ''}
          </div>
          <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap">
            ${d.overall_performance ? `<span title="${perfLabel}" style="font-size:0.82rem">${ratingStars(d.overall_performance)}</span><span style="font-size:0.75rem;color:var(--gray-500)">${perfLabel}</span>` : ''}
            ${d.instructor_name ? `<span style="font-size:0.75rem;color:var(--gray-600);background:rgba(148,163,184,0.1);padding:0.15rem 0.45rem;border-radius:4px">${escHtml(d.instructor_name)}</span>` : ''}
          </div>
        </div>
        ${(gradeChips || topicsNoGrade) ? `<div style="display:flex;flex-wrap:wrap;gap:0.3rem;margin-bottom:0.5rem">${gradeChips}${topicsNoGrade}</div>` : ''}
        ${d.notes ? `<div style="font-size:0.85rem;color:var(--gray-300);line-height:1.5;margin-bottom:0.35rem">${escHtml(d.notes)}</div>` : ''}
        ${d.recommendations ? `<div style="font-size:0.82rem;color:var(--sky);background:rgba(56,189,248,0.07);border-left:2px solid var(--sky);padding:0.3rem 0.6rem;border-radius:0 4px 4px 0;margin-top:0.35rem"><strong>Next flight:</strong> ${escHtml(d.recommendations)}</div>` : ''}
      </div>`;
  }).join('');
  return `<div class="feedback-list" style="padding:0">${items}</div>`;
}

function renderCohortPanel(cohort) {
  if (!cohort || !cohort.enough_data) {
    return `
      <div class="empty-state">
        <div class="empty-icon">&#128101;</div>
        <h3>Not enough data yet</h3>
        <p>Cohort comparison requires at least 2 students enrolled in the same program.</p>
      </div>`;
  }
  const percentileTxt = cohort.percentile !== null
    ? `<p style="font-size:0.85rem;color:var(--gray-300);margin-top:0.5rem">
         You're ahead of <strong>${cohort.percentile}%</strong> of your cohort by total flight hours.
       </p>` : '';
  return `
    <div class="cohort-grid">
      <div class="cohort-stat">
        <div class="cohort-stat-value">${cohort.cohort_size}</div>
        <div class="cohort-stat-label">Students Enrolled</div>
      </div>
      <div class="cohort-stat">
        <div class="cohort-stat-value">${cohort.avg_hours}</div>
        <div class="cohort-stat-label">Avg Flight Hours</div>
      </div>
      ${cohort.percentile !== null ? `
        <div class="cohort-stat">
          <div class="cohort-stat-value">${cohort.percentile}%</div>
          <div class="cohort-stat-label">Your Percentile</div>
        </div>` : ''}
    </div>
    ${percentileTxt}`;
}

function renderEndorsementsPanel(endorsements) {
  if (!endorsements || endorsements.length === 0) {
    return `<div class="empty-state"><div class="empty-icon">&#9997;</div>
      <h3>No endorsements yet</h3><p>Your CFI will add endorsements as you reach each milestone.</p></div>`;
  }
  const today = new Date();
  const items = endorsements.map(e => {
    let badge = '';
    if (e.expiration_date) {
      const exp = new Date(toDateOnly(e.expiration_date) + 'T12:00:00');
      const daysLeft = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));
      if (daysLeft < 0)      badge = `<span class="endorsement-badge expired">Expired</span>`;
      else if (daysLeft <= 14) badge = `<span class="endorsement-badge expiring">Expires in ${daysLeft}d</span>`;
      else badge = `<span class="endorsement-badge active">Exp ${exp.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}</span>`;
    } else {
      badge = `<span class="endorsement-badge permanent">No Expiry</span>`;
    }
    const dateStr = e.endorsement_date
      ? new Date(toDateOnly(e.endorsement_date) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : '';
    return `
      <div class="endorsement-item">
        <div class="endorsement-info">
          <div class="endorsement-type">${e.endorsement_type}</div>
          <div class="endorsement-meta">
            ${dateStr ? `Issued ${dateStr}` : ''}
            ${e.instructor_name ? ` by ${e.instructor_name}` : ''}
            ${e.instructor_cert_number ? ` &nbsp;·&nbsp; CFI# ${e.instructor_cert_number}` : ''}
          </div>
        </div>
        ${badge}
      </div>`;
  }).join('');
  return `<div class="endorsement-list">${items}</div>`;
}

function switchPortalProgram(idx) {
  if (!portalData) return;
  portalProgramIdx = idx;
  document.querySelectorAll('.prog-tab').forEach((t, i) => t.classList.toggle('active', i === idx));
  const prog = portalData.programs[idx];
  const heroCard = document.getElementById('portal-hero-card');
  if (heroCard) heroCard.innerHTML = renderPortalHeroCard(prog);
  document.getElementById('portal-panel-readiness').innerHTML      = renderReadinessPanel(prog);
  document.getElementById('portal-panel-milestones').innerHTML     = renderMilestonesPanel(prog);
  document.getElementById('portal-panel-recommendations').innerHTML = renderRecommendationsPanel(prog);
  document.getElementById('portal-panel-feedback').innerHTML       = renderFeedbackPanel(prog.debriefs);
  document.getElementById('portal-panel-cohort').innerHTML         = renderCohortPanel(prog.cohort);
  document.getElementById('portal-panel-endorsements').innerHTML   = renderEndorsementsPanel(prog.endorsements);
  switchPortalTab('readiness');
}

function switchPortalTab(tabId) {
  document.querySelectorAll('.portal-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tabId));
  document.querySelectorAll('.portal-panel').forEach(p => p.classList.toggle('active', p.id === `portal-panel-${tabId}`));
}

// ─── END STUDENT PORTAL ─────────────────────────────────

// ─── INSTRUCTOR AVAILABILITY ─────────────────────────────

let availabilityData = null; // { instructor_id, weekly, overrides }
let availEditingInstructorId = null;

const DAY_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const DAY_SHORT = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

// Build a list of HH:MM time options for selects (30-min intervals 5am–11pm)
function buildAvailTimeOptions(selectedVal) {
  let html = '';
  for (let h = 5; h <= 23; h++) {
    for (let m = 0; m < 60; m += 30) {
      const val = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
      const label = formatTimeStr(h, m);
      html += `<option value="${val}"${selectedVal === val ? ' selected' : ''}>${label}</option>`;
    }
  }
  return html;
}

async function loadAvailabilityPage() {
  console.log('[AVAIL] loadAvailabilityPage called, currentUser:', currentUser?.id, currentUser?.role);
  const isAdmin = ['owner','admin'].includes(currentUser.role);

  // Show/hide instructor selector for admin/owner
  const selectorDiv = document.getElementById('avail-instructor-selector');
  if (isAdmin && selectorDiv) {
    selectorDiv.classList.remove('hidden');
    selectorDiv.style.display = 'flex';
    const sel = document.getElementById('avail-instructor-select');
    if (sel && sel.options.length === 0) {
      // Populate with instructors
      const instructors = (allUsers || []).filter(u => ['instructor','admin','owner'].includes(u.role) && !u.deleted_at);
      sel.innerHTML = instructors.map(u => `<option value="${u.id}"${u.id === currentUser.id ? ' selected' : ''}>${u.name}</option>`).join('');
    }
  }

  // Determine which instructor to show
  const selEl = document.getElementById('avail-instructor-select');
  availEditingInstructorId = isAdmin && selEl ? parseInt(selEl.value) : currentUser.id;

  // Show admin grid section for admin/owner
  const adminSection = document.getElementById('avail-admin-section');
  if (adminSection) {
    if (isAdmin) {
      adminSection.classList.remove('hidden');
      // Default date to today
      const dateEl = document.getElementById('avail-admin-date');
      if (dateEl && !dateEl.value) {
        dateEl.value = new Date().toISOString().slice(0,10);
      }
      loadAdminAvailGrid();
    } else {
      adminSection.classList.add('hidden');
    }
  }

  try {
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderWeeklyGrid();
    renderOverridesList();
  } catch (err) {
    showToast('Failed to load availability', 'error');
  }
}

function renderWeeklyGrid() {
  const grid = document.getElementById('avail-weekly-grid');
  if (!grid) return;

  const weekly = availabilityData ? availabilityData.weekly : [];
  // Group by day
  const byDay = {};
  for (let d = 0; d < 7; d++) byDay[d] = [];
  for (const row of weekly) byDay[row.day_of_week].push(row);

  grid.innerHTML = [0,1,2,3,4,5,6].map(d => {
    const blocks = byDay[d];
    const isWeekend = d === 0 || d === 6;
    return `
      <div style="background:var(--navy);border:1px solid var(--border);border-radius:10px;padding:0.85rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.6rem;">
          <span style="font-size:0.88rem;font-weight:600;color:${isWeekend ? 'var(--gray-400)' : 'var(--white)'};">${DAY_NAMES[d]}</span>
          <button onclick="openAddWindowModal(${d})" title="Add window" style="background:var(--sky-faint);border:none;color:var(--sky);width:22px;height:22px;border-radius:5px;font-size:1rem;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1;">+</button>
        </div>
        ${blocks.length === 0
          ? `<span style="font-size:0.78rem;color:var(--gray-600);">No availability</span>`
          : blocks.map(b => `
            <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(14,165,233,0.08);border:1px solid rgba(14,165,233,0.2);border-radius:6px;padding:0.3rem 0.55rem;margin-bottom:0.35rem;">
              <span style="font-size:0.82rem;color:var(--sky);">${fmtTimeRange(b.start_time, b.end_time)}</span>
              <button onclick="deleteAvailWindow(${b.id})" title="Remove" style="background:transparent;border:none;color:var(--gray-500);font-size:0.95rem;cursor:pointer;padding:0;line-height:1;" onmouseover="this.style.color='var(--red)'" onmouseout="this.style.color='var(--gray-500)'">&#215;</button>
            </div>`).join('')
        }
        ${blocks.length > 0 ? `
          <div style="margin-top:0.5rem;">
            <button onclick="openCopyDayModal(${d})" style="background:transparent;border:none;color:var(--gray-500);font-size:0.75rem;cursor:pointer;padding:0;text-decoration:underline;" onmouseover="this.style.color='var(--sky)'" onmouseout="this.style.color='var(--gray-500)'">Copy to other days</button>
          </div>` : ''}
      </div>`;
  }).join('');
}

function fmtTimeRange(start, end) {
  // start/end can be "HH:MM:SS" or "HH:MM"
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  return `${formatTimeStr(sh, sm)} – ${formatTimeStr(eh, em)}`;
}

function renderOverridesList() {
  const el = document.getElementById('avail-overrides-list');
  if (!el) return;
  const overrides = availabilityData ? availabilityData.overrides : [];
  if (overrides.length === 0) {
    el.innerHTML = `<p style="color:var(--gray-500);font-size:0.85rem;margin:0;">No exceptions set. Add vacation days, extra hours, or blocked times.</p>`;
    return;
  }
  el.innerHTML = overrides.map(o => {
    const dateRange = o.start_date === o.end_date
      ? formatOverrideDate(o.start_date)
      : `${formatOverrideDate(o.start_date)} – ${formatOverrideDate(o.end_date)}`;
    const timeRange = o.start_time && o.end_time ? ` · ${fmtTimeRange(o.start_time, o.end_time)}` : '';
    const badge = o.is_available
      ? `<span style="background:rgba(34,197,94,0.12);color:var(--green);border:1px solid rgba(34,197,94,0.25);border-radius:5px;font-size:0.72rem;font-weight:600;padding:0.15rem 0.45rem;">AVAILABLE</span>`
      : `<span style="background:rgba(239,68,68,0.1);color:var(--red);border:1px solid rgba(239,68,68,0.2);border-radius:5px;font-size:0.72rem;font-weight:600;padding:0.15rem 0.45rem;">BLOCKED</span>`;
    const reason = o.reason ? `<span style="color:var(--gray-400);font-size:0.78rem;"> — ${escHtml(o.reason)}</span>` : '';
    return `
      <div style="display:flex;align-items:center;justify-content:space-between;background:var(--navy);border:1px solid var(--border);border-radius:8px;padding:0.6rem 0.85rem;">
        <div style="display:flex;align-items:center;gap:0.6rem;flex-wrap:wrap;">
          ${badge}
          <span style="font-size:0.85rem;color:var(--white);">${escHtml(dateRange)}${escHtml(timeRange)}</span>
          ${reason}
        </div>
        <button onclick="deleteAvailOverride(${o.id})" title="Remove" style="background:transparent;border:none;color:var(--gray-500);font-size:1rem;cursor:pointer;padding:0.25rem 0.4rem;" onmouseover="this.style.color='var(--red)'" onmouseout="this.style.color='var(--gray-500)'">&#128465;</button>
      </div>`;
  }).join('');
}

function formatOverrideDate(dateStr) {
  // dateStr may be YYYY-MM-DD or an ISO timestamp from the API (e.g. "2026-06-03T00:00:00.000Z")
  // Strip any time component to get just the date, then parse in local time to avoid UTC-offset issues
  const dateOnly = typeof dateStr === 'string' && dateStr.includes('T')
    ? dateStr.substring(0, 10)
    : (typeof dateStr === 'string' ? dateStr : String(dateStr));
  const [y, m, d] = dateOnly.split('-').map(Number);
  if (isNaN(y) || isNaN(m) || isNaN(d)) return String(dateStr);
  return new Date(y, m - 1, d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

async function deleteAvailWindow(id) {
  if (!confirm('Remove this availability window?')) return;
  try {
    await api(`/api/instructor-availability/${id}`, { method: 'DELETE' });
    showToast('Window removed', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderWeeklyGrid();
  } catch (err) {
    showToast(err.error || 'Failed to remove window', 'error');
  }
}

async function deleteAvailOverride(id) {
  if (!confirm('Remove this exception?')) return;
  try {
    await api(`/api/instructor-availability/overrides/${id}`, { method: 'DELETE' });
    showToast('Exception removed', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderOverridesList();
  } catch (err) {
    showToast(err.error || 'Failed to remove exception', 'error');
  }
}

async function clearAllAvailability() {
  if (!confirm('Clear ALL weekly availability for this instructor? This cannot be undone.')) return;
  try {
    await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`, { method: 'DELETE' });
    showToast('Weekly schedule cleared', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderWeeklyGrid();
  } catch (err) {
    showToast(err.error || 'Failed to clear', 'error');
  }
}

// ── Add Window Modal ────────────────────────────────────────
function openAddWindowModal(dayOfWeek) {
  const modal = document.getElementById('avail-window-modal');
  if (!modal) return;
  document.getElementById('avail-window-day').value = dayOfWeek;
  document.getElementById('avail-window-day-label').textContent = DAY_NAMES[dayOfWeek];
  document.getElementById('avail-window-start').innerHTML = buildAvailTimeOptions('08:00');
  document.getElementById('avail-window-end').innerHTML = buildAvailTimeOptions('17:00');
  document.getElementById('avail-window-error').classList.add('hidden');
  modal.classList.remove('hidden');
}

function closeAddWindowModal() {
  const modal = document.getElementById('avail-window-modal');
  if (modal) modal.classList.add('hidden');
}

async function saveAvailWindow() {
  const dayOfWeek = parseInt(document.getElementById('avail-window-day').value);
  const start = document.getElementById('avail-window-start').value;
  const end = document.getElementById('avail-window-end').value;
  const errEl = document.getElementById('avail-window-error');
  errEl.classList.add('hidden');

  if (start >= end) {
    errEl.textContent = 'End time must be after start time';
    errEl.classList.remove('hidden');
    return;
  }

  try {
    await api('/api/instructor-availability', {
      method: 'POST',
      body: JSON.stringify({ instructor_id: availEditingInstructorId, day_of_week: dayOfWeek, start_time: start, end_time: end })
    });
    closeAddWindowModal();
    showToast('Availability added', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderWeeklyGrid();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save';
    errEl.classList.remove('hidden');
  }
}

// ── Copy Day Modal ─────────────────────────────────────────
function openCopyDayModal(fromDay) {
  const modal = document.getElementById('avail-copy-modal');
  if (!modal) return;
  document.getElementById('avail-copy-from-day').value = fromDay;
  document.getElementById('avail-copy-from-label').textContent = DAY_NAMES[fromDay];
  // Render checkboxes for other days
  const cbContainer = document.getElementById('avail-copy-days');
  cbContainer.innerHTML = [0,1,2,3,4,5,6].filter(d => d !== fromDay).map(d =>
    `<label style="display:flex;align-items:center;gap:0.4rem;font-size:0.88rem;color:var(--gray-300);cursor:pointer;">
       <input type="checkbox" value="${d}" style="accent-color:var(--sky);width:14px;height:14px;"> ${DAY_NAMES[d]}
     </label>`
  ).join('');
  document.getElementById('avail-copy-error').classList.add('hidden');
  modal.classList.remove('hidden');
}

function closeAvailCopyModal() {
  const modal = document.getElementById('avail-copy-modal');
  if (modal) modal.classList.add('hidden');
}

async function saveAvailCopy() {
  const fromDay = parseInt(document.getElementById('avail-copy-from-day').value);
  const checked = Array.from(document.getElementById('avail-copy-days').querySelectorAll('input:checked')).map(i => parseInt(i.value));
  const errEl = document.getElementById('avail-copy-error');
  errEl.classList.add('hidden');

  if (checked.length === 0) {
    errEl.textContent = 'Select at least one day to copy to';
    errEl.classList.remove('hidden');
    return;
  }

  const sourceBlocks = availabilityData.weekly.filter(b => b.day_of_week === fromDay);
  if (sourceBlocks.length === 0) {
    errEl.textContent = 'No availability to copy from this day';
    errEl.classList.remove('hidden');
    return;
  }

  try {
    for (const targetDay of checked) {
      // Remove existing windows for target day first
      const existing = availabilityData.weekly.filter(b => b.day_of_week === targetDay);
      for (const ex of existing) {
        await api(`/api/instructor-availability/${ex.id}`, { method: 'DELETE' });
      }
      // Copy source blocks
      for (const b of sourceBlocks) {
        await api('/api/instructor-availability', {
          method: 'POST',
          body: JSON.stringify({ instructor_id: availEditingInstructorId, day_of_week: targetDay, start_time: b.start_time.slice(0,5), end_time: b.end_time.slice(0,5) })
        });
      }
    }
    closeAvailCopyModal();
    showToast('Schedule copied to ' + checked.length + ' day(s)', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderWeeklyGrid();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to copy';
    errEl.classList.remove('hidden');
  }
}

// ── Add Override Modal ─────────────────────────────────────
function openAddOverrideModal() {
  const modal = document.getElementById('avail-override-modal');
  if (!modal) return;
  const today = new Date().toISOString().slice(0,10);
  document.getElementById('avail-override-start').value = today;
  document.getElementById('avail-override-end').value = today;
  document.getElementById('avail-override-type').value = 'unavailable_day';
  document.getElementById('avail-override-reason').value = '';
  document.getElementById('avail-override-start-time').innerHTML = buildAvailTimeOptions('08:00');
  document.getElementById('avail-override-end-time').innerHTML = buildAvailTimeOptions('12:00');
  handleOverrideTypeChange();
  document.getElementById('avail-override-error').classList.add('hidden');
  modal.classList.remove('hidden');
}

function closeAddOverrideModal() {
  const modal = document.getElementById('avail-override-modal');
  if (modal) modal.classList.add('hidden');
}

function handleOverrideTypeChange() {
  const type = document.getElementById('avail-override-type').value;
  const timeRow = document.getElementById('avail-override-time-row');
  if (timeRow) {
    timeRow.style.display = type === 'unavailable_day' ? 'none' : '';
  }
}

async function saveOverride() {
  const startDate = document.getElementById('avail-override-start').value;
  const endDate = document.getElementById('avail-override-end').value;
  const type = document.getElementById('avail-override-type').value;
  const reason = document.getElementById('avail-override-reason').value.trim();
  const startTime = document.getElementById('avail-override-start-time').value;
  const endTime = document.getElementById('avail-override-end-time').value;
  const errEl = document.getElementById('avail-override-error');
  errEl.classList.add('hidden');

  if (!startDate || !endDate) {
    errEl.textContent = 'Start and end dates are required';
    errEl.classList.remove('hidden');
    return;
  }
  if (startDate > endDate) {
    errEl.textContent = 'End date must be on or after start date';
    errEl.classList.remove('hidden');
    return;
  }
  if (type !== 'unavailable_day' && startTime >= endTime) {
    errEl.textContent = 'End time must be after start time';
    errEl.classList.remove('hidden');
    return;
  }

  const payload = {
    instructor_id: availEditingInstructorId,
    start_date: startDate,
    end_date: endDate,
    reason: reason || null,
    override_type: 'personal'
  };

  if (type === 'unavailable_day') {
    payload.is_available = false;
    // no time range — full day block
  } else if (type === 'unavailable_hours') {
    payload.is_available = false;
    payload.start_time = startTime;
    payload.end_time = endTime;
  } else if (type === 'available_hours') {
    payload.is_available = true;
    payload.start_time = startTime;
    payload.end_time = endTime;
  }

  try {
    await api('/api/instructor-availability/overrides', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    closeAddOverrideModal();
    showToast('Exception saved', 'success');
    const data = await api(`/api/instructor-availability?instructor_id=${availEditingInstructorId}`);
    availabilityData = data;
    renderOverridesList();
  } catch (err) {
    errEl.textContent = err.error || 'Failed to save exception';
    errEl.classList.remove('hidden');
  }
}

// ── Admin: All-instructor day view ─────────────────────────
async function loadAdminAvailGrid() {
  const dateEl = document.getElementById('avail-admin-date');
  const gridEl = document.getElementById('avail-admin-grid');
  if (!dateEl || !gridEl) return;
  const date = dateEl.value;
  if (!date) return;

  gridEl.innerHTML = `<p style="color:var(--gray-400);font-size:0.85rem;">Loading…</p>`;
  try {
    const data = await api(`/api/instructor-availability/all?date=${date}`);
    if (!data.instructors || data.instructors.length === 0) {
      gridEl.innerHTML = `<p style="color:var(--gray-500);font-size:0.85rem;">No instructors found.</p>`;
      return;
    }

    gridEl.innerHTML = data.instructors.map(inst => {
      const nameTag = `<strong style="color:var(--white);font-size:0.9rem;">${escHtml(inst.name)}</strong>`;

      if (!inst.has_config) {
        return `<div style="padding:0.65rem 0.85rem;background:var(--navy);border:1px solid var(--border);border-radius:8px;margin-bottom:0.6rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;">
          ${nameTag}
          <span style="color:var(--gray-500);font-size:0.8rem;">No schedule configured — always available</span>
        </div>`;
      }

      if (inst.fully_blocked) {
        return `<div style="padding:0.65rem 0.85rem;background:var(--navy);border:1px solid rgba(239,68,68,0.3);border-radius:8px;margin-bottom:0.6rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;">
          ${nameTag}
          <span style="color:var(--red);font-size:0.8rem;">🚫 Day blocked</span>
        </div>`;
      }

      const windowsHtml = inst.windows.length === 0
        ? `<span style="color:var(--gray-500);font-size:0.8rem;">Not available ${data.day}</span>`
        : inst.windows.map(w => `<span style="background:rgba(14,165,233,0.1);color:var(--sky);border:1px solid rgba(14,165,233,0.2);border-radius:5px;font-size:0.78rem;padding:0.15rem 0.4rem;">${w.start} – ${w.end}</span>`).join(' ');

      const bookingsHtml = inst.bookings.length === 0 ? '' :
        `<div style="margin-top:0.4rem;display:flex;flex-wrap:wrap;gap:0.35rem;">` +
        inst.bookings.map(b => `<span style="background:rgba(251,191,36,0.1);color:var(--amber);border:1px solid rgba(251,191,36,0.2);border-radius:5px;font-size:0.75rem;padding:0.12rem 0.4rem;">✈ ${b.start}–${b.end}${b.student ? ' · '+escHtml(b.student) : ''}</span>`).join('') +
        `</div>`;

      return `<div style="padding:0.75rem 0.85rem;background:var(--navy);border:1px solid var(--border);border-radius:8px;margin-bottom:0.6rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;margin-bottom:0.35rem;">
          ${nameTag}
          <div style="display:flex;flex-wrap:wrap;gap:0.3rem;">${windowsHtml}</div>
        </div>
        ${bookingsHtml}
      </div>`;
    }).join('');
  } catch (err) {
    gridEl.innerHTML = `<p style="color:var(--red);font-size:0.85rem;">Failed to load.</p>`;
  }
}

// ─── END INSTRUCTOR AVAILABILITY ─────────────────────────

// ─── ADMIN: SOURCE CODE DOWNLOAD ─────────────────────────
function downloadSourceCode() {
  const btn = document.getElementById('download-source-btn');
  const status = document.getElementById('download-source-status');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Generating…'; }
  if (status) { status.style.display = 'inline'; status.textContent = 'Building archive — this may take a few seconds…'; }

  // Create a hidden anchor and trigger download via the authenticated session
  fetch('/api/admin/download-source', {
    method: 'GET',
    headers: { 'Authorization': 'Bearer ' + (localStorage.getItem('fs_token') || '') },
    credentials: 'include'
  })
  .then(res => {
    if (!res.ok) return res.json().then(e => { throw new Error(e.error || 'Download failed'); });
    return res.blob();
  })
  .then(blob => {
    const today = new Date().toISOString().slice(0,10).replace(/-/g,'');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FlightSlate_Source_${today}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    if (status) status.textContent = 'Downloaded!';
    setTimeout(() => { if (status) status.style.display = 'none'; }, 3000);
  })
  .catch(err => {
    if (status) { status.style.display = 'inline'; status.style.color = '#EF4444'; status.textContent = 'Error: ' + err.message; }
    showToast('Download failed: ' + err.message, 'error');
  })
  .finally(() => {
    if (btn) { btn.disabled = false; btn.innerHTML = '&#8659; Download ZIP'; }
  });
}

// ─── ADMIN: RESET ALL DATA ───────────────────────────────
function openResetModal() {
  const input = document.getElementById('reset-confirm-input');
  const btn = document.getElementById('reset-confirm-btn');
  const errEl = document.getElementById('reset-modal-error');
  if (input) input.value = '';
  if (btn) btn.disabled = true;
  if (errEl) errEl.classList.add('hidden');
  document.getElementById('reset-modal').classList.remove('hidden');
}

function closeResetModal() {
  document.getElementById('reset-modal').classList.add('hidden');
}

async function confirmResetAllData() {
  const input = document.getElementById('reset-confirm-input');
  const btn = document.getElementById('reset-confirm-btn');
  const errEl = document.getElementById('reset-modal-error');
  if (input.value !== 'RESET') return;

  btn.disabled = true;
  btn.textContent = 'Resetting…';
  if (errEl) errEl.classList.add('hidden');

  try {
    await api('/api/admin/reset-all-data', { method: 'POST' });
    closeResetModal();
    showToast('All flight data, hours, billing, and training history have been reset', 'success');
    // Reload dashboard to reflect clean slate
    navigate('dashboard');
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.error || 'Reset failed. Please try again.';
      errEl.classList.remove('hidden');
    }
    btn.disabled = false;
    btn.textContent = '🗑️ Delete Everything';
  }
}
// ─── END ADMIN: RESET ALL DATA ───────────────────────────

init();