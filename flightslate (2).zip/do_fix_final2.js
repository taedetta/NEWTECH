// Fix the broken \\' and \\"  escapes in HTML attribute values
const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// The broken line uses onclick="..." (double-quoted HTML attr)
// Inside it has \" sequences that break HTML
// Fix: change onclick=" to onclick=' (HTML single-quoted attr)
// Then the inner JS can use ' without breaking

// Direct string replacement approach
// The problematic line (from JSON output):
// "var editRoleBtn = isOwner && !isSelf ? ' <button style=\"background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s\" title=\"Edit user\" onmouseover=\"this.style.color='var(--sky)'\" onmouseout=\"this.style.color='var(--gray-400)'\" onclick=\"openRoleChangeModal(' + u.id + ',\\'\\'' + escHtml(u.name).replace(/'/g,\"\\\\'\") + '\\'\\',\\'' + u.role + '\\', ' + (!!u.is_instructor ? 'true' : 'false') + ')"

The fix:
1. Change onclick=" to onclick='
2. Change the escaped quotes inside to use plain ' (no backslash)
3. Change the replace pattern from "\\\\'" to "&apos;"

Let me apply the fix by replacing the specific broken sequences:

// Step 1: Change onclick=" to onclick='
let fixed = targetLine.replace('onclick="openRoleChangeModal', "onclick='openRoleChangeModal");

// Step 2: Fix the inner \\'  sequences - they become just '
// The pattern in file: ',\\'\\'' + escHtml -> ' , ' + escHtml (remove backslash before quotes)
fixed = fixed.replace(",'\\'' + escHtml(u.name)", ",'" + " + escHtml(u.name)");
fixed = fixed.replace("'\\'' + u.role", "'" + " + u.role");

// Hmm, this is getting messy. Let me try a more targeted approach.
// The actual broken pattern in the file is the combination of:
// 1. onclick=" instead of onclick='
// 2. The escaped quotes inside

// Let me just write the correct replacement using string concatenation
const correctBtn = [
  'var editRoleBtn = isOwner && !isSelf ? ',
  '\u0027 <button style="background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s" title="Edit user" onmouseover="this.style.color=\u0027var(--sky)\u0027" onmouseout="this.style.color=\u0027var(--gray-400)\u0027" onclick=\u0027openRoleChangeModal(\u0027 + u.id + \u0027,\u0027 + escHtml(u.name).replace(/\u0027/g,"&apos;") + \u0027,\u0027 + u.role + \u0027,\u0027 + (!!u.is_instructor ? \u0027true\u0027 : \u0027false\u0027) + \u0027)\u0027>&#9998;<\/button>\u0027 : \u0027\u0027;'
].join('');

console.log('Correct btn:', correctBtn);

// But this won't work because the template substitutions won't happen in the .map context
// Let me just directly fix the specific broken parts

// The key insight: in the onclick HTML single-quoted attribute,
// we don't need to escape ' (single quote) because HTML attr uses ' as delimiter
// So: onclick='...openRoleChangeModal(' + u.id + ','...'>' - this works!

// The issue is the \\'  patterns in the file make JS parse errors
// Fix: remove the backslash before each ' in the onclick value

// The specific broken sequences in onclick value:
const onclickBrokenParts = [
  ",'\\'' + escHtml(u.name)",    // broken: ,'\"
  "'\"," + u.role",           // broken: '"\"
  "'\", '",                   // broken: '\"
];

// The correct versions (without backslash before quote in HTML single-quoted attr):
// ' + u.id + ','  (no backslash)
// + u.role + ',
// + (!!u.is_instructor ? 'true' : 'false') + '

// Let me just do a direct replacement using the exact file content
const fileContent = targetLine;
console.log('File line has onclick with double quotes:', fileContent.includes('onclick="openRoleChangeModal'));
console.log('File line has broken \\'\\'' pattern:', fileContent.includes("\\'\\''"));

// If the line has the broken pattern, apply fixes
if (fileContent.includes('onclick="openRoleChangeModal')) {
  // Fix 1: change onclick=" to onclick='
  let f = fileContent.replace('onclick="openRoleChangeModal', "onclick='openRoleChangeModal");

  // Fix 2: change \\'\\''  to just '  (backslash-quote-quote becomes just quote)
  f = f.replace(/\\'\\''/g, "'");

  // Fix 3: change the closing of onclick to use single quote
  f = f.replace(/\\)"\/>/g, ")'>");

  // Fix 4: change remaining \\'  in the onclick value
  f = f.replace(/\\'/g, "'");

  console.log('After fix, has onclick with single quote:', f.includes("onclick='openRoleChangeModal"));
  console.log('After fix, preview:', f.substring(f.indexOf('onclick='), f.indexOf('onclick=') + 150));

  lines[8888] = f;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('onclick pattern not found - might already be fixed or different');
}