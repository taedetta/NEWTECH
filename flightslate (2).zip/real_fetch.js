// Use the sapiom_fetch to get the actual served HTML
// Or use the screenshot tool that already works
// Let's use browser automation to check the console

// For now, let's check the actual script structure by looking at
// what comes BEFORE the main JS block in app.html

const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');

// Find where the main <script> block starts (the big one at the end)
const mainScriptStart = content.lastIndexOf('<script>');
console.log('Last <script> at char:', mainScriptStart);

// The script starts at mainScriptStart. Let's check what's before it.
const beforeMainScript = content.slice(Math.max(0, mainScriptStart - 200), mainScriptStart);
console.log('Before main script:', beforeMainScript);

// Check if the HTML before contains any broken script references
const lines = content.split('\n');
console.log('Total lines:', lines.length);

// Look for onclick handlers with complex content that might have broken syntax
// Specifically look for patterns with &apos; or &#39;
let found = [];
for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('&apos;') || lines[i].includes('&#39;')) {
        found.push({line: i+1, content: lines[i].slice(0, 150)});
    }
}
console.log('Lines with HTML entities in JS context:', found.length);
if (found.length > 0) console.log(found[0]);

// Check for BOM or other invisible chars at start of script
const mainJSBlock = content.slice(mainScriptStart + '<script>'.length);
console.log('\nFirst 100 chars of main JS:');
console.log(mainJSBlock.slice(0, 100));
console.log('\nLast 100 chars of main JS:');
console.log(mainJSBlock.slice(-100));
