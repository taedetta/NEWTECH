// Fix line 8889 - it has a broken double-onclick that needs complete replacement
const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const target = lines[8888];

console.log('Line length:', target.length);
console.log('Has &#9998;:', target.includes('&#9998;'));
console.log('First 200 chars:', JSON.stringify(target.substring(0, 200)));

// The correct onclick value (what we want in the HTML file):
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// In this, '\\\") is: three backslashes + quote (the JS replacement string)
// In the HTML file: we need the three backslashes, so the template must have six backslashes: '\\\\\\"'

// Build the correct onclick using template literal (backtick string, so \backslash is literal)
const correctOnclick = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\\\\"') + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log('Correct onclick:', correctOnclick);
console.log('Correct onclick JSON:', JSON.stringify(correctOnclick));

// Check: what does the replacement part look like?
const repIdx = correctOnclick.indexOf('.replace');
console.log('Replacement section:', correctOnclick.substring(repIdx, repIdx + 50));
console.log('Replacement JSON:', JSON.stringify(correctOnclick.substring(repIdx, repIdx + 50)));

// The replacement in correctOnclick is: '\\\\\\"' which in JS string = 3 backslashes + quote = 4 chars
// When the browser parses the HTML attribute, it sees: replace(/'/g,'\\\") where \\\\" = 3 backslashes + quote
// That's the correct replacement string!

// Now find and replace in the target line.
// Strategy: find &#9998; and work backwards to find the last "onclick=" before it
// Then replace from that "onclick=" to the ">" after it

const btnIdx = target.indexOf('&#9998;');
console.log('&#9998; at:', btnIdx);

// Find the last "onclick=" before the button
let lastOnclickIdx = -1;
let searchFrom = 0;
while (true) {
  const found = target.indexOf('onclick="', searchFrom);
  if (found > 0 && found < btnIdx) {
    lastOnclickIdx = found;
    searchFrom = found + 1;
  } else {
    break;
  }
}
console.log('Last onclick= before button at:', lastOnclickIdx);

if (lastOnclickIdx < 0) {
  console.log('ERROR: could not find onclick before button');
  process.exit(1);
}

// Find the ">" that closes this onclick (the one right before &#9998;)
const onclickEndIdx = target.lastIndexOf('">', btnIdx);
console.log('onclick end tag at:', onclickEndIdx);

if (onclickEndIdx < lastOnclickIdx) {
  console.log('ERROR: could not find onclick end');
  process.exit(1);
}

// Extract parts before and after
const beforeOnclick = target.substring(0, lastOnclickIdx);
const afterOnclickEnd = target.substring(onclickEndIdx + 2); // include the ">"

console.log('Before onclick:', JSON.stringify(beforeOnclick.substring(0, 100)));
console.log('After onclick end:', JSON.stringify(afterOnclickEnd.substring(0, 50)));

// Construct new line
const newLine = beforeOnclick + correctOnclick + afterOnclickEnd;

console.log('---');
const newOnclickStart = newLine.indexOf('onclick');
console.log('New line onclick area:', JSON.stringify(newLine.substring(newOnclickStart, newOnclickStart + 300)));

lines[8888] = newLine;
fs.writeFileSync('./public/app.html', lines.join('\n'));
console.log('File written!');