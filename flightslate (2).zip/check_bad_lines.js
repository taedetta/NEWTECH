const fs = require('fs');
const content = fs.readFileSync('./public/app.html', 'utf8');
const lines = content.split('\n');

let bad = [];
let good = [];

lines.forEach((line, i) => {
  if (!line.includes('replace')) return;
  // Find all replace(/'/g,...) occurrences in this line
  let idx = line.indexOf("replace(/'/g");
  while (idx !== -1) {
    // Get the rest of the replace call
    let rest = line.substring(idx);
    let end = rest.search(/[,)]/);
    if (end !== -1 && end < 30) {
      let call = rest.substring(0, end + 1);
      // Good: ends with "\\'"  (backslash-quote)
      // Bad: ends with "\\\""  (backslash-quote-mark)
      if (call.includes('\\\\\\"') || call.includes('\\\\"')) {
        bad.push((i+1) + ': ' + call);
      } else if (call.includes("\\\\'") || call.includes("\\'")) {
        good.push((i+1) + ': ' + call);
      }
    }
    idx = line.indexOf("replace(/'/g", idx + 1);
  }
});

console.log('BAD (double-quote escape - BROKEN):');
bad.forEach(l => console.log(l));
console.log('\nGOOD (single-quote escape - OK):');
good.forEach(l => console.log(l));
console.log('\nTotal bad:', bad.length, 'Total good:', good.length);