const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  
  await page.goto('https://new-tech-aviation.polsia.app/app');
  await page.waitForTimeout(2000);
  
  console.log('Page URL:', page.url());
  console.log('Page title:', await page.title());
  
  const bodyText = await page.textContent('body');
  console.log('Body preview:', bodyText.slice(0, 500));
  
  await browser.close();
})().catch(e => {
  console.error('Playwright error:', e.message);
  process.exit(1);
});
