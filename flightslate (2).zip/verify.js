const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const idx = content.indexOf('code-file-tree');
console.log('code-file-tree at index:', idx);
if (idx !== -1) {
  console.log('Context:', JSON.stringify(content.substring(idx-20, idx+50)));
}
const idx2 = content.indexOf('code-file-empty');
console.log('code-file-empty at index:', idx2);
if (idx2 !== -1) {
  console.log('Context:', JSON.stringify(content.substring(idx2-20, idx2+50)));
}