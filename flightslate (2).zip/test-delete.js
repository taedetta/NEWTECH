const https = require('https');
const crypto = require('crypto');

const APP_URL = 'https://new-tech-aviation.polsia.app';
const JWT_SECRET = 'a0df902b43ec02b1d7d0c9159f71ebaaa493f20e40b84bf109ed8a7e6c8244aec5d1d554782a4670cdb460b660740e1a486a3f495fbbe2fe668af4908c95136f';

// Generate JWT for user
function generateJWT(userId, email, role) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const payload = {
    userId,
    email,
    role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 3600
  };

  const base64Header = Buffer.from(JSON.stringify(header)).toString('base64url');
  const base64Payload = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signatureInput = `${base64Header}.${base64Payload}`;
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(signatureInput).digest('base64url');

  return `${base64Header}.${base64Payload}.${signature}`;
}

// Find an aircraft to delete (one with no active bookings)
async function findAircraftWithNoBookings() {
  return new Promise((resolve, reject) => {
    const req = https.request(`${APP_URL}/api/aircraft`, {
      headers: { Authorization: `Bearer ${generateJWT(1, 'bunnfarmva@gmail.com', 'owner')}` }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const aircraft = JSON.parse(data);
          console.log('Aircraft list:', aircraft.map(a => ({ id: a.id, tail: a.tail_number, status: a.status })));
          // Pick the first aircraft with no bookings
          resolve(aircraft[0]?.id);
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

// Try to DELETE an aircraft
async function deleteAircraft(aircraftId) {
  return new Promise((resolve, reject) => {
    const req = https.request(`${APP_URL}/api/aircraft/${aircraftId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${generateJWT(1, 'bunnfarmva@gmail.com', 'owner')}`,
        'Content-Type': 'application/json'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`DELETE /api/aircraft/${aircraftId} → Status: ${res.statusCode}`);
        console.log('Response:', data.substring(0, 500));
        resolve({ status: res.statusCode, body: data });
      });
    });
    req.on('error', reject);
    req.end();
  });
}

(async () => {
  console.log('=== Testing DELETE /api/aircraft/:id ===\n');

  // Step 1: Get aircraft list
  console.log('Step 1: Fetching aircraft list...');
  let aircraftId;
  try {
    aircraftId = await findAircraftWithNoBookings();
    console.log('First aircraft ID:', aircraftId);
  } catch (e) {
    console.error('Failed to fetch aircraft list:', e.message);
    process.exit(1);
  }

  if (!aircraftId) {
    console.log('No aircraft found');
    process.exit(1);
  }

  // Step 2: Try to delete
  console.log(`\nStep 2: Attempting DELETE on aircraft ID ${aircraftId}...`);
  await deleteAircraft(aircraftId);
})().catch(e => {
  console.error('Script error:', e.message);
  process.exit(1);
});