const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');

// Find all script tags and extract content
const scriptContent = [];
const regex = /<script>([\n\r]*[\\S]+[\n\r]*)<\/script>/gi;
let match;
while ((match = regex.exec(html)) !== null) {
  scriptContent.push(match[1]);
}
const fullScript = scriptContent.join('\n');
fs.writeFileSync('./tmp_js.js', fullScript);
console.log('Written', fullScript.length, 'chars of JS');