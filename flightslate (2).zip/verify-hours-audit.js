'use strict';
// Verification script for hours-audit endpoint
require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const pool = require('./db/index');

async function verify() {
  console.log('=== Database Schema Checks ===\n');

  // Check aircraft_hours_history table exists
  try {
    const tableCheck = await pool.query(`
      SELECT column_name, data_type
      FROM information_schema.columns
      WHERE table_name = 'aircraft_hours_history'
      ORDER BY ordinal_position
    `);
    if (tableCheck.rows.length === 0) {
      console.log('FAIL: aircraft_hours_history table does not exist');
    } else {
      console.log('OK: aircraft_hours_history table exists with columns:');
      tableCheck.rows.forEach(r => console.log(`  - ${r.column_name} (${r.data_type})`));
    }
  } catch (err) {
    console.log('ERROR checking table:', err.message);
  }

  // Check users table
  try {
    const userCheck = await pool.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'users' AND column_name IN ('id','name','role')
    `);
    console.log('\nOK: users table has relevant columns:', userCheck.rows.map(r=>r.column_name).join(', '));
  } catch (err) {
    console.log('ERROR checking users:', err.message);
  }

  // Check aircraft table
  try {
    const acCheck = await pool.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_name = 'aircraft' AND column_name IN ('id','tail_number','make_model')
    `);
    console.log('OK: aircraft table has relevant columns:', acCheck.rows.map(r=>r.column_name).join(', '));
  } catch (err) {
    console.log('ERROR checking aircraft:', err.message);
  }

  // Simulate the hours-audit query
  console.log('\n=== Running hours-audit query (as simulated owner) ===\n');
  try {
    const result = await pool.query(`
      SELECT h.id, h.aircraft_id, h.field, h.old_value, h.new_value, h.note, h.created_at,
             h.source, h.booking_id, u.name AS changed_by_name, a.tail_number, a.make_model
      FROM aircraft_hours_history h
      LEFT JOIN users u ON h.changed_by = u.id
      JOIN aircraft a ON a.id = h.aircraft_id
      ORDER BY h.created_at DESC LIMIT 500
    `);
    console.log(`OK: Query succeeded, ${result.rows.length} rows returned`);
    if (result.rows.length > 0) {
      console.log('Sample row keys:', Object.keys(result.rows[0]).join(', '));
    }
  } catch (err) {
    console.log('ERROR: Query failed:', err.message);
    console.log('SQLSTATE:', err.code);
  }

  await pool.end();
}

verify().catch(e => {
  console.error('Verification script error:', e);
  pool.end().catch(() => {});
});