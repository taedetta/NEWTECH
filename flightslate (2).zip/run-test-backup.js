/**
 * One-shot test backup script — runs immediately, sends to both recipients.
 * Run: NODE_ENV=development node run-test-backup.js
 */

'use strict';

// Load env
require('dotenv').config({ path: '.env' });

// Manually set env if not already set
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = 'REDACTED/neondb?sslmode=require';
}
if (!process.env.POLSIA_API_KEY) {
  process.env.POLSIA_API_KEY = 'company_96457_38438287bb28c60fe17bb8740cc859f3';
}

const { Pool } = require('pg');
const { runBackup } = require('./backup-service');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

async function main() {
  console.log('Starting test backup (daily frequency with current data)...');
  console.log('Recipients: operations@3vaflight.com, blankthe97@gmail.com');
  console.log('');

  try {
    const result = await runBackup(pool, 'daily');
    console.log('\nTest backup result:', JSON.stringify(result, null, 2));
    if (result.success) {
      console.log('\n✅ Test backup sent successfully!');
      console.log(`   Archive: NewTechAviation_Backup_Daily_${result.label}.zip`);
      console.log(`   Size: ${result.zipSizeKb}KB`);
      console.log(`   Records: ${result.recordCounts?.map(r => `${r.name}: ${r.count}`).join(', ')}`);
    } else {
      console.log('\n❌ Backup failed:', result.error);
    }
  } catch (err) {
    console.error('Fatal error:', err);
  } finally {
    await pool.end();
  }
}

main();
