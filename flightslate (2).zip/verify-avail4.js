const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';

(async () => {
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0];
    const page = context.pages()[0];

    // Navigate to availability
    await page.evaluate(() => navigate('availability'));
    await page.waitForTimeout(3000);

    // Get bounding rects and positions of key elements
    const diagnostics = await page.evaluate(() => {
      const results = {};

      // Check page-availability
      const pageDiv = document.getElementById('page-availability');
      if (pageDiv) {
        const rect = pageDiv.getBoundingClientRect();
        const style = window.getComputedStyle(pageDiv);
        results.pageAvailability = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: rect.bottom, right: rect.right },
          display: style.display,
          visibility: style.visibility,
          opacity: style.opacity,
          overflow: style.overflow,
          position: style.position,
          zIndex: style.zIndex,
          color: style.color,
          backgroundColor: style.backgroundColor,
          transform: style.transform
        };
      }

      // Check main-content
      const mainContent = document.querySelector('.main-content');
      if (mainContent) {
        const rect = mainContent.getBoundingClientRect();
        const style = window.getComputedStyle(mainContent);
        results.mainContent = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: rect.bottom, right: rect.right },
          display: style.display,
          overflow: style.overflow,
          overflowY: style.overflowY,
          scrollTop: mainContent.scrollTop,
          scrollHeight: mainContent.scrollHeight,
          clientHeight: mainContent.clientHeight
        };
      }

      // Check app-layout
      const appLayout = document.querySelector('.app-layout');
      if (appLayout) {
        const rect = appLayout.getBoundingClientRect();
        const style = window.getComputedStyle(appLayout);
        results.appLayout = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          display: style.display,
          overflow: style.overflow
        };
      }

      // Check app-screen
      const appScreen = document.getElementById('app-screen');
      if (appScreen) {
        const rect = appScreen.getBoundingClientRect();
        const style = window.getComputedStyle(appScreen);
        results.appScreen = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          display: style.display,
          overflow: style.overflow
        };
      }

      // Check the H1 inside page-availability
      const h1 = pageDiv ? pageDiv.querySelector('h1') : null;
      if (h1) {
        const rect = h1.getBoundingClientRect();
        const style = window.getComputedStyle(h1);
        results.h1 = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          color: style.color,
          fontSize: style.fontSize,
          text: h1.textContent.trim()
        };
      }

      // Check the weekly grid
      const grid = document.getElementById('avail-weekly-grid');
      if (grid) {
        const rect = grid.getBoundingClientRect();
        results.weeklyGrid = {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          children: grid.children.length,
          innerHTMLLength: grid.innerHTML.length
        };
      }

      // Check viewport
      results.viewport = {
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight,
        scrollX: window.scrollX,
        scrollY: window.scrollY
      };

      // Check body/html
      results.body = {
        scrollTop: document.body.scrollTop,
        scrollHeight: document.body.scrollHeight,
        clientHeight: document.body.clientHeight
      };

      return results;
    });

    console.log('FULL DIAGNOSTICS:', JSON.stringify(diagnostics, null, 2));

    // Now add a bright debug overlay to verify rendering
    await page.evaluate(() => {
      const pageDiv = document.getElementById('page-availability');
      if (pageDiv) {
        pageDiv.style.border = '5px solid red';
        pageDiv.style.background = 'rgba(255,0,0,0.1)';
        pageDiv.style.minHeight = '200px';
      }
      const h1 = pageDiv ? pageDiv.querySelector('h1') : null;
      if (h1) {
        h1.style.color = 'red';
        h1.style.fontSize = '40px';
        h1.style.background = 'yellow';
      }
    });
    await page.waitForTimeout(500);

    // Take screenshot with debug overlay
    await page.screenshot({ path: './availability-debug.png', fullPage: false });
    console.log('Debug screenshot saved to ./availability-debug.png');

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
    console.error(err.stack);
  }
})();
