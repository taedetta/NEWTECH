'use strict';

// Startup route verification — runs after server.listen().
// Hits critical endpoints locally and logs their status.
// Ensures broken routes fail fast and are visible in Render logs.

const http = require('http');

const CRITICAL_ROUTES = [
  { path: '/health', expectedStatus: 200, label: '/health', method: 'GET' },
  { path: '/api/auth/login', expectedStatus: [400, 401, 500], label: '/api/auth/login (no-creds POST)', method: 'POST', body: JSON.stringify({ email: 'test@test.com', password: 'test' }) },
  { path: '/api/site-content', expectedStatus: [200, 401], label: '/api/site-content', method: 'GET' },
  { path: '/api/bookings', expectedStatus: [200, 401], label: '/api/bookings', method: 'GET' },
  { path: '/api/instructor-availability', expectedStatus: [200, 401], label: '/api/instructor-availability', method: 'GET' },
];

function makeLocalRequest(port, route) {
  return new Promise((resolve) => {
    const opts = { hostname: 'localhost', port, path: route.path, method: route.method || 'GET', timeout: 3000 };
    if (route.body) {
      opts.headers = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(route.body) };
    }
    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        resolve({ status: res.statusCode, body: data });
      });
    });
    req.on('error', (err) => resolve({ status: -1, error: err.message }));
    req.on('timeout', () => { req.destroy(); resolve({ status: -1, error: 'timeout' }); });
    if (route.body) req.write(route.body);
    req.end();
  });
}

async function runStartupVerification(port) {
  console.log('\n━━━ Startup Route Verification ━━━');

  let criticalFailures = [];
  let passed = 0;
  let failed = 0;

  for (const route of CRITICAL_ROUTES) {
    await new Promise((r) => setTimeout(r, 50)); // small stagger to avoid port race
    const result = await makeLocalRequest(port, route);
    const status = result.status;
    const expectedStatuses = Array.isArray(route.expectedStatus) ? route.expectedStatus : [route.expectedStatus];
    const isOk = expectedStatuses.includes(status);

    if (status === -1) {
      console.log(`✗ ${route.label.padEnd(40)} CRITICAL — unreachable: ${result.error}`);
      criticalFailures.push(route.path);
      failed++;
    } else if (status === 404) {
      console.log(`✗ ${route.label.padEnd(40)} CRITICAL — 404 NOT FOUND`);
      criticalFailures.push(route.path);
      failed++;
    } else if (!isOk) {
      console.log(`⚠ ${route.label.padEnd(40)} unexpected status ${status} (expected ${expectedStatuses.join(' or ')})`);
      failed++;
    } else {
      console.log(`✓ ${route.label.padEnd(40)} ${status === 200 ? '200 OK' : status === 401 ? '401 auth required' : status}`);
      passed++;
    }
  }

  console.log('━'.repeat(46));

  if (criticalFailures.length > 0) {
    console.error(`[CRITICAL] Route verification FAILED — the following routes returned 404:`);
    criticalFailures.forEach((p) => console.error(`  [CRITICAL]   ${p}`));
    console.error('[CRITICAL] These routes need immediate attention. Deploy may serve broken routes.');
  } else if (failed > 0) {
    console.log(`Route verification completed — ${passed} passed, ${failed} warning(s)`);
  } else {
    console.log(`✓ Server ready — all critical routes verified (${passed}/${CRITICAL_ROUTES.length})`);
  }

  return { passed, failed, criticalFailures };
}

module.exports = { runStartupVerification };