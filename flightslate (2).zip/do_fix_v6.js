const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Find and fix the broken replace pattern
// The file has the pattern where \\'  appears (backslash-quote)
// This is in the replace(/'/g,"\\'") section

// Search for the pattern by looking for .replace followed by /'/g
const replaceIdx = targetLine.indexOf('.replace(/'/g');
if (replaceIdx >= 0) {
  console.log('Found replace at position:', replaceIdx);
  console.log('Content around replace:', JSON.stringify(targetLine.substring(replaceIdx, replaceIdx + 50)));

  // The pattern to find is: .replace(/'/g,"\\\\'")  (in JS string notation: \\\\ = \\ in actual string)
  // In actual characters in the file: \\\\ = two backslashes, ' = single quote, ") = close paren
  // So the actual pattern is: replace(/'/g,"\\'")  where \\ = two literal backslashes

  // Let's find the section to replace
  const sectionStart = replaceIdx;
  const sectionEnd = targetLine.indexOf('")', replaceIdx) + 2;
  const currentSection = targetLine.substring(sectionStart, sectionEnd);
  console.log('Current section:', JSON.stringify(currentSection));

  // The fix: replace .replace(/'/g,"\\'") with .replace(/'/g,"&apos;")
  // But we need to be careful about escaping

  // Since the current section is: .replace(/'/g,"\\'")
  // We want: .replace(/'/g,"&apos;")
  // Both are inside a JS double-quoted context in the file

  const fixedSection = '.replace(/'/g,"&apos;")';
  console.log('Fixed section:', JSON.stringify(fixedSection));

  const newLine = targetLine.substring(0, sectionStart) + fixedSection + targetLine.substring(sectionEnd);
  console.log('New line preview:', newLine.substring(newLine.indexOf('onclick='), newLine.indexOf('onclick=') + 200));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}