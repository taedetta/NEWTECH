const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=ef2e1541-b370-4f38-96f5-8387aff0b22e';
const BASE_URL = 'https://www.newtechaviation.com';

async function test() {
  const browser = await chromium.connectOverCDP(CDP_URL);
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();

  const consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', err => consoleErrors.push('PAGE ERROR: ' + err.message));

  try {
    // Navigate to app
    console.log('Navigating to app...');
    await page.goto(BASE_URL + '/app', { waitUntil: 'networkidle', timeout: 15000 });

    const loginForm = await page.$('#login-form');
    console.log('Login form visible:', !!loginForm);

    // Login as Brandon (owner)
    console.log('Logging in as Brandon (owner)...');
    await page.fill('#login-email', 'blankthe97@gmail.com');
    await page.fill('#login-password', 'TestPass123!');
    await page.click('#login-form button[type="submit"]');
    await page.waitForTimeout(3000);

    const appVisible = await page.$('#app-screen:not(.hidden)');
    console.log('App screen visible:', !!appVisible);

    if (!appVisible) {
      console.log('Login failed!');
      const errorEl = await page.$('#login-error');
      if (errorEl) console.log('Error:', await errorEl.textContent());
      return;
    }

    // Check Programs nav visibility
    const navPrograms = await page.$('#nav-programs');
    console.log('nav-programs element exists:', !!navPrograms);

    if (navPrograms) {
      const isHidden = await navPrograms.evaluate(el => el.classList.contains('hidden'));
      console.log('nav-programs is hidden:', isHidden);
    }

    // Navigate to Programs page
    console.log('\nNavigating to Programs page...');
    await page.click('#nav-programs');
    await page.waitForTimeout(2000);

    // Check if page is visible
    const pagePrograms = await page.$('#page-programs');
    const pageHidden = pagePrograms ? await pagePrograms.evaluate(el => el.classList.contains('hidden')) : true;
    console.log('page-programs is hidden:', pageHidden);

    // Check content
    const listContent = await page.$eval('#programs-list', el => el.textContent).catch(() => 'NOT FOUND');
    console.log('\nPrograms list content:');
    console.log('- Length:', listContent.length);
    console.log('- First 300 chars:', listContent.substring(0, 300).replace(/\n/g, ' '));

    // Check page description
    const pageDesc = await page.$eval('#programs-page-desc', el => el.textContent).catch(() => 'NOT FOUND');
    console.log('\nPage description:', pageDesc);

    // Check console errors
    console.log('\n=== Console Errors ===');
    consoleErrors.forEach(e => console.log(' -', e));

    // Take a screenshot
    console.log('\nTaking screenshot...');
    const screenshot = await page.screenshot({ path: 'programs-page-screenshot.png', fullPage: true });
    console.log('Screenshot saved to programs-page-screenshot.png');

  } catch (err) {
    console.error('Test error:', err.message);
  } finally {
    await browser.close();
  }
}

test().catch(console.error);