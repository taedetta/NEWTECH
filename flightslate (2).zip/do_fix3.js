// Fix the editRoleBtn button - all \\'  and \\"  in HTML attrs are broken
// The fix: in HTML attribute values inside template literals, we need to NOT escape quotes
// because HTML doesn't have \\'  escape sequence. Instead use the quote chars directly
// BUT: JS single-quoted strings still need escaping of '
// So: the replace(/'/g,"\\'") is for JS string escaping, but the HTML context breaks it
//
// Solution: use HTML &#39; (entity) for the replacement string so HTML doesn't break
// And use plain '  in the HTML attr since single quotes don't end a double-quoted HTML attr
//
// Actually simpler: just change the entire button to use a more careful construction
// that avoids the double-escape problem

const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');

const targetLine = lines[8888];

// The broken line (current state after first fix):
// var editRoleBtn = isOwner && !isSelf ? ' <button style="..." title="Edit user" onmouseover="this.style.color='var(--sky)'" onmouseout="this.style.color='var(--gray-400)'" onclick="openRoleChangeModal(' + u.id + ',\\'\"
//   + escHtml(u.name).replace(/'/g,"\\'") + '\\',' + u.role + '\\',' + (!!u.is_instructor ? 'true' : 'false') + ')"><img src="edit.svg"/><'/button>' : '';

// The problem: the onclick="..." HTML double-quoted attr contains \\' which is broken
// Fix: change onclick to use single-quoted HTML attr (so JS single quotes are fine)
// Then fix the replace() to not have escaped quotes in the replacement string

// New editRoleBtn construction:
// Use ' for HTML attr instead of " to avoid HTML attr quoting issues
const newEditRoleBtn = `var editRoleBtn = isOwner && !isSelf ? ' <button style="background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s" title="Edit user" onmouseover="this.style.color='var(--sky)'" onmouseout="this.style.color='var(--gray-400)'" onclick='openRoleChangeModal(${u.id},"${escHtml(u.name).replace(/'/g,"&apos;")}",${u.role},${!!u.is_instructor})'>&#9998;</button>' : '';`;

// But this doesn't work because the button is inside a template literal that builds HTML
// The issue: the template uses ' as JS string delimiter, so the whole thing is complex

// LET'S JUST FIX THE SPECIFIC BROKEN PATTERN DIRECTLY
// The onclick has: onclick="openRoleChangeModal(...\\'...\\',..."
// We need to change the HTML attr delimiter to ' so JS ' doesn't need escaping

// Check if the line contains the broken pattern
const brokenOnclick = targetLine.includes("onclick=\"openRoleChangeModal(' + u.id + ',\\'\\''");
console.log('Has broken onclick pattern:', brokenOnclick);

if (brokenOnclick) {
  // Replace the broken onclick pattern with a working version
  // The fix: change onclick=" to onclick=' (HTML single-quoted attr)
  // and change \\'  to ' in the JS code
  // The replace(/'/g,"\\'") needs to become replace(/'/g,"&apos;") for HTML safety

  let fixedLine = targetLine
    // Change onclick HTML attr from double-quoted to single-quoted
    .replace(/onclick="openRoleChangeModal\/'/, "onclick='openRoleChangeModal/")
    // Fix the escaped quotes: \\'  -> ' in the HTML single-quoted attr context
    .replace(/,\\'\\''/g, ",'")
    .replace(/\\'\\'/g, "'")
    .replace(/replace\/'\/g,"\\\\'")/g, 'replace(/'/'/g,"&apos;")')
    .replace(/\\'\\','/g, "','");

  console.log('After replacement:', fixedLine.includes("onclick='openRoleChangeModal"));
  console.log('Fixed line preview:', fixedLine.substring(200, 400));
} else {
  console.log('Looking for alternative pattern...');
  // Show what the actual onclick looks like
  const onclickIdx = targetLine.indexOf('onclick=');
  if (onclickIdx >= 0) {
    console.log('Actual onclick:', JSON.stringify(targetLine.substring(onclickIdx, onclickIdx + 150)));
  }
}