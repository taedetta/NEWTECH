// Verify the POST /enroll endpoint returns proper errors
const BASE = 'https://new-tech-aviation.polsia.app';

async function test(label, url, opts, expectStatus, expectErrorContains) {
  try {
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({ error: 'non-JSON response' }));
    const pass = res.status === expectStatus &&
      (!expectErrorContains || (data.error && data.error.toLowerCase().includes(expectErrorContains.toLowerCase())));
    console.log(`${pass ? '✅' : '❌'} ${label} — status=${res.status} error=${data.error || 'none'}`);
    return pass;
  } catch (e) {
    console.log(`❌ ${label} — fetch error: ${e.message}`);
    return false;
  }
}

async function main() {
  // Test 1: No auth → should get 401
  await test(
    'No auth token',
    `${BASE}/api/training/enroll`,
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' },
    401, null
  );

  // Test 2: Try to log in with test account
  let token = null;
  try {
    const loginRes = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'blankthe97@gmail.com', password: 'test123' })
    });
    const loginData = await loginRes.json();
    token = loginData.token;
    console.log(`Login: status=${loginRes.status} role=${loginData.user?.role || 'unknown'}`);
  } catch (e) {
    console.log(`Login failed: ${e.message}`);
  }

  if (token) {
    const authHeaders = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };

    await test(
      'Missing student_id',
      `${BASE}/api/training/enroll`,
      { method: 'POST', headers: authHeaders, body: JSON.stringify({ program_id: 1 }) },
      400, 'student_id'
    );

    await test(
      'Missing program_id',
      `${BASE}/api/training/enroll`,
      { method: 'POST', headers: authHeaders, body: JSON.stringify({ student_id: 1 }) },
      400, 'program_id'
    );

    await test(
      'Invalid program_id (nonexistent)',
      `${BASE}/api/training/enroll`,
      { method: 'POST', headers: authHeaders, body: JSON.stringify({ student_id: 999999, program_id: 999999 }) },
      404, 'not found'
    );
  } else {
    console.log('Skipping auth tests — could not log in');
  }

  console.log('\nDone.');
}
main();
