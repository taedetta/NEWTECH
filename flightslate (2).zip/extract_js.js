const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
// Extract all script tag contents (non-greedy, handles newlines)
const scriptMatches = html.match(/<script>([\\S\t\n\r ]*?)<\/script>/g);
if (!scriptMatches) {
  console.log('No scripts found');
  process.exit(1);
}
let allJS = '';
scriptMatches.forEach((m, i) => {
  const content = m.replace('<script>', '').replace('</script>', '');
  allJS += '\n// --- SCRIPT ' + i + ' ---\n' + content;
});
// Write to temp file
fs.writeFileSync('/tmp/app_js_check.js', allJS);
console.log('Extracted ' + scriptMatches.length + ' script blocks, ' + allJS.length + ' chars');