const { chromium } = require('playwright');

async function main() {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=cd9b0d7e-4033-45cb-84cb-9b92a75f72bc');
  const page = await browser.newPage();

  const errors = [];

  page.on('console', msg => {
    if (msg.type() === 'error') errors.push('[ERROR] ' + msg.text());
  });

  page.on('pageerror', err => errors.push('[PAGE ERROR] ' + err.message));

  await page.goto('https://www.newtechaviation.com/app');
  await page.waitForTimeout(3000);

  console.log('=== CONSOLE ERRORS ===');
  errors.forEach(e => console.log(e));
  console.log('Total errors:', errors.length);

  // Check if showScreen is defined
  const hasShowScreen = await page.evaluate(() => typeof showScreen === 'function');
  console.log('showScreen defined:', hasShowScreen);

  // Check if previewLoaded is defined
  const hasPreviewLoaded = await page.evaluate(() => typeof previewLoaded === 'function');
  console.log('previewLoaded defined:', hasPreviewLoaded);

  // Try clicking sign in button
  const signInBtn = await page.$('button[type="submit"]');
  console.log('Submit button found:', !!signInBtn);

  // Get the onclick of the Forgot Password link
  const forgotLink = await page.$('a:has-text("Forgot your password")');
  if (forgotLink) {
    const onclick = await forgotLink.getAttribute('onclick');
    console.log('Forgot password onclick:', onclick);
  }

  // Get the login form action
  const loginForm = await page.$('#login-form');
  if (loginForm) {
    console.log('Login form found');
  }

  // Check what screen is visible
  const loginScreen = await page.$('#login-screen:not(.hidden)');
  console.log('Login screen visible:', !!loginScreen);

  await browser.close();
  console.log('Done');
}

main().catch(e => { console.error('Error:', e.message); process.exit(1); });