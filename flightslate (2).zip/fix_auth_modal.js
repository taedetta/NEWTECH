const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');

// Fix line 8889 (0-indexed: 8888) - editRoleBtn inline handler broken \\_' escape
const targetLine = lines[8888];

// The broken pattern: onmouseover="this.style.color=\\'var(--sky)\\'"
// In the file this is the literal backslash-quote sequence
// Fix: remove the backslash before each single quote in these HTML attribute values
const fixedLine = targetLine
  .replace(/onmouseover="this.style.color=\\'var\/\/sky\/'/, 'onmouseover="this.style.color=\\\\'var--sky\\\\\\'')
  .replace(/onmouseout="this.style.color=\\'var\/\/gray-400\/'/, 'onmouseout="this.style.color=\\\\'var--gray-400\\\\\\'');

console.log('Target line contains broken pattern:', targetLine.includes("onmouseover=\"this.style.color=\\'var(--sky)\\'\""));
console.log('Fixed would be:', fixedLine.includes("onmouseover=\"this.style.color='var(--sky)'\""));