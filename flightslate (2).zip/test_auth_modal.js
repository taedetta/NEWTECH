const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=fb877040-1d06-495d-9003-f6738260e095');
  const page = await browser.newPage();
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', err => errors.push('PAGE ERROR: ' + err.message));

  await page.goto('https://www.newtechaviation.com/app', { waitUntil: 'networkidle' });
  await new Promise(r => setTimeout(r, 2000));

  // Check auth modal state
  const authModalDisplay = await page.evaluate(() => {
    const modal = document.getElementById('auth-modal');
    if (!modal) return 'ELEMENT NOT FOUND';
    return {
      display: modal.style.display,
      computedDisplay: window.getComputedStyle(modal).display,
      className: modal.className,
      clientWidth: modal.clientWidth,
      clientHeight: modal.clientHeight,
      opacity: window.getComputedStyle(modal).opacity,
    };
  });
  console.log('Auth modal state:', JSON.stringify(authModalDisplay, null, 2));

  // Check what screen is showing
  const screenState = await page.evaluate(() => {
    return {
      appScreen: document.getElementById('app-screen') ? document.getElementById('app-screen').className : 'NOT FOUND',
      pendingScreen: document.getElementById('pending-screen') ? document.getElementById('pending-screen').className : 'NOT FOUND',
      resetScreen: document.getElementById('reset-screen') ? document.getElementById('reset-screen').className : 'NOT FOUND',
    };
  });
  console.log('Screen state:', JSON.stringify(screenState, null, 2));

  // Check visible elements in body
  const bodyInfo = await page.evaluate(() => {
    const body = document.body;
    return {
      bodyChildren: body.children.length,
      bodyBg: window.getComputedStyle(body).backgroundColor,
      bodyMinHeight: window.getComputedStyle(body).minHeight,
      authModalParent: document.getElementById('auth-modal') ? document.getElementById('auth-modal').parentElement.tagName : 'NOT FOUND',
    };
  });
  console.log('Body info:', JSON.stringify(bodyInfo, null, 2));

  console.log('JS Errors:', errors.length ? errors : 'NONE');
  await browser.close();
})().catch(e => console.error('Error:', e.message));