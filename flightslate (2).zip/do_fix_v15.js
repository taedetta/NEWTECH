const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

console.log('Checking current state...');
const onclickStart = targetLine.indexOf('onclick');
const s = targetLine.substring(onclickStart, onclickStart + 250);

// Show the onclick section
console.log('onclick section:', s.substring(0, 200));

// The current broken onclick has:
// ,' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')">
// The ' before + ( is wrong - it puts the quote before ) in the ternary result
// Fix: remove the ' before + ( and put it after ) instead

// The correct onclick:
const correctOnclick = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log('Correct onclick:', correctOnclick);

// Find the onclick section - look for onclick="openRoleChangeModal
const onclickAttrStart = targetLine.indexOf('onclick="openRoleChangeModal');
const quoteEnd = targetLine.indexOf('">', onclickAttrStart);

if (onclickAttrStart >= 0 && quoteEnd >= 0) {
  console.log('Found onclick at', onclickAttrStart, 'ends at', quoteEnd);
  const before = targetLine.substring(0, onclickAttrStart);
  const after = targetLine.substring(quoteEnd + 2);

  const newLine = before + correctOnclick + after;
  console.log('New line preview:', newLine.substring(onclickAttrStart, onclickAttrStart + 200));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}