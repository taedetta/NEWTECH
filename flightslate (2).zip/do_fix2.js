// Fix all broken \\' escapes in HTML attribute values in the editRoleBtn button
// In HTML attribute values, \\' is WRONG - it causes JS parse errors
// Fix: use ' instead of \\' (single quotes don't need escaping in HTML attribute values)
// But wait - the HTML attr uses double quotes for the attribute itself
// So the issue is: onclick="..." contains single quotes as JS string delimiters
// In an HTML double-quoted attr, you can't put literal ' without escaping... except HTML has no escape for '
// The fix: change HTML attr to use single quotes: onclick='...'

const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');

// The broken line is at index 8888
const targetLine = lines[8888];

// We need to replace the entire broken editRoleBtn button with one that uses
// single-quoted HTML attributes (so JS single quotes don't need escaping)
const brokenBtn = " <button style=\"background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s\" title=\"Edit user\" onmouseover=\"this.style.color='var(--sky)'\" onmouseout=\"this.style.color='var(--gray-400)'\" onclick=\"openRoleChangeModal(' + u.id + ',\\'\\'' + escHtml(u.name).replace(/'/g,\"\\\\'\") + '\\'\\',\\'\\'' + u.role + '\\'\\', ' + (!!u.is_instructor ? 'true' : 'false') + ')';\">&#9998;</button>";

// Wait, the actual content in the file is more complex. Let me just directly fix the \\' in onclick

// The line currently (after first fix) has:
// onclick="openRoleChangeModal(' + u.id + ',\\'\\'' + escHtml(u.name).replace(/'/g,\"\\\\'\") + '\\'\\',\\'\\'' + u.role + '\\'\\', ' + ...

// In HTML double-quoted attributes, \\' is WRONG. Replace with '
// But we also need to escape the HTML quotes... actually, let me just use a direct approach
// Replace the \\'  patterns (backslash-quote) in HTML attributes with just '

// Count how many \\' patterns exist in the line
const backslashQuoteCount = (targetLine.match(/\\'/g) || []).length;
console.log('Backslash-quote count in target line:', backslashQuoteCount);

// These are all in the context of an HTML attribute with double quotes
// In HTML, \\' inside a double-quoted attr means: backslash is literal, ' ends the attr
// The fix: use single-quoted HTML attributes for the button element
// onclick='...' allows ' inside without any escaping

// Let me replace the entire editRoleBtn with a version using single-quoted attrs
// But first, let me verify what's in the file
console.log('Line 8889:', targetLine.substring(0, 200));

// Fix: change all HTML attribute double-quotes in the button to single-quotes
// This allows JS single-quoted strings to be used without escaping
let fixedLine = targetLine
  // Fix onmouseover/onmouseout (already fixed but let's be sure)
  .replace(/onmouseover="this.style.color='var\/\/sky\/'"/, 'onmouseover=\\'this.style.color=\\'var(--sky)\\'\\'')
  .replace(/onmouseout="this.style.color='var\/\/gray-400\/'"/, 'onmouseout=\\'this.style.color=\\'var(--gray-400)\\'\\'');

// Now fix the onclick by replacing \\'  with just ' in HTML attribute context
// The pattern: in HTML double-quoted attrs, \\'  means literal backslash then ' which breaks
// The fix: use plain ' since single quotes don't need HTML escaping
// But since the HTML attr is double-quoted, we need a different approach

// Actually, the simplest fix is to use HTML entity for the quote in the replace fn
// No, let's use a JS approach: replace \\'  with ' in the onclick value
// But this is complex because the \\'  in the replace() call is valid JS, just broken in HTML context

// Best approach: change the entire button to use single-quoted HTML attributes
const goodBtn = " <button style='background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s' title='Edit user' onmouseover=\"this.style.color='var(--sky)'\" onmouseout=\"this.style.color='var(--gray-400)'\" onclick='openRoleChangeModal(" + ' + u.id + ',"' + " + escHtml(u.name).replace(/'/g,"\\\\'") + ","' + " + u.role + ",' + (!!u.is_instructor ? 'true' : 'false') + ')'><' + '/button>';

// Hmm, this is getting complex. Let me just directly fix the specific broken patterns

// The onclick attribute contains these broken patterns:
// 1. ',\\''  (openRoleChangeModal arg)
// 2. .replace(/'/g,"\\'")  (in the middle)
// 3. '\\','  (next arg)
// 4. '\\''  (u.role)
// 5. '\\','  (instructor bool)

// All of these inside onclick="..." are wrong because HTML double-quoted attrs
// don't support \\'  escape sequence

// Fix: change the HTML attribute from double-quoted to single-quoted
// This way, single quotes inside don't need escaping
// onclick='...' instead of onclick="..."

// For onclick, since we want to use single quotes in HTML, the onclick value should use
// template literals (backticks) for JS, or double-quoted JS strings
// The simplest: use onclick='...' (HTML single-quoted attr) so JS single quotes don't break

// But the replace(/'/g,"\\'") is for escaping single quotes IN JS STRINGS
// In this context, since we're in an HTML single-quoted attr, we just need to NOT escape the '

// The replace pattern: .replace(/'/g,"\\'") becomes .replace(/'/g,"'")
// But that's wrong - we need to escape ' for when it's inside a JS string
// The JS string delimiter here would be " (double quotes), not ' (single quotes)

// Wait, let me look at the actual onclick more carefully:
// onclick="openRoleChangeModal(' + u.id + ','\"
// The JS string is delimited by ' (single quote)
// So in the JS string ' + u.id + ', the ' ends the string
// But this is inside an HTML attribute value "..."
// The HTML parser sees ' as just a character, not a string delimiter
// So the HTML attr "..." continues until it sees another "

// So the issue is: onclick="openRoleChangeModal(' + u.id + ','"
// When HTML parses this: "openRoleChangeModal(" ends the attribute!
// Then the rest " + u.id + ','' is treated as HTML text

// Actually no, that's not right either. HTML doesn't stop at ' - only at " (for double-quoted attrs) or at > (for unquoted attrs).

// Let me reconsider. In an HTML double-quoted attribute:
// - " ends the attribute
// - ' is just a character (like any other letter)
// So onclick="openRoleChangeModal(' + u.id + ','' IS valid HTML

// The problem is when the browser passes this to JavaScript to execute as an inline handler.
// JavaScript sees: onclick="openRoleChangeModal(' + u.id + ',''"
// The HTML attribute value contains: openRoleChangeModal(' + u.id + ',''
// JavaScript parses this as: onclick handler
// The code: openRoleChangeModal(' + u.id + ',''
// JavaScript sees: openRoleChangeModal( → function call
// Then: ' + u.id + ' → a string containing " + u.id + "
// Then: , → comma
// Then: '' → two single quotes → empty string
// Then: ) → close paren... but the HTML attr has more content after

// I think the real issue is that the HTML attribute value doesn't close properly. Let me check the actual HTML attribute value for the onclick handler.

Looking at the attribute value in the file, I need to count the quotes carefully. The onclick starts with `onclick="openRoleChangeModal(` and contains multiple escaped quotes throughout. Rather than trace through every character, I should just fix this directly. The safest approach is to use single quotes for the HTML attribute so that JavaScript's single quote strings don't need escaping inside it. I'll rewrite the onclick handler with single quotes and handle the string concatenation properly for the name parameter. I'm seeing the full onclick handler now—the HTML attribute contains a JavaScript expression that builds a function call with interpolated values. The `replace()` method is escaping single quotes in the name parameter to prevent syntax errors, and the whole thing wraps up with a ternary operator to conditionally include an instructor flag. When the template gets inserted into the HTML, the escaped quotes become part of the actual JavaScript that runs.

The issue is that in HTML, backslash-quote sequences don't work as escapes inside attribute values, so the `replace()` call stays malformed in the final HTML. I'm considering a few solutions: using HTML entities like `&apos;` for quotes (though that might break JavaScript), switching to template literals with backticks instead of single quotes (but those are also special in HTML), or refactoring the code to avoid inline JavaScript in attributes altogether. The cleanest approach seems to be changing how the `replace()` function escapes quotes—instead of using `\\'`, I could use HTML entities or restructure the escaping logic.

Actually, the simplest fix is to change the HTML attribute itself from double quotes to single quotes. That way the JavaScript code inside can use single quotes without any escaping needed. I could replace all the double-quoted attributes in the button with single quotes, then adjust the template literal to produce the right output. But this is getting complicated with all the escaping layers—HTML attributes, template literals, and JavaScript string escaping all interacting with each other. Let me just write a quick fix that directly manipulates the string instead of trying to build it up layer by layer.