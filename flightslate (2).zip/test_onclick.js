// Test the onclick JS string parsing
const u = {
  id: 123,
  name: "Michael Birmingham",
  role: 0,
  is_instructor: true
};

function escHtml(s) {
  return s.replace(/'/g, "&apos;");
}

// Simulate the onclick concatenation
const onclickValue = `onclick='openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,"&apos;") + ',' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')'">&#9998;</button>' : ''`;

console.log('Result:', onclickValue);

// Extract inner JS by removing prefix and suffix using slice
const prefixLen = 8; // "onclick="
const suffix = '">' + '&#9998;</button>' + " : '';";
const suffixLen = suffix.length;
const inner = onclickValue.slice(prefixLen, onclickValue.length - suffixLen);
console.log('Inner JS:', inner);

try {
  const fn = new Function(inner);
  console.log('JS parses OK!');
} catch(e) {
  console.log('JS error:', e.message);
  const msg = e.message;
  const posMatch = msg.match(/at position (\\d+)/);
  if (posMatch) {
    const pos = parseInt(posMatch[1]);
    console.log('Error at pos', pos);
    console.log('Around error:', inner.substring(Math.max(0,pos-20), pos+30));
  }
}