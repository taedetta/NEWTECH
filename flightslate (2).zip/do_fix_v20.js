// Fix line 8889 - simpler approach
// Find first onclick= at position 1
// Find &#9998; at position 486
// The last onclick before button ends at the " just before &#9998; (position 485)
// Replace from position 1 to 486 (just before &#9998;) with correct onclick

const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const t = lines[8888];

console.log('Line length:', t.length);
console.log('First onclick= at:', t.indexOf('onclick='));
console.log('Button at:', t.indexOf('&#9998;'));

// Find first onclick= at position 1
const firstOnclickStart = t.indexOf('onclick=');
console.log('First onclick starts at:', firstOnclickStart);

// Find the " just before &#9998;
const btnIdx = t.indexOf('&#9998;');
const quoteBeforeBtn = btnIdx - 1; // the " just before &
console.log('Quote before button at:', quoteBeforeBtn);
console.log('Char at btnIdx-1:', JSON.stringify(t.charAt(btnIdx - 1))); // should be "

// The last onclick ends at quoteBeforeBtn (position 485)
// Replace from firstOnclickStart (1) to quoteBeforeBtn + 1 = 486 with correct onclick

// Build the correct onclick using template literal
// Want in file: onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,'\\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// In JS string: use character code to avoid quote issues
const sq = String.fromCharCode(39); // single quote
const correctOnclick = `onclick="openRoleChangeModal(${sq} + u.id + ${sq},${sq} + escHtml(u.name).replace(/${sq}/g,${sq}\\\\\\\"${sq}) + ${sq},${sq} + u.role + ${sq},${sq} + (!!u.is_instructor ? ${sq}true${sq} : ${sq}false${sq})${sq})"`;

console.log('\nCorrect onclick:', correctOnclick);
console.log('Correct onclick JSON:', JSON.stringify(correctOnclick));

// Verify replacement
const repStart = correctOnclick.indexOf('.replace');
console.log('Replacement:', JSON.stringify(correctOnclick.substring(repStart, repStart + 45)));

// Construct new line
const before = t.substring(0, firstOnclickStart); // everything before first onclick (position 0 = space)
const after = t.substring(btnIdx); // from &#9998; to end (includes &#9998;)
const newLine = before + correctOnclick + after;

console.log('\nNew line length:', newLine.length);
const newOnIdx = newLine.indexOf('onclick');
console.log('New line onclick area:', JSON.stringify(newLine.substring(newOnIdx, newOnIdx + 300)));

lines[8888] = newLine;
fs.writeFileSync('./public/app.html', lines.join('\n'));
console.log('File written!');