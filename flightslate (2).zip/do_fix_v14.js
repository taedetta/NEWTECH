const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

console.log('Current line 8889:');
console.log(targetLine);

// The broken onclick uses:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,&quot;&apos;&quot;) + ',' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')">
// The issue: + ' + ( places the quote before the ) in the ternary, breaking JS parsing
// Fix: put the quote AFTER the ), and use proper escaping

// Correct template:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')">
// In file: \\") -> template: \\") -> HTML attr: \") -> JS: \") -> replacement: "

// Also need to fix the quote position - put it at the end after )

// The correct line:
const correctOnclick = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log('Correct onclick:', correctOnclick);

// Find the onclick section
const onclickStart = targetLine.indexOf('onclick="');
const quoteEnd = targetLine.indexOf('">', onclickStart);

if (onclickStart >= 0 && quoteEnd >= 0) {
  console.log('Found onclick at', onclickStart, 'ends at', quoteEnd);
  const before = targetLine.substring(0, onclickStart);
  const after = targetLine.substring(quoteEnd + 2);

  const newLine = before + correctOnclick + after;
  console.log('New line preview:', newLine.substring(onclickStart, onclickStart + 200));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('onclick pattern not found');
  console.log('Current onclick:', targetLine.includes('onclick') ? targetLine.substring(targetLine.indexOf('onclick'), targetLine.indexOf('onclick') + 150) : 'not found');
}