const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const line = lines[8888];

console.log('Current onclick section:');
const onclickStart = line.indexOf('onclick');
console.log(line.substring(onclickStart, onclickStart + 250));

// Build the correct onclick using template literal
// The correct template for replace: /'/g,\"\\\"
// In template literal: /'/g,\"\\\\\" = /'/g,\"\\\" in output
// This gives \" in HTML attr -> \" in JS = \" escape = " (literal quote)
// Replacement string = " + & + a + p + o + s + ; + " = "&apos;"
// That's WRONG - we need the replacement to be " (just quote), not "&apos;"
// So we need \" in JS replacement = just quote char
// For JS to see \", the HTML attr must have \"
// For HTML attr to have \", the template must have \\
// So: template = \\\"  (4 chars: \\\\ = \\\\ in string = \\ output, \" = \" output) = \\"
// Wait: in template, \\\" = \\ + \" = \\ + " = \" (2 chars: backslash, quote)
// So \\\" in template = \" in output = \" in HTML = \" in JS = " (escaped quote) = literal quote in replacement
// Correct!

const newOnclick = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log('New onclick:', newOnclick);

// Find the old onclick in the line
const oldOnclickStart = line.indexOf('onclick="openRoleChangeModal');
const quoteEndPos = line.indexOf('">', oldOnclickStart);
const oldOnclick = line.substring(oldOnclickStart, quoteEndPos + 2);

console.log('Old onclick (exact):', JSON.stringify(oldOnclick));

if (line.includes(oldOnclick)) {
  const newLine = line.replace(oldOnclick, newOnclick);
  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
  console.log('New line preview:', newLine.substring(oldOnclickStart, oldOnclickStart + 200));
} else {
  console.log('Old onclick not found in line');
}