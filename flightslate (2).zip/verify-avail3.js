const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';

(async () => {
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0];
    const page = context.pages()[0];

    // Capture console logs
    const logs = [];
    page.on('console', msg => logs.push(`[${msg.type()}] ${msg.text()}`));

    // Re-navigate to availability to trigger loadAvailabilityPage again
    console.log('Re-navigating to availability...');
    await page.evaluate(() => {
      navigate('availability');
    });
    await page.waitForTimeout(3000);

    // Print captured console logs
    console.log('Console logs captured:');
    logs.forEach(l => console.log('  ', l));

    // Check grid again
    const gridContent = await page.evaluate(() => {
      const grid = document.getElementById('avail-weekly-grid');
      if (!grid) return 'grid not found';
      return `children: ${grid.children.length}, innerHTML length: ${grid.innerHTML.length}, first 500 chars: ${grid.innerHTML.substring(0, 500)}`;
    });
    console.log('Weekly grid after re-nav:', gridContent);

    // Check if availabilityData was set
    const availData = await page.evaluate(() => {
      return JSON.stringify(typeof availabilityData !== 'undefined' ? availabilityData : 'undefined');
    });
    console.log('availabilityData:', availData);

    // Check if DAY_NAMES exists
    const dayNames = await page.evaluate(() => {
      return typeof DAY_NAMES !== 'undefined' ? JSON.stringify(DAY_NAMES) : 'undefined';
    });
    console.log('DAY_NAMES:', dayNames);

    // Try manually calling renderWeeklyGrid
    console.log('Manually calling renderWeeklyGrid...');
    await page.evaluate(() => {
      try {
        renderWeeklyGrid();
        console.log('[MANUAL] renderWeeklyGrid succeeded');
      } catch (e) {
        console.error('[MANUAL] renderWeeklyGrid error:', e.message, e.stack);
      }
    });
    await page.waitForTimeout(1000);

    // Check grid again
    const gridAfter = await page.evaluate(() => {
      const grid = document.getElementById('avail-weekly-grid');
      if (!grid) return 'grid not found';
      return `children: ${grid.children.length}, innerHTML length: ${grid.innerHTML.length}`;
    });
    console.log('Weekly grid after manual render:', gridAfter);

    // Print any new console logs
    console.log('New console logs:');
    logs.forEach(l => console.log('  ', l));

    // Take final screenshot
    await page.screenshot({ path: './availability-final.png', fullPage: false });
    console.log('Final screenshot saved');

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
  }
})();
