const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';

(async () => {
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0];
    const page = context.pages()[0];

    // First: navigate to dashboard and check its dimensions
    console.log('=== NAVIGATING TO DASHBOARD ===');
    await page.evaluate(() => navigate('dashboard'));
    await page.waitForTimeout(3000);

    const dashDiag = await page.evaluate(() => {
      const pageDiv = document.getElementById('page-dashboard');
      if (!pageDiv) return 'not found';
      const rect = pageDiv.getBoundingClientRect();
      const style = window.getComputedStyle(pageDiv);
      return {
        rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
        display: style.display,
        className: pageDiv.className,
        inlineStyle: pageDiv.getAttribute('style')
      };
    });
    console.log('Dashboard page:', JSON.stringify(dashDiag, null, 2));

    await page.screenshot({ path: './dashboard-check.png', fullPage: false });
    console.log('Dashboard screenshot saved');

    // Now navigate to availability
    console.log('\n=== NAVIGATING TO AVAILABILITY ===');
    await page.evaluate(() => navigate('availability'));
    await page.waitForTimeout(3000);

    const availDiag = await page.evaluate(() => {
      const pageDiv = document.getElementById('page-availability');
      if (!pageDiv) return 'not found';
      const rect = pageDiv.getBoundingClientRect();
      const style = window.getComputedStyle(pageDiv);

      // Also check all other hidden pages' inline styles
      const allPages = Array.from(document.querySelectorAll('.page')).map(p => ({
        id: p.id,
        className: p.className,
        display: window.getComputedStyle(p).display,
        inlineStyle: p.getAttribute('style'),
        rect: {
          width: p.getBoundingClientRect().width,
          height: p.getBoundingClientRect().height
        }
      }));

      return {
        availability: {
          rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          display: style.display,
          className: pageDiv.className,
          inlineStyle: pageDiv.getAttribute('style'),
          visibility: style.visibility,
          opacity: style.opacity
        },
        allPages
      };
    });
    console.log('Availability diagnostic:', JSON.stringify(availDiag, null, 2));

    await page.screenshot({ path: './availability-check2.png', fullPage: false });
    console.log('Availability screenshot saved');

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
    console.error(err.stack);
  }
})();
