// Fix script: remove incorrect \\_' escaping in HTML attribute values
// The file has: onmouseover="this.style.color=\\'var(--sky)\\'"
// These backslash-quote patterns in HTML attrs are WRONG and cause JS parse errors
// Fix: change to plain single quotes: onmouseover="this.style.color='var(--sky)'"

const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');

const targetLine = lines[8888];

// Check the pattern
const hasBroken = targetLine.includes("onmouseover=\"this.style.color=\\'var(--sky)\\'\"");
console.log('Found broken pattern:', hasBroken);

if (hasBroken) {
  // Replace the broken escaped quotes with plain quotes
  const fixedLine = targetLine
    .replace("onmouseover=\"this.style.color=\\'var(--sky)\\'\"", "onmouseover=\"this.style.color='var(--sky)'\"")
    .replace("onmouseout=\"this.style.color=\\'var(--gray-400)\\'\"", "onmouseout=\"this.style.color='var(--gray-400)'\"");

  lines[8888] = fixedLine;

  const newHtml = lines.join('\n');
  fs.writeFileSync('./public/app.html', newHtml);
  console.log('Fixed! New line contains correct pattern:', fixedLine.includes("onmouseover=\"this.style.color='var(--sky)'\""));
} else {
  console.log('Pattern not found - checking for variations...');
  // Check what's actually there
  const idx = targetLine.indexOf('onmouseover');
  if (idx >= 0) {
    console.log('Actual onmouseover:', JSON.stringify(targetLine.substring(idx, idx+80)));
  }
}