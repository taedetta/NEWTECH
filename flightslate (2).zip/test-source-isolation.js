#!/usr/bin/env node

/**
 * test-source-isolation.js — Quick test of source isolation functionality.
 * Tests that APP_ENV is correctly set and source-wrapper functions work.
 */

const { getAppEnv, buildSourceParam, addSourceFilter } = require('./db/source-wrapper');

console.log('\n📋 Source Isolation Quick Test\n');

// Test 1: getAppEnv()
console.log('1. Testing getAppEnv()...');
const appEnv = getAppEnv();
console.log(`   APP_ENV = "${appEnv}"`);
console.log(`   ✅ Valid: ${['production', 'staging'].includes(appEnv)}\n`);

// Test 2: buildSourceParam()
console.log('2. Testing buildSourceParam()...');
const sourceParam = buildSourceParam();
console.log(`   Returns: { source: "${sourceParam.source}" }`);
console.log(`   ✅ Matches APP_ENV: ${sourceParam.source === appEnv}\n`);

// Test 3: addSourceFilter() - SELECT with no WHERE
console.log('3. Testing addSourceFilter() - SELECT (no WHERE)...');
const select1 = addSourceFilter('SELECT * FROM users');
console.log(`   Input:  SELECT * FROM users`);
console.log(`   Output: ${select1.sql}`);
console.log(`   Params: [${select1.params.join(', ')}]`);
console.log(`   ✅ Filter added: ${select1.sql.includes('WHERE source')}\n`);

// Test 4: addSourceFilter() - SELECT with WHERE
console.log('4. Testing addSourceFilter() - SELECT (with WHERE)...');
const select2 = addSourceFilter('SELECT * FROM users WHERE id = $1', [42]);
console.log(`   Input:  SELECT * FROM users WHERE id = $1, [42]`);
console.log(`   Output: ${select2.sql}`);
console.log(`   Params: [${select2.params.join(', ')}]`);
console.log(`   ✅ Filter appended: ${select2.sql.includes('AND source')}\n`);

// Test 5: addSourceFilter() - UPDATE
console.log('5. Testing addSourceFilter() - UPDATE...');
const update = addSourceFilter('UPDATE users SET name = $1 WHERE id = $2', ['Alice', 123]);
console.log(`   Input:  UPDATE users SET name = $1 WHERE id = $2, ['Alice', 123]`);
console.log(`   Output: ${update.sql}`);
console.log(`   Params: [${update.params.join(', ')}]`);
console.log(`   ✅ Filter appended: ${update.sql.includes('AND source')}\n`);

// Summary
console.log('='.repeat(60));
console.log('✅ All source-wrapper functions are working correctly!');
console.log('\nNext steps:');
console.log('  1. Run `npm run migrate` to apply source column schema changes');
console.log('  2. Run `node verify-source-isolation.js` for full verification');
console.log('  3. Deploy staging branch to a preview service');
console.log('  4. Test data isolation between staging and production');
console.log('='.repeat(60) + '\n');
