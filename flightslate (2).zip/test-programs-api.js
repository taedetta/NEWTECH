const https = require('https');

function httpReq(method, pathname, body, token) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'new-tech-aviation.polsia.app',
      path: pathname,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'FlightSlate/1.0'
      }
    };
    if (token) options.headers['Authorization'] = 'Bearer ' + token;
    if (body) options.headers['Content-Length'] = Buffer.byteLength(body);
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch (e) { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

(async () => {
  // 1. Login as Brandon to get a token
  const loginRes = await httpReq('POST', '/api/auth/login', JSON.stringify({ email: 'blankthe97@gmail.com', password: 'TestPass123!' }));
  console.log('Login status:', loginRes.status, 'role:', loginRes.body.user ? loginRes.body.user.role : 'no user');
  if (!loginRes.body.token) {
    console.log('No token, body:', JSON.stringify(loginRes.body).substring(0, 300));
    return;
  }

  const token = loginRes.body.token;
  console.log('Got token:', token.substring(0, 20) + '...');

  // 2. Test programs API (should work for owner)
  const programsRes = await httpReq('GET', '/api/training/programs', null, token);
  console.log('Programs API status:', programsRes.status);
  if (Array.isArray(programsRes.body)) {
    console.log('Number of programs:', programsRes.body.length);
    if (programsRes.body.length > 0) {
      console.log('First program stages count:', (programsRes.body[0].stages || []).length);
      console.log('First program first stage:', JSON.stringify(programsRes.body[0].stages[0]).substring(0, 200));
    }
  } else {
    console.log('Programs body:', JSON.stringify(programsRes.body).substring(0, 300));
  }

  // 3. Test program-enrollments API
  const enrollRes = await httpReq('GET', '/api/training/program-enrollments', null, token);
  console.log('Enrollments API status:', enrollRes.status);
  if (Array.isArray(enrollRes.body)) {
    console.log('Number of programs with enrollments:', enrollRes.body.length);
  } else {
    console.log('Enrollments body:', JSON.stringify(enrollRes.body).substring(0, 300));
  }
})().catch(e => console.error('Error:', e.message));