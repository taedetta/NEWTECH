const fs = require('fs');
const c = fs.readFileSync('public/app.html', 'utf8');
const l = c.split('\n');
const checks = [8744, 8789, 8809, 10136, 10337, 10338, 10355, 10356, 10364, 10365, 10949, 14557, 15243, 15253, 15348];
for (const n of checks) {
  const line = l[n-1];
  const idx = line.indexOf('replace(/');
  const slice = idx >= 0 ? line.substring(idx, idx+25) : 'NOT FOUND';
  const status = slice.includes('&#39;') ? 'BROKEN' : (slice.includes("\\'") || slice.includes("'\\'")) ? 'FIXED' : 'UNKNOWN';
  console.log('Line ' + n + ': ' + status + ' -> ' + slice.substring(0,30));
}