#!/usr/bin/env node

/**
 * verify-source-isolation.js — Verify source-tag data isolation is set up correctly.
 *
 * Tests:
 * 1. Source columns exist on data tables
 * 2. Existing records tagged as 'production'
 * 3. Source-wrapper module is importable
 * 4. APP_ENV is set correctly
 * 5. getAppEnv() returns expected value
 */

const pool = require('./db/index');
const { getAppEnv, addSourceFilter, buildSourceParam } = require('./db/source-wrapper');

const CRITICAL_TABLES = [
  'users', 'bookings', 'aircraft', 'users',
  'aircraft_downtime', 'flight_logs', 'billing_entries',
  'endorsements', 'discovery_flight_leads', 'feedback'
];

async function verify() {
  console.log('\n🔍 FlightSlate Source Isolation Verification\n');

  let allPass = true;

  // Test 1: Check APP_ENV
  console.log('1️⃣  Checking APP_ENV environment variable...');
  const appEnv = getAppEnv();
  const isValid = ['production', 'staging'].includes(appEnv);
  console.log(`   APP_ENV = "${appEnv}" ${isValid ? '✅' : '❌'}`);
  if (!isValid) allPass = false;

  // Test 2: Check source columns exist
  console.log('\n2️⃣  Checking source columns on critical tables...');
  for (const table of CRITICAL_TABLES) {
    try {
      const result = await pool.query(`
        SELECT column_name FROM information_schema.columns
        WHERE table_name = $1 AND column_name = 'source'
      `, [table]);

      const hasSourceCol = result.rows.length > 0;
      console.log(`   ${table}: ${hasSourceCol ? '✅' : '❌'}`);
      if (!hasSourceCol) allPass = false;
    } catch (e) {
      console.log(`   ${table}: ❌ (error: ${e.message})`);
      allPass = false;
    }
  }

  // Test 3: Check existing records are tagged
  console.log('\n3️⃣  Checking if production records are tagged...');
  const dataTables = [
    'users', 'bookings', 'aircraft',
    'billing_entries', 'discovery_flight_leads'
  ];

  for (const table of dataTables) {
    try {
      const result = await pool.query(
        `SELECT COUNT(*) as total,
                COUNT(CASE WHEN source = 'production' THEN 1 END) as prod_count,
                COUNT(CASE WHEN source = 'staging' THEN 1 END) as stag_count,
                COUNT(CASE WHEN source IS NULL THEN 1 END) as null_count
         FROM ${table} LIMIT 1`
      );

      const row = result.rows[0];
      if (row.total > 0) {
        const hasProduction = parseInt(row.prod_count) > 0;
        const hasNull = parseInt(row.null_count) > 0;
        const status = hasProduction || row.total === 0 ? '✅' : '⚠️ ';
        console.log(`   ${table}: ${status} (${row.total} total, ${row.prod_count} production, ${row.stag_count} staging, ${row.null_count} null)`);

        if (hasNull && row.total > 0) {
          console.log(`       ⚠️  WARNING: Found NULL source values! These should be tagged.`);
          allPass = false;
        }
      } else {
        console.log(`   ${table}: ✅ (empty, will be tagged on first insert)`);
      }
    } catch (e) {
      // Table might not exist or have data
      console.log(`   ${table}: ℹ️  (${e.message.substring(0, 50)}...)`);
    }
  }

  // Test 4: Test source-wrapper functions
  console.log('\n4️⃣  Testing source-wrapper functions...');

  try {
    const param = buildSourceParam();
    console.log(`   buildSourceParam(): ✅ (returns { source: "${param.source}" })`);
  } catch (e) {
    console.log(`   buildSourceParam(): ❌ (${e.message})`);
    allPass = false;
  }

  try {
    const filtered = addSourceFilter('SELECT * FROM users WHERE id = $1', [1]);
    const hasSourceFilter = filtered.sql.includes('AND source =') || filtered.sql.includes('WHERE source =');
    console.log(`   addSourceFilter(): ${hasSourceFilter ? '✅' : '❌'}`);
    if (hasSourceFilter) {
      console.log(`      Generated SQL: ${filtered.sql}`);
      console.log(`      Generated params: [${filtered.params.join(', ')}]`);
    }
  } catch (e) {
    console.log(`   addSourceFilter(): ❌ (${e.message})`);
    allPass = false;
  }

  // Test 5: Check migration file
  console.log('\n5️⃣  Checking migration file...');
  const fs = require('fs');
  const migrationExists = fs.existsSync('./migrations/1779395261_add_source_isolation.sql');
  console.log(`   migration/1779395261_add_source_isolation.sql: ${migrationExists ? '✅' : '❌'}`);
  if (!migrationExists) allPass = false;

  // Test 6: Check source-wrapper module
  console.log('\n6️⃣  Checking source-wrapper module...');
  try {
    const wrapper = require('./db/source-wrapper');
    const hasGetAppEnv = typeof wrapper.getAppEnv === 'function';
    const hasAddSourceFilter = typeof wrapper.addSourceFilter === 'function';
    const hasBuildSourceParam = typeof wrapper.buildSourceParam === 'function';
    const hasQueryWithSourceFilter = typeof wrapper.queryWithSourceFilter === 'function';

    console.log(`   getAppEnv: ${hasGetAppEnv ? '✅' : '❌'}`);
    console.log(`   addSourceFilter: ${hasAddSourceFilter ? '✅' : '❌'}`);
    console.log(`   buildSourceParam: ${hasBuildSourceParam ? '✅' : '❌'}`);
    console.log(`   queryWithSourceFilter: ${hasQueryWithSourceFilter ? '✅' : '❌'}`);

    if (!hasGetAppEnv || !hasAddSourceFilter || !hasBuildSourceParam || !hasQueryWithSourceFilter) {
      allPass = false;
    }
  } catch (e) {
    console.log(`   Error loading module: ❌ (${e.message})`);
    allPass = false;
  }

  // Summary
  console.log('\n' + '='.repeat(60));
  if (allPass) {
    console.log('✅ All source isolation checks PASSED!');
    console.log('\nYour staging/production data isolation is ready.');
    console.log('Next steps:');
    console.log('  1. Deploy staging branch to a preview service');
    console.log('  2. Set APP_ENV=staging on the preview service');
    console.log('  3. Test: Create data on staging, verify it doesn\'t appear in production');
  } else {
    console.log('⚠️  Some checks FAILED. Please review the output above.');
    console.log('\nCommon issues:');
    console.log('  - Migration not run: Execute `npm run migrate`');
    console.log('  - source column missing: Ensure migration is in migrations/ folder');
    console.log('  - APP_ENV not set: Set APP_ENV=production or APP_ENV=staging');
  }
  console.log('='.repeat(60) + '\n');

  pool.end();
  process.exit(allPass ? 0 : 1);
}

verify().catch(e => {
  console.error('❌ Verification error:', e.message);
  pool.end();
  process.exit(1);
});
