const { chromium } = require('playwright');
const sessionId = process.argv[2];
const cdpUrl = `wss://connect.anchorbrowser.io/?sessionId=${sessionId}`;

(async () => {
  const browser = await chromium.connectOverCDP(cdpUrl);
  const context = browser.contexts()[0] || await browser.newContext();
  const page = context.pages()[0] || await context.newPage();
  
  const errors = [];
  const consoleMsgs = [];
  
  page.on('console', msg => {
    consoleMsgs.push({ type: msg.type(), text: msg.text() });
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });
  
  page.on('pageerror', err => {
    errors.push('PageError: ' + err.message);
  });
  
  await page.goto('https://www.newtechaviation.com/app', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);
  
  console.log('=== Console Errors ===');
  errors.forEach(e => console.log(e));
  console.log('=== All Console Messages ===');
  consoleMsgs.forEach(m => console.log(`[${m.type}] ${m.text}`));
  console.log('=== Page Title ===');
  console.log(await page.title());
  
  await browser.close();
})().catch(e => { console.error('Error:', e.message); process.exit(1); });
