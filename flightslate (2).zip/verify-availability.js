const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';
const TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTQsImVtYWlsIjoiYXZ0ZXN0MkBwb2xzaWEuaW50ZXJuYWwiLCJuYW1lIjoiVGVzdGVyIiwicm9sZSI6Imluc3RydWN0b3IiLCJpYXQiOjE3NzgxODY3MDEsImV4cCI6MTc3ODc5MTUwMX0.DEMny0FY2eZzeXFvr62yH7rcmaD4Mrrqdwla245hWYs';
const APP_URL = 'https://www.newtechaviation.com/app';

(async () => {
  let browser;
  try {
    console.log('Connecting to browser...');
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0] || await browser.newContext();
    const page = context.pages()[0] || await context.newPage();

    // Navigate to the app login page first
    console.log('Navigating to app...');
    await page.goto(APP_URL, { waitUntil: 'networkidle', timeout: 30000 });
    console.log('Page loaded, URL:', page.url());

    // Set the JWT token in localStorage
    console.log('Setting JWT token...');
    await page.evaluate((token) => {
      localStorage.setItem('fs_token', token);
    }, TOKEN);

    // Reload to trigger login with the token
    console.log('Reloading to login...');
    await page.reload({ waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(3000);

    // Check if we're in the app
    const appVisible = await page.evaluate(() => {
      const appScreen = document.getElementById('app-screen');
      if (!appScreen) return 'app-screen not found';
      const computed = window.getComputedStyle(appScreen);
      return `app-screen: display=${computed.display}, classes=${appScreen.className}`;
    });
    console.log('App state:', appVisible);

    // Check sidebar for My Availability
    const navAvailState = await page.evaluate(() => {
      const nav = document.getElementById('nav-availability');
      if (!nav) return 'nav-availability not found';
      const computed = window.getComputedStyle(nav);
      return `nav-availability: display=${computed.display}, classes=${nav.className}, text=${nav.textContent.trim()}`;
    });
    console.log('Nav availability state:', navAvailState);

    // Click on My Availability
    console.log('Clicking My Availability...');
    await page.evaluate(() => {
      navigate('availability');
    });
    await page.waitForTimeout(3000);

    // Check page-availability state
    const pageState = await page.evaluate(() => {
      const pageDiv = document.getElementById('page-availability');
      if (!pageDiv) return 'page-availability NOT FOUND IN DOM';
      const computed = window.getComputedStyle(pageDiv);
      const innerText = pageDiv.innerText.substring(0, 200);
      const childCount = pageDiv.children.length;
      return {
        display: computed.display,
        visibility: computed.visibility,
        opacity: computed.opacity,
        height: computed.height,
        width: computed.width,
        classes: pageDiv.className,
        childCount: childCount,
        innerHTML_length: pageDiv.innerHTML.length,
        innerText_preview: innerText
      };
    });
    console.log('Page availability state:', JSON.stringify(pageState, null, 2));

    // Check for console errors
    const consoleLogs = [];
    page.on('console', msg => consoleLogs.push(`[${msg.type()}] ${msg.text()}`));

    // Check current page
    const currentPage = await page.evaluate(() => {
      return typeof currentPage !== 'undefined' ? currentPage : 'undefined';
    });
    console.log('currentPage:', currentPage);

    // Take a screenshot
    console.log('Taking screenshot...');
    const screenshot = await page.screenshot({
      path: '/tmp/claude/availability-check.png',
      fullPage: false
    });
    console.log('Screenshot saved to /tmp/claude/availability-check.png');
    console.log('Screenshot size:', screenshot.length, 'bytes');

    // Final check - dump all page elements visibility
    const allPages = await page.evaluate(() => {
      const pages = document.querySelectorAll('.page');
      return Array.from(pages).map(p => ({
        id: p.id,
        classes: p.className,
        display: window.getComputedStyle(p).display,
        innerHTML_length: p.innerHTML.length
      }));
    });
    console.log('All pages:', JSON.stringify(allPages, null, 2));

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
    console.error(err.stack);
  }
})();
