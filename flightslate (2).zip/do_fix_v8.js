const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Find the .replace section
const searchPattern = `.replace(/'/g`;
const replaceIdx = targetLine.indexOf(searchPattern);

if (replaceIdx >= 0) {
  console.log('Found replace at position:', replaceIdx);

  const afterReplace = targetLine.substring(replaceIdx);
  const closeQuoteIdx = afterReplace.indexOf('")');
  const sectionEnd = replaceIdx + closeQuoteIdx + 2;
  const currentSection = targetLine.substring(replaceIdx, sectionEnd);

  console.log('Current section:', JSON.stringify(currentSection));

  // Fix: change to use &apos; in the replacement
  const fixedSection = `.replace(/'/g,"&apos;")`;
  console.log('Fixed section:', JSON.stringify(fixedSection));

  let newLine = targetLine.substring(0, replaceIdx) + fixedSection + targetLine.substring(sectionEnd);

  // Also fix the extra empty strings
  newLine = newLine.split(`onclick='openRoleChangeModal(' + u.id + ','' +`).join(`onclick='openRoleChangeModal(' + u.id + ',' +`);
  newLine = newLine.split(`+ '','' + u.role`).join(`+ ',' + u.role`);
  newLine = newLine.split(`+ '', ' +`).join(`+ ',' + ' +`);

  const idx = newLine.indexOf('onclick');
  console.log('After fix, onclick:', JSON.stringify(newLine.substring(idx, idx + 200)));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}