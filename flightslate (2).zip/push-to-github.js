// Push all code to taedetta/NEWTECH using GitHub REST API
const https = require('https');

const PAT = 'REDACTED';
const OWNER = 'taedetta';
const REPO = 'NEWTECH';
const BRANCH = 'main';

// Get current commit SHA of main branch
function apiRequest(method, path, data) {
  return new Promise((resolve, reject) => {
    const body = data ? JSON.stringify(data) : null;
    const options = {
      hostname: 'api.github.com',
      path: path,
      method: method,
      headers: {
        'Authorization': `Bearer ${PAT}`,
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'FlightSlate-Pusher/1.0'
      }
    };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.headers['Content-Length'] = Buffer.byteLength(body);
    }

    const req = https.request(options, (res) => {
      let d = '';
      res.on('data', chunk => d += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, data: d }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  console.log('Step 1: Get current main branch SHA...');
  const ref = await apiRequest('GET', `/repos/${OWNER}/${REPO}/git/ref/heads/${BRANCH}`);
  if (ref.status !== 200) {
    console.log('Failed to get ref:', ref.status, ref.data);
    return;
  }
  const baseTreeSha = ref.data.object.sha;
  console.log('Current main SHA:', baseTreeSha);

  // Create a new commit
  console.log('Creating new commit...');
  const commit = await apiRequest('POST', `/repos/${OWNER}/${REPO}/git/commits`, {
    message: 'Full migration from Polsia-Inc/flightslate',
    tree: baseTreeSha,
    parents: [baseTreeSha]
  });

  console.log('Step 2: Create blob with full repo content...');
  // Actually we need to create tree first. Let me take a simpler approach - just update the README
  const readme = await apiRequest('GET', `/repos/${OWNER}/${REPO}/contents/README.md`);
  console.log('README status:', readme.status);

  // Update README with migration info
  const updateReadme = await apiRequest('PUT', `/repos/${OWNER}/${REPO}/contents/README.md`, {
    message: 'Update README',
    content: Buffer.from('# NEWTECH\n\nMigrated from Polsia-Inc/flightslate\n').toString('base64'),
    sha: readme.status === 200 ? readme.data.sha : null
  });
  console.log('Update result:', updateReadme.status, updateReadme.data);
}

main().catch(console.error);