const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const lines = content.split('\n');

// Check key lines
console.log('Line 8744 check:');
const l8744 = lines[8743];
console.log('  Has &#39;:', l8744.includes('&#39;'));
console.log('  Has backslash-quote pattern:', l8744.includes("\\'") || l8744.includes("'\\'"));

console.log('\nLine 10136 check:');
const l10136 = lines[10135];
console.log('  Has &#39;:', l10136.includes('&#39;'));
console.log('  Has backslash-quote pattern:', l10136.includes("\\'") || l10136.includes("'\\'"));

console.log('\nLine 15348 check:');
const l15348 = lines[15347];
console.log('  Has &#39;:', l15348.includes('&#39;'));
console.log('  Has backslash-quote pattern:', l15348.includes("\\'") || l15348.includes("'\\'"));

// Find all replace patterns with issues
console.log('\nAll replace(/... patterns:');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('replace(/')) {
    const idx = lines[i].indexOf('replace(/');
    const slice = lines[i].substring(idx, idx + 30);
    if (slice.includes('&#39;')) {
      console.log('Line ' + (i+1) + ' OK: ' + slice.substring(0, 40));
    } else if (slice.includes("\\'") || slice.includes("'\\'")) {
      console.log('Line ' + (i+1) + ' HAS BACKSLASH-QUOTE: ' + slice.substring(0, 40));
    } else {
      console.log('Line ' + (i+1) + ' OTHER: ' + slice.substring(0, 40));
    }
  }
}