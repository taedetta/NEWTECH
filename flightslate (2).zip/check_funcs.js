const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const scriptStart = html.indexOf('<script>');
const scriptEnd = html.lastIndexOf('</script>');
const js = html.substring(scriptStart + 8, scriptEnd);
console.log('Script block length:', js.length, 'bytes');

const funcs = ['viewStudentReadiness', 'openAssignModal', 'closeReadinessModal', 'closeAssignModal'];
for (const f of funcs) {
  const idx = js.indexOf(f);
  if (idx >= 0) {
    console.log(f + ': FOUND at position ' + idx);
  } else {
    console.log(f + ': MISSING!');
  }
}

// Check modal HTML
const modals = ['readiness-modal', 'assign-modal'];
for (const m of modals) {
  const idx = html.indexOf('id="' + m + '"');
  if (idx >= 0) {
    console.log(m + ': FOUND at position ' + idx);
  } else {
    console.log(m + ': MISSING!');
  }
}

// Check the button onclick attributes
const btn1 = html.includes('onclick="viewStudentReadiness(');
const btn2 = html.includes('onclick="openAssignModal(');
console.log('Button onclick viewStudentReadiness:', btn1 ? 'YES' : 'NO');
console.log('Button onclick openAssignModal:', btn2 ? 'YES' : 'NO');

// Check the API endpoint in the function
const apiEndpoint = js.includes('/api/training/checkride-readiness/');
console.log('API endpoint /api/training/checkride-readiness/:', apiEndpoint ? 'YES' : 'NO');

// Check the route exists
const fs2 = require('fs');
const trainingRoute = fs2.readFileSync('./routes/training.js', 'utf8');
const routeCheck = trainingRoute.includes("router.get('/checkride-readiness/:studentId'");
console.log('Route /checkride-readiness/:studentId:', routeCheck ? 'YES' : 'NO');