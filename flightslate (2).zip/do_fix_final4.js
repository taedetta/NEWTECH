const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Current broken state has: onclick='openRoleChangeModal(' + u.id + ','' + escHtml(u.name).replace(/'/g,"\\'") + '',''
// The replace(/'/g,"\\'")  has broken \" in the replacement string
// Fix: change "\\\\'" to "&apos;" so HTML doesn't break

let f = targetLine;

// Fix 1: change the broken replace pattern
// Current: .replace(/'/g,"\\'")
// Fix: .replace(/'/g,"&apos;")
f = f.replace('.replace(/'/g,"\\\\'")', '.replace(/'/g,"&apos;")');

// Fix 2: remove the extra empty strings '' that were created by the previous fix
// Current: onclick='openRoleChangeModal(' + u.id + ','' +
// Should be: onclick='openRoleChangeModal(' + u.id + ',' +
f = f.replace("onclick='openRoleChangeModal(' + u.id + ','' +", "onclick='openRoleChangeModal(' + u.id + ',' +");

// Fix 3: remove the extra '' before + u.role
f = f.replace("+ '','' + u.role", "+ ',' + u.role");

// Fix 4: remove the extra '' before + '
f = f.replace("+ '', ' +", "+ ',' + ' +");

console.log('Fixed onclick check:', f.includes("onclick='openRoleChangeModal"));
const idx = f.indexOf('onclick');
console.log('onclick section:', f.substring(idx, idx + 250));

lines[8888] = f;
fs.writeFileSync('./public/app.html', lines.join('\n'));
console.log('File updated!');