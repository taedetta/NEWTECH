// Test script for auth flows
const { chromium } = require('playwright');

const BASE_URL = 'https://www.newtechaviation.com';

async function test() {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=3762dc35-8627-4d57-a55f-52191471e617');
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();

  // Collect console errors
  const consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', err => consoleErrors.push(`PAGE ERROR: ${err.message}`));

  // Collect network failures
  const networkFailures = [];
  page.on('requestfailed', req => networkFailures.push(`${req.method()} ${req.url()}: ${req.failure()?.errorText}`));

  try {
    // === TEST 1: Login page loads ===
    console.log('\n=== TEST 1: Login page loads ===');
    await page.goto(BASE_URL + '/app', { waitUntil: 'networkidle', timeout: 15000 });
    const loginForm = await page.$('#login-form');
    console.log('Login form visible:', !!loginForm);

    // Check for any visible error on load
    const loginError = await page.$('#login-error');
    if (loginError) {
      const text = await loginError.textContent();
      if (text) console.log('Login error on load:', text);
    }

    // === TEST 2: Login with test credentials ===
    console.log('\n=== TEST 2: Login with blankthe97@gmail.com ===');
    await page.fill('#login-email', 'blankthe97@gmail.com');
    await page.fill('#login-password', 'TestPass123!');
    await page.click('#login-form button[type="submit"]');
    await page.waitForTimeout(3000);

    const errorAfterLogin = await page.$eval('#login-error', el => el.textContent).catch(() => null);
    const appVisible = await page.$('#app-screen:not(.hidden)').catch(() => null);

    console.log('Login error:', errorAfterLogin || 'none');
    console.log('App screen visible:', !!appVisible);
    console.log('URL after login:', page.url());

    if (appVisible) {
      console.log('SUCCESS: Login worked!');
    } else {
      console.log('FAILED: Login did not succeed');
    }

    // === TEST 3: Forgot password flow ===
    console.log('\n=== TEST 3: Forgot password flow ===');
    // Navigate back to login
    await page.goto(BASE_URL + '/app', { waitUntil: 'networkidle', timeout: 10000 });
    await page.click('text=Forgot your password?');
    await page.waitForTimeout(500);

    const forgotScreen = await page.$('#forgot-screen:not(.hidden)');
    console.log('Forgot screen visible:', !!forgotScreen);

    await page.fill('#forgot-email', 'blankthe97@gmail.com');
    await page.click('#forgot-btn');
    await page.waitForTimeout(2000);

    const forgotSuccess = await page.$('#forgot-success:not(.hidden)');
    const forgotError = await page.$('#forgot-error:not(.hidden)');
    console.log('Forgot success msg:', await forgotSuccess?.textContent() || 'none');
    console.log('Forgot error msg:', await forgotError?.textContent() || 'none');

    // === TEST 4: Direct API calls ===
    console.log('\n=== TEST 4: Direct API tests ===');
    const resp1 = await page.evaluate(async () => {
      const r = await fetch('/api/auth/diagnostic');
      return { status: r.status, body: await r.json() };
    });
    console.log('/api/auth/diagnostic:', resp1);

    const resp2 = await page.evaluate(async () => {
      const r = await fetch('/api/auth/debug-test');
      return { status: r.status, body: await r.json() };
    });
    console.log('/api/auth/debug-test:', resp2);

    const resp3 = await page.evaluate(async () => {
      const r = await fetch('/api/auth/me');
      return { status: r.status, body: await r.json() };
    });
    console.log('/api/auth/me (unauthenticated):', resp3);

    // Console errors
    console.log('\n=== Console Errors ===');
    consoleErrors.forEach(e => console.log(' -', e));

    // Network failures
    console.log('\n=== Network Failures ===');
    networkFailures.forEach(f => console.log(' -', f));

  } catch (err) {
    console.error('Test error:', err.message);
  } finally {
    await browser.close();
  }
}

test().catch(console.error);