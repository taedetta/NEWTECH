const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const lines = content.split('\n');

// Find all return statements between 8907 (start of map) and 9200
for (let i = 8907; i <= 9200; i++) {
    const l = lines[i].trim();
    if (l.startsWith('return') && !l.includes('makeToggle') && !l.includes('function')) {
        console.log('Return at line', i+1, ':', l.slice(0, 250));
    }
}

// Also look for closing of map callback
for (let i = 9050; i <= 9200; i++) {
    if (lines[i].includes('});') || lines[i].includes('}));')) {
        console.log('Callback close at line', i+1, ':', lines[i]);
    }
}