const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const scriptBlocks = content.split('<script>');
const mainJS = scriptBlocks[scriptBlocks.length - 1];

// Check syntax
try {
    new Function(mainJS);
    console.log('Main JS: Syntax OK');
} catch(e) {
    console.log('Main JS Syntax Error:', e.message);
    const lines = mainJS.split('\n');
    const m = e.message.match(/position (\n?\\d+)/);
    if (m) {
        const pos = parseInt(m[1].replace('\n',''));
        let charSum = 0;
        for (let i = 0; i < lines.length; i++) {
            charSum += lines[i].length + 1;
            if (charSum >= pos) {
                console.log('Error around line', i+1, 'char', pos - (charSum - lines[i].length - 1));
                console.log('Context:', lines[Math.max(0,i-1)], '<<<ERROR>>>', lines[i], '<<<ERROR>>>', lines[Math.min(lines.length-1, i+1)]);
                break;
            }
        }
    }
}

// Check for null bytes
let nullCount = 0;
for (let i = 0; i < mainJS.length; i++) {
    if (mainJS.charCodeAt(i) === 0) nullCount++;
}
console.log('NULL bytes in mainJS:', nullCount);

// Check block 1 (cache-busting)
const block1 = scriptBlocks[1];
try {
    new Function(block1);
    console.log('Block 1: Syntax OK');
} catch(e) {
    console.log('Block 1 Syntax Error:', e.message);
}

// Check block 3 (admin)
const block3 = scriptBlocks[3];
try {
    new Function(block3);
    console.log('Block 3: Syntax OK');
} catch(e) {
    console.log('Block 3 Syntax Error:', e.message);
}

// Check block 2 (preview)
const block2 = scriptBlocks[2];
try {
    new Function(block2);
    console.log('Block 2: Syntax OK');
} catch(e) {
    console.log('Block 2 Syntax Error:', e.message);
}
