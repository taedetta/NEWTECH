const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Use template literal to build the onclick string
// The correct onclick using HTML double-quoted attribute:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,&quot;&apos;&quot;) + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// Note: &quot; in the replace pattern for JS double quotes

const onclickAttr = `onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,&quot;&apos;&quot;) + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"`;

console.log(`Replacement: ${onclickAttr}`);

// Find the onclick section
const onclickStart = targetLine.indexOf(`onclick='`);
const quoteEnd = targetLine.indexOf(`">`, onclickStart);

if (onclickStart >= 0 && quoteEnd >= 0) {
  console.log(`Found onclick at ${onclickStart}, ends at ${quoteEnd}`);
  const before = targetLine.substring(0, onclickStart);
  const after = targetLine.substring(quoteEnd + 2);

  const newLine = before + onclickAttr + after;
  console.log(`New line preview: ${newLine.substring(onclickStart, onclickStart + 200)}`);

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log(`Pattern not found, checking alternative...`);
  const onclickStart2 = targetLine.indexOf(`onclick="`);
  console.log(`Has double-quoted onclick: ${onclickStart2 >= 0}`);
}