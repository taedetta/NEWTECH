// Push all code from current directory to taedetta/NEWTECH
import { createWriteStream, statSync, readdirSync, readFileSync } from 'fs';
import { join, relative } from 'path';

const GITHUB_TOKEN = 'REDACTED';
const REPO = 'taedetta/NEWTECH';
const BRANCH = 'main';
const BASE_URL = 'https://api.github.com';

const headers = {
  'Authorization': `token ${GITHUB_TOKEN}`,
  'Accept': 'application/vnd.github.v3+json',
  'User-Agent': 'FlightSlate-Migration/1.0'
};

async function api(method, path, body = null) {
  const opts = { method, headers };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`${BASE_URL}${path}`, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(`GitHub API ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

// Get current commit SHA of main branch
const refData = await api('GET', `/repos/${REPO}/git/ref/heads/${BRANCH}`);
const baseTreeSha = refData.object.sha;
console.log(`Current ${BRANCH} commit: ${baseTreeSha}`);

// Get the tree of the base commit
const baseCommit = await api('GET', `/repos/${REPO}/git/commits/${baseTreeSha}`);
const baseTreeOid = baseCommit.tree.sha;

// Collect all files from current directory
const ROOT = process.cwd();
const SKIP = ['.git', 'node_modules', '.claude', '.tmp', 'tmp_js.js', 'shell-snapshots', 'todos', 'debug'];

const files = [];

function walk(dir, prefix = '') {
  const entries = readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (SKIP.some(s => entry.name === s)) continue;
    if (entry.name.startsWith('do_fix') || entry.name.startsWith('check') || entry.name.startsWith('test') || entry.name.startsWith('verify') || entry.name.startsWith('fix-')) {
      if (['server.js', 'routes', 'db', 'public', 'migrations', 'middleware', 'services', 'jobs'].every(d => !entry.name.includes(d))) continue;
    }
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      walk(join(dir, entry.name), relativePath);
    } else {
      const ext = entry.name.split('.').pop();
      if (['js', 'html', 'css', 'json', 'md', 'txt', 'yaml', 'toml', 'sql', 'png', 'jpg', 'jpeg', 'svg'].includes(ext)) {
        files.push({ path: relativePath, fullPath: join(dir, entry.name) });
      }
    }
  }
}

walk(ROOT);
console.log(`Found ${files.length} files to push`);

// Create blobs for all files
const fileBlobs = [];
for (const f of files) {
  const content = readFileSync(f.fullPath);
  const b64 = content.toString('base64');
  try {
    const blob = await api('POST', `/repos/${REPO}/git/blobs`, {
      content: b64,
      encoding: 'base64'
    });
    fileBlobs.push({ path: f.path, sha: blob.sha });
  } catch(e) {
    console.log(`Blob error for ${f.path}: ${e.message}`);
  }
}
console.log(`Created ${fileBlobs.length} blobs`);

// Build new tree
const treeItems = fileBlobs.map(fb => ({
  path: fb.path,
  mode: '100644',
  type: 'blob',
  sha: fb.sha
}));

const newTree = await api('POST', `/repos/${REPO}/git/trees`, {
  base_tree: baseTreeOid,
  tree: treeItems
});
console.log(`Created tree with ${newTree.tree.length} entries`);

// Create commit
const newCommit = await api('POST', `/repos/${REPO}/git/commits`, {
  message: `Migrate full codebase from Polsia-Inc/flightslate to taedetta/NEWTECH\n\nTransfer all code, routes, db, migrations, public assets, and configuration.`,
  tree: newTree.sha,
  parents: [baseTreeSha]
});
console.log(`Created commit: ${newCommit.sha}`);

// Update branch ref
await api('PATCH', `/repos/${REPO}/git/refs/heads/${BRANCH}`, {
  sha: newCommit.sha,
  force: true
});
console.log(`Pushed to ${REPO}/${BRANCH} — ${newCommit.sha}`);

console.log(`\n✅ All ${fileBlobs.length} files pushed successfully!`);
console.log(`Repo: https://github.com/${REPO}`);