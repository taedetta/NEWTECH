const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const scriptBlocks = content.split('<script>');
const mainJS = scriptBlocks[scriptBlocks.length - 1];

// Find the actual error by catching with column info
// Use acorn or just try/compile to get position
try {
    // Simple approach: test halves
    const mid = Math.floor(mainJS.length / 2);
    new Function(mainJS.slice(0, mid));
    console.log('First half OK');
    new Function(mainJS.slice(mid));
    console.log('Second half OK');
} catch(e) {
    console.log('Error:', e.message);
}

// Let's try finding the actual offending character position by parsing
// The error is "Unexpected token ':'" - let's find where
const lines = mainJS.split('\n');
let lineNum = 0;
let col = 0;
let found = false;

// Look for places where ':' appears at start of expression (after newline or ;)
for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trimStart();
    if (trimmed.startsWith(':')) {
        console.log('Line', i+1, ':', lines[i].slice(0, 100));
        if (i > 1000 && \!found) {
            console.log('First significant at line', i+1);
            found = true;
        }
    }
}
