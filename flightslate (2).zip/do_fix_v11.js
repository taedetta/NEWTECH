const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// The broken onclick is:
// onclick='openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,"&apos;") + ',' + u.role + ',' + ' + (!!u.is_instructor ? 'true' : 'false') + ')'">&#9998;</button>' : '';

// The issue: + ' + '  creates an extra ' that breaks JS parsing
// Fix: change to use HTML double-quoted attribute so JS single quotes work
// In double-quoted HTML attr, we need &quot; for JS double quotes in replace pattern

// The correct onclick using double-quoted HTML attr:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,&quot;&apos;&quot;) + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
// In file: &quot;&apos;&quot;  -> template: &quot;&apos;&quot;  -> HTML attr: replace(/'/g,"&quot;&apos;&quot;)  -> JS: replace(/'/g,"&apos;")

// Build the replacement using character codes to avoid escaping issues
const onclickAttr = 'onclick="openRoleChangeModal(' + "'" + ' + u.id + ' + "'" + ',' + ' + escHtml(u.name).replace(/' + "'" + '/g,' + '"&apos;"' + ') + ',' + ' + u.role + ',' + ' + (!!u.is_instructor ? ' + "'" + 'true' + "'" + ' : ' + "'" + 'false' + "'" + ' + ' + "'" + '))"';

console.log('Building replacement onclick...');
console.log('Replacement:', onclickAttr);

// Find the onclick section
const onclickStart = targetLine.indexOf("onclick='");
const quoteEnd = targetLine.indexOf('">', onclickStart);

if (onclickStart >= 0 && quoteEnd >= 0) {
  console.log('Found onclick at', onclickStart, 'ends at', quoteEnd);
  const before = targetLine.substring(0, onclickStart);
  const after = targetLine.substring(quoteEnd + 2);

  const newLine = before + onclickAttr + after;
  console.log('New line preview:', newLine.substring(onclickStart, onclickStart + 200));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}