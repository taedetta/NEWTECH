const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const t = lines[8888];

console.log('Length:', t.length);

// Find all > positions
let count = 0;
for (let i = 0; i < t.length; i++) {
  if (t[i] === '>') {
    console.log('> at', i, 'prev:', JSON.stringify(t.substring(Math.max(0,i-3),i+1)));
    count++;
    if (count > 10) { console.log('...more...'); break; }
  }
}

// Check for specific sequences
console.log('Has !!u.is:', t.includes('!!u.is'));
console.log('Has closing sequence:', t.includes(")'>"));
console.log('Index of button:', t.indexOf('&#9998;'));

// Show the last 100 chars
console.log('Last 100:', JSON.stringify(t.substring(t.length-100)));

// Also check: what's the actual char at position 100?
console.log('Char at 100:', JSON.stringify(t.charAt(100)));
console.log('Char at 115:', JSON.stringify(t.charAt(115)));
console.log('Char at 177:', JSON.stringify(t.charAt(177)));
console.log('Char at 178:', JSON.stringify(t.charAt(178)));

// Check for the pattern > followed by "
for (let i = 0; i < t.length - 1; i++) {
  if (t[i] === '>' && t[i+1] === '"') {
    console.log('> followed by " at', i);
    count++;
    if (count > 5) break;
  }
}

// Try to find lastIndexOf(">
const last = t.lastIndexOf('">');
console.log('lastIndexOf(">) =', last);
const secondLast = t.lastIndexOf('">', last - 1);
console.log('second-last ">=', secondLast);