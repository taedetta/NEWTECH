const { chromium } = require('playwright');

// Use the current active browser session
const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=276c1344-f226-4ce3-a1c5-021e09811213';
const BASE_URL = 'https://www.newtechaviation.com';

async function test() {
  const browser = await chromium.connectOverCDP(CDP_URL);
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage();

  // Collect console errors
  const consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', err => consoleErrors.push(`PAGE ERROR: ${err.message}`));

  // Collect network failures
  const networkFailures = [];
  page.on('requestfailed', req => networkFailures.push(`${req.method()} ${req.url()}: ${req.failure()?.errorText}`));

  try {
    // === TEST 1: Login as Brandon (owner) ===
    console.log('\n=== TEST 1: Login as Brandon (owner) ===');
    await page.goto(BASE_URL + '/app', { waitUntil: 'networkidle', timeout: 15000 });

    const loginForm = await page.$('#login-form');
    console.log('Login form visible:', !!loginForm);

    await page.fill('#login-email', 'blankthe97@gmail.com');
    await page.fill('#login-password', 'TestPass123!');
    await page.click('#login-form button[type="submit"]');
    await page.waitForTimeout(3000);

    const appVisible = await page.$('#app-screen:not(.hidden)');
    console.log('App screen visible:', !!appVisible);

    // Check current user role
    const roleText = await page.$eval('#sidebar-role', el => el.textContent).catch(() => 'unknown');
    console.log('User role:', roleText);

    // === TEST 2: Navigate to Programs page ===
    console.log('\n=== TEST 2: Navigate to Programs page ===');

    // Check if Programs nav is visible
    const navPrograms = await page.$('#nav-programs');
    const navProgramsVisible = navPrograms ? !(await navPrograms.evaluate(el => el.classList.contains('hidden'))) : false;
    console.log('Programs nav visible:', navProgramsVisible);

    // Click Programs nav
    if (navProgramsVisible) {
      await page.click('#nav-programs');
      await page.waitForTimeout(3000);

      const pagePrograms = await page.$('#page-programs');
      const pageVisible = pagePrograms ? !(await pagePrograms.evaluate(el => el.classList.contains('hidden'))) : false;
      console.log('Programs page visible:', pageVisible);

      // Check if content loaded
      const listContent = await page.$eval('#programs-list', el => el.textContent).catch(() => 'NOT FOUND');
      console.log('Programs list content length:', listContent.length);
      console.log('Programs list content (first 200 chars):', listContent.substring(0, 200));

      // Check for loading state
      const loadingText = await page.$eval('#programs-list', el => el.textContent).catch(() => '');
      console.log('Is still loading?:', loadingText.includes('Loading'));
    } else {
      console.log('Programs nav is HIDDEN for this user!');
      // Check why
      const navItem = await page.$('#nav-programs');
      if (navItem) {
        const classList = await navItem.evaluate(el => el.className);
        console.log('nav-programs classList:', classList);
      }
    }

    // Console errors
    console.log('\n=== Console Errors ===');
    consoleErrors.forEach(e => console.log(' -', e));

    // Network failures
    console.log('\n=== Network Failures ===');
    networkFailures.forEach(f => console.log(' -', f));

  } catch (err) {
    console.error('Test error:', err.message);
  } finally {
    await browser.close();
  }
}

test().catch(console.error);