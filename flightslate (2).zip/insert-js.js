const fs = require('fs');
const file = 'public/app.html';
let content = fs.readFileSync(file, 'utf8');

// Find the end of saveFromCodeTab function (the } before handleEditorImageUpload)
const insertAfter = `  }
}

async function handleEditorImageUpload(key, input) {`;

const insertPoint = content.indexOf(insertAfter);
if (insertPoint === -1) {
  console.error('Could not find insertion point');
  // Let's try a simpler search
  const idx = content.indexOf('async function handleEditorImageUpload');
  console.log('handleEditorImageUpload at index:', idx);
  if (idx !== -1) {
    // Find the } before it
    const before = content.substring(idx - 200, idx);
    console.log('Context before handleEditorImageUpload:');
    console.log(JSON.stringify(before));
  }
  process.exit(1);
}

const insertIdx = insertPoint + insertAfter.length;

// The new functions to insert
const newFunctions = `

// ─── FILE BROWSER (Code Tab — Project Files Mode) ───
var codeMode = 'json'; // 'json' or 'files'
var currentFilePath = null;
var currentFileContent = null;
var fileTreeCache = null;

function switchCodeMode(mode) {
  codeMode = mode;
  document.getElementById('code-mode-json-btn').classList.toggle('active', mode === 'json');
  document.getElementById('code-mode-files-btn').classList.toggle('active', mode === 'files');
  document.getElementById('code-json-panel').classList.toggle('hidden', mode !== 'json');
  document.getElementById('code-files-panel').classList.toggle('active', mode === 'files');
  if (mode === 'files' && !fileTreeCache) {
    loadFileTree();
  }
}

async function loadFileTree() {
  const treeEl = document.getElementById('code-file-tree');
  const emptyEl = document.getElementById('code-file-empty');
  treeEl.innerHTML = '<div class=&quot;code-empty-state&quot;><div class=&quot;ces-icon&quot;>&#8987;</div><p>Loading files…</p></div>';
  try {
    const data = await fetch('/api/project-files').then(r => r.ok ? r.json() : Promise.reject(r.status));
    fileTreeCache = data;
    // Show root entries as a flat list with folder expansion
    renderFileTree(data.entries || [], treeEl, '');
    emptyEl.style.display = 'none';
  } catch (err) {
    treeEl.innerHTML = '<div class=&quot;code-empty-state&quot;><div class=&quot;ces-icon&quot;>&#9888;</div><p>Could not load files: ' + (err.message || 'Server error') + '</p></div>';
    console.error('File tree load error:', err);
  }
}

function renderFileTree(entries, container, parentPath) {
  container.innerHTML = '';
  // Sort: folders first, then files
  const sorted = [...entries].sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  for (const entry of sorted) {
    const item = document.createElement('div');
    const fullPath = parentPath ? parentPath + '/' + entry.name : entry.name;

    if (entry.type === 'dir') {
      item.className = 'file-tree-item folder';
      item.innerHTML = '<span class=&quot;ft-icon&quot;>&#128193;</span><span class=&quot;ft-name&quot;>' + escHtml(entry.name) + '/</span>';
      // Make folders expandable
      item.style.cursor = 'pointer';
      item.onclick = async function(e) {
        e.stopPropagation();
        const icon = item.querySelector('.ft-icon');
        const childContainer = item.nextElementSibling;
        if (childContainer && childContainer.classList.contains('ft-children')) {
          // Toggle collapse
          childContainer.style.display = childContainer.style.display === 'none' ? 'block' : 'none';
          icon.textContent = childContainer.style.display === 'none' ? '&#128194;' : '&#128194;';
        } else {
          // Load children
          icon.textContent = '&#8987;';
          try {
            const data = await fetch('/api/project-files?path=' + encodeURIComponent(fullPath)).then(r => r.json());
            const childDiv = document.createElement('div');
            childDiv.className = 'ft-children';
            item.parentNode.insertBefore(childDiv, item.nextSibling);
            renderFileTree(data.entries || [], childDiv, fullPath);
            icon.textContent = '&#128194;';
          } catch(e) {
            icon.textContent = '&#9888;';
          }
        }
      };
    } else {
      const ext = entry.extension || '';
      const icon = getFileIcon(ext);
      item.className = 'file-tree-item file';
      item.innerHTML = '<span class=&quot;ft-icon&quot;>' + icon + '</span><span class=&quot;ft-name&quot;>' + escHtml(entry.name) + '</span>';
      item.onclick = function() {
        openFile(fullPath);
      };
    }

    container.appendChild(item);
  }
}

function getFileIcon(ext) {
  const icons = {
    '.js': '&#129704;',
    '.html': '&#128196;',
    '.css': '&#127912;',
    '.json': '&#123;',
    '.md': '&#128221;',
    '.txt': '&#128196;',
    '.yaml': '&#128260;',
    '.yml': '&#128260;',
    '.sql': '&#128451;',
    '.gitignore': '&#128270;',
    '.env': '&#128274;',
  };
  return icons[ext] || '&#128196;';
}

async function openFile(filePath) {
  currentFilePath = filePath;
  const editor = document.getElementById('code-file-editor');
  const empty = document.getElementById('code-file-empty');
  editor.style.display = 'flex';
  empty.style.display = 'none';

  // Update header
  const filename = filePath.split('/').pop();
  const ext = '.' + filename.split('.').pop();
  document.getElementById('code-filename').textContent = filename;
  document.getElementById('code-lang').textContent = getLangLabel(ext);

  // Show loading state
  const body = document.getElementById('code-editor-body');
  body.innerHTML = '<div class=&quot;code-empty-state&quot;><div class=&quot;ces-icon&quot;>&#8987;</div><p>Loading ' + escHtml(filename) + '…</p></div>';
  document.getElementById('code-status-msg').textContent = '';

  try {
    const data = await fetch('/api/project-files?path=' + encodeURIComponent(filePath)).then(r => r.ok ? r.json() : Promise.reject(r.status));
    if (data.type === 'file' && data.content !== undefined) {
      currentFileContent = data.content;
      const lang = getLangLabel(data.extension || '.' + filename.split('.').pop());
      document.getElementById('code-lang').textContent = lang;
      document.getElementById('code-file-size').textContent = formatBytes(data.size || data.content.length);
      renderCodeViewer(data.content, data.extension || '.' + filename.split('.').pop());
      document.getElementById('code-status-msg').textContent = 'Loaded ' + filename + ' (' + formatBytes(data.size || data.content.length) + ')';
      // Highlight active file in tree
      document.querySelectorAll('.file-tree-item.file').forEach(el => {
        el.classList.toggle('active', el.querySelector('.ft-name').textContent === filename);
      });
    }
  } catch (err) {
    body.innerHTML = '<div class=&quot;code-empty-state&quot;><div class=&quot;ces-icon&quot;>&#9888;</div><p>Could not load file: ' + (err.message || 'Server error') + '</p></div>';
  }
}

function renderCodeViewer(code, ext) {
  const body = document.getElementById('code-editor-body');
  const lines = code.split('\n');
  let html = '';
  for (let i = 0; i < lines.length; i++) {
    const highlighted = highlightLine(lines[i], ext);
    html += '<div class=&quot;code-line&quot;><span class=&quot;code-linenum&quot;>' + (i + 1) + '</span><span class=&quot;code-token&quot;>' + highlighted + '</span></div>';
  }
  body.innerHTML = html;
  body.scrollTop = 0;
}

function highlightLine(line, ext) {
  // Simple syntax highlighting
  const escaped = escHtml(line);
  if (ext === '.js' || ext === '.json' || ext === '.html' || ext === '.css') {
    // Highlight strings first (to avoid conflicts with keywords)
    let result = escaped
      // HTML comments
      .replace(/(&lt;!--[\u0000-\uffff]*?--&gt;)/g, '<span class=&quot;token-comment&quot;>$1</span>')
      // Single-line comments (for JS/CSS)
      .replace(/(\/\/[^\n]*)/g, '<span class=&quot;token-comment&quot;>$1</span>')
      // HTML tags
      .replace(/(&lt;\/?[\u0000-\uffff]+)/g, '<span class=&quot;token-tag&quot;>$1</span>')
      .replace(/(&gt;)/g, '<span class=&quot;token-tag&quot;>$1</span>')
      // Strings
      .replace(/(&quot;[^&quot;]*?&quot;)/g, '<span class=&quot;token-string&quot;>$1</span>')
      .replace(/('[^']*?')/g, '<span class=&quot;token-string&quot;>$1</span>')
      // Numbers
      .replace(/\b(\b[0-9]+(?:\b|$))/g, '<span class=&quot;token-number&quot;>$1</span>')
      // JS/CSS keywords
      .replace(/\b(function|const|let|var|return|if|else|for|while|class|import|export|from|async|await|new|try|catch|throw|default|extends|this|true|false|null|undefined|typeof|instanceof|require|module|exports)\b/g, '<span class=&quot;token-keyword&quot;>$1</span>')
      // Functions
      .replace(/\b([a-zA-Z_$][a-zA-Z0-9_$]*)\b(?=\\(\u002F)/g, '<span class=&quot;token-function&quot;>$1</span>');
    return result;
  }
  // For other file types, just return escaped text
  return escaped;
}

function getLangLabel(ext) {
  const labels = {
    '.js': 'JavaScript',
    '.html': 'HTML',
    '.css': 'CSS',
    '.json': 'JSON',
    '.md': 'Markdown',
    '.txt': 'Text',
    '.yaml': 'YAML',
    '.yml': 'YAML',
    '.sql': 'SQL',
    '.gitignore': 'Git Ignore',
    '.env': 'Environment',
    '.txt': 'Plain Text',
  };
  return labels[ext] || ext.replace('.', '') || 'File';
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

async function saveProjectFile() {
  if (!currentFilePath || currentFileContent === null) {
    document.getElementById('code-status-msg').textContent = 'No file open to save';
    return;
  }
  // Get current content from the displayed code (read back from the rendered divs)
  const lines = Array.from(document.querySelectorAll('#code-editor-body .code-line')).map(l => {
    const tokens = l.querySelectorAll('.code-token');
    // Get the raw text content (de-highlighted)
    return Array.from(tokens).map(t => t.textContent).join('');
  });

  const btn = document.getElementById('code-save-btn');
  btn.disabled = true;
  btn.textContent = 'Saving…';
  document.getElementById('code-status-msg').textContent = 'Saving ' + currentFilePath + '…';

  try {
    const resp = await api('/api/project-files', {
      method: 'PUT',
      body: JSON.stringify({ path: currentFilePath, content: lines.join('\n') })
    });
    currentFileContent = lines.join('\n');
    document.getElementById('code-status-msg').textContent = '✓ Saved ' + currentFilePath;
    setTimeout(() => {
      const msg = document.getElementById('code-status-msg');
      if (msg.textContent.includes('Saved')) msg.textContent = 'Saved ' + currentFilePath;
    }, 2000);
  } catch (err) {
    document.getElementById('code-status-msg').textContent = '✗ Save failed: ' + (err.error || 'Unknown error');
  } finally {
    btn.disabled = false;
    btn.textContent = '✓ Save File';
  }
}

async function copyCodeContent() {
  if (!currentFilePath) return;
  // Copy from the displayed code
  const lines = Array.from(document.querySelectorAll('#code-editor-body .code-line')).map(l => {
    return Array.from(l.querySelectorAll('.code-token')).map(t => t.textContent).join('');
  });
  const text = lines.join('\n');
  try {
    await navigator.clipboard.writeText(text);
    document.getElementById('code-status-msg').textContent = '✓ Copied to clipboard';
    setTimeout(() => {
      const msg = document.getElementById('code-status-msg');
      if (msg.textContent.includes('Copied')) msg.textContent = currentFilePath ? 'Viewing ' + currentFilePath.split('/').pop() : '';
    }, 2000);
  } catch (err) {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    document.getElementById('code-status-msg').textContent = '✓ Copied to clipboard';
  }
}

function escHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&quot;/g, '&quot;');
}

`;

const newContent = content.substring(0, insertIdx) + newFunctions + content.substring(insertIdx);
fs.writeFileSync(file, newContent);
console.log('SUCCESS: Added file browser JS functions');
console.log('File is now', fs.readFileSync(file, 'utf8').split('\n').length, 'lines');