const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';

(async () => {
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0];
    const page = context.pages()[0];

    // Navigate to availability
    await page.evaluate(() => navigate('availability'));
    await page.waitForTimeout(2000);

    // Check the parent chain of page-availability
    const parentChain = await page.evaluate(() => {
      const el = document.getElementById('page-availability');
      if (!el) return 'element not found';

      const chain = [];
      let current = el;
      for (let i = 0; i < 10 && current; i++) {
        const rect = current.getBoundingClientRect();
        const style = window.getComputedStyle(current);
        chain.push({
          tag: current.tagName,
          id: current.id || '',
          className: current.className || '',
          display: style.display,
          overflow: style.overflow,
          position: style.position,
          width: rect.width,
          height: rect.height,
          top: rect.top,
          left: rect.left
        });
        current = current.parentElement;
      }
      return chain;
    });
    console.log('Parent chain of page-availability:');
    console.log(JSON.stringify(parentChain, null, 2));

    // Now check if page-availability is ACTUALLY a child of main-content
    const isChild = await page.evaluate(() => {
      const mainContent = document.querySelector('.main-content');
      const availPage = document.getElementById('page-availability');
      if (!mainContent || !availPage) return 'elements missing';

      // Check direct children
      const directChildren = Array.from(mainContent.children).map(c => ({
        tag: c.tagName,
        id: c.id,
        className: c.className
      }));

      return {
        isDirectChild: mainContent.contains(availPage),
        parentOfAvail: availPage.parentElement?.tagName + '#' + (availPage.parentElement?.id || '') + '.' + (availPage.parentElement?.className || ''),
        mainContentChildCount: mainContent.children.length,
        lastFewChildren: directChildren.slice(-5)
      };
    });
    console.log('Child check:', JSON.stringify(isChild, null, 2));

    // Check if the <script> tag breaks the DOM tree
    const scriptCheck = await page.evaluate(() => {
      // The admin-settings page has an inline <script> tag
      // Check if this breaks the DOM nesting
      const adminSettings = document.getElementById('page-admin-settings');
      const avail = document.getElementById('page-availability');

      if (!adminSettings || !avail) return 'missing elements';

      return {
        adminSettingsParent: adminSettings.parentElement?.tagName + '.' + (adminSettings.parentElement?.className || ''),
        availParent: avail.parentElement?.tagName + '.' + (avail.parentElement?.className || ''),
        sameParent: adminSettings.parentElement === avail.parentElement,
        adminNextSibling: adminSettings.nextElementSibling?.id,
        adminPrevSibling: avail.previousElementSibling?.id
      };
    });
    console.log('Script/nesting check:', JSON.stringify(scriptCheck, null, 2));

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
    console.error(err.stack);
  }
})();
