const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');

// Find all script src references
const regex = /<script[^>]+src=[^>]*>/gi;
let match;
while ((match = regex.exec(content)) !== null) {
    console.log('Pos:', match.index, ':', match[0]);
}

// Also look for dynamic script loading patterns
const dynamic = /document.createElement\uff1bscript|script.*src|innerHTML.*script/gi;
let dmatch;
while ((dmatch = dynamic.exec(content)) !== null) {
    console.log('Dynamic script at:', dmatch.index, ':', dmatch[0].slice(0,200));
}

console.log('---');
console.log('Total file size:', content.length);
console.log('Has external JS:', content.includes('.js'));