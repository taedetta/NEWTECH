const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// The current broken line uses onclick='...' (single-quoted HTML attr)
// The JS inside has concatenation like ' + ' which creates broken quote structure
//
// Fix: use HTML double-quoted attribute: onclick="..."
// This way, JS single-quote strings work without escaping
// But we need to escape " inside the JS replace() call
//
// The correct line using double-quoted HTML attr:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\"&apos;\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
//
// Let's build this correctly:
// - HTML attr uses " delimiters
// - JS uses ' for strings
// - replace(/'/g,"&apos;") works in double-quoted attr
// - The entire onclick builds as ONE JS string without extra concatenation

const correctLine = `var editRoleBtn = isOwner && !isSelf ? ' <button style="background:none;border:none;cursor:pointer;color:var(--gray-400);font-size:0.85rem;padding:0.15rem 0.3rem;border-radius:4px;line-height:1;vertical-align:middle;transition:color 0.15s" title="Edit user" onmouseover="this.style.color='var(--sky)'" onmouseout="this.style.color='var(--gray-400)'" onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\\"&apos;\\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')" >&#9998;</button>' : '';`;

// But we need to escape the double quotes in the template literal
// In the file, the line should be:
// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,\"&apos;\") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"

console.log('Checking current line...');
console.log('Has onclick= with single quote:', targetLine.includes("onclick='openRoleChangeModal"));
console.log('Has onclick= with double quote:', targetLine.includes('onclick="openRoleChangeModal'));

// Find the line to replace
const brokenStart = targetLine.indexOf("onclick='");
if (brokenStart >= 0) {
  console.log('Found broken onclick at position', brokenStart);
  // Find where the onclick ends (before ">")
  const quoteEnd = targetLine.indexOf('">', brokenStart);
  console.log('onclick ends at position', quoteEnd);

  // Build the replacement
  const onclickAttr = 'onclick="openRoleChangeModal(\\' + u.id + \\',\\' + escHtml(u.name).replace(/\\'/g,"&apos;") + \\',\\' + u.role + \\',(\\' + (!!u.is_instructor ? \\'true\\' : \\'false\\') + \\'\\')"';

  console.log('Replacement:', onclickAttr);

  // Actually let me just build the correct full line
  const newLine = targetLine.substring(0, brokenStart) + 'onclick="openRoleChangeModal(\\' + u.id + \\',\\' + escHtml(u.name).replace(/\\'/g,"&apos;") + \\',\\' + u.role + \\',(\\' + (!!u.is_instructor ? \\'true\\' : \\'false\\') + \\'\\')"' + targetLine.substring(quoteEnd + 2);

  console.log('New line preview:', newLine.substring(newLine.indexOf('onclick='), newLine.indexOf('onclick=') + 150));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('No broken onclick found, checking alternative patterns...');
  console.log('Current onclick:', targetLine.includes('onclick') ? targetLine.substring(targetLine.indexOf('onclick'), targetLine.indexOf('onclick') + 100) : 'not found');
}