const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const scriptBlocks = content.split('<script>');
const mainJS = scriptBlocks[scriptBlocks.length - 1];
const lines = mainJS.split('\n');

// Try to find the specific line with ':'
let charCount = 0;
for (let i = 0; i < lines.length; i++) {
    charCount += lines[i].length + 1;
    // Find lines that have just a colon or colons in unusual places
    // Looking for: arrow functions, object literals, etc.
    if (lines[i].includes(':') && i > 1000) {
        const trimmed = lines[i].trim();
        // Object method shorthand or property with colon at start of expression
        if (trimmed.startsWith(':') || (trimmed.startsWith(',') && trimmed.includes(':'))) {
            console.log('Found at line', i+1, 'char offset approx', charCount - lines[i].length - 1);
            console.log('Context: ...' + lines[i-1] + '|||' + lines[i] + '|||' + lines[i+1] + '...');
            break;
        }
    }
}
