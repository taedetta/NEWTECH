/**
 * Verify permissions system end-to-end
 * Run after deploy: node verify-permissions.js
 */
const BASE = process.env.APP_URL || 'https://flightslate.polsia.app';

async function verify() {
  console.log('Verifying permissions system on', BASE);

  // 1. Health check
  const health = await fetch(`${BASE}/health`);
  const healthData = await health.json();
  console.log('Health:', healthData.status === 'healthy' ? 'PASS' : 'FAIL');

  // 2. Register a test admin
  const ts = Date.now();
  const regRes = await fetch(`${BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: `TestAdmin_${ts}`,
      email: `testadmin_${ts}@test.internal`,
      password: 'TestPass123!',
      role: 'admin'
    })
  });
  const regData = await regRes.json();
  console.log('Register admin:', regRes.ok ? 'PASS' : 'FAIL', regData.user?.permissions ? '(has permissions obj)' : '(MISSING permissions)');

  if (!regRes.ok) {
    console.log('Cannot continue without registration');
    return;
  }

  const token = regData.token;
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };

  // 3. Auth/me returns permissions and hasOwner
  const meRes = await fetch(`${BASE}/api/auth/me`, { headers });
  const meData = await meRes.json();
  console.log('Auth/me permissions:', meData.user?.permissions ? 'PASS' : 'FAIL');
  console.log('Auth/me hasOwner:', meData.hasOwner !== undefined ? 'PASS' : 'FAIL');

  // 4. Users list includes permission fields
  const usersRes = await fetch(`${BASE}/api/users`, { headers });
  const usersData = await usersRes.json();
  const hasPermFields = usersData.length > 0 && usersData[0].can_manage_aircraft !== undefined;
  console.log('Users list permissions:', hasPermFields ? 'PASS' : 'FAIL');

  // 5. Aircraft POST should be 403 (no can_manage_aircraft permission)
  const aircraftRes = await fetch(`${BASE}/api/aircraft`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ tail_number: 'N99999', make_model: 'Test' })
  });
  console.log('Aircraft POST blocked (403):', aircraftRes.status === 403 ? 'PASS' : `FAIL (got ${aircraftRes.status})`);

  // 6. Try claim-owner
  const claimRes = await fetch(`${BASE}/api/auth/claim-owner`, { method: 'POST', headers });
  const claimData = await claimRes.json();
  console.log('Claim owner:', claimRes.ok ? 'PASS' : `FAIL (${claimData.error})`);

  if (claimRes.ok) {
    const ownerHeaders = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${claimData.token}` };

    // 7. As owner, aircraft POST should work
    const aircraftRes2 = await fetch(`${BASE}/api/aircraft`, {
      method: 'POST',
      headers: ownerHeaders,
      body: JSON.stringify({ tail_number: `N${ts.toString().slice(-5)}`, make_model: 'Verify Test' })
    });
    console.log('Owner aircraft POST:', aircraftRes2.ok ? 'PASS' : `FAIL (${aircraftRes2.status})`);

    // 8. Register an instructor to test permission toggle
    const instrRes = await fetch(`${BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: `TestInstr_${ts}`,
        email: `testinstr_${ts}@test.internal`,
        password: 'TestPass123!',
        role: 'instructor'
      })
    });
    const instrData = await instrRes.json();

    if (instrRes.ok) {
      // 9. Toggle permission for instructor
      const toggleRes = await fetch(`${BASE}/api/users/${instrData.user.id}/permissions`, {
        method: 'PUT',
        headers: ownerHeaders,
        body: JSON.stringify({ can_manage_aircraft: true })
      });
      const toggleData = await toggleRes.json();
      console.log('Toggle permission:', toggleRes.ok && toggleData.can_manage_aircraft ? 'PASS' : 'FAIL');

      // 10. Verify instructor can now add aircraft
      const instrHeaders = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${instrData.token}` };
      const aircraftRes3 = await fetch(`${BASE}/api/aircraft`, {
        method: 'POST',
        headers: instrHeaders,
        body: JSON.stringify({ tail_number: `N${(ts + 1).toString().slice(-5)}`, make_model: 'Instructor Test' })
      });
      console.log('Instructor with permission can add aircraft:', aircraftRes3.ok ? 'PASS' : `FAIL (${aircraftRes3.status})`);

      // 11. Try student permission update (should be blocked)
      const studentRes = await fetch(`${BASE}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `TestStudent_${ts}`,
          email: `teststudent_${ts}@test.internal`,
          password: 'TestPass123!',
          role: 'student'
        })
      });
      const studentData = await studentRes.json();

      if (studentRes.ok) {
        const toggleStudentRes = await fetch(`${BASE}/api/users/${studentData.user.id}/permissions`, {
          method: 'PUT',
          headers: ownerHeaders,
          body: JSON.stringify({ can_manage_aircraft: true })
        });
        console.log('Student permission blocked:', toggleStudentRes.status === 403 ? 'PASS' : `FAIL (${toggleStudentRes.status})`);
      }
    }
  }

  console.log('\nVerification complete.');
}

verify().catch(err => {
  console.error('Verification failed:', err.message);
  process.exit(1);
});
