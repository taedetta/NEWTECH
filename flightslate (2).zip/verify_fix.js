const fs = require('fs');
const html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const t = lines[8888];

console.log('Line 8889 length:', t.length);
console.log('Line 8889 (first 300):', JSON.stringify(t.substring(0, 300)));

// Check for the replacement pattern
const hasReplace = t.includes('.replace(/');
console.log('Has .replace(/ :', hasReplace);

if (hasReplace) {
  const repIdx = t.indexOf('.replace');
  console.log('Replacement section:', JSON.stringify(t.substring(repIdx, repIdx + 45)));
  const repSection = t.substring(repIdx + 16, repIdx + 21);
  console.log('Replacement part:', JSON.stringify(repSection));
}

// Extract and check JS syntax
const scriptContent = [];
const regex = /<script>([\n\r]*[\\S]+[\n\r]*)<\/script>/gi;
let match;
let count = 0;
while ((match = regex.exec(html)) !== null && count < 5) {
  scriptContent.push(match[1]);
  count++;
}
const fullScript = scriptContent.join('\n');
fs.writeFileSync('./public/app_check.js', fullScript);
console.log('\nJS extracted, length:', fullScript.length);

// Check syntax
try {
  require('vm').createScript(fullScript);
  console.log('JS syntax: OK');
} catch (e) {
  console.log('JS syntax ERROR:', e.message);
}