const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Fix: change the broken "\\\\'" pattern to "&apos;"
// The current pattern in the file is: "\\\\'"  (backslash-backslash-quote in JS string)
// Which represents the actual file bytes: \"

const oldReplace = '.replace(/'/g,"\\\\'")';
const newReplace = '.replace(/'/g,"&apos;")';

if (targetLine.includes(oldReplace)) {
  let f = targetLine;
  f = f.split(oldReplace).join(newReplace);

  // Also fix the extra empty strings
  f = f.split("onclick='openRoleChangeModal(' + u.id + ','' +").join("onclick='openRoleChangeModal(' + u.id + ',' +");
  f = f.split("+ '','' + u.role").join("+ ',' + u.role");
  f = f.split("+ '', ' +").join("+ ',' + ' +");

  console.log('Fixed! onclick check:', f.includes("onclick='openRoleChangeModal"));
  const idx = f.indexOf('onclick');
  console.log('onclick section:', f.substring(idx, idx + 250));

  lines[8888] = f;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found, checking current content...');
  console.log('Has replace:', targetLine.includes('.replace(/'));
  const idx = targetLine.indexOf('.replace');
  console.log('Replace area:', JSON.stringify(targetLine.substring(idx, idx + 60)));
}