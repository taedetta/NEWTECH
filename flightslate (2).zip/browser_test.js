const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=fb877040-1d06-495d-9003-f6738260e095');
  const page = await browser.newPage();
  await page.setViewportSize({ width: 1280, height: 720 });
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', err => errors.push('PAGE ERROR: ' + err.message));

  // Navigate to the app
  await page.goto('https://www.newtechaviation.com/app', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);

  // Check what elements are visible
  const bodyInfo = await page.evaluate(() => {
    const authModal = document.getElementById('auth-modal');
    const appScreen = document.getElementById('app-screen');
    return {
      authModalExists: !!authModal,
      authModalDisplay: authModal ? authModal.style.display : 'N/A',
      authModalClassList: authModal ? Array.from(authModal.classList) : [],
      authModalClientRect: authModal ? authModal.getBoundingClientRect() : null,
      authModalChildren: authModal ? authModal.children.length : 0,
      appScreenDisplay: appScreen ? appScreen.style.display : 'N/A',
      appScreenClassList: appScreen ? Array.from(appScreen.classList) : [],
      bodyBg: window.getComputedStyle(document.body).backgroundColor,
    };
  });
  console.log('Body info:', JSON.stringify(bodyInfo, null, 2));

  // Try clicking Sign In button if visible
  const signInButtons = await page.$$('button:has-text("Sign In"), a:has-text("Sign In"), [onclick*="signin"]');
  console.log('Sign In buttons found:', signInButtons.length);

  // Take screenshot
  await page.screenshot({ path: 'screenshot1_initial.png' });
  console.log('Screenshot saved: screenshot1_initial.png');

  // Try to find and click a sign in button
  const buttons = await page.evaluate(() => {
    const allButtons = Array.from(document.querySelectorAll('button, a, [onclick]'));
    return allButtons.map(b => ({
      tag: b.tagName,
      text: b.textContent.trim().substring(0, 50),
      onclick: b.getAttribute('onclick'),
      className: b.className,
    })).filter(b => b.text && b.text.length > 0).slice(0, 20);
  });
  console.log('Buttons on page:', JSON.stringify(buttons, null, 2));

  console.log('Errors:', errors.length ? errors : 'NONE');
  await browser.close();
})().catch(e => console.error('Error:', e.message));