const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

console.log('Has onclick with double quotes:', targetLine.includes('onclick="openRoleChangeModal'));
console.log('Has backslash-quote-quote pattern:', targetLine.includes("\\'\\''"));

if (targetLine.includes('onclick="openRoleChangeModal')) {
  let f = targetLine;

  // Fix 1: change onclick=" to onclick='
  f = f.replace('onclick="openRoleChangeModal', "onclick='openRoleChangeModal");

  // Fix 2: change \\'\\'' to just ' (backslash-quote-quote in HTML single-quoted attr)
  f = f.replace(/\\'\\''/g, "'");

  // Fix 3: change the closing of onclick from "\") to ') (but need to handle the > properly)
  f = f.replace(')"\">', ")'>");

  // Fix 4: change remaining \\'  patterns to just '
  f = f.replace(/\\'/g, "'");

  console.log('After fix, has onclick with single quote:', f.includes("onclick='openRoleChangeModal"));
  const idx = f.indexOf('onclick=');
  console.log('onclick section:', f.substring(idx, idx + 200));

  lines[8888] = f;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}