const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const scriptBlocks = content.split('<script>');
const mainJS = scriptBlocks[scriptBlocks.length - 1];

// Check for HTML entities that might cause JS syntax errors
const badEntities = ['&colon;', '&semi;', '&plus;', '&amp;'];
for (const entity of badEntities) {
    if (mainJS.includes(entity)) {
        console.log('Found entity:', entity, 'at positions:', mainJS.split(entity).length - 1);
    }
}

// Check for unescaped backticks in template literals
// Look for patterns like `...` that might have unescaped ${ inside JS string contexts
// Also check for unusual quote patterns

// Try binary search to find the error
let start = 0;
let end = mainJS.length;
let iterations = 0;
while (iterations < 30 && end - start > 1000) {
    const mid = Math.floor((start + end) / 2);
    try {
        new Function(mainJS.slice(0, mid));
        start = mid;
    } catch(e) {
        end = mid;
    }
    iterations++;
}

// Now we know error is between start and end
const suspect = mainJS.slice(start, end);
const lines = suspect.split('\n');
console.log('Error around position', start, '-', end, '(', end-start, 'chars)');
console.log('Context:');
console.log('---start---');
console.log(lines.slice(0, 5).join('\n'));
console.log('...');
console.log(lines.slice(-5).join('\n'));
console.log('---end---');

// Find the actual offending character
for (let i = 0; i < suspect.length; i++) {
    const c = suspect.charCodeAt(i);
    if (c === 58 && i > 0) { // ':' char
        const before = suspect.slice(Math.max(0, i-20), i);
        const after = suspect.slice(i+1, Math.min(suspect.length, i+20));
        // Check if this is inside a string (unquoted :)
        if (!before.match(/[\n;{,\\[\\(\\]}\/?:|]/)) {
            console.log('Suspicious : at pos', start+i, ':', before + '>>>:<<<' + after);
        }
    }
}