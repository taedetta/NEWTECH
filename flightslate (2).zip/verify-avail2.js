const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=adc417c6-3234-4b8b-b2fc-3d5cde694121';

(async () => {
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
    const context = browser.contexts()[0];
    const page = context.pages()[0];

    // The previous script already navigated to availability page
    // Take screenshot to workspace directory
    await page.screenshot({
      path: './availability-screenshot.png',
      fullPage: false
    });
    console.log('Screenshot saved to ./availability-screenshot.png');

    // Also get the page title / visible text
    const visibleText = await page.evaluate(() => {
      const avail = document.getElementById('page-availability');
      if (!avail) return 'page-availability not found';
      // Get all visible text
      const texts = [];
      const walker = document.createTreeWalker(avail, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const t = walker.currentNode.textContent.trim();
        if (t) texts.push(t);
      }
      return texts.join(' | ');
    });
    console.log('Visible text on availability page:', visibleText);

    // Check which h1/h2 headers are visible
    const headers = await page.evaluate(() => {
      const avail = document.getElementById('page-availability');
      if (!avail) return [];
      const hdrs = avail.querySelectorAll('h1, h2, h3, button, label');
      return Array.from(hdrs).map(h => ({
        tag: h.tagName,
        text: h.textContent.trim(),
        visible: window.getComputedStyle(h).display !== 'none'
      }));
    });
    console.log('Headers/elements:', JSON.stringify(headers, null, 2));

    // Check weekly grid
    const gridContent = await page.evaluate(() => {
      const grid = document.getElementById('avail-weekly-grid');
      if (!grid) return 'grid not found';
      return `children: ${grid.children.length}, innerHTML length: ${grid.innerHTML.length}, text: ${grid.innerText.substring(0, 200)}`;
    });
    console.log('Weekly grid:', gridContent);

    // Check overrides list
    const overridesContent = await page.evaluate(() => {
      const list = document.getElementById('avail-overrides-list');
      if (!list) return 'list not found';
      return `children: ${list.children.length}, innerHTML length: ${list.innerHTML.length}, text: ${list.innerText.substring(0, 200)}`;
    });
    console.log('Overrides list:', overridesContent);

    console.log('Done!');
  } catch (err) {
    console.error('Error:', err.message);
  }
})();
