const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// The broken onclick uses single-quoted HTML attr with JS that creates bad quotes
// Fix: use HTML double-quoted attr with proper escaping

// Using character codes to avoid quoting issues
const sq = String.fromCharCode(39); // single quote
const dq = String.fromCharCode(34); // double quote

// onclick="openRoleChangeModal(' + u.id + ',' + escHtml(u.name).replace(/'/g,"&apos;") + ',' + u.role + ',' + (!!u.is_instructor ? 'true' : 'false') + ')"
const onclickAttr = "onclick=" + dq + "openRoleChangeModal(" + sq + " + u.id + " + sq + "," + sq + " + escHtml(u.name).replace(/" + sq + "/g," + dq + "&apos;" + dq + ") + " + sq + "," + sq + " + u.role + "," + sq + " + (!!u.is_instructor ? " + sq + "true" + sq + " : " + sq + "false" + sq + ") + " + sq + "))" + dq;

console.log("Replacement:", onclickAttr);

// Find the onclick section
const onclickStart = targetLine.indexOf("onclick='");
const quoteEnd = targetLine.indexOf('">', onclickStart);

if (onclickStart >= 0 && quoteEnd >= 0) {
  console.log("Found onclick at", onclickStart, "ends at", quoteEnd);
  const before = targetLine.substring(0, onclickStart);
  const after = targetLine.substring(quoteEnd + 2);

  const newLine = before + onclickAttr + after;
  console.log("New line preview:", newLine.substring(onclickStart, onclickStart + 200));

  lines[8888] = newLine;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log("File updated!");
} else {
  console.log("Pattern not found, checking alternative...");
  const onclickStart2 = targetLine.indexOf('onclick="');
  console.log("Has double-quoted onclick:", onclickStart2 >= 0);
}