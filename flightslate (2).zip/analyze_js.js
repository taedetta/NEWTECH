const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');

// Split by <script> tags to find the main JS block
const scriptBlocks = content.split('<script>');
console.log('Script block count:', scriptBlocks.length);
for (let i = 0; i < scriptBlocks.length; i++) {
    console.log(`Block ${i}: ${scriptBlocks[i].length} chars, starts: ${scriptBlocks[i].slice(0,50).replace(/\n/g,' ')}`);
}

// The last block is the main app JS
const mainJS = scriptBlocks[scriptBlocks.length - 1];
console.log('\nMain JS length:', mainJS.length);

// Line 8917 in minified bundle corresponds to approximately char position in main JS
// Since the bundle is minified (one long line), "line 8917" means char offset ~8917*estimated_line
// Let's find what's at position around 8917*150 chars (avg 150 chars per line)
const targetPos = 8917 * 150;
console.log('\nAround position', targetPos, ':');
console.log(mainJS.slice(Math.max(0, targetPos - 50), targetPos + 100));

// Also check for obvious syntax issues
// Look for patterns like: var without name, trailing operators, unclosed strings
const lines = mainJS.split('\n');
console.log('\nTotal JS lines:', lines.length);

// Find near line 8917 equivalent in the source (last block)
const jsLines = mainJS.split('\n');
console.log('JS line count:', jsLines.length);

// The bundle line 8917 - let's look at what byte offset that would be
// In a minified file, each "line" is roughly 500 chars (line 8917 = char 8917*500 = ~4.5MB)
// Our app.html JS section is 625487 chars - that's only ~1250 minified lines
// So the bundle must be MUCH larger than our source
// This means the browser is compiling/transpiling the source via some bundler

console.log('\nThe bundle must include other files too. Checking for any bundler config...');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
console.log('Scripts:', JSON.stringify(pkg.scripts));
console.log('Deps:', Object.keys(pkg.dependencies));

// Check if there's a build step or bundler
const buildFiles = ['rollup.config.js', 'webpack.config.js', 'vite.config.js', 'esbuild.config.js', 'tsconfig.json', 'webpack.config.cjs'];
for (const f of buildFiles) {
    if (fs.existsSync(f)) console.log('Found:', f);
}