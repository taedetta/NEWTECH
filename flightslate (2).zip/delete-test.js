const { chromium } = require('playwright');

const CDP_URL = 'wss://connect.anchorbrowser.io/?sessionId=7e2ecb99-a404-4071-878e-b9d1e469b564';
const APP_URL = 'https://new-tech-aviation.polsia.app';

(async () => {
  console.log('Connecting to browser...');
  const browser = await chromium.connect(CDP_URL);
  const page = await browser.newPage();

  // Navigate to login page
  console.log('Navigating to app...');
  await page.goto(`${APP_URL}/app`, { waitUntil: 'networkidle' });

  // Wait for the login form to appear
  console.log('Page title:', await page.title());
  const html = await page.content();
  console.log('HTML preview:', html.substring(0, 500));

  // Check if we need to log in (look for login form)
  if (html.includes('login') || html.includes('signin') || !html.includes('Fleet')) {
    console.log('Need to log in...');
    // The app might have a login form - let's try to find it
    const emailInput = await page.$('input[type="email"], input[name="email"], input[name="username"]');
    const passwordInput = await page.$('input[type="password"]');

    if (emailInput && passwordInput) {
      await emailInput.fill('admin@newtechaviation.com');
      await passwordInput.fill('admin123');
      await page.click('button[type="submit"]');
      await page.waitForTimeout(3000);
      console.log('Logged in');
    }
  }

  // Navigate to Fleet tab
  console.log('Navigating to Fleet tab...');
  await page.goto(`${APP_URL}/app#/fleet`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);

  const fleetHtml = await page.content();
  console.log('Fleet page preview:', fleetHtml.substring(0, 1000));

  await browser.close();
  console.log('Done');
})().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});