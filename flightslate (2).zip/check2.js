const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const lines = content.split('\n');

console.log('=== Checking all patterns ===');
// Find all lines with replace(/'/g patterns
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.includes('replace(/')) {
    const idx = line.indexOf('replace(/');
    const slice = line.substring(idx, idx + 25);
    // Check if it has the broken patterns
    if (slice.includes('&#39;')) {
      console.log('Line ' + (i+1) + ' BROKEN (HTML entity): ' + slice.substring(0, 40));
    } else if (slice.includes("\\'") || slice.includes("'\\'")) {
      console.log('Line ' + (i+1) + ' FIXED (backslash-quote): ' + slice.substring(0, 40));
    } else if (slice.includes('&apos;')) {
      console.log('Line ' + (i+1) + ' BROKEN (&apos;): ' + slice.substring(0, 40));
    } else if (slice.includes("'\\\\\\''")) {
      console.log('Line ' + (i+1) + ' BROKEN (double backslash): ' + slice.substring(0, 40));
    } else {
      console.log('Line ' + (i+1) + ' OTHER: ' + slice.substring(0, 40));
    }
  }
}