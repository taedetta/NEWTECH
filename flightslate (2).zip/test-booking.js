const { chromium } = require('playwright');

async function test() {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=b56d3339-cea9-4c61-937f-92e4f71194ee');
  const page = await browser.newPage();
  
  // Go to the app
  await page.goto('https://www.newtechaviation.com/app', { waitUntil: 'networkidle', timeout: 30000 });
  
  // Check if we need to log in
  const url = page.url();
  console.log('Current URL:', url);
  
  // Try to log in
  const emailInput = await page.$('input[type="email"], input[name="email"]');
  if (emailInput) {
    console.log('Login page detected, logging in...');
    await page.fill('input[type="email"], input[name="email"]', 'blankthe97@gmail.com');
    await page.fill('input[type="password"]', 'Password123\!');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(3000);
    console.log('After login URL:', page.url());
  } else {
    console.log('Already logged in');
  }
  
  // Look for the booking button
  const links = await page.$$('a, button');
  for (const link of links) {
    const text = await link.textContent();
    if (text && text.trim().toLowerCase().includes('book')) {
      console.log('Found booking element:', text.trim());
      await link.click();
      await page.waitForTimeout(2000);
      break;
    }
  }
  
  // Check the start time dropdown
  const startSelect = await page.$('#booking-start');
  if (startSelect) {
    console.log('Found start time dropdown');
    const options = await startSelect.$$('option');
    console.log('Start time options count:', options.length);
    
    // Try to find 21:30 (9:30pm)
    const optionTexts = [];
    for (const opt of options) {
      const val = await opt.getAttribute('value');
      const txt = await opt.textContent();
      optionTexts.push({ val, txt });
    }
    console.log('All start options:', JSON.stringify(optionTexts));
    
    // Select 21:30
    await startSelect.selectOption('21:30');
    await page.waitForTimeout(1000);
    
    // Now check the end time dropdown
    const endSelect = await page.$('#booking-end');
    if (endSelect) {
      console.log('Found end time dropdown');
      const endOptions = await endSelect.$$('option');
      console.log('End time options count:', endOptions.length);
      
      const endOptionTexts = [];
      for (const opt of endOptions) {
        const val = await opt.getAttribute('value');
        const txt = await opt.textContent();
        endOptionTexts.push({ val, txt });
      }
      console.log('End options after selecting 21:30 start:', JSON.stringify(endOptionTexts));
      
      // Check if disabled
      const disabled = await endSelect.getAttribute('disabled');
      console.log('End dropdown disabled:', disabled);
    } else {
      console.log('No end time dropdown found');
    }
  } else {
    console.log('No start time dropdown found - maybe modal is not open');
    // Try to click on something to open booking
    const bookButtons = await page.$$('button');
    for (const btn of bookButtons) {
      const txt = await btn.textContent();
      if (txt && txt.toLowerCase().includes('flight')) {
        console.log('Clicking flight button:', txt);
        await btn.click();
        await page.waitForTimeout(2000);
        break;
      }
    }
    
    // Try again
    const start2 = await page.$('#booking-start');
    if (start2) {
      console.log('Modal now open, testing...');
      await start2.selectOption('21:30');
      await page.waitForTimeout(1000);
      const end2 = await page.$('#booking-end');
      if (end2) {
        const endOpts = await end2.$$('option');
        console.log('End options count:', endOpts.length);
        for (const opt of endOpts) {
          const val = await opt.getAttribute('value');
          const txt = await opt.textContent();
          console.log('  End option:', val, txt);
        }
      }
    }
  }
  
  // Take screenshot
  await page.screenshot({ path: 'test-result.png' });
  console.log('Screenshot saved to test-result.png');
  
  await browser.close();
  console.log('Test complete');
}

test().catch(e => console.error('Error:', e.message));
