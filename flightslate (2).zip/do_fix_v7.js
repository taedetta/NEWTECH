const fs = require('fs');
let html = fs.readFileSync('./public/app.html', 'utf8');
const lines = html.split('\n');
const targetLine = lines[8888];

// Find the .replace section using a regex-like approach
// Search for the pattern: .replace(/'/g,"...")
// We need to find the literal string in the file
const searchPattern = ".replace(/'/g";
const replaceIdx = targetLine.indexOf(searchPattern);

if (replaceIdx >= 0) {
  console.log('Found replace at position:', replaceIdx);

  // Find the closing )")" after the pattern
  // The pattern is: .replace(/'/g,"\\'") or now .replace(/'/g,"&apos;")
  // We need to find the section from replaceIdx to the closing "

  // Look for the pattern: replace(/'/g,"..."")  where "..." contains the replacement
  // In the file, after /'/g," we have the replacement string, then ")
  const afterReplace = targetLine.substring(replaceIdx);
  const closeQuoteIdx = afterReplace.indexOf('")');
  const sectionEnd = replaceIdx + closeQuoteIdx + 2;
  const currentSection = targetLine.substring(replaceIdx, sectionEnd);

  console.log('Current section:', JSON.stringify(currentSection));

  // Fix: change to use &apos; in the replacement
  const fixedSection = '.replace(/'/g,"&apos;")';
  console.log('Fixed section:', JSON.stringify(fixedSection));

  const newLine = targetLine.substring(0, replaceIdx) + fixedSection + targetLine.substring(sectionEnd);

  // Also fix the extra empty strings
  let f = newLine;
  f = f.split("onclick='openRoleChangeModal(' + u.id + ','' +").join("onclick='openRoleChangeModal(' + u.id + ',' +");
  f = f.split("+ '','' + u.role").join("+ ',' + u.role");
  f = f.split("+ '', ' +").join("+ ',' + ' +");

  const idx = f.indexOf('onclick');
  console.log('After fix, onclick:', JSON.stringify(f.substring(idx, idx + 200)));

  lines[8888] = f;
  fs.writeFileSync('./public/app.html', lines.join('\n'));
  console.log('File updated!');
} else {
  console.log('Pattern not found');
}