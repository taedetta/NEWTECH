const https = require('https');

function fetchPage(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

async function main() {
  try {
    const html = await fetchPage('https://www.newtechaviation.com/app');
    console.log('Page fetched, length:', html.length);

    // Check for auth modal
    const hasAuthModal = html.includes('id="auth-modal"');
    console.log('Has auth modal:', hasAuthModal);

    // Check for auth modal display:none
    const authModalHidden = html.includes('id="auth-modal" style="display:none"');
    console.log('Auth modal has display:none:', authModalHidden);

    // Check for auth modal classes
    const authModalClass = html.match(/id="auth-modal"[^>]*class="([^"]*)"/);
    console.log('Auth modal class:', authModalClass ? authModalClass[1] : 'not found');

    // Check for app-screen hidden
    const appScreenHidden = html.includes('id="app-screen" class="hidden"');
    console.log('App screen has class="hidden":', appScreenHidden);

    // Check for init() call
    const hasInit = html.includes('init()');
    console.log('Has init() call:', hasInit);

    // Check for openAuthModal function
    const hasOpenAuthModal = html.includes('function openAuthModal');
    console.log('Has openAuthModal function:', hasOpenAuthModal);

    // Check for auth modal inner content
    const hasAuthPanelSignin = html.includes('id="auth-panel-signin"');
    console.log('Has auth-panel-signin:', hasAuthPanelSignin);

    // Check for version comment
    const versionMatch = html.match(/v(\/\/|<!--\u0020)([0-9.]+)/);
    console.log('Version:', versionMatch ? versionMatch[2] : 'not found');

    // Check for body background
    const bodyBgMatch = html.match(/body.*background:\u0020*([^;]+)/);
    console.log('Body bg:', bodyBgMatch ? bodyBgMatch[1] : 'not found');

    // Check for auth modal CSS
    const hasAuthModalCSS = html.includes('.auth-modal-overlay');
    console.log('Has auth-modal-overlay CSS:', hasAuthModalCSS);

    // Check what the first visible element on page load would be
    const firstElements = html.substring(html.indexOf('<body>'), html.indexOf('<body>') + 2000);
    console.log('\nFirst 2000 chars of body:');
    console.log(firstElements);

  } catch (e) {
    console.error('Error:', e.message);
  }
}

main();