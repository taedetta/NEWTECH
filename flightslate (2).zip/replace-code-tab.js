const fs = require('fs');
const file = 'public/app.html';
let content = fs.readFileSync(file, 'utf8');

// Find the exact occurrence in the HTML (after CSS section)
const searchFrom = 100000;
const startTag = 'class=\u0022editor-code-toolbar\u0022>';
const startIdx = content.indexOf(startTag, searchFrom);
if (startIdx === -1) {
  console.error('Could not find editor-code-toolbar HTML element');
  process.exit(1);
}

// The opening div starts 5 chars before (the < character)
const divStart = startIdx - 5;

// Now find the closing </div> that ends editor-code-panel
// It's the </div> with 12 spaces that comes after the textarea
const afterTextarea = startIdx + 500;
const closePattern = '            </div>';
const closeIdx = content.indexOf(closePattern, afterTextarea);
if (closeIdx === -1) {
  console.error('Could not find closing </div>');
  process.exit(1);
}

// The closing </div> ends at closeIdx + closePattern.length
const endIdx = closeIdx + closePattern.length;

// Extract the exact old string
const oldStr = content.substring(divStart, endIdx);

console.log('OLD STRING LENGTH:', oldStr.length);
console.log('OLD STRING (first 200 chars):');
console.log(JSON.stringify(oldStr.substring(0, 200)));

// Now define the new string
const newStr = `<!-- Mode switcher -->
              <div class=&quot;code-mode-switcher&quot;>
                <button class=&quot;code-mode-btn active&quot; id=&quot;code-mode-json-btn&quot; onclick=&quot;switchCodeMode('json')&quot;>&#123; JSON Content</button>
                <button class=&quot;code-mode-btn&quot; id=&quot;code-mode-files-btn&quot; onclick=&quot;switchCodeMode('files')&quot;>&#128196; Project Files</button>
              </div>
              <!-- JSON Content Mode -->
              <div class=&quot;code-json-panel&quot; id=&quot;code-json-panel&quot;>
                <div class=&quot;editor-code-toolbar&quot;>
                  <button class=&quot;btn btn-secondary btn-sm&quot; onclick=&quot;formatCodeTab()&quot;>&#9998; Format JSON</button>
                  <button class=&quot;btn btn-secondary btn-sm&quot; onclick=&quot;validateCodeTab()&quot;>&#10003; Validate</button>
                  <button class=&quot;btn btn-primary btn-sm&quot; onclick=&quot;saveFromCodeTab()&quot;>&#10003; Save &amp; Publish</button>
                  <span class=&quot;ec-hint&quot;>Edit raw site content as JSON. Save writes directly to the database.</span>
                </div>
                <div class=&quot;editor-code-error&quot; id=&quot;editor-code-error&quot;></div>
                <textarea class=&quot;editor-code-textarea&quot; id=&quot;editor-code-textarea&quot; spellcheck=&quot;false&quot; placeholder=&quot;Loading JSON...&quot;></textarea>
              </div>
              <!-- Project Files Mode -->
              <div class=&quot;code-files-panel&quot; id=&quot;code-files-panel&quot;>
                <div id=&quot;code-file-tree&quot; class=&quot;file-tree&quot;>
                  <div class=&quot;code-empty-state&quot;>
                    <div class=&quot;ces-icon&quot;>&#128196;</div>
                    <p>Loading project files…</p>
                  </div>
                </div>
                <div id=&quot;code-file-editor&quot; class=&quot;code-editor-panel&quot; style=&quot;display:none&quot;>
                  <div class=&quot;code-editor-header&quot;>
                    <div style=&quot;display:flex;align-items:center;gap:0.6rem&quot;>
                      <span class=&quot;code-editor-filename&quot; id=&quot;code-filename&quot;></span>
                      <span class=&quot;code-editor-lang&quot; id=&quot;code-lang&quot;></span>
                    </div>
                    <span id=&quot;code-file-size&quot; style=&quot;font-size:0.7rem;color:#858585&quot;></span>
                  </div>
                  <div class=&quot;code-editor-body&quot; id=&quot;code-editor-body&quot;>
                    <div class=&quot;code-empty-state&quot;>
                      <div class=&quot;ces-icon&quot;>&#128269;</div>
                      <p>Select a file to view and edit its code</p>
                    </div>
                  </div>
                  <div class=&quot;code-editor-status&quot;>
                    <span class=&quot;code-status-msg&quot; id=&quot;code-status-msg&quot;></span>
                    <div class=&quot;code-editor-actions&quot;>
                      <button class=&quot;btn btn-secondary btn-sm&quot; onclick=&quot;copyCodeContent()&quot;>&#10002; Copy</button>
                      <button class=&quot;btn btn-primary btn-sm&quot; id=&quot;code-save-btn&quot; onclick=&quot;saveProjectFile()&quot;>&#10003; Save File</button>
                    </div>
                  </div>
                </div>
                <div id=&quot;code-file-empty&quot; class=&quot;code-empty-state&quot; style=&quot;display:none&quot;>
                  <div class=&quot;ces-icon&quot;>&#128269;</div>
                  <p>Select a file from the tree to view and edit it</p>
                </div>
              </div>`;

// Verify exact match
if (content.indexOf(oldStr) === -1) {
  console.error('ERROR: extracted oldStr not found in file');
  process.exit(1);
}

console.log('OLD STRING FOUND at index:', content.indexOf(oldStr));
content = content.replace(oldStr, newStr);
fs.writeFileSync(file, content);
console.log('SUCCESS: Code tab HTML replaced');
console.log('File is now', fs.readFileSync(file, 'utf8').split('\n').length, 'lines');