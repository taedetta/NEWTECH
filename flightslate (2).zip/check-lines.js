const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');
const idx = content.indexOf('editor-code-toolbar');
console.log('First occurrence at index:', idx);
const chunk = content.substring(idx, idx + 600);
console.log('Content around first occurrence:');
console.log(JSON.stringify(chunk));
console.log('\n--- Checking what the Code tab inner content looks like ---');
// Find the Code tab section
const codeTabStart = content.indexOf('<div class=\u0022editor-code-toolbar\u0022>', 40000);
console.log('editor-code-toolbar opening tag at:', codeTabStart);
if (codeTabStart !== -1) {
  const section = content.substring(codeTabStart, codeTabStart + 500);
  console.log(JSON.stringify(section));
}