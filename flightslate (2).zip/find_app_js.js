const fs = require('fs');
const content = fs.readFileSync('public/app.html', 'utf8');

// Find lines with app.js
const lines = content.split('\n');
for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('app.js')) {
        console.log('Line', i+1, ':', lines[i]);
    }
}

// Find lines with dynamic script injection
for (let i = 0; i < lines.length; i++) {
    if (lines[i].toLowerCase().includes('script') && lines[i].toLowerCase().includes('src')) {
        console.log('Script src at line', i+1, ':', lines[i].slice(0,200));
    }
}

// Find any fetch/XHR calls to app.js
for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('app.js') || lines[i].includes("'app.js'") || lines[i].includes('"app.js"')) {
        console.log('app.js ref at line', i+1, ':', lines[i].slice(0,200));
    }
}