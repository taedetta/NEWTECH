const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.connectOverCDP('wss://connect.anchorbrowser.io/?sessionId=e726c49c-3342-4341-8775-d8a39598d928');
  const page = await browser.newPage();
  await page.setViewportSize({ width: 1280, height: 720 });
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
    if (msg.type() === 'log') console.log('LOG:', msg.text());
  });
  page.on('pageerror', err => errors.push('PAGE ERROR: ' + err.message));

  await page.goto('https://www.newtechaviation.com/app', { waitUntil: 'networkidle', timeout: 20000 });
  await page.waitForTimeout(2000);

  // Get auth modal state
  const authModalState = await page.evaluate(() => {
    const modal = document.getElementById('auth-modal');
    if (!modal) return { error: 'auth-modal not found' };
    const computed = window.getComputedStyle(modal);
    return {
      display: modal.style.display,
      computedDisplay: computed.display,
      visibility: computed.visibility,
      opacity: computed.opacity,
      zIndex: computed.zIndex,
      backgroundColor: computed.backgroundColor,
      children: modal.children.length,
      innerModal: modal.querySelector('.auth-modal') ? 'found' : 'not found',
      signinPanel: document.getElementById('auth-panel-signin') ? 'found' : 'not found',
    };
  });
  console.log('Auth modal state:', JSON.stringify(authModalState, null, 2));

  // Get app screen state
  const appScreenState = await page.evaluate(() => {
    const screen = document.getElementById('app-screen');
    if (!screen) return { error: 'app-screen not found' };
    const computed = window.getComputedStyle(screen);
    return {
      display: screen.style.display,
      computedDisplay: computed.display,
      classList: Array.from(screen.classList),
      visibility: computed.visibility,
    };
  });
  console.log('App screen state:', JSON.stringify(appScreenState, null, 2));

  // Check body state
  const bodyState = await page.evaluate(() => {
    const body = document.body;
    return {
      bodyBg: window.getComputedStyle(body).backgroundColor,
      bodyMinHeight: window.getComputedStyle(body).minHeight,
      childCount: body.children.length,
      firstChildTag: body.children[0] ? body.children[0].tagName : 'none',
      firstChildId: body.children[0] ? body.children[0].id : 'none',
    };
  });
  console.log('Body state:', JSON.stringify(bodyState, null, 2));

  // Check if init() was called by looking for currentUser
  const jsState = await page.evaluate(() => {
    return {
      currentUserDefined: typeof currentUser !== 'undefined',
      currentUser: typeof currentUser !== 'undefined' ? currentUser : 'undefined',
      tokenDefined: typeof token !== 'undefined',
      token: typeof token !== 'undefined' ? token : 'undefined',
    };
  });
  console.log('JS state:', JSON.stringify(jsState, null, 2));

  // Take screenshot
  await page.screenshot({ path: 'screenshot2.png', fullPage: true });
  console.log('Screenshot saved: screenshot2.png');

  console.log('Console errors:', errors.length ? errors : 'NONE');
  await browser.close();
})().catch(e => console.error('Error:', e.message));